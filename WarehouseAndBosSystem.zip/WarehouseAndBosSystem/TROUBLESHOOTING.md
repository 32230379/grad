# Troubleshooting Guide

## Common Issues & Solutions

### 1. Database Connection Errors

#### Error: "Connection failed: Access denied for user 'root'@'localhost'"

**Cause:** Wrong database credentials in `config.php`

**Solution:**
1. Open `config.php`
2. Verify these settings:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');  // Empty if no password
   define('DB_NAME', 'branch_system');
   ```
3. Test MySQL connection:
   ```bash
   mysql -u root -p
   ```

---

### 2. Table Not Found Errors

#### Error: "Table 'branch_system.branches' doesn't exist"

**Cause:** Database tables not created

**Solution:**
1. Run setup wizard: `http://localhost/warehouse+bos%20system/setup_rbac.php`
2. Click "Start Setup"
3. Wait for all tables to be created

---

#### Error: "Unknown column 'category_id' in 'field list'"

**Cause:** Products table exists but is missing the `category_id` column

**Solution:**
1. Run setup wizard again (it will add missing columns)
2. Or manually add the column:
   ```sql
   ALTER TABLE products ADD COLUMN category_id INT AFTER description;
   ```

---

### 3. Login Issues

#### Error: "Invalid username or password"

**Cause:** Wrong credentials or user doesn't exist

**Solution:**
1. Verify you're using correct default credentials:
   - Username: `admin`, `manager`, or `cashier`
   - Password: `admin123`
2. Verify user exists in database:
   ```sql
   SELECT * FROM users WHERE username = 'admin';
   ```
3. Check if user is active:
   ```sql
   SELECT * FROM users WHERE is_active = 1;
   ```

---

#### Error: "Access denied" after login

**Cause:** User role doesn't match page requirements

**Solution:**
1. Check user role in database:
   ```sql
   SELECT username, role, is_admin FROM users WHERE username = 'admin';
   ```
2. Verify role is correct:
   - Admin should have `is_admin = 1`
   - Manager should have `role = 'manager'`
   - Cashier should have `role = 'cashier'`

---

### 4. Setup Wizard Issues

#### Error: "Unknown column 'category_id' in 'field list'" during setup

**Cause:** Products table exists but is incomplete

**Solution:**
1. Drop and recreate the products table:
   ```sql
   DROP TABLE IF EXISTS products;
   ```
2. Run setup wizard again

---

#### Setup wizard shows "already initialized"

**Cause:** Setup has already been run

**Solution:**
1. If you need to reset, delete all tables:
   ```sql
   DROP DATABASE branch_system;
   CREATE DATABASE branch_system;
   ```
2. Run setup wizard again

---

### 5. Login Redirect Issues

#### Admin redirects to wrong page

**Cause:** User doesn't have `is_admin = 1` flag

**Solution:**
1. Check user in database:
   ```sql
   SELECT * FROM users WHERE username = 'admin';
   ```
2. Update if needed:
   ```sql
   UPDATE users SET is_admin = 1 WHERE username = 'admin';
   ```

---

#### Manager/Cashier can't access their pages

**Cause:** User role not set correctly

**Solution:**
1. Verify role in database:
   ```sql
   SELECT username, role FROM users;
   ```
2. Update if needed:
   ```sql
   UPDATE users SET role = 'manager' WHERE username = 'manager';
   UPDATE users SET role = 'cashier' WHERE username = 'cashier';
   ```

---

### 6. Permission Issues

#### Error: "Admin access required"

**Cause:** User is not admin

**Solution:**
1. Make user admin:
   ```sql
   UPDATE users SET is_admin = 1, role = 'admin' WHERE username = 'newadmin';
   ```

---

#### Error: "Manager access required"

**Cause:** User is not manager

**Solution:**
1. Change user role:
   ```sql
   UPDATE users SET role = 'manager' WHERE username = 'username';
   ```

---

### 7. BOS (Cashier) Issues

#### Cashier can't access BOS

**Cause:** User role is not 'cashier'

**Solution:**
1. Verify role:
   ```sql
   SELECT * FROM users WHERE username = 'cashier';
   ```
2. Update if needed:
   ```sql
   UPDATE users SET role = 'cashier' WHERE username = 'cashier';
   ```

---

#### Inventory not showing products

**Cause:** No products in branch inventory

**Solution:**
1. Add products to inventory:
   ```sql
   INSERT INTO branch_inventory (branch_id, product_id, quantity, selling_price) 
   VALUES (1, 1, 100, 1000);
   ```

---

### 8. Admin Panel Issues

#### Can't create users

**Cause:** User is not admin

**Solution:**
1. Login as admin user
2. Verify you have admin role:
   ```sql
   SELECT * FROM users WHERE username = 'admin';
   ```

---

#### User creation fails silently

**Cause:** Username already exists

**Solution:**
1. Use a unique username
2. Or delete existing user:
   ```sql
   DELETE FROM users WHERE username = 'duplicate_username';
   ```

---

### 9. Session Issues

#### Session expires too quickly

**Cause:** Session timeout is set to 1 hour

**Solution:**
1. Change timeout in `config.php`:
   ```php
   define('SESSION_TIMEOUT', 7200); // 2 hours
   ```

---

#### Logged out unexpectedly

**Cause:** Session was destroyed or expired

**Solution:**
1. Login again
2. Check browser cookies are enabled
3. Check session directory has write permissions

---

### 10. Database Issues

#### Can't connect to MySQL

**Cause:** MySQL service not running

**Solution:**
1. Start MySQL:
   ```bash
   # Windows
   net start MySQL80
   
   # Or use XAMPP control panel
   ```

---

#### Database is locked

**Cause:** Another process is using the database

**Solution:**
1. Restart MySQL
2. Check for stuck processes:
   ```sql
   SHOW PROCESSLIST;
   KILL process_id;
   ```

---

### 11. File Permission Issues

#### Error: "Permission denied"

**Cause:** File permissions are incorrect

**Solution:**
1. Check file permissions
2. Make files readable:
   ```bash
   chmod 644 *.php
   chmod 755 */
   ```

---

### 12. PHP Errors

#### Error: "Undefined variable"

**Cause:** Variable not initialized

**Solution:**
1. Check if variable is set before using:
   ```php
   if (isset($_SESSION['user_id'])) {
       // Use variable
   }
   ```

---

#### Error: "Call to undefined function"

**Cause:** Function not included

**Solution:**
1. Check if file is included:
   ```php
   require_once 'functions.php';
   ```

---

## Quick Diagnostic Checklist

- [ ] MySQL is running
- [ ] Database `branch_system` exists
- [ ] All tables are created
- [ ] Default users exist
- [ ] User roles are correct
- [ ] User is_admin flag is correct
- [ ] Session is working
- [ ] Cookies are enabled
- [ ] File permissions are correct
- [ ] config.php has correct credentials

## Database Verification Commands

```sql
-- Check if database exists
SHOW DATABASES;

-- Check all tables
USE branch_system;
SHOW TABLES;

-- Check users
SELECT * FROM users;

-- Check roles
SELECT * FROM roles;

-- Check permissions
SELECT * FROM permissions;

-- Check user roles
SELECT u.username, u.role, u.is_admin FROM users u;

-- Check audit logs
SELECT * FROM user_audit_log ORDER BY created_at DESC LIMIT 10;
```

## Reset Everything

If you need to start fresh:

```sql
-- Drop database
DROP DATABASE IF EXISTS branch_system;

-- Create new database
CREATE DATABASE branch_system;
USE branch_system;
```

Then run the setup wizard again.

## Getting Help

1. Check this troubleshooting guide
2. Review error messages carefully
3. Check database with SQL commands above
4. Review setup wizard output
5. Check browser console for JavaScript errors
6. Check PHP error logs

## Common Error Messages

| Error | Cause | Solution |
|-------|-------|----------|
| Table doesn't exist | Tables not created | Run setup wizard |
| Unknown column | Missing column | Run setup wizard |
| Access denied | Wrong credentials | Check config.php |
| Invalid username or password | Wrong credentials | Check default users |
| Access denied (page) | Wrong role | Check user role in DB |
| Connection failed | MySQL not running | Start MySQL |
| Permission denied | File permissions | Fix permissions |
| Session expired | Timeout | Login again |

---

**Last Updated**: 2024
**Version**: 1.0
