<?php
// Admin Navbar Component
// Include this file at the top of each admin page after requireLogin() and requireAdmin()

$current_page = basename($_SERVER['PHP_SELF']);
?>
<div style="background: white; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); padding: 15px 20px; margin-bottom: 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
        <a href="/WarehouseAndBosSystem/admin/dashboard.php" class="btn" style="background: <?php echo $current_page === 'dashboard.php' ? '#667eea' : '#95a5a6'; ?>; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📊 Dashboard</a>
        
        <a href="/WarehouseAndBosSystem/bos/reports.php" class="btn" style="background: <?php echo $current_page === 'reports.php' ? '#667eea' : '#95a5a6'; ?>; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📈 Reports</a>
        
        <a href="/WarehouseAndBosSystem/bos/shelf_management.php" class="btn" style="background: <?php echo $current_page === 'shelf_management.php' ? '#667eea' : '#f39c12'; ?>; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📦 Shelf Management</a>
    </div>
    
    <div style="display: flex; gap: 10px; align-items: center;">
        <a href="/WarehouseAndBosSystem/admin/audit_logs.php" class="btn" style="background: <?php echo $current_page === 'audit_logs.php' ? '#667eea' : '#95a5a6'; ?>; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📋 Audit Logs</a>
        
        <a href="/WarehouseAndBosSystem/admin/manage_permissions.php" class="btn" style="background: <?php echo $current_page === 'manage_permissions.php' ? '#667eea' : '#95a5a6'; ?>; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">🔑 Permissions</a>
        
        <a href="/WarehouseAndBosSystem/dashboard/order_request.php" class="btn" style="background: #2ecc71; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📋 Stock Order</a>
        
        <a href="/WarehouseAndBosSystem/dashboard/order_history.php" class="btn" style="background: #3498db; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📦 Order History</a>
        
        <a href="/WarehouseAndBosSystem/bos/inventory.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📦 Inventory</a>
        
        <a href="/WarehouseAndBosSystem/bos/reports.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📈 Reports</a>
    </div>
    
    <div style="display: flex; gap: 10px; align-items: center;">
        <div style="display: flex; align-items: center; gap: 10px; padding: 0 15px; border-right: 1px solid #eee;">
            <div>
                <strong style="color: #333;"><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong><br>
                <small style="color: #999;">Admin</small>
            </div>
        </div>
        <a href="/WarehouseAndBosSystem/logout.php" class="btn" style="background: #e74c3c; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">🚪 Logout</a>
    </div>
</div>
