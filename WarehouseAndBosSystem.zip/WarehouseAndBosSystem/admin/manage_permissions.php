<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireAdmin();

$user = getUserInfo();
$message = '';
$error = '';

// Handle permission updates
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_permissions') {
    $role_id = (int)$_POST['role_id'];
    $permissions = isset($_POST['permissions']) ? $_POST['permissions'] : [];
    
    // Validate role exists
    $role_check = mysqli_query($conn, "SELECT role_name FROM roles WHERE role_id = $role_id");
    if (mysqli_num_rows($role_check) == 0) {
        $error = 'Invalid role selected';
    } else {
        $role_data = mysqli_fetch_assoc($role_check);
        $role_name = $role_data['role_name'];
        
        // Prevent modifying admin role permissions
        if ($role_name === 'admin') {
            $error = 'Cannot modify admin role permissions';
        } else {
            // Delete existing permissions for this role
            $delete_query = "DELETE FROM role_permissions WHERE role_id = $role_id";
            if (mysqli_query($conn, $delete_query)) {
                // Insert new permissions
                $inserted = 0;
                foreach ($permissions as $permission_id) {
                    $permission_id = (int)$permission_id;
                    $insert_query = "INSERT INTO role_permissions (role_id, permission_id) VALUES ($role_id, $permission_id)";
                    if (mysqli_query($conn, $insert_query)) {
                        $inserted++;
                    }
                }
                
                // Log the action
                auditLog($_SESSION['user_id'], 'UPDATE_PERMISSIONS', 
                        "Updated permissions for role: $role_name. Assigned $inserted permissions", 
                        null, ['role_id' => $role_id, 'permissions_count' => $inserted]);
                
                $message = "Permissions updated successfully for $role_name! ($inserted permissions assigned)";
            } else {
                $error = 'Error updating permissions: ' . $conn->error;
            }
        }
    }
}

// Get all roles
$roles_query = "SELECT * FROM roles WHERE is_active = 1 ORDER BY role_name";
$roles_result = mysqli_query($conn, $roles_query);

// Get all permissions grouped by module
$permissions_query = "SELECT * FROM permissions ORDER BY module, permission_name";
$permissions_result = mysqli_query($conn, $permissions_query);

$permissions_by_module = [];
while ($perm = mysqli_fetch_assoc($permissions_result)) {
    $module = $perm['module'] ?? 'general';
    if (!isset($permissions_by_module[$module])) {
        $permissions_by_module[$module] = [];
    }
    $permissions_by_module[$module][] = $perm;
}

// Get current role permissions for display
$current_role_permissions = [];
if (isset($_GET['role_id'])) {
    $role_id = (int)$_GET['role_id'];
    $perm_query = "SELECT permission_id FROM role_permissions WHERE role_id = $role_id";
    $perm_result = mysqli_query($conn, $perm_query);
    while ($row = mysqli_fetch_assoc($perm_result)) {
        $current_role_permissions[] = $row['permission_id'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Permissions - Admin Panel</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .navbar {
            background: white;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-left {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .navbar-right {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .btn {
            display: inline-block;
            padding: 10px 16px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn:hover {
            background: #5568d3;
        }

        .btn-secondary {
            background: #95a5a6;
        }

        .btn-secondary:hover {
            background: #7f8c8d;
        }

        .btn-danger {
            background: #e74c3c;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0 15px;
            border-right: 1px solid #eee;
        }

        .user-info strong {
            color: #333;
        }

        .user-info small {
            color: #999;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 32px;
            margin-bottom: 5px;
        }

        .header p {
            font-size: 16px;
            opacity: 0.9;
        }

        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }

        .card h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }

        .role-selector {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }

        .role-card {
            background: white;
            border: 2px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
        }

        .role-card:hover {
            border-color: #667eea;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.2);
        }

        .role-card.active {
            border-color: #667eea;
            background: #f0f4ff;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }

        .role-card h3 {
            font-size: 18px;
            color: #333;
            margin-bottom: 5px;
        }

        .role-card p {
            font-size: 12px;
            color: #666;
        }

        .permissions-grid {
            display: none;
        }

        .permissions-grid.active {
            display: block;
        }

        .module-section {
            margin-bottom: 30px;
        }

        .module-title {
            background: #f9f9f9;
            padding: 12px 15px;
            border-left: 4px solid #667eea;
            margin-bottom: 15px;
            border-radius: 4px;
            font-weight: 600;
            color: #333;
            text-transform: uppercase;
            font-size: 12px;
        }

        .permissions-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .permission-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 12px;
            background: #f9f9f9;
            border-radius: 6px;
            border: 1px solid #eee;
        }

        .permission-item input[type="checkbox"] {
            margin-top: 3px;
            cursor: pointer;
            width: 18px;
            height: 18px;
        }

        .permission-info {
            flex: 1;
        }

        .permission-name {
            font-weight: 600;
            color: #333;
            margin-bottom: 3px;
        }

        .permission-desc {
            font-size: 12px;
            color: #666;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .btn-save {
            background: #2ecc71;
            flex: 1;
        }

        .btn-save:hover {
            background: #27ae60;
        }

        .btn-cancel {
            background: #95a5a6;
            flex: 1;
        }

        .btn-cancel:hover {
            background: #7f8c8d;
        }

        .info-box {
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            color: #0c5460;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .info-box strong {
            display: block;
            margin-bottom: 5px;
        }

        .no-data {
            text-align: center;
            padding: 40px;
            color: #999;
        }

        .select-role-prompt {
            text-align: center;
            padding: 40px;
            color: #666;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <?php include 'navbar.php'; ?>

        <div class="header">
            <h1>🔑 Manage Permissions</h1>
            <p>Configure role-based access control and assign permissions to user roles.</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success">✓ <?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error">✗ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="info-box">
            <strong>ℹ️ How to Use</strong>
            Select a role from below, then check or uncheck permissions to assign them. Click "Save Permissions" to apply changes. 
            Note: Admin role permissions cannot be modified.
        </div>

        <!-- Role Selector -->
        <div class="card">
            <h2>Select Role</h2>
            <div class="role-selector">
                <?php while ($role = mysqli_fetch_assoc($roles_result)): ?>
                    <div class="role-card <?php echo (isset($_GET['role_id']) && $_GET['role_id'] == $role['role_id']) ? 'active' : ''; ?>" 
                         onclick="selectRole(<?php echo $role['role_id']; ?>)">
                        <h3><?php echo ucfirst($role['role_name']); ?></h3>
                        <p><?php echo htmlspecialchars($role['description']); ?></p>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>

        <!-- Permissions Management -->
        <?php if (isset($_GET['role_id'])): 
            $role_id = (int)$_GET['role_id'];
            $role_query = mysqli_query($conn, "SELECT * FROM roles WHERE role_id = $role_id");
            $role = mysqli_fetch_assoc($role_query);
            $is_admin_role = ($role['role_name'] === 'admin');
        ?>
            <div class="card">
                <h2>Permissions for <?php echo ucfirst($role['role_name']); ?></h2>
                
                <?php if ($is_admin_role): ?>
                    <div class="info-box">
                        <strong>⚠️ Admin Role</strong>
                        The admin role has full access to all permissions and cannot be modified.
                    </div>
                    <div class="permissions-list">
                        <?php 
                        // Show all permissions as read-only for admin
                        foreach ($permissions_by_module as $module => $perms): 
                        ?>
                            <div class="module-section">
                                <div class="module-title"><?php echo ucfirst($module); ?></div>
                                <?php foreach ($perms as $perm): ?>
                                    <div class="permission-item">
                                        <input type="checkbox" checked disabled>
                                        <div class="permission-info">
                                            <div class="permission-name"><?php echo htmlspecialchars($perm['permission_name']); ?></div>
                                            <div class="permission-desc"><?php echo htmlspecialchars($perm['description']); ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="update_permissions">
                        <input type="hidden" name="role_id" value="<?php echo $role_id; ?>">
                        
                        <?php foreach ($permissions_by_module as $module => $perms): ?>
                            <div class="module-section">
                                <div class="module-title"><?php echo ucfirst($module); ?></div>
                                <div class="permissions-list">
                                    <?php foreach ($perms as $perm): ?>
                                        <div class="permission-item">
                                            <input type="checkbox" name="permissions[]" value="<?php echo $perm['permission_id']; ?>"
                                                   <?php echo in_array($perm['permission_id'], $current_role_permissions) ? 'checked' : ''; ?>>
                                            <div class="permission-info">
                                                <div class="permission-name"><?php echo htmlspecialchars($perm['permission_name']); ?></div>
                                                <div class="permission-desc"><?php echo htmlspecialchars($perm['description']); ?></div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-save">💾 Save Permissions</button>
                            <a href="manage_permissions.php" class="btn btn-cancel" style="text-align: center; text-decoration: none;">❌ Cancel</a>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="select-role-prompt">
                    👆 Select a role above to manage its permissions
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function selectRole(roleId) {
            window.location.href = '?role_id=' + roleId;
        }
    </script>
</body>
</html>
