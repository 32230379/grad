<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireAdmin();

// Get audit logs with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Get total count
$count_query = "SELECT COUNT(*) as total FROM user_audit_log";
$count_result = mysqli_query($conn, $count_query);
$total_records = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_records / $per_page);

// Get audit logs
$logs_query = "SELECT al.*, u.username, u.full_name 
               FROM user_audit_log al 
               LEFT JOIN users u ON al.user_id = u.user_id 
               ORDER BY al.created_at DESC 
               LIMIT $offset, $per_page";
$logs_result = mysqli_query($conn, $logs_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Logs - Admin Panel</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .header h1 {
            font-size: 28px;
            color: #333;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-badge {
            background: #667eea;
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }

        .btn-logout {
            background: #e74c3c;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s;
        }

        .btn-logout:hover {
            background: #c0392b;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }

        .card h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }

        .filters {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filters input,
        .filters select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        .filters button {
            padding: 8px 20px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }

        .filters button:hover {
            background: #5568d3;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        .logs-table {
            width: 100%;
            border-collapse: collapse;
        }

        .logs-table thead {
            background: #f9f9f9;
            border-bottom: 2px solid #667eea;
        }

        .logs-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            font-size: 13px;
            text-transform: uppercase;
        }

        .logs-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            font-size: 14px;
        }

        .logs-table tbody tr:hover {
            background: #f9f9f9;
        }

        .action-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .action-create {
            background: #d4edda;
            color: #155724;
        }

        .action-update {
            background: #cce5ff;
            color: #004085;
        }

        .action-delete {
            background: #f8d7da;
            color: #721c24;
        }

        .action-login {
            background: #d1ecf1;
            color: #0c5460;
        }

        .timestamp {
            color: #666;
            font-size: 13px;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
        }

        .pagination a,
        .pagination span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #667eea;
        }

        .pagination a:hover {
            background: #667eea;
            color: white;
        }

        .pagination .active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .json-viewer {
            background: #f5f5f5;
            padding: 10px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            max-height: 200px;
            overflow-y: auto;
            color: #333;
        }

        .no-data {
            text-align: center;
            padding: 40px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <?php include 'navbar.php'; ?>
        
        <div class="header">
            <div>
                <h1>📋 Audit Logs</h1>
                <p style="color: #666; margin-top: 5px;">System activity and user actions</p>
            </div>
        </div>

        <a href="/WarehouseAndBosSystem/admin/dashboard.php" class="back-link">← Back to Dashboard</a>

        <div class="card">
            <h2>Activity Log</h2>
            
            <?php if ($total_records > 0): ?>
                <div class="table-wrapper">
                    <table class="logs-table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Action</th>
                                <th>Description</th>
                                <th>IP Address</th>
                                <th>Timestamp</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($log = mysqli_fetch_assoc($logs_result)): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($log['username'] ?? 'System'); ?></strong><br>
                                        <span class="timestamp"><?php echo htmlspecialchars($log['full_name'] ?? ''); ?></span>
                                    </td>
                                    <td>
                                        <span class="action-badge action-<?php echo strtolower(str_replace('_', '-', $log['action'])); ?>">
                                            <?php echo htmlspecialchars($log['action']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php echo htmlspecialchars($log['description']); ?>
                                        <?php if ($log['old_values'] || $log['new_values']): ?>
                                            <details style="margin-top: 5px;">
                                                <summary style="cursor: pointer; color: #667eea; font-size: 12px;">View Details</summary>
                                                <?php if ($log['old_values']): ?>
                                                    <div style="margin-top: 5px;">
                                                        <strong>Before:</strong>
                                                        <div class="json-viewer"><?php echo htmlspecialchars($log['old_values']); ?></div>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if ($log['new_values']): ?>
                                                    <div style="margin-top: 5px;">
                                                        <strong>After:</strong>
                                                        <div class="json-viewer"><?php echo htmlspecialchars($log['new_values']); ?></div>
                                                    </div>
                                                <?php endif; ?>
                                            </details>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="timestamp"><?php echo htmlspecialchars($log['ip_address']); ?></span>
                                    </td>
                                    <td>
                                        <span class="timestamp"><?php echo date('M d, Y H:i:s', strtotime($log['created_at'])); ?></span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=1">« First</a>
                            <a href="?page=<?php echo $page - 1; ?>">‹ Previous</a>
                        <?php endif; ?>

                        <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="active"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo $page + 1; ?>">Next ›</a>
                            <a href="?page=<?php echo $total_pages; ?>">Last »</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="no-data">
                    <p>No audit logs found</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
