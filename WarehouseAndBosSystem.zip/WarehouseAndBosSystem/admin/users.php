<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireAdmin();

$message = '';
$error = '';

// Handle user creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_user') {
    $username = sanitizeInput($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $full_name = sanitizeInput($_POST['full_name']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $role = sanitizeInput($_POST['role']);
    $branch_id = isset($_POST['branch_id']) && $_POST['branch_id'] ? (int)$_POST['branch_id'] : null;
    
    // Validation
    if (empty($username) || empty($password) || empty($full_name) || empty($email) || empty($role)) {
        $error = 'All fields are required';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } elseif (!in_array($role, ['admin', 'manager', 'cashier', 'receiver'])) {
        $error = 'Invalid role selected';
    } else {
        // Check if username exists
        $check_query = "SELECT user_id FROM users WHERE username = '$username'";
        $check_result = mysqli_query($conn, $check_query);
        
        if (mysqli_num_rows($check_result) > 0) {
            $error = 'Username already exists';
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            
            // Insert user
            $stmt = $conn->prepare("INSERT INTO users (username, password, full_name, email, phone, role, branch_id, is_active, created_by) 
                                   VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)");
            $user_id = $_SESSION['user_id'];
            $stmt->bind_param("ssssssii", $username, $hashed_password, $full_name, $email, $phone, $role, $branch_id, $user_id);
            
            if ($stmt->execute()) {
                $new_user_id = $stmt->insert_id;
                $stmt->close();
                
                // Log audit
                auditLog($_SESSION['user_id'], 'CREATE_USER', "Created new user: $username ($role)", null, 
                        ['user_id' => $new_user_id, 'username' => $username, 'role' => $role]);
                
                $message = "User '$username' created successfully!";
            } else {
                $error = 'Error creating user: ' . $conn->error;
            }
        }
    }
}

// Handle user deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_user') {
    $user_id = (int)$_POST['user_id'];
    
    // Prevent deleting admin user
    if ($user_id == 1) {
        $error = 'Cannot delete the main admin user';
    } else {
        // Get user info before deletion
        $user_query = "SELECT username, role FROM users WHERE user_id = $user_id";
        $user_result = mysqli_query($conn, $user_query);
        $user_data = mysqli_fetch_assoc($user_result);
        
        $delete_query = "DELETE FROM users WHERE user_id = $user_id";
        if (mysqli_query($conn, $delete_query)) {
            auditLog($_SESSION['user_id'], 'DELETE_USER', "Deleted user: {$user_data['username']}", 
                    ['user_id' => $user_id, 'username' => $user_data['username'], 'role' => $user_data['role']], null);
            $message = "User deleted successfully!";
        } else {
            $error = 'Error deleting user: ' . $conn->error;
        }
    }
}

// Handle user status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_status') {
    $user_id = (int)$_POST['user_id'];
    $new_status = (int)$_POST['is_active'];
    
    if ($user_id == 1 && $new_status == 0) {
        $error = 'Cannot deactivate the main admin user';
    } else {
        $update_query = "UPDATE users SET is_active = $new_status WHERE user_id = $user_id";
        if (mysqli_query($conn, $update_query)) {
            $status_text = $new_status ? 'activated' : 'deactivated';
            auditLog($_SESSION['user_id'], 'UPDATE_USER_STATUS', "User status changed to $status_text", null, ['user_id' => $user_id, 'is_active' => $new_status]);
            $message = "User status updated successfully!";
        } else {
            $error = 'Error updating user status: ' . $conn->error;
        }
    }
}

// Get all users
$users_query = "SELECT u.*, b.branch_name, creator.full_name as created_by_name 
                FROM users u 
                LEFT JOIN branches b ON u.branch_id = b.branch_id 
                LEFT JOIN users creator ON u.created_by = creator.user_id 
                ORDER BY u.created_at DESC";
$users_result = mysqli_query($conn, $users_query);

// Get branches for dropdown
$branches_query = "SELECT branch_id, branch_name FROM branches WHERE is_active = 1 ORDER BY branch_name";
$branches_result = mysqli_query($conn, $branches_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Admin Panel</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .header h1 {
            font-size: 28px;
            color: #333;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-badge {
            background: #667eea;
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }

        .btn-logout {
            background: #e74c3c;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s;
        }

        .btn-logout:hover {
            background: #c0392b;
        }

        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .card h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            font-family: inherit;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn-primary {
            background: #667eea;
            color: white;
            width: 100%;
        }

        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }

        .btn-danger {
            background: #e74c3c;
            color: white;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-warning {
            background: #f39c12;
            color: white;
        }

        .btn-warning:hover {
            background: #d68910;
        }

        .users-table {
            width: 100%;
            border-collapse: collapse;
        }

        .users-table thead {
            background: #f9f9f9;
            border-bottom: 2px solid #667eea;
        }

        .users-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            font-size: 13px;
            text-transform: uppercase;
        }

        .users-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }

        .users-table tbody tr:hover {
            background: #f9f9f9;
        }

        .role-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .role-admin {
            background: #e74c3c;
            color: white;
        }

        .role-manager {
            background: #3498db;
            color: white;
        }

        .role-cashier {
            background: #2ecc71;
            color: white;
        }

        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-active {
            background: #d4edda;
            color: #155724;
        }

        .status-inactive {
            background: #f8d7da;
            color: #721c24;
        }

        .actions {
            display: flex;
            gap: 5px;
        }

        .actions form {
            display: inline;
        }

        .action-btn {
            padding: 6px 12px;
            font-size: 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }

        .action-btn-toggle {
            background: #f39c12;
            color: white;
        }

        .action-btn-toggle:hover {
            background: #d68910;
        }

        .action-btn-delete {
            background: #e74c3c;
            color: white;
        }

        .action-btn-delete:hover {
            background: #c0392b;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .stat-card h3 {
            font-size: 32px;
            margin-bottom: 5px;
        }

        .stat-card p {
            font-size: 13px;
            opacity: 0.9;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 8px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        }

        .modal-header {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #333;
        }

        .modal-footer {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .modal-footer button {
            flex: 1;
        }

        .btn-secondary {
            background: #ddd;
            color: #333;
        }

        .btn-secondary:hover {
            background: #ccc;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <?php include 'navbar.php'; ?>
        
        <div class="header">
            <div>
                <h1>👨‍💼 Admin Panel - User Management</h1>
                <p style="color: #666; margin-top: 5px;">Manage system users and roles</p>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success">✓ <?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error">✗ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="stats">
            <?php
            $total_users_result = mysqli_query($conn, "SELECT COUNT(*) as count FROM users");
            $total_users = mysqli_fetch_assoc($total_users_result)['count'];
            
            $total_managers_result = mysqli_query($conn, "SELECT COUNT(*) as count FROM users WHERE role = 'branch_manager'");
            $total_managers = mysqli_fetch_assoc($total_managers_result)['count'];
            
            $total_cashiers_result = mysqli_query($conn, "SELECT COUNT(*) as count FROM users WHERE role = 'cashier'");
            $total_cashiers = mysqli_fetch_assoc($total_cashiers_result)['count'];
            ?>
            <div class="stat-card">
                <h3><?php echo $total_users; ?></h3>
                <p>Total Users</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $total_managers; ?></h3>
                <p>Managers</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $total_cashiers; ?></h3>
                <p>Cashiers</p>
            </div>
        </div>

        <div class="content">
            <!-- Add User Form -->
            <div class="card">
                <h2>➕ Add New User</h2>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="add_user">
                    
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" required>
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" id="full_name" name="full_name" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" name="phone" required>
                    </div>

                    <div class="form-group">
                        <label for="role">Role</label>
                        <select id="role" name="role" required>
                            <option value="">-- Select Role --</option>
                            <option value="manager">Manager</option>
                            <option value="cashier">Cashier</option>
                            <option value="receiver">Receiver</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="branch_id">Branch (Optional)</label>
                        <select id="branch_id" name="branch_id">
                            <option value="">-- Select Branch --</option>
                            <?php 
                            mysqli_data_seek($branches_result, 0);
                            while ($branch = mysqli_fetch_assoc($branches_result)): 
                            ?>
                                <option value="<?php echo $branch['branch_id']; ?>">
                                    <?php echo htmlspecialchars($branch['branch_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Create User</button>
                </form>
            </div>

            <!-- Quick Actions -->
            <div class="card">
                <h2>⚙️ Quick Actions</h2>
                <div style="display: flex; flex-direction: column; gap: 10px;">
                    <a href="dashboard.php" class="btn btn-primary" style="text-align: center; text-decoration: none;">
                        📊 Admin Dashboard
                    </a>
                    <a href="audit_logs.php" class="btn btn-primary" style="text-align: center; text-decoration: none;">
                        📋 View Audit Logs
                    </a>
                    <a href="manage_permissions.php" class="btn btn-primary" style="text-align: center; text-decoration: none;">
                        🔑 Manage Permissions
                    </a>
                    <a href="../login_new.php" class="btn btn-primary" style="text-align: center; text-decoration: none;">
                        🔐 Go to Login
                    </a>
                </div>
            </div>
        </div>

        <!-- Users List -->
        <div class="card">
            <h2>👥 All Users</h2>
            <div class="table-wrapper">
                <table class="users-table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Branch</th>
                            <th>Status</th>
                            <th>Created By</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($user = mysqli_fetch_assoc($users_result)): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
                                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td>
                                    <span class="role-badge role-<?php echo $user['role']; ?>">
                                        <?php echo ucfirst($user['role']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($user['branch_name'] ?? 'N/A'); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $user['is_active'] ? 'active' : 'inactive'; ?>">
                                        <?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($user['created_by_name'] ?? 'System'); ?></td>
                                <td>
                                    <div class="actions">
                                        <?php if ($user['user_id'] != 1): ?>
                                            <form method="POST" action="" style="display: inline;">
                                                <input type="hidden" name="action" value="toggle_status">
                                                <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                                <input type="hidden" name="is_active" value="<?php echo $user['is_active'] ? 0 : 1; ?>">
                                                <button type="submit" class="action-btn action-btn-toggle">
                                                    <?php echo $user['is_active'] ? 'Deactivate' : 'Activate'; ?>
                                                </button>
                                            </form>
                                            <form method="POST" action="" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                                <input type="hidden" name="action" value="delete_user">
                                                <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                                <button type="submit" class="action-btn action-btn-delete">Delete</button>
                                            </form>
                                        <?php else: ?>
                                            <span style="color: #999; font-size: 12px;">System Admin</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
