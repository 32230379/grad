<?php
require_once 'config.php';

echo "Assigning branch_id to users...\n\n";

// Get the main branch
$branch = mysqli_fetch_assoc(mysqli_query($conn, "SELECT branch_id FROM branches LIMIT 1"));
if (!$branch) {
    echo "No branches found! Creating main branch...\n";
    $insert = mysqli_query($conn, "INSERT INTO branches (branch_code, branch_name, is_active) VALUES ('BR001', 'Main Branch', 1)");
    $branch = mysqli_fetch_assoc(mysqli_query($conn, "SELECT branch_id FROM branches LIMIT 1"));
}

$branch_id = $branch['branch_id'];
echo "Using branch_id: $branch_id\n\n";

// Assign branch to all users
$update = mysqli_query($conn, "UPDATE users SET branch_id = $branch_id WHERE branch_id IS NULL");
echo "Updated users without branch_id\n\n";

// Verify
echo "Final user assignments:\n";
$result = mysqli_query($conn, "SELECT user_id, username, role, branch_id FROM users");
while ($row = mysqli_fetch_assoc($result)) {
    echo "ID: {$row['user_id']}, Username: {$row['username']}, Role: {$row['role']}, Branch: {$row['branch_id']}\n";
}
?>
