<?php
require_once 'config.php';
require_once 'functions.php';

// If already logged in, redirect based on role
if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']) {
        header('Location: admin/dashboard.php');
    } elseif (isset($_SESSION['role'])) {
        if ($_SESSION['role'] === 'manager') {
            header('Location: dashboard.php');
        } elseif ($_SESSION['role'] === 'cashier') {
            header('Location: bos/index.php');
        } elseif ($_SESSION['role'] === 'receiver') {
            header('Location: receiver/dashboard.php');
        }
    }
    exit();
}

$error = '';
$step = 'role_select';
$selected_role = '';

// Map display roles to database roles
$role_mapping = [
    'admin' => 'admin',
    'manager' => 'manager',
    'cashier' => 'cashier',
    'receiver' => 'receiver'
];

// Determine current step
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'select_role') {
        // Step 1: Role Selection
        $role = isset($_POST['role']) ? $_POST['role'] : '';
        
        if (!in_array($role, ['admin', 'manager', 'cashier', 'receiver'])) {
            $error = 'Please select a valid role';
            $step = 'role_select';
        } else {
            $selected_role = $role;
            $step = 'login';
        }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'login') {
        // Step 2: Login
        $role = isset($_POST['role']) ? $_POST['role'] : '';
        $username = isset($_POST['username']) ? mysqli_real_escape_string($conn, $_POST['username']) : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        
        if (empty($role) || !in_array($role, ['admin', 'manager', 'cashier', 'receiver'])) {
            $error = 'Invalid role selected';
            $selected_role = $role;
            $step = 'login';
        } elseif (empty($username) || empty($password)) {
            $error = 'Username and password are required';
            $selected_role = $role;
            $step = 'login';
        } else {
            // Query user with role verification
            $query = "SELECT u.*, b.branch_name 
                      FROM users u 
                      LEFT JOIN branches b ON u.branch_id = b.branch_id 
                      WHERE u.username = '$username' AND u.is_active = 1";
            
            $result = mysqli_query($conn, $query);
            
            if (mysqli_num_rows($result) == 1) {
                $user = mysqli_fetch_assoc($result);
                
                // Get the expected database role for the selected role
                $expected_db_role = $role_mapping[$role];
                
                // Verify role matches
                if ($user['role'] !== $expected_db_role) {
                    $error = 'Invalid role for this user';
                    $role_match = false;
                    $selected_role = $role;
                    $step = 'login';
                } else {
                    $role_match = true;
                }
                
                if ($role_match && password_verify($password, $user['password'])) {
                    // Set session variables
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['role'] = $role;  // Store the display role, not DB role
                    $_SESSION['db_role'] = $user['role'];  // Store DB role for reference
                    $_SESSION['is_admin'] = (bool)$user['is_admin'];  // Set admin flag
                    $_SESSION['branch_id'] = $user['branch_id'];
                    $_SESSION['branch_name'] = $user['branch_name'];
                    
                    // Update last login
                    $user_id = $user['user_id'];
                    mysqli_query($conn, "UPDATE users SET last_login = NOW() WHERE user_id = $user_id");
                    
                    // Log activity
                    $ip = $_SERVER['REMOTE_ADDR'];
                    logActivity($user_id, 'Login', 'Authentication', "User logged in as {$role}");
                    
                    // Redirect based on role
                    if ($role === 'admin') {
                        header('Location: admin/dashboard.php');
                    } elseif ($role === 'manager') {
                        header('Location: dashboard.php');
                    } elseif ($role === 'cashier') {
                        header('Location: bos/index.php');
                    } elseif ($role === 'receiver') {
                        header('Location: receiver/dashboard.php');
                    }
                    exit();
                } else {
                    $error = 'Invalid username or password';
                    $selected_role = $role;
                    $step = 'login';
                }
            } else {
                $error = 'Invalid username or password';
                $selected_role = $role;
                $step = 'login';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/login.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .login-container {
            width: 100%;
            max-width: 450px;
        }

        .login-box {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .login-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }

        .login-header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }

        .login-header p {
            font-size: 14px;
            opacity: 0.9;
        }

        .login-content {
            padding: 40px 30px;
        }

        .alert {
            padding: 12px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-error {
            background-color: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }

        .alert-info {
            background-color: #eef;
            color: #33c;
            border: 1px solid #ccf;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .role-selector {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr 1fr;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .role-selector {
                grid-template-columns: 1fr 1fr;
            }
        }

        .role-option {
            position: relative;
        }

        .role-option input[type="radio"] {
            display: none;
        }

        .role-option label {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            border: 2px solid #ddd;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            background: #f9f9f9;
            margin: 0;
        }

        .role-option input[type="radio"]:checked + label {
            border-color: #667eea;
            background: #f0f4ff;
        }

        .role-icon {
            font-size: 32px;
            margin-bottom: 8px;
        }

        .role-name {
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }

        .btn {
            width: 100%;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        .btn-primary:active {
            transform: translateY(0);
        }

        .btn-secondary {
            background: #f0f0f0;
            color: #333;
            margin-top: 10px;
        }

        .btn-secondary:hover {
            background: #e0e0e0;
        }

        .login-footer {
            background: #f9f9f9;
            padding: 20px 30px;
            border-top: 1px solid #eee;
            text-align: center;
            font-size: 13px;
            color: #666;
        }

        .login-footer p {
            margin: 5px 0;
        }

        .login-footer strong {
            color: #333;
        }

        .step-indicator {
            text-align: center;
            margin-bottom: 20px;
            font-size: 12px;
            color: #999;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .step-indicator.step-2 {
            color: #667eea;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h1>🏢 Branch Management</h1>
                <p>Role-Based Access System</p>
            </div>
            
            <div class="login-content">
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        ⚠️ <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <?php if ($step === 'role_select'): ?>
                    <div class="step-indicator">Step 1: Select Your Role</div>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label>Who are you?</label>
                            <div class="role-selector">
                                <div class="role-option">
                                    <input type="radio" id="role_admin" name="role" value="admin" required>
                                    <label for="role_admin">
                                        <div class="role-icon">👨‍💼</div>
                                        <div class="role-name">Admin</div>
                                    </label>
                                </div>
                                <div class="role-option">
                                    <input type="radio" id="role_manager" name="role" value="manager" required>
                                    <label for="role_manager">
                                        <div class="role-icon">📊</div>
                                        <div class="role-name">Manager</div>
                                    </label>
                                </div>
                                <div class="role-option">
                                    <input type="radio" id="role_cashier" name="role" value="cashier" required>
                                    <label for="role_cashier">
                                        <div class="role-icon">💳</div>
                                        <div class="role-name">Cashier</div>
                                    </label>
                                </div>
                                <div class="role-option">
                                    <input type="radio" id="role_receiver" name="role" value="receiver" required>
                                    <label for="role_receiver">
                                        <div class="role-icon">📦</div>
                                        <div class="role-name">Receiver</div>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="action" value="select_role">
                        <button type="submit" class="btn btn-primary">Continue</button>
                    </form>

                <?php else: ?>
                    <div class="step-indicator step-2">Step 2: Enter Credentials</div>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" id="username" name="username" required autofocus>
                        </div>
                        
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" required>
                        </div>
                        
                        <input type="hidden" name="action" value="login">
                        <input type="hidden" name="role" value="<?php echo htmlspecialchars($selected_role); ?>">
                        
                        <button type="submit" class="btn btn-primary">Login</button>
                        <button type="button" class="btn btn-secondary" onclick="window.location.href='login_new.php'">Back to Role Selection</button>
                    </form>
                <?php endif; ?>
            </div>

            <div class="login-footer">
                <p><strong>Demo Credentials:</strong></p>
                <p>Admin: <code>admin</code> / <code>admin123</code></p>
                <p>Manager: <code>manager</code> / <code>admin123</code></p>
                <p>Cashier: <code>cashier</code> / <code>admin123</code></p>
            </div>
        </div>
    </div>
</body>
</html>
