<?php
require_once 'config.php';

// Test database connection
echo "<h2>System Test</h2>";

// Check database connection
if ($conn) {
    echo "✓ Database connected<br>";
} else {
    echo "✗ Database connection failed<br>";
    exit;
}

// Check if users table exists
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM users");
if ($result) {
    $row = mysqli_fetch_assoc($result);
    echo "✓ Users table exists (" . $row['count'] . " users)<br>";
} else {
    echo "✗ Users table not found<br>";
    exit;
}

// Check if admin user exists
$result = mysqli_query($conn, "SELECT * FROM users WHERE username = 'admin'");
if (mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
    echo "✓ Admin user exists<br>";
    echo "  - Username: " . $user['username'] . "<br>";
    echo "  - Role: " . $user['role'] . "<br>";
    echo "  - Is Admin: " . ($user['is_admin'] ? 'Yes' : 'No') . "<br>";
    echo "  - Active: " . ($user['is_active'] ? 'Yes' : 'No') . "<br>";
} else {
    echo "✗ Admin user not found<br>";
}

// Check if manager user exists
$result = mysqli_query($conn, "SELECT * FROM users WHERE username = 'manager'");
if (mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
    echo "✓ Manager user exists<br>";
    echo "  - Username: " . $user['username'] . "<br>";
    echo "  - Role: " . $user['role'] . "<br>";
} else {
    echo "✗ Manager user not found<br>";
}

// Check if cashier user exists
$result = mysqli_query($conn, "SELECT * FROM users WHERE username = 'cashier'");
if (mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
    echo "✓ Cashier user exists<br>";
    echo "  - Username: " . $user['username'] . "<br>";
    echo "  - Role: " . $user['role'] . "<br>";
} else {
    echo "✗ Cashier user not found<br>";
}

echo "<br><hr>";
echo "<h3>Login Credentials</h3>";
echo "Username: <strong>admin</strong><br>";
echo "Password: <strong>admin123</strong><br>";
echo "Role: Select <strong>Admin</strong><br>";
echo "<br>";
echo "<a href='login_new.php' style='background: #667eea; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none;'>Go to Login</a>";
?>
