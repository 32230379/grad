<?php
require_once 'config.php';

echo "<h2>Database Debug - Users Table</h2>";

// Get all users
$result = mysqli_query($conn, "SELECT user_id, username, role, is_active, password FROM users");

if ($result) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>ID</th><th>Username</th><th>Role</th><th>Active</th><th>Password Hash</th></tr>";
    
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['user_id'] . "</td>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['role'] . "</td>";
        echo "<td>" . ($row['is_active'] ? 'Yes' : 'No') . "</td>";
        echo "<td><code>" . substr($row['password'], 0, 20) . "...</code></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Error: " . mysqli_error($conn);
}

echo "<hr>";
echo "<h3>Test Password Verification</h3>";

// Test with admin user
$admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE username = 'admin' LIMIT 1"));

if ($admin) {
    echo "<p><strong>Admin User Found:</strong></p>";
    echo "Username: " . $admin['username'] . "<br>";
    echo "Password Hash: " . $admin['password'] . "<br>";
    
    $test_password = 'admin123';
    $verify = password_verify($test_password, $admin['password']);
    
    echo "<p><strong>Testing password_verify('admin123', hash):</strong> ";
    echo ($verify ? '<span style="color:green;">✓ MATCH</span>' : '<span style="color:red;">✗ NO MATCH</span>');
    echo "</p>";
} else {
    echo "Admin user not found!";
}
?>
