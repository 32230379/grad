<?php
// Test database connection
$conn = mysqli_connect('localhost', 'root', '', 'branch_system');

if (!$conn) {
    echo "Connection failed: " . mysqli_connect_error();
    exit;
}

echo "✓ Connected to database\n\n";

// Check if users table exists
$result = mysqli_query($conn, "SHOW TABLES LIKE 'users'");
if (mysqli_num_rows($result) > 0) {
    echo "✓ Users table exists\n";
} else {
    echo "✗ Users table does NOT exist\n";
    echo "Available tables:\n";
    $tables = mysqli_query($conn, "SHOW TABLES");
    while ($table = mysqli_fetch_row($tables)) {
        echo "  - " . $table[0] . "\n";
    }
    exit;
}

// Check users count
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM users");
$row = mysqli_fetch_assoc($result);
echo "✓ Users in database: " . $row['count'] . "\n\n";

// List all users
echo "Users:\n";
$result = mysqli_query($conn, "SELECT user_id, username, role, is_active FROM users");
while ($row = mysqli_fetch_assoc($result)) {
    echo "  ID: {$row['user_id']}, Username: {$row['username']}, Role: {$row['role']}, Active: " . ($row['is_active'] ? 'Yes' : 'No') . "\n";
}

// Test password verification
echo "\n\nPassword Verification Test:\n";
$admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT username, password FROM users WHERE username = 'admin'"));

if ($admin) {
    echo "Admin password hash: " . $admin['password'] . "\n";
    $verify = password_verify('admin123', $admin['password']);
    echo "password_verify('admin123', hash) = " . ($verify ? "TRUE ✓" : "FALSE ✗") . "\n";
} else {
    echo "Admin user not found!\n";
}
?>
