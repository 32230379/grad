<?php
require_once 'config.php';

$messages = [];
$errors = [];

// Create order_receipts table
$sql1 = "CREATE TABLE IF NOT EXISTS order_receipts (
    receipt_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    received_by INT NOT NULL,
    receipt_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    status ENUM('completed', 'partial', 'rejected') DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES order_requests(order_id),
    FOREIGN KEY (received_by) REFERENCES users(user_id),
    INDEX idx_order (order_id),
    INDEX idx_received_by (received_by),
    INDEX idx_date (receipt_date)
)";

// Create receipt_items table
$sql2 = "CREATE TABLE IF NOT EXISTS receipt_items (
    receipt_item_id INT PRIMARY KEY AUTO_INCREMENT,
    receipt_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity_received INT NOT NULL,
    status ENUM('received', 'partial', 'damaged', 'not_received') NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (receipt_id) REFERENCES order_receipts(receipt_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_receipt (receipt_id),
    INDEX idx_product (product_id)
)";

if (mysqli_query($conn, $sql1)) {
    $messages[] = "✓ order_receipts table created successfully";
} else {
    $errors[] = "✗ Error creating order_receipts table: " . mysqli_error($conn);
}

if (mysqli_query($conn, $sql2)) {
    $messages[] = "✓ receipt_items table created successfully";
} else {
    $errors[] = "✗ Error creating receipt_items table: " . mysqli_error($conn);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Setup</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; color: #333; }
        .container { max-width: 800px; margin: 50px auto; padding: 20px; }
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 30px; }
        h1 { margin-bottom: 20px; color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
        .message { padding: 12px; margin: 10px 0; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .btn { background: #667eea; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 20px; }
        .btn:hover { background: #5568d3; }
        .info { background: #cfe2ff; color: #084298; border: 1px solid #b6d4fe; padding: 15px; border-radius: 5px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>📦 Receiver System Setup</h1>
            
            <div class="info">
                <strong>ℹ️ Database Setup Status:</strong><br>
                Creating necessary tables for the receiver system...
            </div>
            
            <?php foreach ($messages as $msg): ?>
                <div class="message success">✓ <?php echo $msg; ?></div>
            <?php endforeach; ?>
            
            <?php foreach ($errors as $err): ?>
                <div class="message error">✗ <?php echo $err; ?></div>
            <?php endforeach; ?>
            
            <?php if (empty($errors)): ?>
                <div class="message success" style="margin-top: 20px; font-weight: bold;">
                    ✓ Setup Complete! All tables created successfully.
                </div>
            <?php endif; ?>
            
            <div style="margin-top: 30px; padding: 15px; background: #f9f9f9; border-radius: 5px;">
                <h3>Next Steps:</h3>
                <ol style="margin-left: 20px; line-height: 1.8;">
                    <li>Go to <a href="admin/users.php" style="color: #667eea; text-decoration: none;"><strong>User Management</strong></a></li>
                    <li>Create a new user with role "Receiver"</li>
                    <li>Login with the receiver account</li>
                    <li>Start receiving orders!</li>
                </ol>
            </div>
            
            <a href="admin/users.php" class="btn">Go to User Management →</a>
        </div>
    </div>
</body>
</html>
