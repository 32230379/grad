# Complete Setup Instructions

## ⚠️ Important: Database Setup Required

The system requires a properly configured database. Follow these steps:

## Step 1: Create Database

### Option A: Using phpMyAdmin (Recommended)
1. Open http://localhost/phpmyadmin
2. Click "New" on the left sidebar
3. Enter database name: `branch_system`
4. Click "Create"

### Option B: Using Command Line
```bash
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS branch_system;"
```

## Step 2: Run Automated Setup

1. Navigate to: `http://localhost/warehouse+bos%20system/setup_rbac.php`
2. Click "Start Setup" button
3. Wait for all tables to be created
4. You should see ✓ checkmarks for all operations

**The setup wizard will automatically create:**
- ✓ Branches table
- ✓ Roles table
- ✓ Permissions table
- ✓ Role-Permission mappings
- ✓ Users table (with RBAC columns)
- ✓ Categories table
- ✓ Products table
- ✓ Branch inventory table
- ✓ Sales transactions table
- ✓ Sales items table
- ✓ Activity logs table
- ✓ Alerts table
- ✓ User audit log table
- ✓ Default roles (Admin, Manager, Cashier)
- ✓ Default permissions (13 total)
- ✓ Default branch
- ✓ Default categories
- ✓ Sample products
- ✓ Sample inventory
- ✓ Default users

## Step 3: Login

Navigate to: `http://localhost/warehouse+bos%20system/login_new.php`

### Default Credentials (Password: admin123)

**Admin Access:**
- Username: `admin`
- Password: `admin123`
- Redirects to: `/admin/users.php`

**Manager Access:**
- Username: `manager`
- Password: `admin123`
- Redirects to: `/dashboard.php`

**Cashier Access:**
- Username: `cashier`
- Password: `admin123`
- Redirects to: `/bos/index.php`

## Step 4: Verify Installation

### For Admin:
1. Login as admin
2. You should see the user management panel
3. Click "View Audit Logs" to verify audit system
4. Create a new user to test the system

### For Manager:
1. Login as manager
2. You should see the dashboard
3. Try accessing inventory and sales

### For Cashier:
1. Login as cashier
2. You should see the BOS dashboard
3. Try accessing Point of Sale
4. Try viewing inventory

## Troubleshooting

### Error: "Table 'branch_system.branches' doesn't exist"
**Solution:** Run the setup wizard at `setup_rbac.php`

### Error: "Connection failed"
**Solution:** 
- Verify MySQL is running
- Check config.php has correct database credentials
- Verify database `branch_system` exists

### Error: "Access denied for user"
**Solution:**
- Check username/password in config.php
- Verify MySQL user has correct permissions
- Try: `mysql -u root -p` to test connection

### Setup wizard shows errors
**Solution:**
- Check MySQL error messages
- Verify database is created
- Try running setup again
- Check file permissions

### Can't login after setup
**Solution:**
- Verify users were created (check setup messages)
- Try default credentials again
- Clear browser cache
- Check if user is active in database

## Manual Database Setup (If Needed)

If the setup wizard fails, you can import the complete schema manually:

### Using phpMyAdmin:
1. Go to http://localhost/phpmyadmin
2. Select database `branch_system`
3. Click "Import" tab
4. Choose file: `database_schema_complete.sql`
5. Click "Go"

### Using Command Line:
```bash
mysql -u root -p branch_system < database_schema_complete.sql
```

## Verify Database Structure

After setup, verify all tables exist:

```bash
mysql -u root -p -e "USE branch_system; SHOW TABLES;"
```

You should see these tables:
- activity_logs
- alerts
- branch_inventory
- branches
- categories
- permissions
- products
- role_permissions
- roles
- sales_items
- sales_transactions
- user_audit_log
- users

## Next Steps

1. ✅ Database created
2. ✅ Setup wizard completed
3. ✅ Default users created
4. ✅ Sample data loaded

### Now you can:
- Login with default credentials
- Create new users via admin panel
- Process sales via BOS
- View reports and inventory
- Manage users and permissions

## Support Files

- **QUICK_REFERENCE.md** - Quick command reference
- **RBAC_SETUP.md** - Detailed setup guide
- **IMPLEMENTATION_GUIDE.md** - Implementation details
- **SYSTEM_SUMMARY.md** - Complete system overview
- **database_schema_complete.sql** - Full database schema

## Important Notes

⚠️ **Change Default Passwords**
- After setup, change all default passwords
- Use strong passwords (minimum 8 characters)
- Don't share credentials

⚠️ **Database Backups**
- Regularly backup your database
- Keep backups in a safe location
- Test restore procedures

⚠️ **Security**
- Keep MySQL updated
- Use strong database passwords
- Restrict database access
- Monitor audit logs regularly

## Getting Help

If you encounter issues:

1. Check the error message carefully
2. Review the troubleshooting section above
3. Check the documentation files
4. Verify database connection
5. Check MySQL error logs

---

**Setup Status**: Ready to use after completing these steps
**Last Updated**: 2024
**Version**: 1.0
