-- Complete Branch Management System Database Schema
-- Includes RBAC, Branches, Products, Inventory, and all required tables

-- =============================================
-- CREATE DATABASE
-- =============================================

CREATE DATABASE IF NOT EXISTS branch_system;
USE branch_system;

-- =============================================
-- BRANCHES TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS branches (
    branch_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_code VARCHAR(20) UNIQUE NOT NULL,
    branch_name VARCHAR(100) NOT NULL,
    address TEXT,
    city VARCHAR(50),
    phone VARCHAR(20),
    email VARCHAR(100),
    manager_id INT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_code (branch_code),
    INDEX idx_manager (manager_id)
);

-- =============================================
-- ROLES TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS roles (
    role_id INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =============================================
-- PERMISSIONS TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS permissions (
    permission_id INT PRIMARY KEY AUTO_INCREMENT,
    permission_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    module VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =============================================
-- ROLE PERMISSIONS MAPPING
-- =============================================

CREATE TABLE IF NOT EXISTS role_permissions (
    role_permission_id INT PRIMARY KEY AUTO_INCREMENT,
    role_id INT NOT NULL,
    permission_id INT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(role_id) ON DELETE CASCADE,
    FOREIGN KEY (permission_id) REFERENCES permissions(permission_id) ON DELETE CASCADE,
    UNIQUE KEY unique_role_permission (role_id, permission_id)
);

-- =============================================
-- USERS TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    role ENUM('admin', 'manager', 'cashier') NOT NULL,
    branch_id INT,
    is_admin BOOLEAN DEFAULT FALSE,
    admin_since TIMESTAMP NULL,
    created_by INT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_username (username),
    INDEX idx_role (role),
    INDEX idx_branch (branch_id),
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- =============================================
-- USER AUDIT LOG TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS user_audit_log (
    audit_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    description TEXT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at)
);

-- =============================================
-- CATEGORIES TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100) NOT NULL,
    description TEXT,
    parent_category_id INT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_parent (parent_category_id)
);

-- =============================================
-- PRODUCTS TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_code VARCHAR(50) UNIQUE NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    description TEXT,
    category_id INT,
    unit VARCHAR(20) NOT NULL,
    barcode VARCHAR(100),
    has_expiry BOOLEAN DEFAULT FALSE,
    has_batch BOOLEAN DEFAULT FALSE,
    reorder_level INT DEFAULT 0,
    min_stock_level INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
    INDEX idx_code (product_code),
    INDEX idx_barcode (barcode),
    INDEX idx_category (category_id)
);

-- =============================================
-- BRANCH INVENTORY TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS branch_inventory (
    inventory_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    product_id INT NOT NULL,
    batch_number VARCHAR(50),
    quantity INT NOT NULL DEFAULT 0,
    expiry_date DATE NULL,
    cost_price DECIMAL(10,2),
    selling_price DECIMAL(10,2),
    location VARCHAR(50),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_branch_product (branch_id, product_id),
    INDEX idx_batch (batch_number),
    INDEX idx_expiry (expiry_date)
);

-- =============================================
-- SALES TRANSACTIONS TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS sales_transactions (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    transaction_number VARCHAR(50) UNIQUE NOT NULL,
    branch_id INT NOT NULL,
    sale_date DATE NOT NULL,
    sale_time TIME NOT NULL,
    cashier_id INT NOT NULL,
    customer_name VARCHAR(100),
    customer_phone VARCHAR(20),
    subtotal DECIMAL(10,2) NOT NULL,
    discount DECIMAL(10,2) DEFAULT 0,
    tax DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('cash', 'card', 'mobile', 'credit') NOT NULL,
    payment_status ENUM('paid', 'partial', 'pending') DEFAULT 'paid',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (cashier_id) REFERENCES users(user_id),
    INDEX idx_transaction_number (transaction_number),
    INDEX idx_branch_date (branch_id, sale_date),
    INDEX idx_cashier (cashier_id)
);

-- =============================================
-- SALES ITEMS TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS sales_items (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    transaction_id INT NOT NULL,
    product_id INT NOT NULL,
    batch_number VARCHAR(50),
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    discount DECIMAL(10,2) DEFAULT 0,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (transaction_id) REFERENCES sales_transactions(transaction_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_transaction (transaction_id),
    INDEX idx_product (product_id)
);

-- =============================================
-- ACTIVITY LOGS TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS activity_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    branch_id INT,
    action VARCHAR(100) NOT NULL,
    module VARCHAR(50) NOT NULL,
    description TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    INDEX idx_user (user_id),
    INDEX idx_module (module),
    INDEX idx_created (created_at)
);

-- =============================================
-- ALERTS TABLE
-- =============================================

CREATE TABLE IF NOT EXISTS alerts (
    alert_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    alert_type ENUM('low_stock', 'expiry_warning', 'expired', 'reorder_point', 'discrepancy', 'system') NOT NULL,
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    product_id INT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_branch_unread (branch_id, is_read),
    INDEX idx_type (alert_type)
);

-- =============================================
-- INSERT DEFAULT ROLES
-- =============================================

INSERT IGNORE INTO roles (role_id, role_name, description, is_active) VALUES
(1, 'admin', 'System Administrator - Full access to all features', TRUE),
(2, 'manager', 'Branch Manager - Manages branch operations and staff', TRUE),
(3, 'cashier', 'Cashier - Handles sales transactions', TRUE);

-- =============================================
-- INSERT DEFAULT PERMISSIONS
-- =============================================

INSERT IGNORE INTO permissions (permission_id, permission_name, description, module) VALUES
(1, 'manage_users', 'Create, edit, delete users', 'admin'),
(2, 'manage_roles', 'Manage roles and permissions', 'admin'),
(3, 'view_audit_logs', 'View activity logs', 'admin'),
(4, 'system_settings', 'Access system settings', 'admin'),
(5, 'view_dashboard', 'View dashboard', 'dashboard'),
(6, 'manage_inventory', 'Manage inventory', 'inventory'),
(7, 'manage_sales', 'Manage sales', 'sales'),
(8, 'manage_receiving', 'Manage receiving', 'receiving'),
(9, 'view_reports', 'View reports', 'reports'),
(10, 'manage_staff', 'Manage branch staff', 'staff'),
(11, 'process_sales', 'Process sales transactions', 'sales'),
(12, 'view_inventory', 'View inventory', 'inventory'),
(13, 'access_bos', 'Access BOS system', 'bos');

-- =============================================
-- ASSIGN PERMISSIONS TO ROLES
-- =============================================

INSERT IGNORE INTO role_permissions (role_id, permission_id) 
SELECT 1, permission_id FROM permissions;

INSERT IGNORE INTO role_permissions (role_id, permission_id) 
SELECT 2, permission_id FROM permissions WHERE permission_id IN (5, 6, 7, 8, 9, 10);

INSERT IGNORE INTO role_permissions (role_id, permission_id) 
SELECT 3, permission_id FROM permissions WHERE permission_id IN (11, 12, 13);

-- =============================================
-- INSERT DEFAULT BRANCH
-- =============================================

INSERT IGNORE INTO branches (branch_id, branch_code, branch_name, address, city, phone, email, is_active) 
VALUES (1, 'BR001', 'Main Branch', '123 Main Street', 'City Center', '+1234567890', 'main@branch.com', TRUE);

-- =============================================
-- INSERT DEFAULT CATEGORIES
-- =============================================

INSERT IGNORE INTO categories (category_name, description) VALUES
('Electronics', 'Electronic devices and accessories'),
('Food & Beverages', 'Food items and drinks'),
('Clothing', 'Apparel and fashion items'),
('Home & Garden', 'Home improvement and garden supplies'),
('Health & Beauty', 'Personal care and cosmetics');

-- =============================================
-- INSERT DEFAULT ADMIN USER
-- =============================================

INSERT IGNORE INTO users (user_id, username, password, full_name, email, phone, role, is_admin, is_active) 
VALUES (
    1, 
    'admin', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 
    'System Administrator', 
    'admin@branch.com',
    '+1234567890',
    'admin', 
    TRUE, 
    TRUE
);

-- =============================================
-- INSERT SAMPLE MANAGER USER
-- =============================================

INSERT IGNORE INTO users (user_id, username, password, full_name, email, phone, role, branch_id, is_active, created_by) 
VALUES (
    2, 
    'manager', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 
    'John Manager', 
    'manager@branch.com',
    '+1234567891',
    'manager', 
    1, 
    TRUE,
    1
);

-- =============================================
-- INSERT SAMPLE CASHIER USER
-- =============================================

INSERT IGNORE INTO users (user_id, username, password, full_name, email, phone, role, branch_id, is_active, created_by) 
VALUES (
    3, 
    'cashier', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 
    'Jane Cashier', 
    'cashier@branch.com',
    '+1234567892',
    'cashier', 
    1, 
    TRUE,
    1
);

-- =============================================
-- INSERT SAMPLE PRODUCTS
-- =============================================

INSERT IGNORE INTO products (product_code, product_name, description, category_id, unit, reorder_level, min_stock_level, is_active) VALUES
('PROD001', 'Laptop Computer', 'High-performance laptop', 1, 'piece', 5, 2, TRUE),
('PROD002', 'Wireless Mouse', 'USB wireless mouse', 1, 'piece', 20, 10, TRUE),
('PROD003', 'Coffee Beans', 'Premium coffee beans', 2, 'kg', 10, 5, TRUE),
('PROD004', 'T-Shirt', 'Cotton t-shirt', 3, 'piece', 30, 15, TRUE),
('PROD005', 'Garden Shovel', 'Steel garden shovel', 4, 'piece', 8, 4, TRUE);

-- =============================================
-- INSERT SAMPLE INVENTORY
-- =============================================

INSERT IGNORE INTO branch_inventory (branch_id, product_id, batch_number, quantity, cost_price, selling_price, location) VALUES
(1, 1, 'BATCH001', 10, 30000, 45000, 'A1'),
(1, 2, 'BATCH002', 50, 500, 1000, 'A2'),
(1, 3, 'BATCH003', 100, 300, 500, 'B1'),
(1, 4, 'BATCH004', 200, 200, 400, 'B2'),
(1, 5, 'BATCH005', 25, 1000, 1500, 'C1');

-- =============================================
-- NOTES
-- =============================================
-- Default passwords for sample users: admin123
-- Login with: admin / admin123, manager / admin123, cashier / admin123
-- Admin can access: /admin/users.php
-- Managers redirect to: /dashboard.php
-- Cashiers redirect to: /bos/index.php
