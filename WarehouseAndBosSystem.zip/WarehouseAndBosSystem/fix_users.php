<?php
require_once 'config.php';

echo "<h2>Fixing Users Table</h2>";

// First, let's see what we have
echo "<h3>Current Users:</h3>";
$result = mysqli_query($conn, "SELECT user_id, username, role, is_active FROM users");
while ($row = mysqli_fetch_assoc($result)) {
    echo "ID: {$row['user_id']}, Username: {$row['username']}, Role: {$row['role']}, Active: " . ($row['is_active'] ? 'Yes' : 'No') . "<br>";
}

echo "<hr>";

// Update manager role from 'branch_manager' to 'manager'
$update1 = mysqli_query($conn, "UPDATE users SET role = 'manager' WHERE username = 'manager'");
if ($update1) {
    echo "✓ Updated manager role to 'manager'<br>";
} else {
    echo "✗ Error updating manager: " . mysqli_error($conn) . "<br>";
}

// Create admin user if it doesn't exist
$admin_exists = mysqli_fetch_assoc(mysqli_query($conn, "SELECT user_id FROM users WHERE username = 'admin'"));

if (!$admin_exists) {
    // Hash the password
    $password_hash = password_hash('admin123', PASSWORD_BCRYPT);
    
    $insert = mysqli_query($conn, "INSERT INTO users (username, password, full_name, email, phone, role, is_admin, is_active) 
                                   VALUES ('admin', '$password_hash', 'System Administrator', 'admin@branch.com', '+1234567890', 'admin', 1, 1)");
    
    if ($insert) {
        echo "✓ Created admin user<br>";
    } else {
        echo "✗ Error creating admin: " . mysqli_error($conn) . "<br>";
    }
} else {
    echo "✓ Admin user already exists<br>";
}

// Ensure all user passwords are properly hashed
echo "<hr>";
echo "<h3>Ensuring all passwords are hashed:</h3>";

$users = mysqli_query($conn, "SELECT user_id, username, password FROM users");
while ($user = mysqli_fetch_assoc($users)) {
    // Check if password looks like a hash (starts with $2y$ or $2a$ or $2b$)
    if (!preg_match('/^\$2[aby]\$/', $user['password'])) {
        // Password is not hashed, hash it
        $new_hash = password_hash('admin123', PASSWORD_BCRYPT);
        $update = mysqli_query($conn, "UPDATE users SET password = '$new_hash' WHERE user_id = {$user['user_id']}");
        if ($update) {
            echo "✓ Hashed password for user: {$user['username']}<br>";
        }
    } else {
        echo "✓ {$user['username']} password already hashed<br>";
    }
}

echo "<hr>";
echo "<h3>Final Users:</h3>";
$result = mysqli_query($conn, "SELECT user_id, username, role, is_active FROM users");
while ($row = mysqli_fetch_assoc($result)) {
    echo "ID: {$row['user_id']}, Username: {$row['username']}, Role: {$row['role']}, Active: " . ($row['is_active'] ? 'Yes' : 'No') . "<br>";
}

echo "<hr>";
echo "<h3>Test Credentials:</h3>";
echo "<p><strong>Admin:</strong> username: <code>admin</code>, password: <code>admin123</code>, role: <code>Admin</code></p>";
echo "<p><strong>Manager:</strong> username: <code>manager</code>, password: <code>admin123</code>, role: <code>Manager</code></p>";
echo "<p><strong>Cashier:</strong> username: <code>cashier</code>, password: <code>admin123</code>, role: <code>Cashier</code></p>";
echo "<p><a href='login_new.php' style='background: #667eea; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; display: inline-block;'>Go to Login</a></p>";
?>
