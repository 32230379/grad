<?php
require_once 'config.php';

echo "Updating existing users...\n\n";

// Hash the password
$password_hash = password_hash('admin123', PASSWORD_BCRYPT);

// Update cashier user (already has correct role)
$update1 = mysqli_query($conn, "UPDATE users SET password = '$password_hash', full_name = 'Jane Cashier', email = 'cashier@branch.com', phone = '+1234567892' WHERE username = 'cashier'");
echo "Updated cashier user: " . ($update1 ? "OK" : "FAILED") . "\n";

// Update manager user
$update2 = mysqli_query($conn, "UPDATE users SET password = '$password_hash', full_name = 'John Manager', email = 'manager@branch.com', phone = '+1234567891', role = 'branch_manager' WHERE username = 'manager'");
echo "Updated manager user: " . ($update2 ? "OK" : "FAILED") . "\n";

// Create admin user if doesn't exist
$admin_exists = mysqli_fetch_assoc(mysqli_query($conn, "SELECT user_id FROM users WHERE username = 'admin'"));
if (!$admin_exists) {
    $insert = mysqli_query($conn, "INSERT INTO users (username, password, full_name, email, phone, role, is_active) 
                                   VALUES ('admin', '$password_hash', 'System Administrator', 'admin@branch.com', '+1234567890', 'branch_manager', 1)");
    echo "Created admin user: " . ($insert ? "OK" : "FAILED") . "\n";
} else {
    $update3 = mysqli_query($conn, "UPDATE users SET password = '$password_hash', full_name = 'System Administrator', email = 'admin@branch.com', phone = '+1234567890', role = 'branch_manager' WHERE username = 'admin'");
    echo "Updated admin user: " . ($update3 ? "OK" : "FAILED") . "\n";
}

echo "\n\nVerifying users:\n";
$result = mysqli_query($conn, "SELECT user_id, username, role, is_active FROM users WHERE username IN ('admin', 'manager', 'cashier')");
while($row = mysqli_fetch_assoc($result)) {
    echo "ID: {$row['user_id']}, Username: {$row['username']}, Role: {$row['role']}, Active: " . ($row['is_active'] ? 'Yes' : 'No') . "\n";
}

echo "\n\nPassword verification test:\n";
$admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT password FROM users WHERE username = 'admin'"));
$verify = password_verify('admin123', $admin['password']);
echo "password_verify('admin123', admin_hash) = " . ($verify ? "TRUE ✓" : "FALSE ✗") . "\n";

echo "\n\n✓ Setup complete! Try logging in with:\n";
echo "  Admin: username=admin, password=admin123, role=Admin\n";
echo "  Manager: username=manager, password=admin123, role=Manager\n";
echo "  Cashier: username=cashier, password=admin123, role=Cashier\n";
?>
