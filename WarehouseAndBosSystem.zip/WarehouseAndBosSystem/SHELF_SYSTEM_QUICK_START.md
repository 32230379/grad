# Shelf Management System - Quick Start Guide

## 🚀 Getting Started in 5 Minutes

### Step 1: Initialize the System
1. Open browser and go to:
   ```
   http://localhost/WarehouseAndBosSystem/setup_shelf_system.php
   ```
2. Wait for setup to complete
3. Click "Go to Dashboard"

### Step 2: Login as Manager
- Username: `manager`
- Password: `admin123`

### Step 3: Access Shelf Management
- Click on "Shelf Management" in the dashboard menu
- Or go directly to: `/bos/shelf_management.php`

---

## 📦 How It Works

### Two Stock Levels

```
INVENTORY (Back Storage)          ON-SHELF (Customer Area)
    100 units                          30 units
         ↓                                  ↓
    Manager transfers 20          Customer buys 5
         ↓                                  ↓
    80 units left                    25 units left
```

### When to Transfer
- When shelf stock is LOW (below minimum level)
- When shelf stock is CRITICAL (at or below minimum)
- During slow periods to avoid disrupting customers

### When Alerts Appear
- **Shelf Alert:** "Product X shelf stock is low. Please refill from inventory."
- **Inventory Alert:** "Product X inventory stock is low. Need to reorder from supplier."

---

## 🎯 Common Tasks

### Task 1: Transfer Items to Shelf

1. Go to Shelf Management page
2. Find product with LOW or CRITICAL shelf status
3. Click **"Transfer"** button
4. Enter quantity to transfer
5. (Optional) Add notes
6. Click **"Transfer"**
7. ✅ Done! Shelf stock updated

### Task 2: Check Stock Levels

1. Go to Shelf Management page
2. View the table showing:
   - **Inventory** - Back stock quantity
   - **On Shelf** - Customer area quantity
   - **Total** - Combined quantity
   - **Status** - OK / LOW / CRITICAL

### Task 3: View Alerts

1. Go to Dashboard
2. Look for alert notifications
3. Click on alert to see details
4. Acknowledge when addressed

### Task 4: View Transfer History

1. Go to Shelf Management page
2. Scroll to "Recent Transfers" section
3. See who transferred what and when

---

## 🔴 Status Indicators

| Status | Meaning | Action |
|--------|---------|--------|
| **OK** | Stock is good | No action needed |
| **LOW** | Below reorder level | Plan to transfer soon |
| **CRITICAL** | Below minimum level | Transfer immediately |

---

## 📊 Understanding the Numbers

### Example: Coffee Beans

```
Inventory: 100 units (back storage)
On Shelf: 20 units (customer area)
Total: 120 units

Shelf Min Level: 5
Shelf Reorder Level: 10
```

**Status:** OK (20 > 10)

---

### When Shelf Becomes Low

```
After 3 customers buy:
On Shelf: 17 units (still OK)

After 8 customers buy:
On Shelf: 12 units (still OK)

After 12 customers buy:
On Shelf: 8 units (still OK)

After 15 customers buy:
On Shelf: 5 units (CRITICAL!)
Alert: "Coffee Beans shelf stock is critical. Please refill from inventory."
```

**Action:** Manager transfers 20 units from inventory to shelf

```
After transfer:
Inventory: 80 units
On Shelf: 25 units
Status: OK ✅
```

---

## 🔧 Configuration

### Default Settings
- Shelf Minimum Level: 5 units
- Shelf Reorder Level: 10 units

### Change for Specific Product
Contact admin to update thresholds for high-demand items.

---

## ⚠️ Important Notes

1. **Sales use SHELF stock only**
   - Customers buy from shelf
   - Inventory stays untouched until transfer

2. **Transfers are logged**
   - Every transfer recorded
   - Shows who, what, when
   - Audit trail for compliance

3. **Alerts are automatic**
   - System monitors stock 24/7
   - Alerts appear in dashboard
   - No manual checking needed

4. **Inventory ≠ Shelf**
   - Don't confuse the two
   - Inventory = back storage
   - Shelf = customer display area

---

## 🚨 Troubleshooting

### "Insufficient inventory" error
- **Problem:** Trying to transfer more than available
- **Solution:** Check inventory quantity, transfer less

### Alerts not appearing
- **Problem:** Stock might not be below threshold
- **Solution:** Check shelf_min_level setting

### Transfer not showing in history
- **Problem:** No transfers made yet
- **Solution:** Make a test transfer

### Can't access shelf management
- **Problem:** Not logged in as manager
- **Solution:** Login with manager account

---

## 📱 Mobile Tips

- Shelf Management page is responsive
- Works on tablets and phones
- Use landscape mode for better view

---

## 🎓 Learning Path

1. **Beginner:** Just transfer items when shelf is low
2. **Intermediate:** Monitor alerts and plan transfers
3. **Advanced:** Analyze transfer patterns, optimize thresholds

---

## 📞 Quick Help

**Q: How often should I check shelf stock?**
A: Check at start of shift and after busy periods.

**Q: What if I transfer too much?**
A: Extra stock stays on shelf, customers buy it. No problem.

**Q: What if I transfer too little?**
A: Shelf will run low again soon. You'll get another alert.

**Q: Can I undo a transfer?**
A: No, but you can transfer back to inventory if needed.

**Q: Who sees the alerts?**
A: Only branch managers see alerts.

---

## 🎯 Best Practices

✅ **DO:**
- Check alerts daily
- Transfer during slow hours
- Keep notes on unusual patterns
- Monitor high-demand items closely

❌ **DON'T:**
- Wait until shelf is empty to transfer
- Transfer huge quantities at once
- Ignore critical alerts
- Forget to acknowledge alerts

---

## 📊 Quick Stats

After setup, your system will track:
- Total products in inventory
- Total shelf stock
- Number of transfers
- Alert history
- Stock movement patterns

---

## 🔗 Useful Links

- **Shelf Management:** `/bos/shelf_management.php`
- **Dashboard:** `/dashboard.php`
- **Full Guide:** `SHELF_MANAGEMENT_GUIDE.md`
- **Setup Script:** `setup_shelf_system.php`

---

## ✅ Checklist for First Day

- [ ] Run setup script
- [ ] Login as manager
- [ ] Visit shelf management page
- [ ] Make test transfer
- [ ] Check transfer history
- [ ] View alerts
- [ ] Process a sale
- [ ] Verify shelf stock decreased

---

**You're all set! Start managing your shelf stock like a pro! 🎉**

For detailed information, see `SHELF_MANAGEMENT_GUIDE.md`
