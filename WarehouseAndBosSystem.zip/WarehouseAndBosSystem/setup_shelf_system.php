<?php
/**
 * Shelf Management System Setup
 * Initializes the two-tier inventory system (Inventory + On-Shelf)
 */

require_once 'config.php';

$messages = [];
$errors = [];

// Check if setup is already complete
$check_query = "SHOW COLUMNS FROM branch_inventory LIKE 'on_shelf_quantity'";
$result = mysqli_query($conn, $check_query);

if (mysqli_num_rows($result) > 0) {
    $messages[] = "✓ Shelf management system already initialized";
} else {
    // Step 1: Add columns to branch_inventory
    $alter_queries = [
        "ALTER TABLE branch_inventory ADD COLUMN on_shelf_quantity INT NOT NULL DEFAULT 0 AFTER quantity",
        "ALTER TABLE branch_inventory ADD COLUMN shelf_min_level INT NOT NULL DEFAULT 5 AFTER on_shelf_quantity",
        "ALTER TABLE branch_inventory ADD COLUMN shelf_reorder_level INT NOT NULL DEFAULT 10 AFTER shelf_min_level"
    ];

    foreach ($alter_queries as $query) {
        if (mysqli_query($conn, $query)) {
            $messages[] = "✓ " . substr($query, 0, 50) . "...";
        } else {
            $errors[] = "✗ Failed: " . substr($query, 0, 50) . "... - " . mysqli_error($conn);
        }
    }
}

// Step 2: Create shelf_transfers table
$shelf_transfers_query = "CREATE TABLE IF NOT EXISTS shelf_transfers (
    transfer_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    product_id INT NOT NULL,
    batch_number VARCHAR(50),
    quantity_transferred INT NOT NULL,
    from_location VARCHAR(50),
    to_location VARCHAR(50),
    transferred_by INT NOT NULL,
    transfer_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (transferred_by) REFERENCES users(user_id),
    INDEX idx_branch_product (branch_id, product_id),
    INDEX idx_transfer_date (transfer_date)
)";

if (mysqli_query($conn, $shelf_transfers_query)) {
    $messages[] = "✓ Created shelf_transfers table";
} else {
    if (strpos(mysqli_error($conn), "already exists") === false) {
        $errors[] = "✗ Failed to create shelf_transfers table: " . mysqli_error($conn);
    } else {
        $messages[] = "✓ shelf_transfers table already exists";
    }
}

// Step 3: Create shelf_stock_alerts table
$shelf_alerts_query = "CREATE TABLE IF NOT EXISTS shelf_stock_alerts (
    alert_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    product_id INT NOT NULL,
    alert_type ENUM('shelf_low_stock', 'shelf_critical', 'inventory_low_stock', 'inventory_critical') NOT NULL,
    current_shelf_qty INT,
    current_inventory_qty INT,
    shelf_min_level INT,
    shelf_reorder_level INT,
    inventory_min_level INT,
    inventory_reorder_level INT,
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    acknowledged_by INT,
    acknowledged_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (acknowledged_by) REFERENCES users(user_id),
    INDEX idx_branch_unread (branch_id, is_read),
    INDEX idx_alert_type (alert_type),
    INDEX idx_created (created_at)
)";

if (mysqli_query($conn, $shelf_alerts_query)) {
    $messages[] = "✓ Created shelf_stock_alerts table";
} else {
    if (strpos(mysqli_error($conn), "already exists") === false) {
        $errors[] = "✗ Failed to create shelf_stock_alerts table: " . mysqli_error($conn);
    } else {
        $messages[] = "✓ shelf_stock_alerts table already exists";
    }
}

// Step 4: Create shelf_stock_history table
$shelf_history_query = "CREATE TABLE IF NOT EXISTS shelf_stock_history (
    history_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    product_id INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    quantity_change INT,
    old_shelf_qty INT,
    new_shelf_qty INT,
    old_inventory_qty INT,
    new_inventory_qty INT,
    performed_by INT,
    reference_id INT,
    reference_type VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (performed_by) REFERENCES users(user_id),
    INDEX idx_branch_product (branch_id, product_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at)
)";

if (mysqli_query($conn, $shelf_history_query)) {
    $messages[] = "✓ Created shelf_stock_history table";
} else {
    if (strpos(mysqli_error($conn), "already exists") === false) {
        $errors[] = "✗ Failed to create shelf_stock_history table: " . mysqli_error($conn);
    } else {
        $messages[] = "✓ shelf_stock_history table already exists";
    }
}

// Step 5: Create views
$views = [
    "v_low_shelf_stock" => "CREATE OR REPLACE VIEW v_low_shelf_stock AS
        SELECT 
            bi.inventory_id,
            bi.branch_id,
            bi.product_id,
            p.product_name,
            p.product_code,
            bi.on_shelf_quantity,
            bi.shelf_min_level,
            bi.shelf_reorder_level,
            bi.quantity as inventory_quantity,
            b.branch_name
        FROM branch_inventory bi
        JOIN products p ON bi.product_id = p.product_id
        JOIN branches b ON bi.branch_id = b.branch_id
        WHERE bi.on_shelf_quantity <= bi.shelf_min_level",
    
    "v_low_inventory_stock" => "CREATE OR REPLACE VIEW v_low_inventory_stock AS
        SELECT 
            bi.inventory_id,
            bi.branch_id,
            bi.product_id,
            p.product_name,
            p.product_code,
            bi.quantity as inventory_quantity,
            p.reorder_level,
            p.min_stock_level,
            bi.on_shelf_quantity,
            b.branch_name
        FROM branch_inventory bi
        JOIN products p ON bi.product_id = p.product_id
        JOIN branches b ON bi.branch_id = b.branch_id
        WHERE bi.quantity <= p.min_stock_level",
    
    "v_shelf_stock_status" => "CREATE OR REPLACE VIEW v_shelf_stock_status AS
        SELECT 
            bi.inventory_id,
            bi.branch_id,
            bi.product_id,
            p.product_name,
            p.product_code,
            bi.quantity as inventory_qty,
            bi.on_shelf_quantity as shelf_qty,
            (bi.quantity + bi.on_shelf_quantity) as total_qty,
            bi.shelf_min_level,
            bi.shelf_reorder_level,
            p.reorder_level as inventory_reorder_level,
            p.min_stock_level as inventory_min_level,
            CASE 
                WHEN bi.on_shelf_quantity <= bi.shelf_min_level THEN 'CRITICAL'
                WHEN bi.on_shelf_quantity <= bi.shelf_reorder_level THEN 'LOW'
                ELSE 'OK'
            END as shelf_status,
            CASE 
                WHEN bi.quantity <= p.min_stock_level THEN 'CRITICAL'
                WHEN bi.quantity <= p.reorder_level THEN 'LOW'
                ELSE 'OK'
            END as inventory_status,
            b.branch_name
        FROM branch_inventory bi
        JOIN products p ON bi.product_id = p.product_id
        JOIN branches b ON bi.branch_id = b.branch_id"
];

foreach ($views as $view_name => $view_query) {
    if (mysqli_query($conn, $view_query)) {
        $messages[] = "✓ Created view: $view_name";
    } else {
        $errors[] = "✗ Failed to create view $view_name: " . mysqli_error($conn);
    }
}

// Step 6: Update alerts table to include new alert types
$alter_alerts = "ALTER TABLE alerts MODIFY alert_type ENUM('low_stock', 'expiry_warning', 'expired', 'reorder_point', 'discrepancy', 'system', 'shelf_low_stock', 'shelf_critical', 'inventory_low_stock', 'inventory_critical') NOT NULL";

if (mysqli_query($conn, $alter_alerts)) {
    $messages[] = "✓ Updated alerts table with new alert types";
} else {
    if (strpos(mysqli_error($conn), "Duplicate") === false) {
        $errors[] = "✗ Failed to update alerts table: " . mysqli_error($conn);
    } else {
        $messages[] = "✓ Alerts table already has new alert types";
    }
}

// Step 7: Initialize on_shelf_quantity with sample data (if empty)
$check_shelf = "SELECT COUNT(*) as count FROM branch_inventory WHERE on_shelf_quantity > 0";
$shelf_result = mysqli_query($conn, $check_shelf);
$shelf_row = mysqli_fetch_assoc($shelf_result);

if ($shelf_row['count'] == 0) {
    // Initialize with 50% of inventory as shelf stock
    $init_query = "UPDATE branch_inventory SET on_shelf_quantity = FLOOR(quantity * 0.5)";
    if (mysqli_query($conn, $init_query)) {
        $messages[] = "✓ Initialized shelf stock with 50% of inventory";
    } else {
        $errors[] = "✗ Failed to initialize shelf stock: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shelf Management System Setup</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            max-width: 600px;
            width: 100%;
            padding: 40px;
        }

        h1 {
            color: #333;
            margin-bottom: 10px;
            text-align: center;
        }

        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }

        .messages {
            margin-bottom: 20px;
        }

        .message-item {
            padding: 12px;
            margin-bottom: 8px;
            border-radius: 5px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .message-item.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message-item.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .icon {
            font-size: 16px;
        }

        .status-summary {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin-top: 30px;
            text-align: center;
        }

        .status-summary h3 {
            color: #333;
            margin-bottom: 10px;
        }

        .status-summary p {
            color: #666;
            font-size: 14px;
            margin-bottom: 15px;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #764ba2;
        }

        .features {
            margin-top: 30px;
            padding-top: 30px;
            border-top: 1px solid #ddd;
        }

        .features h3 {
            color: #333;
            margin-bottom: 15px;
        }

        .feature-list {
            list-style: none;
        }

        .feature-list li {
            padding: 8px 0;
            color: #666;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .feature-list li:before {
            content: "✓";
            color: #28a745;
            font-weight: bold;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📦 Shelf Management System</h1>
        <p class="subtitle">Two-Tier Inventory System Setup</p>

        <div class="messages">
            <?php foreach ($messages as $message): ?>
                <div class="message-item success">
                    <span class="icon">✓</span>
                    <span><?php echo htmlspecialchars($message); ?></span>
                </div>
            <?php endforeach; ?>

            <?php foreach ($errors as $error): ?>
                <div class="message-item error">
                    <span class="icon">✗</span>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="status-summary">
            <h3><?php echo empty($errors) ? '✓ Setup Complete!' : '⚠ Setup Completed with Issues'; ?></h3>
            <p><?php echo count($messages); ?> operations successful<?php echo !empty($errors) ? ', ' . count($errors) . ' issues found' : ''; ?></p>
            <a href="dashboard.php" class="btn">Go to Dashboard</a>
        </div>

        <div class="features">
            <h3>System Features Enabled:</h3>
            <ul class="feature-list">
                <li>Separate Inventory and On-Shelf stock tracking</li>
                <li>Automatic shelf-to-inventory transfers</li>
                <li>Dual-level stock alerts (Inventory & Shelf)</li>
                <li>Transfer history and audit trail</li>
                <li>Low stock notifications for managers</li>
                <li>Shelf management dashboard</li>
            </ul>
        </div>
    </div>
</body>
</html>
