<?php
// Sales Report
$summary_query = "SELECT 
                    COUNT(*) as total_transactions,
                    SUM(total_amount) as total_sales,
                    SUM(discount) as total_discounts,
                    SUM(tax) as total_tax,
                    AVG(total_amount) as average_sale
                  FROM sales_transactions
                  WHERE sale_date BETWEEN '$date_from' AND '$date_to'";
$summary = mysqli_fetch_assoc(mysqli_query($conn, $summary_query));

// Daily sales breakdown
$daily_query = "SELECT 
                    sale_date,
                    COUNT(*) as transactions,
                    SUM(total_amount) as daily_sales
                FROM sales_transactions
                WHERE sale_date BETWEEN '$date_from' AND '$date_to'
                GROUP BY sale_date
                ORDER BY sale_date DESC";
$daily_sales = mysqli_query($conn, $daily_query);

// Top selling products
$products_query = "SELECT 
                        p.product_name,
                        SUM(si.quantity) as total_quantity,
                        SUM(si.subtotal) as total_revenue,
                        COUNT(DISTINCT st.transaction_id) as times_sold
                   FROM sales_items si
                   JOIN sales_transactions st ON si.transaction_id = st.transaction_id
                   JOIN products p ON si.product_id = p.product_id
                   WHERE st.sale_date BETWEEN '$date_from' AND '$date_to'
                   GROUP BY si.product_id
                   ORDER BY total_revenue DESC
                   LIMIT 10";
$top_products = mysqli_query($conn, $products_query);
?>

<div class="report-container">
    <div class="report-header">
        <h2>Sales Report</h2>
        <p>Period: <?php echo date('M d, Y', strtotime($date_from)); ?> - <?php echo date('M d, Y', strtotime($date_to)); ?></p>
    </div>
    
    <!-- Summary Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon blue">💰</div>
            <div class="stat-info">
                <h3>$<?php echo formatMoney($summary['total_sales'] ?? 0); ?></h3>
                <p>Total Sales</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon green">📊</div>
            <div class="stat-info">
                <h3><?php echo $summary['total_transactions'] ?? 0; ?></h3>
                <p>Total Transactions</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon orange">📈</div>
            <div class="stat-info">
                <h3>$<?php echo formatMoney($summary['average_sale'] ?? 0); ?></h3>
                <p>Average Sale</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon red">🎫</div>
            <div class="stat-info">
                <h3>$<?php echo formatMoney($summary['total_discounts'] ?? 0); ?></h3>
                <p>Total Discounts</p>
            </div>
        </div>
    </div>
    
    <!-- Daily Sales -->
    <div class="report-section">
        <h3>Daily Sales Breakdown</h3>
        <table class="data-table" id="reportTable">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Transactions</th>
                    <th>Total Sales</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($day = mysqli_fetch_assoc($daily_sales)): ?>
                    <tr>
                        <td><?php echo date('M d, Y', strtotime($day['sale_date'])); ?></td>
                        <td><?php echo $day['transactions']; ?></td>
                        <td>$<?php echo formatMoney($day['daily_sales']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Top Products -->
    <div class="report-section">
        <h3>Top 10 Selling Products</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Quantity Sold</th>
                    <th>Times Sold</th>
                    <th>Revenue</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($product = mysqli_fetch_assoc($top_products)): ?>
                    <tr>
                        <td><?php echo $product['product_name']; ?></td>
                        <td><?php echo $product['total_quantity']; ?></td>
                        <td><?php echo $product['times_sold']; ?></td>
                        <td>$<?php echo formatMoney($product['total_revenue']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
    .report-container {
        background: white;
        border-radius: 8px;
        padding: 30px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    
    .report-header {
        margin-bottom: 30px;
        padding-bottom: 20px;
        border-bottom: 2px solid var(--border-color);
    }
    
    .report-header h2 {
        font-size: 24px;
        margin-bottom: 8px;
    }
    
    .report-section {
        margin-top: 30px;
    }
    
    .report-section h3 {
        font-size: 18px;
        margin-bottom: 15px;
        color: var(--dark-color);
    }
</style>
