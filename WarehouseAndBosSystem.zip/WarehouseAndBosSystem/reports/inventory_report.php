<?php
// Current Stock Report
$stock_query = "SELECT 
                    p.product_code,
                    p.product_name,
                    c.category_name,
                    SUM(bi.quantity) as total_quantity,
                    p.unit,
                    p.reorder_level,
                    bi.selling_price,
                    SUM(bi.quantity * bi.cost_price) as total_value
                FROM branch_inventory bi
                JOIN products p ON bi.product_id = p.product_id
                JOIN categories c ON p.category_id = c.category_id
                WHERE 1=1
                GROUP BY p.product_id
                ORDER BY total_value DESC";
$stock_items = mysqli_query($conn, $stock_query);

// Summary
$total_value = 0;
$low_stock_count = 0;
$out_of_stock = 0;
mysqli_data_seek($stock_items, 0);
while ($item = mysqli_fetch_assoc($stock_items)) {
    $total_value += $item['total_value'];
    if ($item['total_quantity'] <= $item['reorder_level']) $low_stock_count++;
    if ($item['total_quantity'] == 0) $out_of_stock++;
}
mysqli_data_seek($stock_items, 0);

$total_products = mysqli_num_rows($stock_items);
?>

<div class="report-container">
    <div class="report-header">
        <h2>Inventory Report</h2>
        <p>As of: <?php echo date('M d, Y'); ?></p>
    </div>
    
    <!-- Summary Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon blue">📦</div>
            <div class="stat-info">
                <h3><?php echo $total_products; ?></h3>
                <p>Total Products</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon green">💵</div>
            <div class="stat-info">
                <h3>$<?php echo formatMoney($total_value); ?></h3>
                <p>Total Inventory Value</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon orange">⚠️</div>
            <div class="stat-info">
                <h3><?php echo $low_stock_count; ?></h3>
                <p>Low Stock Items</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon red">❌</div>
            <div class="stat-info">
                <h3><?php echo $out_of_stock; ?></h3>
                <p>Out of Stock</p>
            </div>
        </div>
    </div>
    
    <!-- Stock Details -->
    <div class="report-section">
        <h3>Current Stock Details</h3>
        <table class="data-table" id="reportTable">
            <thead>
                <tr>
                    <th>Product Code</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Current Stock</th>
                    <th>Unit</th>
                    <th>Reorder Level</th>
                    <th>Unit Price</th>
                    <th>Total Value</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($item = mysqli_fetch_assoc($stock_items)): ?>
                    <tr>
                        <td><?php echo $item['product_code']; ?></td>
                        <td><?php echo $item['product_name']; ?></td>
                        <td><?php echo $item['category_name']; ?></td>
                        <td><?php echo $item['total_quantity']; ?></td>
                        <td><?php echo $item['unit']; ?></td>
                        <td><?php echo $item['reorder_level']; ?></td>
                        <td>$<?php echo formatMoney($item['selling_price']); ?></td>
                        <td>$<?php echo formatMoney($item['total_value']); ?></td>
                        <td>
                            <?php if ($item['total_quantity'] == 0): ?>
                                <span class="badge badge-cancelled">Out of Stock</span>
                            <?php elseif ($item['total_quantity'] <= $item['reorder_level']): ?>
                                <span class="badge badge-pending">Low Stock</span>
                            <?php else: ?>
                                <span class="badge badge-completed">In Stock</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
