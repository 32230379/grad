<?php
require_once 'config.php';

echo "<h2>Cleaning Up Duplicate Orders</h2>";

// Get all orders
$result = mysqli_query($conn, "SELECT order_id, order_number, barcode FROM order_requests ORDER BY order_id");

$barcodes = [];
$duplicates = [];

while ($row = mysqli_fetch_assoc($result)) {
    if (isset($barcodes[$row['barcode']])) {
        $duplicates[] = $row['order_id'];
    } else {
        $barcodes[$row['barcode']] = $row['order_id'];
    }
}

if (empty($duplicates)) {
    echo "<p style='color: green;'>✓ No duplicate barcodes found</p>";
} else {
    echo "<p style='color: orange;'>Found " . count($duplicates) . " duplicate orders. Deleting...</p>";
    
    foreach ($duplicates as $order_id) {
        // Delete order items first
        mysqli_query($conn, "DELETE FROM order_request_items WHERE order_id = $order_id");
        
        // Delete order
        if (mysqli_query($conn, "DELETE FROM order_requests WHERE order_id = $order_id")) {
            echo "<p style='color: green;'>✓ Deleted duplicate order ID: $order_id</p>";
        } else {
            echo "<p style='color: red;'>✗ Error deleting order $order_id: " . mysqli_error($conn) . "</p>";
        }
    }
}

echo "<hr>";
echo "<h3>Current Orders:</h3>";
$result = mysqli_query($conn, "SELECT order_id, order_number, barcode, status FROM order_requests");

if (mysqli_num_rows($result) > 0) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>Order ID</th><th>Order Number</th><th>Barcode</th><th>Status</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['order_id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['order_number']) . "</td>";
        echo "<td>" . htmlspecialchars($row['barcode']) . "</td>";
        echo "<td>" . htmlspecialchars($row['status']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No orders in database</p>";
}

echo "<hr>";
echo "<p><a href='dashboard.php'>← Back to Dashboard</a></p>";
?>
