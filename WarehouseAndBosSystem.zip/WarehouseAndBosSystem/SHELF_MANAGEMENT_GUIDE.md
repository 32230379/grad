# Shelf Management System - Complete Guide

## Overview

The Shelf Management System implements a **two-tier inventory model** that separates stock into two distinct areas:

1. **Inventory (Back Stock)** - Products stored in the warehouse/storage area
2. **On-Shelf (Display Stock)** - Products available for customers to purchase

This system provides automatic alerts when either stock level falls below configured thresholds.

---

## System Architecture

### Database Tables

#### 1. **branch_inventory** (Modified)
Added three new columns:
- `on_shelf_quantity` - Number of items currently on the shelf
- `shelf_min_level` - Minimum shelf stock before alert (default: 5)
- `shelf_reorder_level` - Reorder threshold for shelf stock (default: 10)

**Example:**
```
Product: Coffee Beans
- quantity (inventory): 100 units
- on_shelf_quantity: 30 units
- shelf_min_level: 5
- shelf_reorder_level: 10
```

#### 2. **shelf_transfers** (New)
Tracks all movements from inventory to shelf.

**Columns:**
- `transfer_id` - Unique identifier
- `branch_id` - Which branch
- `product_id` - Which product
- `quantity_transferred` - How many units
- `from_location` - Source location (e.g., "A1")
- `to_location` - Destination (always "SHELF")
- `transferred_by` - User who performed transfer
- `transfer_date` - When transfer occurred
- `notes` - Optional notes

#### 3. **shelf_stock_alerts** (New)
Stores all shelf and inventory stock alerts.

**Alert Types:**
- `shelf_low_stock` - Shelf stock below reorder level
- `shelf_critical` - Shelf stock at or below minimum
- `inventory_low_stock` - Inventory below reorder level
- `inventory_critical` - Inventory at or below minimum

**Priorities:**
- `critical` - Immediate action required
- `high` - Should be addressed soon
- `medium` - Monitor situation
- `low` - Informational

#### 4. **shelf_stock_history** (New)
Audit trail for all shelf stock changes.

**Actions Tracked:**
- `transfer_to_shelf` - Items moved from inventory to shelf
- `sale` - Items sold from shelf
- `adjustment` - Manual inventory adjustments
- `return` - Items returned to inventory

---

## Workflow

### 1. Stock Transfer (Inventory → Shelf)

**When:** Manager needs to refill shelf stock

**Process:**
```
Manager views Shelf Management page
    ↓
Sees product with low shelf stock
    ↓
Clicks "Transfer" button
    ↓
Enters quantity to transfer
    ↓
System checks if inventory has enough stock
    ↓
If YES: Updates both quantities
        - inventory: -X units
        - on_shelf: +X units
        - Creates shelf_transfers record
        - Creates shelf_stock_history record
        - Checks if inventory now low, creates alert if needed
        
If NO: Shows error message
```

**API Endpoint:** `POST /api/shelf_transfer.php`

**Request:**
```json
{
    "product_id": 1,
    "quantity": 20,
    "notes": "Restocking for afternoon rush"
}
```

**Response:**
```json
{
    "success": true,
    "message": "Transfer completed successfully",
    "transfer_id": 123,
    "new_inventory_qty": 80,
    "new_shelf_qty": 50
}
```

---

### 2. Customer Purchase (Shelf → Sold)

**When:** Cashier processes a sale

**Process:**
```
Customer takes items to cashier
    ↓
Cashier scans products
    ↓
Customer pays
    ↓
System processes checkout
    ↓
For each item:
    - Checks if enough shelf stock
    - Deducts from on_shelf_quantity ONLY
    - Creates sales_items record
    - Creates shelf_stock_history record
    - Checks if shelf now low
    - If low: Creates shelf_stock_alert
    
Transaction complete
```

**Key Point:** Sales deduct from **shelf stock only**, not inventory!

---

### 3. Alert Generation

#### Shelf Stock Alert
**Triggered when:**
- `on_shelf_quantity <= shelf_min_level`

**Example:**
```
Product: Coffee Beans
- Current shelf: 3 units
- Minimum level: 5 units
- Alert: "CRITICAL - Shelf stock is low. Please refill from inventory."
```

#### Inventory Stock Alert
**Triggered when:**
- `quantity <= min_stock_level`

**Example:**
```
Product: Coffee Beans
- Current inventory: 2 units
- Minimum level: 5 units
- Alert: "CRITICAL - Inventory stock is low. Need to reorder from supplier."
```

---

## User Interfaces

### 1. Shelf Management Dashboard
**Location:** `/bos/shelf_management.php`

**Features:**
- View all products with current inventory and shelf quantities
- See status of each product (OK, LOW, CRITICAL)
- Transfer items from inventory to shelf
- View transfer history
- Alert summary cards

**Access:** Branch Managers only

### 2. Alert Management
**Location:** `/api/get_alerts.php`

**Features:**
- Retrieve all unread alerts
- Filter by type (shelf, inventory, all)
- Sort by priority
- Acknowledge/dismiss alerts

**Access:** Branch Managers only

---

## Configuration

### Default Values

Each product can have custom shelf thresholds:

```php
// In shelf_management.php
$shelf_min_level = 5;        // Alert when at or below this
$shelf_reorder_level = 10;   // Warning when at or below this
```

### Customizing Thresholds

To set custom thresholds per product:

```sql
UPDATE branch_inventory 
SET shelf_min_level = 10, 
    shelf_reorder_level = 15
WHERE product_id = 1;
```

---

## API Endpoints

### 1. Get Shelf Stock Status
```
GET /api/shelf_transfer.php?action=get_status&product_id=1
```

**Response:**
```json
{
    "success": true,
    "data": {
        "product_id": 1,
        "product_name": "Coffee Beans",
        "inventory_qty": 100,
        "shelf_qty": 30,
        "shelf_min_level": 5,
        "shelf_reorder_level": 10
    }
}
```

### 2. Get All Shelf Status
```
GET /api/shelf_transfer.php?action=get_all
```

**Response:**
```json
{
    "success": true,
    "data": [
        {
            "product_id": 1,
            "product_name": "Coffee Beans",
            "inventory_qty": 100,
            "shelf_qty": 30,
            "shelf_status": "OK",
            "inventory_status": "OK"
        },
        ...
    ]
}
```

### 3. Get Transfer History
```
GET /api/shelf_transfer.php?action=get_transfers&product_id=1&limit=50
```

### 4. Create Transfer
```
POST /api/shelf_transfer.php
Content-Type: application/json

{
    "product_id": 1,
    "quantity": 20,
    "notes": "Restocking"
}
```

### 5. Get Alerts
```
GET /api/get_alerts.php?type=all&limit=20
```

**Types:** `all`, `shelf`, `inventory`, `unread`

### 6. Acknowledge Alert
```
POST /api/acknowledge_alert.php
Content-Type: application/json

{
    "alert_id": 123,
    "action": "acknowledge"
}
```

---

## Database Views

### v_low_shelf_stock
Shows all products with low shelf stock.

```sql
SELECT * FROM v_low_shelf_stock WHERE branch_id = 1;
```

### v_low_inventory_stock
Shows all products with low inventory stock.

```sql
SELECT * FROM v_low_inventory_stock WHERE branch_id = 1;
```

### v_shelf_stock_status
Complete status of all products (inventory + shelf).

```sql
SELECT * FROM v_shelf_stock_status WHERE branch_id = 1;
```

---

## Setup Instructions

### 1. Run Setup Script
```
Visit: http://localhost/WarehouseAndBosSystem/setup_shelf_system.php
```

This will:
- Add new columns to branch_inventory
- Create shelf_transfers table
- Create shelf_stock_alerts table
- Create shelf_stock_history table
- Create database views
- Initialize shelf stock with 50% of inventory

### 2. Verify Setup
```sql
-- Check if columns exist
SHOW COLUMNS FROM branch_inventory;

-- Check if tables exist
SHOW TABLES LIKE 'shelf_%';

-- Check if views exist
SHOW FULL TABLES WHERE TABLE_TYPE LIKE 'VIEW';
```

### 3. Test the System
1. Go to `/bos/shelf_management.php`
2. Click "Transfer" on a product
3. Enter quantity and submit
4. Verify transfer appears in history
5. Check alerts in dashboard

---

## Monitoring & Alerts

### Alert Flow

```
Low Stock Detected
    ↓
Alert Created in shelf_stock_alerts
    ↓
Alert appears in manager dashboard
    ↓
Manager receives notification
    ↓
Manager acknowledges alert
    ↓
Alert marked as read
```

### Alert Deduplication

The system prevents duplicate alerts:
- Only one alert per product per alert type per hour
- Prevents alert spam
- Reduces database clutter

---

## Reports & Analytics

### Transfer Report
```sql
SELECT 
    p.product_name,
    COUNT(*) as transfer_count,
    SUM(st.quantity_transferred) as total_transferred,
    MAX(st.transfer_date) as last_transfer
FROM shelf_transfers st
JOIN products p ON st.product_id = p.product_id
WHERE st.branch_id = 1
    AND st.transfer_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY st.product_id
ORDER BY total_transferred DESC;
```

### Stock History Report
```sql
SELECT 
    p.product_name,
    ssh.action,
    COUNT(*) as count,
    SUM(ssh.quantity_change) as total_change
FROM shelf_stock_history ssh
JOIN products p ON ssh.product_id = p.product_id
WHERE ssh.branch_id = 1
    AND ssh.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY ssh.product_id, ssh.action;
```

---

## Troubleshooting

### Issue: "Insufficient inventory" error on transfer

**Cause:** Inventory doesn't have enough stock

**Solution:**
1. Check current inventory quantity
2. Receive more stock from supplier
3. Try transfer again

### Issue: Alerts not appearing

**Cause:** Stock levels might not be below thresholds

**Solution:**
1. Check shelf_min_level and shelf_reorder_level values
2. Manually adjust thresholds if needed:
   ```sql
   UPDATE branch_inventory 
   SET shelf_min_level = 3 
   WHERE product_id = 1;
   ```

### Issue: Transfer history not showing

**Cause:** No transfers have been made yet

**Solution:**
1. Make a test transfer
2. Check shelf_transfers table:
   ```sql
   SELECT * FROM shelf_transfers LIMIT 10;
   ```

---

## Best Practices

1. **Set Appropriate Thresholds**
   - shelf_min_level: Minimum units before critical alert
   - shelf_reorder_level: Units to trigger refill reminder
   - Example: min=5, reorder=10

2. **Regular Transfers**
   - Transfer items during low-traffic hours
   - Batch transfers to reduce database load
   - Add notes for audit trail

3. **Monitor Alerts**
   - Check alerts daily
   - Acknowledge alerts promptly
   - Investigate recurring low stock issues

4. **Audit Trail**
   - Review transfer history regularly
   - Check shelf_stock_history for discrepancies
   - Investigate unusual patterns

5. **Inventory Counts**
   - Perform physical counts weekly
   - Reconcile with system counts
   - Adjust if discrepancies found

---

## Security

- Only managers can access shelf management
- All transfers logged with user ID
- All changes tracked in history table
- Alerts require authentication
- API endpoints require login

---

## Performance Considerations

- Indexes on branch_id, product_id, transfer_date
- Views use indexed columns
- Alert deduplication prevents duplicate queries
- History table archived after 90 days (optional)

---

## Future Enhancements

- Email notifications for critical alerts
- SMS alerts for managers
- Automatic reorder suggestions
- Predictive stock analysis
- Mobile app integration
- Barcode scanning for transfers
- Multi-location shelf management

---

## Support

For issues or questions:
1. Check this guide
2. Review database logs
3. Check activity_logs table
4. Contact system administrator

---

**Last Updated:** 2024
**Version:** 1.0
