<?php
require_once 'config.php';

echo "Fixing roles...\n";

// Fix manager role
$update1 = mysqli_query($conn, "UPDATE users SET role = 'manager' WHERE username = 'manager'");
echo "Updated manager: " . ($update1 ? "OK" : "FAILED") . "\n";

// Fix admin role
$update2 = mysqli_query($conn, "UPDATE users SET role = 'admin' WHERE username = 'admin'");
echo "Updated admin: " . ($update2 ? "OK" : "FAILED") . "\n";

// Verify
echo "\nVerifying:\n";
$result = mysqli_query($conn, "SELECT user_id, username, role, is_active FROM users");
while($row = mysqli_fetch_assoc($result)) {
    echo "ID: {$row['user_id']}, Username: {$row['username']}, Role: [{$row['role']}], Active: " . ($row['is_active'] ? 'Yes' : 'No') . "\n";
}
?>
