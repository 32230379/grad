-- =============================================
-- MIGRATION SCRIPT: Add Shelf Stock Management
-- =============================================
-- This script adds support for two-tier inventory:
-- 1. Inventory (back stock in warehouse)
-- 2. On-Shelf (products available for customers)

-- =============================================
-- ALTER BRANCH_INVENTORY TABLE
-- =============================================

ALTER TABLE branch_inventory ADD COLUMN IF NOT EXISTS on_shelf_quantity INT NOT NULL DEFAULT 0 AFTER quantity;
ALTER TABLE branch_inventory ADD COLUMN IF NOT EXISTS shelf_min_level INT NOT NULL DEFAULT 5 AFTER on_shelf_quantity;
ALTER TABLE branch_inventory ADD COLUMN IF NOT EXISTS shelf_reorder_level INT NOT NULL DEFAULT 10 AFTER shelf_min_level;

-- =============================================
-- CREATE SHELF TRANSFERS TABLE
-- =============================================
-- Tracks all movements from inventory to shelf

CREATE TABLE IF NOT EXISTS shelf_transfers (
    transfer_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    product_id INT NOT NULL,
    batch_number VARCHAR(50),
    quantity_transferred INT NOT NULL,
    from_location VARCHAR(50),
    to_location VARCHAR(50),
    transferred_by INT NOT NULL,
    transfer_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (transferred_by) REFERENCES users(user_id),
    INDEX idx_branch_product (branch_id, product_id),
    INDEX idx_transfer_date (transfer_date)
);

-- =============================================
-- CREATE SHELF STOCK ALERTS TABLE
-- =============================================
-- Separate tracking for shelf stock alerts

CREATE TABLE IF NOT EXISTS shelf_stock_alerts (
    alert_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    product_id INT NOT NULL,
    alert_type ENUM('shelf_low_stock', 'shelf_critical', 'inventory_low_stock', 'inventory_critical') NOT NULL,
    current_shelf_qty INT,
    current_inventory_qty INT,
    shelf_min_level INT,
    shelf_reorder_level INT,
    inventory_min_level INT,
    inventory_reorder_level INT,
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    acknowledged_by INT,
    acknowledged_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (acknowledged_by) REFERENCES users(user_id),
    INDEX idx_branch_unread (branch_id, is_read),
    INDEX idx_alert_type (alert_type),
    INDEX idx_created (created_at)
);

-- =============================================
-- CREATE SHELF STOCK HISTORY TABLE
-- =============================================
-- Audit trail for shelf stock changes

CREATE TABLE IF NOT EXISTS shelf_stock_history (
    history_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    product_id INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    quantity_change INT,
    old_shelf_qty INT,
    new_shelf_qty INT,
    old_inventory_qty INT,
    new_inventory_qty INT,
    performed_by INT,
    reference_id INT,
    reference_type VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (performed_by) REFERENCES users(user_id),
    INDEX idx_branch_product (branch_id, product_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at)
);

-- =============================================
-- UPDATE ALERTS TABLE
-- =============================================
-- Add new alert types for shelf stock

ALTER TABLE alerts MODIFY alert_type ENUM('low_stock', 'expiry_warning', 'expired', 'reorder_point', 'discrepancy', 'system', 'shelf_low_stock', 'shelf_critical', 'inventory_low_stock', 'inventory_critical') NOT NULL;

-- =============================================
-- CREATE VIEW FOR LOW SHELF STOCK
-- =============================================

CREATE OR REPLACE VIEW v_low_shelf_stock AS
SELECT 
    bi.inventory_id,
    bi.branch_id,
    bi.product_id,
    p.product_name,
    p.product_code,
    bi.on_shelf_quantity,
    bi.shelf_min_level,
    bi.shelf_reorder_level,
    bi.quantity as inventory_quantity,
    b.branch_name
FROM branch_inventory bi
JOIN products p ON bi.product_id = p.product_id
JOIN branches b ON bi.branch_id = b.branch_id
WHERE bi.on_shelf_quantity <= bi.shelf_min_level
AND p.is_active = TRUE;

-- =============================================
-- CREATE VIEW FOR LOW INVENTORY STOCK
-- =============================================

CREATE OR REPLACE VIEW v_low_inventory_stock AS
SELECT 
    bi.inventory_id,
    bi.branch_id,
    bi.product_id,
    p.product_name,
    p.product_code,
    bi.quantity as inventory_quantity,
    p.reorder_level,
    p.min_stock_level,
    bi.on_shelf_quantity,
    b.branch_name
FROM branch_inventory bi
JOIN products p ON bi.product_id = p.product_id
JOIN branches b ON bi.branch_id = b.branch_id
WHERE bi.quantity <= p.min_stock_level
AND p.is_active = TRUE;

-- =============================================
-- CREATE VIEW FOR SHELF STOCK STATUS
-- =============================================

CREATE OR REPLACE VIEW v_shelf_stock_status AS
SELECT 
    bi.inventory_id,
    bi.branch_id,
    bi.product_id,
    p.product_name,
    p.product_code,
    bi.quantity as inventory_qty,
    bi.on_shelf_quantity as shelf_qty,
    (bi.quantity + bi.on_shelf_quantity) as total_qty,
    bi.shelf_min_level,
    bi.shelf_reorder_level,
    p.reorder_level as inventory_reorder_level,
    p.min_stock_level as inventory_min_level,
    CASE 
        WHEN bi.on_shelf_quantity <= bi.shelf_min_level THEN 'CRITICAL'
        WHEN bi.on_shelf_quantity <= bi.shelf_reorder_level THEN 'LOW'
        ELSE 'OK'
    END as shelf_status,
    CASE 
        WHEN bi.quantity <= p.min_stock_level THEN 'CRITICAL'
        WHEN bi.quantity <= p.reorder_level THEN 'LOW'
        ELSE 'OK'
    END as inventory_status,
    b.branch_name
FROM branch_inventory bi
JOIN products p ON bi.product_id = p.product_id
JOIN branches b ON bi.branch_id = b.branch_id
WHERE p.is_active = TRUE;
