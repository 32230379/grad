<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();

// Allow both managers and admins
$user = getUserInfo();
if ($user['role'] !== 'manager' && $user['role'] !== 'admin') {
    die('Access denied. Only managers and admins can view stock orders.');
}
$branch_id = $_SESSION['branch_id'] ?? 1;

// Get branch info
$branch_query = mysqli_query($conn, "SELECT branch_name FROM branches WHERE branch_id = $branch_id");
$branch = mysqli_fetch_assoc($branch_query);

// Get all orders for this branch
$orders_query = "SELECT o.*, u.full_name as requested_by_name, COUNT(ori.item_id) as item_count
                 FROM order_requests o
                 JOIN users u ON o.requested_by = u.user_id
                 LEFT JOIN order_request_items ori ON o.order_id = ori.order_id
                 WHERE o.branch_id = $branch_id
                 GROUP BY o.order_id
                 ORDER BY o.order_date DESC";

$orders_result = mysqli_query($conn, $orders_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History - Manager</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .navbar {
            background: white;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-left {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .navbar-right {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .btn {
            display: inline-block;
            padding: 10px 16px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn:hover {
            background: #5568d3;
        }

        .btn-secondary {
            background: #95a5a6;
        }

        .btn-secondary:hover {
            background: #7f8c8d;
        }

        .btn-danger {
            background: #e74c3c;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0 15px;
            border-right: 1px solid #eee;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 32px;
            margin-bottom: 5px;
        }

        .header p {
            font-size: 16px;
            opacity: 0.9;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }

        .card h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        .orders-table {
            width: 100%;
            border-collapse: collapse;
        }

        .orders-table thead {
            background: #f9f9f9;
            border-bottom: 2px solid #667eea;
        }

        .orders-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            font-size: 13px;
            text-transform: uppercase;
        }

        .orders-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }

        .orders-table tbody tr:hover {
            background: #f9f9f9;
        }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-confirmed {
            background: #d4edda;
            color: #155724;
        }

        .status-shipped {
            background: #d1ecf1;
            color: #0c5460;
        }

        .status-delivered {
            background: #d4edda;
            color: #155724;
        }

        .priority-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .priority-low {
            background: #d1ecf1;
            color: #0c5460;
        }

        .priority-normal {
            background: #d4edda;
            color: #155724;
        }

        .priority-high {
            background: #fff3cd;
            color: #856404;
        }

        .priority-urgent {
            background: #f8d7da;
            color: #721c24;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
        }

        .no-data {
            text-align: center;
            padding: 40px;
            color: #999;
        }

        .no-data-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .stat-card h3 {
            font-size: 28px;
            margin-bottom: 5px;
        }

        .stat-card p {
            font-size: 12px;
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <?php if (isAdmin()) { include '../admin/navbar.php'; } else { ?>
        <div style="background: white; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); padding: 15px 20px; margin-bottom: 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                <a href="../dashboard.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📊 Dashboard</a>
                <a href="order_request.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📦 Create Order</a>
                <a href="order_history.php" class="btn" style="background: #667eea; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📋 Order History</a>
                <a href="../bos/inventory.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📦 Inventory</a>
                <a href="../bos/reports.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📈 Reports</a>
            </div>
            <div style="display: flex; gap: 10px; align-items: center;">
                <div style="display: flex; align-items: center; gap: 10px; padding: 0 15px; border-right: 1px solid #eee;">
                    <div>
                        <strong style="color: #333;"><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                        <small style="color: #999;"><?php echo ucfirst($user['role']); ?></small>
                    </div>
                </div>
                <a href="../logout.php" class="btn" style="background: #e74c3c; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">🚪 Logout</a>
            </div>
        </div>
        <?php } ?>

        <div class="header">
            <h1>📋 Order History</h1>
            <p>View all orders sent to the warehouse from <strong><?php echo htmlspecialchars($branch['branch_name']); ?></strong></p>
        </div>

        <?php
        // Calculate statistics
        $pending_count = 0;
        $confirmed_count = 0;
        $delivered_count = 0;
        
        $temp_result = mysqli_query($conn, "SELECT status, COUNT(*) as count FROM order_requests WHERE branch_id = $branch_id GROUP BY status");
        while ($row = mysqli_fetch_assoc($temp_result)) {
            if ($row['status'] == 'pending') $pending_count = $row['count'];
            if ($row['status'] == 'confirmed') $confirmed_count = $row['count'];
            if ($row['status'] == 'delivered') $delivered_count = $row['count'];
        }
        ?>

        <div class="stats">
            <div class="stat-card">
                <h3><?php echo $pending_count; ?></h3>
                <p>Pending Orders</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $confirmed_count; ?></h3>
                <p>Confirmed Orders</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $delivered_count; ?></h3>
                <p>Delivered Orders</p>
            </div>
        </div>

        <div class="card">
            <h2>All Orders</h2>

            <?php if (mysqli_num_rows($orders_result) > 0): ?>
                <div class="table-wrapper">
                    <table class="orders-table">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Barcode</th>
                                <th>Requested By</th>
                                <th>Items</th>
                                <th>Item Status</th>
                                <th>Status</th>
                                <th>Order Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($order = mysqli_fetch_assoc($orders_result)): ?>
                                <?php
                                // Get item statuses for this order if it has been received
                                $item_statuses = [];
                                $receipt_query = "SELECT ri.status, COUNT(*) as count 
                                                FROM receipt_items ri
                                                JOIN order_receipts r ON ri.receipt_id = r.receipt_id
                                                WHERE r.order_id = {$order['order_id']}
                                                GROUP BY ri.status";
                                $receipt_result = mysqli_query($conn, $receipt_query);
                                while ($item = mysqli_fetch_assoc($receipt_result)) {
                                    $item_statuses[$item['status']] = $item['count'];
                                }
                                ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($order['order_number']); ?></strong></td>
                                    <td><code style="background: #f9f9f9; padding: 4px 8px; border-radius: 3px; font-size: 11px;"><?php echo htmlspecialchars($order['barcode']); ?></code></td>
                                    <td><?php echo htmlspecialchars($order['requested_by_name']); ?></td>
                                    <td><?php echo (int)$order['item_count']; ?> items</td>
                                    <td>
                                        <?php if (!empty($item_statuses)): ?>
                                            <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                                                <?php 
                                                $status_colors = [
                                                    'received' => ['bg' => '#d1e7dd', 'text' => '#0f5132'],
                                                    'partial' => ['bg' => '#fff3cd', 'text' => '#856404'],
                                                    'damaged' => ['bg' => '#f8d7da', 'text' => '#721c24'],
                                                    'not_received' => ['bg' => '#e2e3e5', 'text' => '#383d41']
                                                ];
                                                foreach ($item_statuses as $status => $count): 
                                                    $colors = $status_colors[$status] ?? ['bg' => '#f0f0f0', 'text' => '#333'];
                                                ?>
                                                    <span style="background: <?php echo $colors['bg']; ?>; color: <?php echo $colors['text']; ?>; padding: 4px 8px; border-radius: 12px; font-size: 11px; font-weight: 600;">
                                                        <?php echo ucfirst(str_replace('_', ' ', $status)); ?> (<?php echo $count; ?>)
                                                    </span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php else: ?>
                                            <span style="color: #999; font-size: 12px;">Not received yet</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($order['status']); ?>">
                                            <?php echo ucfirst($order['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M d, Y H:i', strtotime($order['order_date'])); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="order_request_print.php?order_id=<?php echo $order['order_id']; ?>" class="btn btn-small" target="_blank">🖨️ Print</a>
                                            <a href="view_order.php?order_id=<?php echo $order['order_id']; ?>" class="btn btn-small" style="background: #2ecc71;">👁️ View</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="no-data">
                    <div class="no-data-icon">📦</div>
                    <p>No orders found. <a href="order_request.php" style="color: #667eea; text-decoration: none; font-weight: 600;">Create your first order →</a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
