<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();

// Allow both managers and admins
$user = getUserInfo();
if ($user['role'] !== 'manager' && $user['role'] !== 'admin') {
    die('Access denied. Only managers and admins can create stock orders.');
}

$message = '';
$error = '';

// Get branch info
$branch_id = $_SESSION['branch_id'] ?? 1;
$branch_query = mysqli_query($conn, "SELECT branch_name FROM branches WHERE branch_id = $branch_id");
$branch = mysqli_fetch_assoc($branch_query);

// Handle delete of a specific return alert (admin only)
if (isset($_GET['delete_alert_id']) && isAdmin()) {
    $delete_alert_id = (int) $_GET['delete_alert_id'];
    $delete_query = "DELETE FROM alerts WHERE alert_id = $delete_alert_id AND title = 'Product Return Request'";
    mysqli_query($conn, $delete_query);
    header("Location: order_request.php");
    exit;
}

// Handle order request submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_order') {
    $items = isset($_POST['items']) ? $_POST['items'] : [];
    $notes = sanitizeInput($_POST['notes'] ?? '');
    
    if (empty($items) || !is_array($items)) {
        $error = 'Please select at least one low stock item to order';
    } else {
        // Generate order request number and barcode with unique sequence
        $today = date('Ymd');
        $today_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM order_requests WHERE DATE(order_date) = CURDATE()"))['count'];
        $sequence = str_pad($today_count + 1, 4, '0', STR_PAD_LEFT);
        
        $order_number = 'STOCK-' . $today . '-' . $sequence;
        $barcode = $order_number; // Barcode is the order number itself
        $order_date = date('Y-m-d H:i:s');
        
        // Insert order request
        $insert_query = "INSERT INTO order_requests (order_number, barcode, branch_id, requested_by, order_date, notes, status) 
                        VALUES ('$order_number', '$barcode', $branch_id, {$_SESSION['user_id']}, '$order_date', '$notes', 'pending')";
        
        if (mysqli_query($conn, $insert_query)) {
            $order_id = mysqli_insert_id($conn);
            
            // Insert order items
            $items_inserted = 0;
            foreach ($items as $item) {
                if (!empty($item['product_id']) && !empty($item['quantity'])) {
                    $product_id = (int)$item['product_id'];
                    $quantity = (int)$item['quantity'];
                    
                    $item_query = "INSERT INTO order_request_items (order_id, product_id, quantity) 
                                  VALUES ($order_id, $product_id, $quantity)";
                    
                    if (mysqli_query($conn, $item_query)) {
                        $items_inserted++;
                    }
                }
            }
            
            // Clear pending product return alerts once order is created
            $clear_alerts_query = "DELETE FROM alerts 
                                   WHERE alert_type = 'system' 
                                   AND title = 'Product Return Request'";
            mysqli_query($conn, $clear_alerts_query);
            
            // Log activity
            logActivity($_SESSION['user_id'], 'Create Stock Order', 'Inventory', 
                       "Created stock order $order_number with $items_inserted items for low stock replenishment");
            
            $message = "Stock order created successfully! Order #: <strong>$order_number</strong>";
            
            // Redirect to print page
            header("Location: order_request_print.php?order_id=$order_id");
            exit;
        } else {
            $error = 'Error creating order request: ' . $conn->error;
        }
    }
}

// Get ALL products for ordering
$all_products_query = "SELECT p.product_id, p.product_name, p.product_code, p.reorder_level,
                              SUM(bi.quantity) as current_stock, p.unit
                       FROM products p
                       LEFT JOIN branch_inventory bi ON p.product_id = bi.product_id
                       GROUP BY p.product_id
                       ORDER BY p.product_name";

$all_products_result = mysqli_query($conn, $all_products_query);
$all_products = [];
$low_stock_products = [];
$normal_stock_products = [];

while ($row = mysqli_fetch_assoc($all_products_result)) {
    $all_products[] = $row;
    
    // Separate low stock from normal stock
    $current_stock = (int)($row['current_stock'] ?? 0);
    if ($current_stock <= $row['reorder_level']) {
        $low_stock_products[] = $row;
    } else {
        $normal_stock_products[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Order Request - Manager</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .navbar {
            background: white;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-left {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .navbar-right {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .btn {
            display: inline-block;
            padding: 10px 16px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn:hover {
            background: #5568d3;
        }

        .btn-small {
            padding: 6px 10px;
            font-size: 12px;
        }

        .btn-secondary {
            background: #95a5a6;
        }

        .btn-secondary:hover {
            background: #7f8c8d;
        }

        .btn-danger {
            background: #e74c3c;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-success {
            background: #2ecc71;
        }

        .btn-success:hover {
            background: #27ae60;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0 15px;
            border-right: 1px solid #eee;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 32px;
            margin-bottom: 5px;
        }

        .header p {
            font-size: 16px;
            opacity: 0.9;
        }

        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }

        .card h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            font-family: inherit;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .items-section {
            margin-top: 30px;
        }

        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .items-table thead {
            background: #f9f9f9;
            border-bottom: 2px solid #667eea;
        }

        .items-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            font-size: 13px;
            text-transform: uppercase;
        }

        .items-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }

        .items-table tbody tr:hover {
            background: #f9f9f9;
        }

        .item-row {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr auto;
            gap: 10px;
            margin-bottom: 10px;
            align-items: end;
        }

        .item-row input,
        .item-row select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 13px;
        }

        .btn-remove {
            background: #e74c3c;
            color: white;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
        }

        .btn-remove:hover {
            background: #c0392b;
        }

        .btn-add-item {
            background: #2ecc71;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .btn-add-item:hover {
            background: #27ae60;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }

        .form-actions button {
            flex: 1;
            padding: 12px;
            font-size: 16px;
            font-weight: 600;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .form-actions .btn-submit {
            background: #2ecc71;
            color: white;
        }

        .form-actions .btn-submit:hover {
            background: #27ae60;
        }

        .form-actions .btn-cancel {
            background: #95a5a6;
            color: white;
        }

        .form-actions .btn-cancel:hover {
            background: #7f8c8d;
        }

        .info-box {
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            color: #0c5460;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .branch-info {
            background: #f0f4ff;
            border-left: 4px solid #667eea;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .search-section {
            margin-bottom: 20px;
        }

        .search-box {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .search-box input {
            flex: 1;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
        }

        .search-box input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .section-title {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin-top: 25px;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }

        .low-stock-badge {
            display: inline-block;
            background: #e74c3c;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
            margin-left: 5px;
        }

        .stock-low {
            background: #e74c3c;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: 600;
        }

        .stock-medium {
            background: #2ecc71;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: 600;
        }

        .btn-select-more {
            background: #3498db;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .btn-select-more:hover {
            background: #2980b9;
        }

        .hidden-section {
            display: none;
        }

        .hidden-section.show {
            display: block;
        }

        .no-results {
            text-align: center;
            padding: 30px;
            color: #999;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <?php if (isAdmin()) { include '../admin/navbar.php'; } else { ?>
        <div style="background: white; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); padding: 15px 20px; margin-bottom: 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                <a href="../dashboard.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📊 Dashboard</a>
                <a href="order_request.php" class="btn" style="background: #667eea; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📦 Create Order</a>
                <a href="order_history.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📋 Order History</a>
                <a href="../bos/inventory.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📦 Inventory</a>
                <a href="../bos/reports.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📈 Reports</a>
            </div>
            <div style="display: flex; gap: 10px; align-items: center;">
                <div style="display: flex; align-items: center; gap: 10px; padding: 0 15px; border-right: 1px solid #eee;">
                    <div>
                        <strong style="color: #333;"><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                        <small style="color: #999;"><?php echo ucfirst($user['role']); ?></small>
                    </div>
                </div>
                <a href="../logout.php" class="btn" style="background: #e74c3c; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">🚪 Logout</a>
            </div>
        </div>
        <?php } ?>

        <div class="header">
            <h1>📦 Create Order Request</h1>
            <p>Send order requests to the warehouse. Your branch: <strong><?php echo htmlspecialchars($branch['branch_name']); ?></strong></p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success">✓ <?php echo $message; ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error">✗ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="info-box">
            <strong>ℹ️ How it works:</strong>
            <ul style="margin-top: 10px; margin-left: 20px;">
                <li>Select any products you want to order from the warehouse</li>
                <li>Check the checkbox next to each product</li>
                <li>Enter the quantity you want to order</li>
                <li>Submit the order - a barcode will be generated on the paper</li>
                <li>Print the paper with barcode and send to warehouse</li>
            </ul>
        </div>

        <!-- Return Alerts Section -->
        <?php
        $return_alerts_query = "SELECT * FROM alerts WHERE alert_type = 'system' AND is_read = FALSE AND title = 'Product Return Request' ORDER BY created_at DESC LIMIT 10";
        $return_alerts = mysqli_query($conn, $return_alerts_query);
        $return_count = mysqli_num_rows($return_alerts);
        
        if ($return_count > 0):
        ?>
        <div class="card" style="background: #fff3cd; border-left: 4px solid #f39c12;">
            <h2 style="color: #856404;">🔔 Pending Return Requests</h2>
            <p style="color: #856404; margin-bottom: 15px;">The following items have been reported by cashiers and need to be returned to the warehouse:</p>
            
            <div style="display: grid; gap: 10px;">
                <?php while ($alert = mysqli_fetch_assoc($return_alerts)): ?>
                    <div style="background: white; padding: 12px; border-radius: 5px; border-left: 3px solid #f39c12;">
                        <strong style="color: #333;">📦 <?php echo htmlspecialchars($alert['message']); ?></strong><br>
                        <small style="color: #666;">Reported: <?php echo date('M d, Y H:i', strtotime($alert['created_at'])); ?></small>
                        <div style="margin-top: 8px; display: flex; gap: 8px; flex-wrap: wrap;">
                            <button type="button"
                                    class="btn btn-secondary btn-small"
                                    data-message="<?php echo htmlspecialchars($alert['message'], ENT_QUOTES); ?>"
                                    onclick="addReturnToNotes(this.getAttribute('data-message'))">
                                ➕ Add to Notes
                            </button>
                            <?php if (isAdmin()): ?>
                                <a href="order_request.php?delete_alert_id=<?php echo $alert['alert_id']; ?>"
                                   class="btn btn-danger btn-small"
                                   onclick="return confirm('Delete this return request?');">
                                    🗑 Delete
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
            
            <p style="margin-top: 15px; color: #856404; font-size: 13px;">
                💡 <strong>Tip:</strong> You can use the <strong>Add to Notes</strong> button to include these return items in the "Additional Notes" field below.
            </p>
        </div>
        <?php endif; ?>

        <form method="POST" action="">
            <input type="hidden" name="action" value="create_order">
            
            <div class="card">
                <h2>Create Stock Order</h2>
                
                <div class="branch-info">
                    <strong>📍 Branch:</strong> <?php echo htmlspecialchars($branch['branch_name']); ?><br>
                    <strong>👤 Requested by:</strong> <?php echo htmlspecialchars($user['full_name']); ?><br>
                    <strong>📅 Order Date:</strong> <?php echo date('M d, Y H:i'); ?>
                </div>

                <div class="form-group">
                    <label for="notes">Additional Notes (Optional)</label>
                    <textarea id="notes" name="notes" rows="3" placeholder="Any special instructions for the warehouse..."></textarea>
                </div>
            </div>

            <div class="card items-section">
                <h2>Select Products to Order</h2>

                <!-- Search Section -->
                <div class="search-section">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="🔍 Search by product name or code..." onkeyup="filterProducts()">
                    </div>
                </div>

                <!-- Low Stock Items Section -->
                <div id="lowStockSection">
                    <div class="section-title">⚠️ Low Stock Items (Reorder Needed)</div>
                    <div style="overflow-x: auto;">
                        <table class="items-table">
                            <thead>
                                <tr>
                                    <th style="width: 50px;">Select</th>
                                    <th>Product Code</th>
                                    <th>Product Name</th>
                                    <th>Current Stock</th>
                                    <th>Reorder Level</th>
                                    <th>Unit</th>
                                    <th>Quantity to Order</th>
                                </tr>
                            </thead>
                            <tbody id="lowStockTable">
                                <?php foreach ($low_stock_products as $index => $item): ?>
                                    <tr class="product-row" data-product-code="<?php echo strtolower($item['product_code']); ?>" data-product-name="<?php echo strtolower($item['product_name']); ?>">
                                        <td>
                                            <input type="checkbox" name="items[<?php echo $index; ?>][product_id]" 
                                                   value="<?php echo $item['product_id']; ?>" 
                                                   onchange="toggleQuantityField(<?php echo $index; ?>)">
                                        </td>
                                        <td><?php echo htmlspecialchars($item['product_code']); ?></td>
                                        <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                        <td>
                                            <span class="stock-low">
                                                <?php echo (int)($item['current_stock'] ?? 0); ?>
                                            </span>
                                        </td>
                                        <td><?php echo $item['reorder_level']; ?></td>
                                        <td><?php echo htmlspecialchars($item['unit']); ?></td>
                                        <td>
                                            <input type="number" name="items[<?php echo $index; ?>][quantity]" 
                                                   id="qty-<?php echo $index; ?>" 
                                                   min="1" value="10" 
                                                   disabled style="width: 80px; padding: 8px;">
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if (empty($low_stock_products)): ?>
                        <div class="no-results">✓ No low stock items at the moment</div>
                    <?php endif; ?>
                </div>

                <!-- Select More Items Button -->
                <button type="button" class="btn-select-more" onclick="toggleMoreItems()">+ Select More Items (Non-Low Stock)</button>

                <!-- Additional Items Section (Hidden by default) -->
                <div id="moreItemsSection" class="hidden-section">
                    <div class="section-title">📦 All Other Products</div>
                    <div style="overflow-x: auto;">
                        <table class="items-table">
                            <thead>
                                <tr>
                                    <th style="width: 50px;">Select</th>
                                    <th>Product Code</th>
                                    <th>Product Name</th>
                                    <th>Current Stock</th>
                                    <th>Unit</th>
                                    <th>Quantity to Order</th>
                                </tr>
                            </thead>
                            <tbody id="normalStockTable">
                                <?php 
                                $start_index = count($low_stock_products);
                                foreach ($normal_stock_products as $offset => $item): 
                                    $index = $start_index + $offset;
                                ?>
                                    <tr class="product-row" data-product-code="<?php echo strtolower($item['product_code']); ?>" data-product-name="<?php echo strtolower($item['product_name']); ?>">
                                        <td>
                                            <input type="checkbox" name="items[<?php echo $index; ?>][product_id]" 
                                                   value="<?php echo $item['product_id']; ?>" 
                                                   onchange="toggleQuantityField(<?php echo $index; ?>)">
                                        </td>
                                        <td><?php echo htmlspecialchars($item['product_code']); ?></td>
                                        <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                        <td>
                                            <span class="stock-medium">
                                                <?php echo (int)($item['current_stock'] ?? 0); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($item['unit']); ?></td>
                                        <td>
                                            <input type="number" name="items[<?php echo $index; ?>][quantity]" 
                                                   id="qty-<?php echo $index; ?>" 
                                                   min="1" value="10" 
                                                   disabled style="width: 80px; padding: 8px;">
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if (empty($normal_stock_products)): ?>
                        <div class="no-results">All products are currently low on stock</div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-submit">✓ Create Stock Order</button>
                <a href="../dashboard.php" class="btn-cancel" style="text-align: center; text-decoration: none;">✕ Cancel</a>
            </div>
        </form>
    </div>

    <script>
        function addReturnToNotes(message) {
            const notesField = document.getElementById('notes');
            if (!notesField) return;
            const current = notesField.value.trim();
            const prefix = current ? "\n" : '';
            notesField.value = notesField.value + prefix + message;
            notesField.focus();
        }

        function toggleQuantityField(index) {
            const checkbox = document.querySelector(`input[name="items[${index}][product_id]"]`);
            const quantityField = document.getElementById(`qty-${index}`);
            
            if (checkbox.checked) {
                quantityField.disabled = false;
                quantityField.style.background = 'white';
            } else {
                quantityField.disabled = true;
                quantityField.style.background = '#f9f9f9';
            }
        }

        function toggleMoreItems() {
            const moreItemsSection = document.getElementById('moreItemsSection');
            const button = event.target;
            
            moreItemsSection.classList.toggle('show');
            
            if (moreItemsSection.classList.contains('show')) {
                button.textContent = '- Hide More Items';
                button.style.background = '#e74c3c';
            } else {
                button.textContent = '+ Select More Items (Non-Low Stock)';
                button.style.background = '#3498db';
            }
        }

        function filterProducts() {
            const searchInput = document.getElementById('searchInput').value.toLowerCase();
            const productRows = document.querySelectorAll('.product-row');
            let visibleCount = 0;

            productRows.forEach(row => {
                const productCode = row.getAttribute('data-product-code');
                const productName = row.getAttribute('data-product-name');

                if (productCode.includes(searchInput) || productName.includes(searchInput)) {
                    row.style.display = '';
                    visibleCount++;
                } else {
                    row.style.display = 'none';
                }
            });

            // Show/hide "no results" message
            const lowStockTable = document.getElementById('lowStockTable');
            const normalStockTable = document.getElementById('normalStockTable');
            
            if (visibleCount === 0) {
                // Show no results message
                let noResultsMsg = document.querySelector('.no-results-search');
                if (!noResultsMsg) {
                    noResultsMsg = document.createElement('div');
                    noResultsMsg.className = 'no-results no-results-search';
                    noResultsMsg.textContent = '🔍 No products found matching your search';
                    document.querySelector('.items-section').appendChild(noResultsMsg);
                }
                noResultsMsg.style.display = 'block';
            } else {
                const noResultsMsg = document.querySelector('.no-results-search');
                if (noResultsMsg) {
                    noResultsMsg.style.display = 'none';
                }
            }
        }
    </script>
</body>
</html>
