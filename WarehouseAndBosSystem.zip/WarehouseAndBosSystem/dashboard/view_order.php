<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();

$user = getUserInfo();
if ($user['role'] !== 'manager' && $user['role'] !== 'admin') {
    die('Access denied. Only managers and admins can view orders.');
}

$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
$error = '';

if (!$order_id) {
    $error = 'No order selected';
}

// Get order details
if ($order_id) {
    $order_query = "SELECT o.*, u.full_name as requested_by_name, b.branch_name
                    FROM order_requests o
                    JOIN users u ON o.requested_by = u.user_id
                    LEFT JOIN branches b ON o.branch_id = b.branch_id
                    WHERE o.order_id = $order_id";
    $order_result = mysqli_query($conn, $order_query);
    $order = mysqli_fetch_assoc($order_result);
    
    if (!$order) {
        $error = 'Order not found';
    }
    
    // Get receipt information if order has been received
    $receipt_info = null;
    if (!$error) {
        $receipt_query = "SELECT r.*, u.full_name as received_by_name
                         FROM order_receipts r
                         JOIN users u ON r.received_by = u.user_id
                         WHERE r.order_id = $order_id
                         LIMIT 1";
        $receipt_result = mysqli_query($conn, $receipt_query);
        $receipt_info = mysqli_fetch_assoc($receipt_result);
    }
    
    // Get order items
    if (!$error) {
        $items_query = "SELECT ori.*, p.product_name, p.product_code
                        FROM order_request_items ori
                        JOIN products p ON ori.product_id = p.product_id
                        WHERE ori.order_id = $order_id";
        $items_result = mysqli_query($conn, $items_query);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Order</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; color: #333; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        
        .navbar { background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 15px 20px; margin-bottom: 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; }
        .navbar-left { display: flex; gap: 10px; align-items: center; }
        .navbar-right { display: flex; gap: 10px; align-items: center; }
        .btn { background: #667eea; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; }
        .btn:hover { background: #5568d3; }
        .btn-secondary { background: #95a5a6; }
        .btn-secondary:hover { background: #7f8c8d; }
        .btn-danger { background: #e74c3c; }
        .btn-danger:hover { background: #c0392b; }
        
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .header h1 { font-size: 28px; margin-bottom: 5px; }
        
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 20px; margin-bottom: 20px; }
        .card h2 { margin-bottom: 15px; color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
        
        .alert { padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        
        .order-info { background: #f9f9f9; padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid #667eea; }
        .order-info strong { color: #333; }
        .order-info p { margin: 8px 0; font-size: 14px; }
        
        .info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
        .info-item { background: #f9f9f9; padding: 12px; border-radius: 5px; }
        .info-item label { font-weight: 600; color: #667eea; font-size: 12px; text-transform: uppercase; }
        .info-item value { display: block; margin-top: 5px; font-size: 14px; }
        
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f5f5f5; padding: 12px; text-align: left; font-weight: 600; border-bottom: 2px solid #ddd; }
        td { padding: 12px; border-bottom: 1px solid #eee; }
        tr:hover { background: #f9f9f9; }
        
        .status-badge { display: inline-block; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-confirmed { background: #cfe2ff; color: #084298; }
        .status-delivered { background: #d1e7dd; color: #0f5132; }
        
        .user-info { display: flex; align-items: center; gap: 10px; padding: 0 15px; border-right: 1px solid #eee; }
        .user-info strong { color: #333; }
        .user-info small { color: #999; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <?php if (isAdmin()) { include '../admin/navbar.php'; } else { ?>
        <div style="background: white; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); padding: 15px 20px; margin-bottom: 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                <a href="../dashboard.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📊 Dashboard</a>
                <a href="order_request.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📦 Create Order</a>
                <a href="order_history.php" class="btn" style="background: #667eea; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📋 Order History</a>
                <a href="../bos/inventory.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📦 Inventory</a>
                <a href="../bos/reports.php" class="btn" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">📈 Reports</a>
            </div>
            <div style="display: flex; gap: 10px; align-items: center;">
                <div style="display: flex; align-items: center; gap: 10px; padding: 0 15px; border-right: 1px solid #eee;">
                    <div>
                        <strong style="color: #333;"><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                        <small style="color: #999;"><?php echo ucfirst($user['role']); ?></small>
                    </div>
                </div>
                <a href="../logout.php" class="btn" style="background: #e74c3c; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; transition: all 0.3s;">🚪 Logout</a>
            </div>
        </div>
        <?php } ?>

        <!-- Header -->
        <div class="header">
            <h1>📋 Order Details</h1>
            <p>View order information and items</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">✗ <?php echo htmlspecialchars($error); ?></div>
            <a href="order_history.php" class="btn">← Back to Order History</a>
        <?php else: ?>
            <!-- Order Information -->
            <div class="card">
                <h2>📦 Order Information</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <label>Order Number</label>
                        <value><strong><?php echo htmlspecialchars($order['order_number']); ?></strong></value>
                    </div>
                    <div class="info-item">
                        <label>Barcode</label>
                        <value><code><?php echo htmlspecialchars($order['barcode']); ?></code></value>
                    </div>
                    <div class="info-item">
                        <label>Branch</label>
                        <value><?php echo htmlspecialchars($order['branch_name'] ?? 'N/A'); ?></value>
                    </div>
                    <div class="info-item">
                        <label>Requested By</label>
                        <value><?php echo htmlspecialchars($order['requested_by_name']); ?></value>
                    </div>
                    <div class="info-item">
                        <label>Order Date</label>
                        <value><?php echo date('M d, Y H:i', strtotime($order['order_date'])); ?></value>
                    </div>
                    <div class="info-item">
                        <label>Status</label>
                        <value><span class="status-badge status-<?php echo strtolower($order['status']); ?>"><?php echo ucfirst($order['status']); ?></span></value>
                    </div>
                    <?php if ($receipt_info): ?>
                        <div class="info-item">
                            <label>Received By</label>
                            <value><?php echo htmlspecialchars($receipt_info['received_by_name']); ?></value>
                        </div>
                        <div class="info-item">
                            <label>Receipt Date</label>
                            <value><?php echo date('M d, Y H:i', strtotime($receipt_info['receipt_date'])); ?></value>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if ($order['notes']): ?>
                    <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee;">
                        <strong>Notes:</strong>
                        <p style="margin-top: 8px; color: #666;"><?php echo htmlspecialchars($order['notes']); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Order Items -->
            <div class="card">
                <h2>📋 Order Items</h2>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Code</th>
                                <th>Quantity</th>
                                <th>Item Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if (mysqli_num_rows($items_result) > 0) {
                                while ($item = mysqli_fetch_assoc($items_result)): 
                                    // Get receipt item status for this product
                                    $receipt_item_query = "SELECT ri.status, COUNT(*) as count
                                                         FROM receipt_items ri
                                                         JOIN order_receipts r ON ri.receipt_id = r.receipt_id
                                                         WHERE r.order_id = $order_id AND ri.product_id = {$item['product_id']}
                                                         GROUP BY ri.status";
                                    $receipt_item_result = mysqli_query($conn, $receipt_item_query);
                                    $receipt_item_statuses = [];
                                    while ($receipt_item = mysqli_fetch_assoc($receipt_item_result)) {
                                        $receipt_item_statuses[$receipt_item['status']] = $receipt_item['count'];
                                    }
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td><code><?php echo htmlspecialchars($item['product_code']); ?></code></td>
                                    <td><strong><?php echo $item['quantity']; ?></strong></td>
                                    <td>
                                        <?php if (!empty($receipt_item_statuses)): ?>
                                            <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                                                <?php 
                                                $status_colors = [
                                                    'received' => ['bg' => '#d1e7dd', 'text' => '#0f5132'],
                                                    'partial' => ['bg' => '#fff3cd', 'text' => '#856404'],
                                                    'damaged' => ['bg' => '#f8d7da', 'text' => '#721c24'],
                                                    'not_received' => ['bg' => '#e2e3e5', 'text' => '#383d41']
                                                ];
                                                foreach ($receipt_item_statuses as $status => $count): 
                                                    $colors = $status_colors[$status] ?? ['bg' => '#f0f0f0', 'text' => '#333'];
                                                ?>
                                                    <span style="background: <?php echo $colors['bg']; ?>; color: <?php echo $colors['text']; ?>; padding: 4px 8px; border-radius: 12px; font-size: 11px; font-weight: 600;">
                                                        <?php echo ucfirst(str_replace('_', ' ', $status)); ?> (<?php echo $count; ?>)
                                                    </span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php else: ?>
                                            <span style="color: #999; font-size: 12px;">Not received yet</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php 
                                endwhile;
                            } else {
                                echo "<tr><td colspan='4' style='text-align: center; color: #999;'>No items in this order</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="card">
                <a href="order_request_print.php?order_id=<?php echo $order['order_id']; ?>" class="btn" target="_blank" style="background: #3498db;">🖨️ Print Order</a>
                <a href="order_history.php" class="btn btn-secondary">← Back to Order History</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
