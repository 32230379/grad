<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireManager();

$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if (!$order_id) {
    die('Invalid order ID');
}

// Get order details
$order_query = "SELECT o.*, u.full_name as requested_by_name, b.branch_name
                FROM order_requests o
                JOIN users u ON o.requested_by = u.user_id
                JOIN branches b ON o.branch_id = b.branch_id
                WHERE o.order_id = $order_id";

$order_result = mysqli_query($conn, $order_query);
if (!$order_result || mysqli_num_rows($order_result) == 0) {
    die('Order not found');
}

$order = mysqli_fetch_assoc($order_result);

// Get order items
$items_query = "SELECT ori.*, p.product_name, p.product_code
                FROM order_request_items ori
                JOIN products p ON ori.product_id = p.product_id
                WHERE ori.order_id = $order_id";

$items_result = mysqli_query($conn, $items_query);
$items = [];
while ($item = mysqli_fetch_assoc($items_result)) {
    $items[] = $item;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Request - <?php echo htmlspecialchars($order['order_number']); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }

        .print-section {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 40px;
            margin-bottom: 20px;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #667eea;
            padding-bottom: 20px;
        }

        .header h1 {
            font-size: 28px;
            color: #667eea;
            margin-bottom: 5px;
        }

        .header p {
            color: #666;
            font-size: 14px;
        }

        .order-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
            background: #f9f9f9;
            padding: 15px;
            border-radius: 6px;
        }

        .info-item {
            font-size: 13px;
        }

        .info-label {
            font-weight: 600;
            color: #667eea;
            margin-bottom: 3px;
        }

        .info-value {
            color: #333;
            font-size: 14px;
        }

        .barcode-section {
            text-align: center;
            margin: 30px 0;
            padding: 30px;
            background: #f0f4ff;
            border: 2px dashed #667eea;
            border-radius: 8px;
        }

        .barcode-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 10px;
            text-transform: uppercase;
            font-weight: 600;
        }

        .barcode-value {
            font-size: 36px;
            font-weight: bold;
            color: #667eea;
            font-family: 'Courier New', monospace;
            letter-spacing: 2px;
            margin-bottom: 10px;
        }

        .barcode-instruction {
            font-size: 11px;
            color: #999;
            margin-top: 10px;
        }

        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        .items-table thead {
            background: #667eea;
            color: white;
        }

        .items-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
            text-transform: uppercase;
        }

        .items-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }

        .items-table tbody tr:hover {
            background: #f9f9f9;
        }

        .items-table tbody tr:last-child td {
            border-bottom: 2px solid #667eea;
        }

        .total-row {
            font-weight: 600;
            background: #f9f9f9;
        }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-confirmed {
            background: #d4edda;
            color: #155724;
        }

        .status-shipped {
            background: #d1ecf1;
            color: #0c5460;
        }

        .status-delivered {
            background: #d4edda;
            color: #155724;
        }

        .priority-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .priority-low {
            background: #d1ecf1;
            color: #0c5460;
        }

        .priority-normal {
            background: #d4edda;
            color: #155724;
        }

        .priority-high {
            background: #fff3cd;
            color: #856404;
        }

        .priority-urgent {
            background: #f8d7da;
            color: #721c24;
        }

        .actions {
            display: flex;
            gap: 10px;
            margin-top: 30px;
            justify-content: center;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn-print {
            background: #667eea;
            color: white;
        }

        .btn-print:hover {
            background: #5568d3;
        }

        .btn-back {
            background: #95a5a6;
            color: white;
        }

        .btn-back:hover {
            background: #7f8c8d;
        }

        .btn-download {
            background: #2ecc71;
            color: white;
        }

        .btn-download:hover {
            background: #27ae60;
        }

        .notes-section {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-left: 4px solid #667eea;
        }

        .notes-section strong {
            color: #667eea;
            display: block;
            margin-bottom: 8px;
        }

        @media print {
            body {
                background: white;
            }

            .container {
                padding: 0;
            }

            .print-section {
                box-shadow: none;
                page-break-after: always;
            }

            .actions {
                display: none;
            }

            .print-section {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="print-section">
            <div class="header">
                <h1>📦 ORDER REQUEST</h1>
                <p>Warehouse Order Form - Please print and send to warehouse</p>
            </div>

            <div class="order-info">
                <div class="info-item">
                    <div class="info-label">Order Number</div>
                    <div class="info-value"><?php echo htmlspecialchars($order['order_number']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Status</div>
                    <div class="info-value">
                        <span class="status-badge status-<?php echo strtolower($order['status']); ?>">
                            <?php echo ucfirst($order['status']); ?>
                        </span>
                    </div>
                </div>
                <div class="info-item">
                    <div class="info-label">Branch</div>
                    <div class="info-value"><?php echo htmlspecialchars($order['branch_name']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Requested By</div>
                    <div class="info-value"><?php echo htmlspecialchars($order['requested_by_name']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Order Date</div>
                    <div class="info-value"><?php echo date('M d, Y H:i', strtotime($order['order_date'])); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Total Items</div>
                    <div class="info-value"><?php echo count($items); ?> items</div>
                </div>
            </div>

            <div class="barcode-section">
                <div class="barcode-label">📊 WAREHOUSE ORDER BARCODE</div>
                <div class="barcode-value"><?php echo htmlspecialchars($order['barcode']); ?></div>
                <div class="barcode-instruction">
                    This paper contains the complete stock order. The barcode above identifies this order.
                </div>
            </div>

            <h3 style="margin-bottom: 15px; color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px;">Order Items</h3>
            <table class="items-table">
                <thead>
                    <tr>
                        <th>Product Code</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Reason</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['product_code']); ?></td>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td><?php echo (int)$item['quantity']; ?></td>
                            <td><?php echo htmlspecialchars($item['reason'] ?? '-'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="total-row">
                        <td colspan="2">TOTAL ITEMS</td>
                        <td><?php echo count($items); ?></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>

            <?php if ($order['notes']): ?>
                <div class="notes-section">
                    <strong>📝 Additional Notes:</strong>
                    <?php echo nl2br(htmlspecialchars($order['notes'])); ?>
                </div>
            <?php endif; ?>

            <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #999; font-size: 12px;">
                <p>This order request was generated on <?php echo date('M d, Y \a\t H:i'); ?></p>
                <p>Order ID: <?php echo $order_id; ?></p>
            </div>
        </div>

        <div class="actions">
            <button class="btn btn-print" onclick="window.print()">🖨️ Print Order</button>
            <a href="order_history.php" class="btn btn-back" style="text-decoration: none;">← Back to Orders</a>
        </div>
    </div>
</body>
</html>
