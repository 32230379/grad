<?php
require_once 'config.php';

echo "<h2>Fixing branch_inventory Table</h2>";

// Drop the existing table if it exists
$drop_sql = "DROP TABLE IF EXISTS branch_inventory";
if (mysqli_query($conn, $drop_sql)) {
    echo "<p style='color: green;'>✓ Dropped existing branch_inventory table</p>";
} else {
    echo "<p style='color: red;'>✗ Error dropping table: " . mysqli_error($conn) . "</p>";
}

// Create the correct table structure
$create_sql = "CREATE TABLE IF NOT EXISTS branch_inventory (
    inventory_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    product_id INT NOT NULL,
    batch_number VARCHAR(50),
    quantity INT NOT NULL DEFAULT 0,
    expiry_date DATE NULL,
    cost_price DECIMAL(10,2),
    selling_price DECIMAL(10,2),
    location VARCHAR(50),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_branch_product (branch_id, product_id),
    INDEX idx_batch (batch_number),
    INDEX idx_expiry (expiry_date)
)";

if (mysqli_query($conn, $create_sql)) {
    echo "<p style='color: green;'>✓ Created correct branch_inventory table with branch_id column</p>";
} else {
    echo "<p style='color: red;'>✗ Error creating table: " . mysqli_error($conn) . "</p>";
}

// Add sample inventory data
$insert_sql = "INSERT INTO branch_inventory (branch_id, product_id, batch_number, quantity, cost_price, selling_price, location) 
               SELECT 1, product_id, 'BATCH001', 100, 100, 150, 'A1' FROM products LIMIT 5";

if (mysqli_query($conn, $insert_sql)) {
    echo "<p style='color: green;'>✓ Added sample inventory data</p>";
} else {
    echo "<p style='color: red;'>✗ Error adding data: " . mysqli_error($conn) . "</p>";
}

echo "<hr>";
echo "<p><a href='receiver/dashboard.php'>← Go to Receiver Dashboard</a></p>";
?>
