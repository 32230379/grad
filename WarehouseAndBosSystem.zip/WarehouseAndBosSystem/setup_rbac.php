<?php
/**
 * RBAC System Setup Script
 * Run this once to initialize the role-based access control system
 */

require_once 'config.php';

$setup_complete = false;
$messages = [];
$errors = [];

// Check if setup is already done
$check_branches = mysqli_query($conn, "SELECT COUNT(*) as count FROM information_schema.TABLES WHERE TABLE_SCHEMA = '" . DB_NAME . "' AND TABLE_NAME = 'branches'");
$table_exists = mysqli_fetch_assoc($check_branches)['count'] > 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm_setup'])) {
    // Create branches table first (needed for foreign keys)
    $sql = "CREATE TABLE IF NOT EXISTS branches (
        branch_id INT PRIMARY KEY AUTO_INCREMENT,
        branch_code VARCHAR(20) UNIQUE NOT NULL,
        branch_name VARCHAR(100) NOT NULL,
        address TEXT,
        city VARCHAR(50),
        phone VARCHAR(20),
        email VARCHAR(100),
        manager_id INT,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_code (branch_code),
        INDEX idx_manager (manager_id)
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Branches table created";
    } else {
        $errors[] = "✗ Error creating branches table: " . mysqli_error($conn);
    }

    // Create roles table
    $sql = "CREATE TABLE IF NOT EXISTS roles (
        role_id INT PRIMARY KEY AUTO_INCREMENT,
        role_name VARCHAR(50) UNIQUE NOT NULL,
        description TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Roles table created";
    } else {
        $errors[] = "✗ Error creating roles table: " . mysqli_error($conn);
    }

    // Create permissions table
    $sql = "CREATE TABLE IF NOT EXISTS permissions (
        permission_id INT PRIMARY KEY AUTO_INCREMENT,
        permission_name VARCHAR(100) UNIQUE NOT NULL,
        description TEXT,
        module VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Permissions table created";
    } else {
        $errors[] = "✗ Error creating permissions table: " . mysqli_error($conn);
    }

    // Create role_permissions table
    $sql = "CREATE TABLE IF NOT EXISTS role_permissions (
        role_permission_id INT PRIMARY KEY AUTO_INCREMENT,
        role_id INT NOT NULL,
        permission_id INT NOT NULL,
        FOREIGN KEY (role_id) REFERENCES roles(role_id) ON DELETE CASCADE,
        FOREIGN KEY (permission_id) REFERENCES permissions(permission_id) ON DELETE CASCADE,
        UNIQUE KEY unique_role_permission (role_id, permission_id)
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Role permissions table created";
    } else {
        $errors[] = "✗ Error creating role_permissions table: " . mysqli_error($conn);
    }

    // Create user_audit_log table
    $sql = "CREATE TABLE IF NOT EXISTS user_audit_log (
        audit_id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        action VARCHAR(100) NOT NULL,
        description TEXT,
        old_values JSON,
        new_values JSON,
        ip_address VARCHAR(45),
        user_agent TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
        INDEX idx_user (user_id),
        INDEX idx_action (action),
        INDEX idx_created (created_at)
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Audit log table created";
    } else {
        $errors[] = "✗ Error creating audit log table: " . mysqli_error($conn);
    }

    // Create categories table
    $sql = "CREATE TABLE IF NOT EXISTS categories (
        category_id INT PRIMARY KEY AUTO_INCREMENT,
        category_name VARCHAR(100) NOT NULL,
        description TEXT,
        parent_category_id INT NULL,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_parent (parent_category_id)
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Categories table created";
    } else {
        $errors[] = "✗ Error creating categories table: " . mysqli_error($conn);
    }

    // Create products table
    $sql = "CREATE TABLE IF NOT EXISTS products (
        product_id INT PRIMARY KEY AUTO_INCREMENT,
        product_code VARCHAR(50) UNIQUE NOT NULL,
        product_name VARCHAR(200) NOT NULL,
        description TEXT,
        category_id INT,
        unit VARCHAR(20) NOT NULL,
        barcode VARCHAR(100),
        has_expiry BOOLEAN DEFAULT FALSE,
        has_batch BOOLEAN DEFAULT FALSE,
        reorder_level INT DEFAULT 0,
        min_stock_level INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(category_id),
        INDEX idx_code (product_code),
        INDEX idx_barcode (barcode),
        INDEX idx_category (category_id)
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Products table created";
    } else {
        $errors[] = "✗ Error creating products table: " . mysqli_error($conn);
    }

    // Add category_id column if it doesn't exist
    $check_col = mysqli_query($conn, "SHOW COLUMNS FROM products LIKE 'category_id'");
    if (mysqli_num_rows($check_col) == 0) {
        $sql = "ALTER TABLE products ADD COLUMN category_id INT AFTER description";
        if (mysqli_query($conn, $sql)) {
            $messages[] = "✓ Added category_id column to products table";
        }
    }

    // Create branch_inventory table
    $sql = "CREATE TABLE IF NOT EXISTS branch_inventory (
        inventory_id INT PRIMARY KEY AUTO_INCREMENT,
        branch_id INT NOT NULL,
        product_id INT NOT NULL,
        batch_number VARCHAR(50),
        quantity INT NOT NULL DEFAULT 0,
        expiry_date DATE NULL,
        cost_price DECIMAL(10,2),
        selling_price DECIMAL(10,2),
        location VARCHAR(50),
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
        FOREIGN KEY (product_id) REFERENCES products(product_id),
        INDEX idx_branch_product (branch_id, product_id),
        INDEX idx_batch (batch_number),
        INDEX idx_expiry (expiry_date)
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Branch inventory table created";
    } else {
        $errors[] = "✗ Error creating branch inventory table: " . mysqli_error($conn);
    }

    // Create sales_transactions table
    $sql = "CREATE TABLE IF NOT EXISTS sales_transactions (
        transaction_id INT PRIMARY KEY AUTO_INCREMENT,
        transaction_number VARCHAR(50) UNIQUE NOT NULL,
        branch_id INT NOT NULL,
        sale_date DATE NOT NULL,
        sale_time TIME NOT NULL,
        cashier_id INT NOT NULL,
        customer_name VARCHAR(100),
        customer_phone VARCHAR(20),
        subtotal DECIMAL(10,2) NOT NULL,
        discount DECIMAL(10,2) DEFAULT 0,
        tax DECIMAL(10,2) DEFAULT 0,
        total_amount DECIMAL(10,2) NOT NULL,
        payment_method ENUM('cash', 'card', 'mobile', 'credit') NOT NULL,
        payment_status ENUM('paid', 'partial', 'pending') DEFAULT 'paid',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
        FOREIGN KEY (cashier_id) REFERENCES users(user_id),
        INDEX idx_transaction_number (transaction_number),
        INDEX idx_branch_date (branch_id, sale_date),
        INDEX idx_cashier (cashier_id)
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Sales transactions table created";
    } else {
        $errors[] = "✗ Error creating sales transactions table: " . mysqli_error($conn);
    }

    // Create sales_items table
    $sql = "CREATE TABLE IF NOT EXISTS sales_items (
        item_id INT PRIMARY KEY AUTO_INCREMENT,
        transaction_id INT NOT NULL,
        product_id INT NOT NULL,
        batch_number VARCHAR(50),
        quantity INT NOT NULL,
        unit_price DECIMAL(10,2) NOT NULL,
        discount DECIMAL(10,2) DEFAULT 0,
        subtotal DECIMAL(10,2) NOT NULL,
        FOREIGN KEY (transaction_id) REFERENCES sales_transactions(transaction_id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(product_id),
        INDEX idx_transaction (transaction_id),
        INDEX idx_product (product_id)
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Sales items table created";
    } else {
        $errors[] = "✗ Error creating sales items table: " . mysqli_error($conn);
    }

    // Create activity_logs table
    $sql = "CREATE TABLE IF NOT EXISTS activity_logs (
        log_id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        branch_id INT,
        action VARCHAR(100) NOT NULL,
        module VARCHAR(50) NOT NULL,
        description TEXT,
        ip_address VARCHAR(45),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id),
        FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
        INDEX idx_user (user_id),
        INDEX idx_module (module),
        INDEX idx_created (created_at)
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Activity logs table created";
    } else {
        $errors[] = "✗ Error creating activity logs table: " . mysqli_error($conn);
    }

    // Create alerts table
    $sql = "CREATE TABLE IF NOT EXISTS alerts (
        alert_id INT PRIMARY KEY AUTO_INCREMENT,
        branch_id INT NOT NULL,
        alert_type ENUM('low_stock', 'expiry_warning', 'expired', 'reorder_point', 'discrepancy', 'system') NOT NULL,
        priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
        product_id INT NULL,
        title VARCHAR(200) NOT NULL,
        message TEXT NOT NULL,
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
        FOREIGN KEY (product_id) REFERENCES products(product_id),
        INDEX idx_branch_unread (branch_id, is_read),
        INDEX idx_type (alert_type)
    )";
    
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Alerts table created";
    } else {
        $errors[] = "✗ Error creating alerts table: " . mysqli_error($conn);
    }

    // Add columns to users table if they don't exist
    $check_columns = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'is_admin'");
    if (mysqli_num_rows($check_columns) == 0) {
        $sql = "ALTER TABLE users ADD COLUMN is_admin BOOLEAN DEFAULT FALSE, ADD COLUMN admin_since TIMESTAMP NULL, ADD COLUMN created_by INT NULL";
        if (mysqli_query($conn, $sql)) {
            $messages[] = "✓ Users table enhanced with RBAC columns";
        } else {
            $errors[] = "✗ Error enhancing users table: " . mysqli_error($conn);
        }
    } else {
        $messages[] = "✓ Users table already has RBAC columns";
    }

    // Insert default roles
    $roles = [
        ['admin', 'System Administrator - Full access to all features'],
        ['manager', 'Branch Manager - Manages branch operations and staff'],
        ['cashier', 'Cashier - Handles sales transactions']
    ];

    foreach ($roles as $role) {
        $role_name = $role[0];
        $description = $role[1];
        $sql = "INSERT IGNORE INTO roles (role_name, description, is_active) VALUES ('$role_name', '$description', 1)";
        if (mysqli_query($conn, $sql)) {
            $messages[] = "✓ Role '$role_name' created";
        } else {
            $errors[] = "✗ Error creating role '$role_name': " . mysqli_error($conn);
        }
    }

    // Insert default permissions
    $permissions = [
        [1, 'manage_users', 'Create, edit, delete users', 'admin'],
        [2, 'manage_roles', 'Manage roles and permissions', 'admin'],
        [3, 'view_audit_logs', 'View activity logs', 'admin'],
        [4, 'system_settings', 'Access system settings', 'admin'],
        [5, 'view_dashboard', 'View dashboard', 'dashboard'],
        [6, 'manage_inventory', 'Manage inventory', 'inventory'],
        [7, 'manage_sales', 'Manage sales', 'sales'],
        [8, 'manage_receiving', 'Manage receiving', 'receiving'],
        [9, 'view_reports', 'View reports', 'reports'],
        [10, 'manage_staff', 'Manage branch staff', 'staff'],
        [11, 'process_sales', 'Process sales transactions', 'sales'],
        [12, 'view_inventory', 'View inventory', 'inventory'],
        [13, 'access_bos', 'Access BOS system', 'bos']
    ];

    foreach ($permissions as $perm) {
        $perm_name = $perm[1];
        $description = $perm[2];
        $module = $perm[3];
        $sql = "INSERT IGNORE INTO permissions (permission_name, description, module) VALUES ('$perm_name', '$description', '$module')";
        if (mysqli_query($conn, $sql)) {
            // Don't show message for each permission
        } else {
            $errors[] = "✗ Error creating permission '$perm_name': " . mysqli_error($conn);
        }
    }
    $messages[] = "✓ Permissions created";

    // Assign permissions to roles
    $role_perms = [
        ['admin', [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]],
        ['manager', [5, 6, 7, 8, 9, 10]],
        ['cashier', [11, 12, 13]]
    ];

    foreach ($role_perms as $rp) {
        $role_name = $rp[0];
        $perms = $rp[1];
        
        $role_result = mysqli_query($conn, "SELECT role_id FROM roles WHERE role_name = '$role_name'");
        $role_row = mysqli_fetch_assoc($role_result);
        $role_id = $role_row['role_id'];
        
        foreach ($perms as $perm_id) {
            $sql = "INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES ($role_id, $perm_id)";
            mysqli_query($conn, $sql);
        }
    }
    $messages[] = "✓ Role permissions assigned";

    // Update admin user
    $sql = "UPDATE users SET is_admin = 1 WHERE user_id = 1";
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Admin user configured";
    } else {
        $errors[] = "✗ Error configuring admin user: " . mysqli_error($conn);
    }

    // Insert default branch
    $sql = "INSERT IGNORE INTO branches (branch_id, branch_code, branch_name, address, city, phone, email, is_active) 
            VALUES (1, 'BR001', 'Main Branch', '123 Main Street', 'City Center', '+1234567890', 'main@branch.com', TRUE)";
    if (mysqli_query($conn, $sql)) {
        $messages[] = "✓ Default branch created";
    } else {
        $errors[] = "✗ Error creating default branch: " . mysqli_error($conn);
    }

    // Insert default categories
    $categories = [
        ['Electronics', 'Electronic devices and accessories'],
        ['Food & Beverages', 'Food items and drinks'],
        ['Clothing', 'Apparel and fashion items'],
        ['Home & Garden', 'Home improvement and garden supplies'],
        ['Health & Beauty', 'Personal care and cosmetics']
    ];
    
    foreach ($categories as $cat) {
        $name = $cat[0];
        $desc = $cat[1];
        $sql = "INSERT IGNORE INTO categories (category_name, description) VALUES ('$name', '$desc')";
        mysqli_query($conn, $sql);
    }
    $messages[] = "✓ Default categories created";

    // Insert sample products
    $products = [
        ['PROD001', 'Laptop Computer', 'High-performance laptop', 1, 'piece', 5, 2],
        ['PROD002', 'Wireless Mouse', 'USB wireless mouse', 1, 'piece', 20, 10],
        ['PROD003', 'Coffee Beans', 'Premium coffee beans', 2, 'kg', 10, 5],
        ['PROD004', 'T-Shirt', 'Cotton t-shirt', 3, 'piece', 30, 15],
        ['PROD005', 'Garden Shovel', 'Steel garden shovel', 4, 'piece', 8, 4]
    ];
    
    foreach ($products as $prod) {
        $code = $prod[0];
        $name = $prod[1];
        $desc = $prod[2];
        $cat = $prod[3];
        $unit = $prod[4];
        $reorder = $prod[5];
        $min = $prod[6];
        $sql = "INSERT IGNORE INTO products (product_code, product_name, description, category_id, unit, reorder_level, min_stock_level, is_active) 
                VALUES ('$code', '$name', '$desc', $cat, '$unit', $reorder, $min, TRUE)";
        if (!mysqli_query($conn, $sql)) {
            // If category_id column doesn't exist, try without it
            $sql = "INSERT IGNORE INTO products (product_code, product_name, description, unit, reorder_level, min_stock_level, is_active) 
                    VALUES ('$code', '$name', '$desc', '$unit', $reorder, $min, TRUE)";
            mysqli_query($conn, $sql);
        }
    }
    $messages[] = "✓ Sample products created";

    // Insert sample inventory
    $inventory = [
        [1, 1, 'BATCH001', 10, 30000, 45000, 'A1'],
        [1, 2, 'BATCH002', 50, 500, 1000, 'A2'],
        [1, 3, 'BATCH003', 100, 300, 500, 'B1'],
        [1, 4, 'BATCH004', 200, 200, 400, 'B2'],
        [1, 5, 'BATCH005', 25, 1000, 1500, 'C1']
    ];
    
    foreach ($inventory as $inv) {
        $branch = $inv[0];
        $product = $inv[1];
        $batch = $inv[2];
        $qty = $inv[3];
        $cost = $inv[4];
        $sell = $inv[5];
        $loc = $inv[6];
        $sql = "INSERT IGNORE INTO branch_inventory (branch_id, product_id, batch_number, quantity, cost_price, selling_price, location) 
                VALUES ($branch, $product, '$batch', $qty, $cost, $sell, '$loc')";
        mysqli_query($conn, $sql);
    }
    $messages[] = "✓ Sample inventory created";

    $setup_complete = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RBAC System Setup</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            max-width: 600px;
            width: 100%;
            padding: 40px;
        }

        h1 {
            color: #333;
            margin-bottom: 10px;
            font-size: 28px;
        }

        .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }

        .info-box {
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            color: #0c5460;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .checklist {
            list-style: none;
            margin-bottom: 20px;
        }

        .checklist li {
            padding: 10px;
            margin-bottom: 5px;
            background: #f9f9f9;
            border-left: 3px solid #667eea;
            border-radius: 3px;
            font-size: 14px;
        }

        .checklist li.done {
            background: #d4edda;
            border-left-color: #28a745;
            color: #155724;
        }

        .message {
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 10px;
            font-size: 14px;
        }

        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        .btn-secondary {
            background: #ddd;
            color: #333;
            margin-top: 10px;
        }

        .btn-secondary:hover {
            background: #ccc;
        }

        .success-box {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            margin-bottom: 20px;
        }

        .success-box h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .success-box p {
            margin-bottom: 10px;
            font-size: 14px;
        }

        .next-steps {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .next-steps h3 {
            color: #333;
            margin-bottom: 10px;
            font-size: 16px;
        }

        .next-steps ol {
            margin-left: 20px;
            font-size: 14px;
            color: #666;
        }

        .next-steps li {
            margin-bottom: 8px;
        }

        .credentials {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            color: #856404;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 13px;
        }

        .credentials h4 {
            margin-bottom: 10px;
        }

        .credentials table {
            width: 100%;
            border-collapse: collapse;
        }

        .credentials td {
            padding: 5px;
            border-bottom: 1px solid #ffeaa7;
        }

        code {
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔐 RBAC System Setup</h1>
        <p class="subtitle">Initialize Role-Based Access Control</p>

        <?php if (!$setup_complete && !$table_exists): ?>
            <div class="info-box">
                <strong>Welcome!</strong> This setup wizard will initialize the RBAC system for your Branch Management Application.
            </div>

            <h3 style="margin-bottom: 15px; color: #333;">What will be created:</h3>
            <ul class="checklist">
                <li class="done">✓ Roles table (Admin, Manager, Cashier)</li>
                <li class="done">✓ Permissions table (13 permissions)</li>
                <li class="done">✓ Role-Permission mappings</li>
                <li class="done">✓ Audit log table</li>
                <li class="done">✓ Enhanced users table</li>
            </ul>

            <form method="POST" action="">
                <input type="hidden" name="confirm_setup" value="1">
                <button type="submit" class="btn btn-primary">Start Setup</button>
            </form>

        <?php elseif ($setup_complete): ?>
            <div class="success-box">
                <h2>✓ Setup Complete!</h2>
                <p>RBAC system has been successfully initialized.</p>
            </div>

            <?php if (!empty($messages)): ?>
                <h3 style="color: #333; margin-bottom: 10px;">Setup Messages:</h3>
                <?php foreach ($messages as $msg): ?>
                    <div class="message success"><?php echo htmlspecialchars($msg); ?></div>
                <?php endforeach; ?>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
                <h3 style="color: #721c24; margin-bottom: 10px;">Errors:</h3>
                <?php foreach ($errors as $err): ?>
                    <div class="message error"><?php echo htmlspecialchars($err); ?></div>
                <?php endforeach; ?>
            <?php endif; ?>

            <div class="credentials">
                <h4>📝 Default Credentials (Password: admin123)</h4>
                <table>
                    <tr>
                        <td><strong>Admin</strong></td>
                        <td>username: <code>admin</code></td>
                        <td>→ <code>/admin/users.php</code></td>
                    </tr>
                    <tr>
                        <td><strong>Manager</strong></td>
                        <td>username: <code>manager</code></td>
                        <td>→ <code>/dashboard.php</code></td>
                    </tr>
                    <tr>
                        <td><strong>Cashier</strong></td>
                        <td>username: <code>cashier</code></td>
                        <td>→ <code>/bos/index.php</code></td>
                    </tr>
                </table>
            </div>

            <div class="next-steps">
                <h3>🚀 Next Steps:</h3>
                <ol>
                    <li>Go to the login page: <code>login_new.php</code></li>
                    <li>Select your role (Admin, Manager, or Cashier)</li>
                    <li>Enter credentials from above</li>
                    <li>Start using the system!</li>
                </ol>
            </div>

            <a href="login_new.php" class="btn btn-primary" style="text-decoration: none; display: block; text-align: center;">
                Go to Login Page
            </a>

        <?php else: ?>
            <div class="info-box">
                <strong>ℹ️ Note:</strong> RBAC system is already initialized. You can proceed to the login page.
            </div>

            <a href="login_new.php" class="btn btn-primary" style="text-decoration: none; display: block; text-align: center;">
                Go to Login Page
            </a>

            <button class="btn btn-secondary" onclick="location.href='index.php'">
                Back to Home
            </button>
        <?php endif; ?>
    </div>
</body>
</html>
