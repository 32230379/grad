<?php
require_once 'config.php';
require_once 'functions.php';

// Create order_requests table
$sql = "CREATE TABLE IF NOT EXISTS order_requests (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    barcode VARCHAR(100) UNIQUE NOT NULL,
    branch_id INT NOT NULL,
    requested_by INT NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (requested_by) REFERENCES users(user_id),
    INDEX idx_branch (branch_id),
    INDEX idx_status (status),
    INDEX idx_barcode (barcode),
    INDEX idx_order_number (order_number)
)";

if (mysqli_query($conn, $sql)) {
    echo "✓ order_requests table created successfully<br>";
} else {
    echo "✗ Error creating order_requests table: " . mysqli_error($conn) . "<br>";
}

// Create order_request_items table
$sql = "CREATE TABLE IF NOT EXISTS order_request_items (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES order_requests(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_order (order_id),
    INDEX idx_product (product_id)
)";

if (mysqli_query($conn, $sql)) {
    echo "✓ order_request_items table created successfully<br>";
} else {
    echo "✗ Error creating order_request_items table: " . mysqli_error($conn) . "<br>";
}

// Create order_scans table (for tracking when warehouse scans orders)
$sql = "CREATE TABLE IF NOT EXISTS order_scans (
    scan_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    scanned_by INT,
    scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    device_info TEXT,
    FOREIGN KEY (order_id) REFERENCES order_requests(order_id) ON DELETE CASCADE,
    FOREIGN KEY (scanned_by) REFERENCES users(user_id),
    INDEX idx_order (order_id),
    INDEX idx_scanned_at (scanned_at)
)";

if (mysqli_query($conn, $sql)) {
    echo "✓ order_scans table created successfully<br>";
} else {
    echo "✗ Error creating order_scans table: " . mysqli_error($conn) . "<br>";
}

echo "<br><strong>✓ Order Request System tables created successfully!</strong><br>";
echo "<a href='dashboard.php'>← Back to Dashboard</a>";
?>
