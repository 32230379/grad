<?php
require_once 'config.php';

// Check if users exist and their password hashes
$result = mysqli_query($conn, "SELECT user_id, username, role, is_active, password FROM users");

echo "Users in database:\n";
echo str_repeat("-", 80) . "\n";

while ($row = mysqli_fetch_assoc($result)) {
    echo "ID: {$row['user_id']}, Username: {$row['username']}, Role: {$row['role']}, Active: {$row['is_active']}\n";
    echo "Password Hash: {$row['password']}\n";
    echo "\n";
}

echo str_repeat("-", 80) . "\n";
echo "\nTesting password verification:\n";

// Test admin user
$admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE username = 'admin' LIMIT 1"));

if ($admin) {
    echo "Admin user password hash: " . $admin['password'] . "\n";
    
    // Test with the known password
    $test_pass = 'admin123';
    $result = password_verify($test_pass, $admin['password']);
    
    echo "password_verify('admin123', hash) = " . ($result ? "TRUE" : "FALSE") . "\n";
    
    // Also test what the hash should be
    echo "\nFor reference, hashing 'admin123' now gives:\n";
    echo password_hash('admin123', PASSWORD_BCRYPT) . "\n";
}
?>
