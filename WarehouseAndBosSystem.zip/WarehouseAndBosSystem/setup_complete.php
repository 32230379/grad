<?php
require_once 'config.php';

echo "<h2>Complete Database Setup</h2>";
echo "<p>Setting up all required tables...</p>";

$errors = [];
$success = [];

// 1. Create order_requests table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS order_requests (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    barcode VARCHAR(100) UNIQUE NOT NULL,
    branch_id INT NOT NULL,
    requested_by INT NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (requested_by) REFERENCES users(user_id),
    INDEX idx_branch (branch_id),
    INDEX idx_status (status),
    INDEX idx_barcode (barcode),
    INDEX idx_order_number (order_number)
)";

if (mysqli_query($conn, $sql)) {
    $success[] = "✓ order_requests table created/verified";
} else {
    $errors[] = "✗ Error with order_requests table: " . mysqli_error($conn);
}

// 2. Create order_request_items table
$sql = "CREATE TABLE IF NOT EXISTS order_request_items (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES order_requests(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_order (order_id),
    INDEX idx_product (product_id)
)";

if (mysqli_query($conn, $sql)) {
    $success[] = "✓ order_request_items table created/verified";
} else {
    $errors[] = "✗ Error with order_request_items table: " . mysqli_error($conn);
}

// 3. Create order_scans table
$sql = "CREATE TABLE IF NOT EXISTS order_scans (
    scan_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    scanned_by INT,
    scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    device_info TEXT,
    FOREIGN KEY (order_id) REFERENCES order_requests(order_id) ON DELETE CASCADE,
    FOREIGN KEY (scanned_by) REFERENCES users(user_id),
    INDEX idx_order (order_id),
    INDEX idx_scanned_at (scanned_at)
)";

if (mysqli_query($conn, $sql)) {
    $success[] = "✓ order_scans table created/verified";
} else {
    $errors[] = "✗ Error with order_scans table: " . mysqli_error($conn);
}

// 4. Create order_receipts table
$sql = "CREATE TABLE IF NOT EXISTS order_receipts (
    receipt_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    received_by INT NOT NULL,
    receipt_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    status ENUM('completed', 'partial', 'rejected') DEFAULT 'completed',
    FOREIGN KEY (order_id) REFERENCES order_requests(order_id),
    FOREIGN KEY (received_by) REFERENCES users(user_id),
    INDEX idx_order (order_id),
    INDEX idx_received_by (received_by)
)";

if (mysqli_query($conn, $sql)) {
    $success[] = "✓ order_receipts table created/verified";
} else {
    $errors[] = "✗ Error with order_receipts table: " . mysqli_error($conn);
}

// 5. Create receipt_items table
$sql = "CREATE TABLE IF NOT EXISTS receipt_items (
    receipt_item_id INT PRIMARY KEY AUTO_INCREMENT,
    receipt_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity_received INT NOT NULL,
    status ENUM('received', 'partial', 'damaged', 'not_received') NOT NULL,
    notes TEXT,
    FOREIGN KEY (receipt_id) REFERENCES order_receipts(receipt_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_receipt (receipt_id),
    INDEX idx_product (product_id)
)";

if (mysqli_query($conn, $sql)) {
    $success[] = "✓ receipt_items table created/verified";
} else {
    $errors[] = "✗ Error with receipt_items table: " . mysqli_error($conn);
}

// 6. Ensure branch_inventory table exists with branch_id column
$sql = "CREATE TABLE IF NOT EXISTS branch_inventory (
    inventory_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    product_id INT NOT NULL,
    batch_number VARCHAR(50),
    quantity INT NOT NULL DEFAULT 0,
    expiry_date DATE NULL,
    cost_price DECIMAL(10,2),
    selling_price DECIMAL(10,2),
    location VARCHAR(50),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_branch_product (branch_id, product_id),
    INDEX idx_batch (batch_number),
    INDEX idx_expiry (expiry_date)
)";

if (mysqli_query($conn, $sql)) {
    $success[] = "✓ branch_inventory table created/verified";
} else {
    $errors[] = "✗ Error with branch_inventory table: " . mysqli_error($conn);
}

// 6. Ensure users table has receiver role support
$sql = "ALTER TABLE users MODIFY role ENUM('admin', 'manager', 'cashier', 'receiver') NOT NULL";
if (mysqli_query($conn, $sql)) {
    $success[] = "✓ users table role enum updated";
} else {
    // This might fail if already updated, which is fine
    $success[] = "✓ users table role enum verified";
}

// Display results
echo "<h3>Setup Results:</h3>";
echo "<ul>";
foreach ($success as $msg) {
    echo "<li style='color: green;'>" . htmlspecialchars($msg) . "</li>";
}
foreach ($errors as $msg) {
    echo "<li style='color: red;'>" . htmlspecialchars($msg) . "</li>";
}
echo "</ul>";

// Verify tables exist
echo "<h3>Table Verification:</h3>";
$tables = ['order_requests', 'order_request_items', 'order_scans', 'order_receipts', 'receipt_items', 'branch_inventory'];
foreach ($tables as $table) {
    $result = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
    if (mysqli_num_rows($result) > 0) {
        echo "<p style='color: green;'>✓ $table exists</p>";
    } else {
        echo "<p style='color: red;'>✗ $table missing</p>";
    }
}

echo "<hr>";
echo "<p><a href='admin/dashboard.php'>← Back to Admin Dashboard</a></p>";
?>
