<?php
require_once 'config.php';

echo "Setting up users...\n\n";

// Delete existing users
mysqli_query($conn, "DELETE FROM users WHERE username IN ('admin', 'manager', 'cashier')");

// Hash the password
$password_hash = password_hash('admin123', PASSWORD_BCRYPT);

// Create admin user (with branch_manager role in DB)
$insert1 = mysqli_query($conn, "INSERT INTO users (username, password, full_name, email, phone, role, is_active) 
                                VALUES ('admin', '$password_hash', 'System Administrator', 'admin@branch.com', '+1234567890', 'branch_manager', 1)");
echo "Created admin user: " . ($insert1 ? "OK" : "FAILED - " . mysqli_error($conn)) . "\n";

// Create manager user
$insert2 = mysqli_query($conn, "INSERT INTO users (username, password, full_name, email, phone, role, branch_id, is_active) 
                                VALUES ('manager', '$password_hash', 'John Manager', 'manager@branch.com', '+1234567891', 'branch_manager', 1, 1)");
echo "Created manager user: " . ($insert2 ? "OK" : "FAILED - " . mysqli_error($conn)) . "\n";

// Create cashier user
$insert3 = mysqli_query($conn, "INSERT INTO users (username, password, full_name, email, phone, role, branch_id, is_active) 
                                VALUES ('cashier', '$password_hash', 'Jane Cashier', 'cashier@branch.com', '+1234567892', 'cashier', 1, 1)");
echo "Created cashier user: " . ($insert3 ? "OK" : "FAILED - " . mysqli_error($conn)) . "\n";

echo "\n\nVerifying users:\n";
$result = mysqli_query($conn, "SELECT user_id, username, role, is_active FROM users WHERE username IN ('admin', 'manager', 'cashier')");
while($row = mysqli_fetch_assoc($result)) {
    echo "ID: {$row['user_id']}, Username: {$row['username']}, Role: {$row['role']}, Active: " . ($row['is_active'] ? 'Yes' : 'No') . "\n";
}

echo "\n\nTest password verification:\n";
$admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT password FROM users WHERE username = 'admin'"));
$verify = password_verify('admin123', $admin['password']);
echo "password_verify('admin123', admin_hash) = " . ($verify ? "TRUE ✓" : "FALSE ✗") . "\n";

echo "\n\nLogin credentials:\n";
echo "Admin: username=admin, password=admin123, select role=Admin\n";
echo "Manager: username=manager, password=admin123, select role=Manager\n";
echo "Cashier: username=cashier, password=admin123, select role=Cashier\n";
?>
