# Complete RBAC Implementation Guide

## Quick Start

### 1. Database Setup (5 minutes)

```bash
# Option A: Using phpMyAdmin
1. Open http://localhost/phpmyadmin
2. Create database: branch_system
3. Import: database_schema_rbac.sql

# Option B: Using Command Line
mysql -u root -p < database_schema_rbac.sql
```

### 2. Run Setup Script (2 minutes)

Visit: `http://localhost/warehouse+bos%20system/setup_rbac.php`

This will:
- Create all RBAC tables
- Insert default roles and permissions
- Configure admin user
- Set up audit logging

### 3. Login (1 minute)

Visit: `http://localhost/warehouse+bos%20system/login_new.php`

Use default credentials:
- **Admin**: admin / admin123
- **Manager**: manager / admin123
- **Cashier**: cashier / admin123

---

## System Overview

### Three-Role Architecture

```
┌─────────────────────────────────────────┐
│         RBAC System                     │
├─────────────────────────────────────────┤
│                                         │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐
│  │  ADMIN   │  │ MANAGER  │  │ CASHIER  │
│  └──────────┘  └──────────┘  └──────────┘
│       │              │              │
│       ▼              ▼              ▼
│  User Mgmt      Dashboard        BOS POS
│  Audit Logs     Inventory        Inventory
│  Permissions    Reports          Sales
│  Settings       Staff Mgmt       Receipts
│                                  
└─────────────────────────────────────────┘
```

### Login Flow

```
User → login_new.php
  ↓
Select Role (Admin/Manager/Cashier)
  ↓
Enter Credentials
  ↓
Verify Role + Password
  ↓
Set Session Variables
  ↓
Redirect:
  Admin → /admin/users.php
  Manager → /dashboard.php
  Cashier → /bos/index.php
```

---

## File Structure

```
warehouse+bos system/
├── login_new.php                    # Main login page
├── logout.php                       # Logout handler
├── setup_rbac.php                   # Setup wizard
├── functions.php                    # RBAC functions
├── config.php                       # Database config
│
├── admin/                           # Admin Panel
│   ├── users.php                   # User management
│   └── audit_logs.php              # Audit logs
│
├── bos/                            # Cashier BOS
│   ├── index.php                   # Dashboard
│   ├── sales.php                   # Point of Sale
│   ├── inventory.php               # Inventory view
│   ├── sales_history.php           # Sales history
│   ├── receipts.php                # Receipts
│   ├── returns.php                 # Returns
│   ├── daily_report.php            # Daily report
│   ├── summary.php                 # Summary
│   ├── profile.php                 # User profile
│   ├── change_password.php         # Change password
│   └── help.php                    # Help center
│
└── database_schema_rbac.sql         # Database schema
```

---

## Key Features

### Admin Panel (`/admin/users.php`)

✅ **User Management**
- Create new users (Manager/Cashier)
- View all users
- Activate/Deactivate users
- Delete users
- Assign to branches
- View user statistics

✅ **Audit Logs** (`/admin/audit_logs.php`)
- Track all user actions
- View IP addresses
- See before/after values
- Pagination support
- JSON data viewer

### Manager Dashboard (`/dashboard.php`)

✅ **Operations**
- View dashboard
- Manage inventory
- Manage sales
- Manage receiving
- View reports
- Manage staff

### Cashier BOS (`/bos/index.php`)

✅ **Point of Sale System**
- Process transactions
- View inventory
- Search products
- Shopping cart
- Multiple payment methods
- Daily sales summary

✅ **Additional Features**
- Sales history
- Receipts management
- Returns processing
- Daily reports
- User profile
- Change password
- Help center

---

## Authentication Functions

### Usage Examples

```php
<?php
require_once 'config.php';
require_once 'functions.php';

// Protect page - require login
requireLogin();

// Protect page - require admin
requireAdmin();

// Protect page - require manager
requireManager();

// Protect page - require cashier
requireCashier();

// Check user role
if (isAdmin()) {
    // Admin-only code
}

if (isManager()) {
    // Manager-only code
}

if (isCashier()) {
    // Cashier-only code
}

// Get user info
$user = getUserInfo();
echo $user['full_name'];
echo $user['role'];
echo $user['branch_id'];

// Log activity
logActivity($_SESSION['user_id'], 'Action', 'Module', 'Description');

// Audit log
auditLog($_SESSION['user_id'], 'CREATE_USER', 'Created new user', null, ['user_id' => 5]);
?>
```

---

## Creating Users

### Via Admin Panel

1. Login as Admin
2. Go to `/admin/users.php`
3. Fill "Add New User" form
4. Select role (Manager or Cashier)
5. Assign branch (optional)
6. Click "Create User"

### Via Database

```sql
INSERT INTO users (username, password, full_name, email, phone, role, branch_id, is_active, created_by) 
VALUES (
    'newuser',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    'New User',
    'newuser@branch.com',
    '+1234567890',
    'manager',
    1,
    1,
    1
);
```

### Generate Password Hash

```php
<?php
$password = 'admin123';
$hash = password_hash($password, PASSWORD_BCRYPT);
echo $hash;
?>
```

---

## Session Variables

After login, these are available:

```php
$_SESSION['user_id']      // int: User ID
$_SESSION['username']     // string: Username
$_SESSION['full_name']    // string: Full name
$_SESSION['role']         // string: admin|manager|cashier
$_SESSION['is_admin']     // bool: Is admin?
$_SESSION['branch_id']    // int: Branch ID (null for admin)
$_SESSION['branch_name']  // string: Branch name
```

---

## Database Tables

### roles
```sql
role_id INT PRIMARY KEY
role_name VARCHAR(50) UNIQUE
description TEXT
is_active BOOLEAN
created_at TIMESTAMP
```

### permissions
```sql
permission_id INT PRIMARY KEY
permission_name VARCHAR(100) UNIQUE
description TEXT
module VARCHAR(50)
created_at TIMESTAMP
```

### role_permissions
```sql
role_permission_id INT PRIMARY KEY
role_id INT FOREIGN KEY
permission_id INT FOREIGN KEY
```

### users (enhanced)
```sql
user_id INT PRIMARY KEY
username VARCHAR(50) UNIQUE
password VARCHAR(255)
full_name VARCHAR(100)
email VARCHAR(100) UNIQUE
phone VARCHAR(20)
role ENUM('admin', 'manager', 'cashier')
branch_id INT
is_admin BOOLEAN DEFAULT FALSE
admin_since TIMESTAMP
created_by INT FOREIGN KEY
is_active BOOLEAN DEFAULT TRUE
created_at TIMESTAMP
updated_at TIMESTAMP
last_login TIMESTAMP
```

### user_audit_log
```sql
audit_id INT PRIMARY KEY
user_id INT FOREIGN KEY
action VARCHAR(100)
description TEXT
old_values JSON
new_values JSON
ip_address VARCHAR(45)
user_agent TEXT
created_at TIMESTAMP
```

---

## Security Features

✅ **Password Security**
- Bcrypt hashing (PASSWORD_BCRYPT)
- Minimum 6 characters
- Secure password verification

✅ **SQL Injection Prevention**
- Prepared statements
- Input sanitization
- Escaped queries

✅ **Session Management**
- Secure session handling
- Session timeout (1 hour)
- Session destruction on logout

✅ **Audit Trail**
- All user actions logged
- IP address tracking
- User agent tracking
- Before/after value comparison

✅ **Access Control**
- Role-based access
- Permission checking
- Strict authorization

---

## Troubleshooting

### Issue: "Access denied" error
**Solution:**
- Check user role in database
- Verify user is active (is_active = 1)
- Check role matches page requirements

### Issue: Login redirects to login page
**Solution:**
- Verify database connection
- Check credentials are correct
- Verify user exists
- Check password hash is correct

### Issue: Can't access admin panel
**Solution:**
- Verify user has is_admin = 1
- Check role is 'admin'
- Check user is active

### Issue: Cashier can't access BOS
**Solution:**
- Verify role is 'cashier'
- Check user is active
- Verify branch is assigned

### Issue: Session variables not set
**Solution:**
- Check config.php has correct database
- Verify session_start() is called
- Check login was successful

---

## Customization

### Adding New Roles

```sql
INSERT INTO roles (role_name, description) 
VALUES ('supervisor', 'Supervisor role');
```

### Adding New Permissions

```sql
INSERT INTO permissions (permission_name, description, module) 
VALUES ('approve_returns', 'Approve product returns', 'returns');
```

### Assigning Permissions to Role

```sql
INSERT INTO role_permissions (role_id, permission_id) 
SELECT r.role_id, p.permission_id 
FROM roles r, permissions p 
WHERE r.role_name = 'supervisor' 
AND p.permission_name = 'approve_returns';
```

---

## Best Practices

1. **Always use requireLogin()** at the start of protected pages
2. **Use specific role checks** (requireAdmin, requireManager, etc.)
3. **Log important actions** with logActivity() or auditLog()
4. **Sanitize user input** with sanitizeInput()
5. **Use prepared statements** for database queries
6. **Check session variables** before using them
7. **Implement password policies** for new users
8. **Review audit logs** regularly
9. **Disable inactive users** instead of deleting
10. **Keep passwords secure** and change regularly

---

## Testing Checklist

- [ ] Admin can create users
- [ ] Admin can view audit logs
- [ ] Admin can deactivate users
- [ ] Manager can access dashboard
- [ ] Manager cannot access admin panel
- [ ] Cashier can access BOS
- [ ] Cashier can process sales
- [ ] Cashier cannot access admin panel
- [ ] Logout works correctly
- [ ] Session timeout works
- [ ] Passwords are hashed
- [ ] Audit logs are created
- [ ] Role-based redirects work

---

## Support & Documentation

- **Setup Guide**: RBAC_SETUP.md
- **Database Schema**: database_schema_rbac.sql
- **Setup Wizard**: setup_rbac.php
- **Admin Panel**: /admin/users.php
- **Audit Logs**: /admin/audit_logs.php

---

## Version History

**v1.0** (Current)
- Initial RBAC implementation
- Three roles: Admin, Manager, Cashier
- User management panel
- Audit logging
- BOS system for cashiers
- Complete authentication system

---

## License

This RBAC system is part of the Branch Management Application.
