# Stock Order System - Setup Guide

## Overview
This system allows **Branch Managers and Admin** to create stock replenishment orders for items that are running low. Orders are printed as paper documents with a barcode at the top that identifies the entire order.

## Features

### 1. **Branch Manager Features**
- ✅ View all low stock items (below reorder level)
- ✅ Select items to order with custom quantities
- ✅ Add notes and special instructions
- ✅ Generate printable order forms with barcode
- ✅ View order history and status
- ✅ Track all orders sent to warehouse

### 2. **Admin Features**
- ✅ View all low stock items across all branches
- ✅ Create stock orders for warehouse replenishment
- ✅ See which manager/admin created each order
- ✅ Track order status (Pending → Confirmed → Shipped → Delivered)
- ✅ View complete order history

## Installation Steps

### Step 1: Create Database Tables
Run the setup script to create required tables:

```
Visit: http://localhost/WarehouseAndBosSystem/setup_order_requests.php
```

This will create:
- `order_requests` - Main order table
- `order_request_items` - Order line items
- `order_scans` - Barcode scan tracking

### Step 2: Access the System

#### For Branch Managers:
1. Login as a manager
2. Go to Dashboard → Create Stock Order
3. View all low stock items
4. Select items to order (checkboxes)
5. Adjust quantities as needed
6. Add notes if necessary
7. Submit order
8. Print the paper with barcode at top
9. Send printed paper to warehouse

**URL:** `http://localhost/WarehouseAndBosSystem/dashboard/order_request.php`

#### For Admin:
1. Login as admin
2. Go to Admin Dashboard
3. Access Stock Orders section
4. View all orders from all branches
5. See which manager created each order
6. Track order status
7. View complete order history

**URL:** `http://localhost/WarehouseAndBosSystem/admin/order_requests.php` (to be created)

## Database Schema

### order_requests Table
```sql
- order_id: INT (Primary Key)
- order_number: VARCHAR(50) UNIQUE (e.g., STOCK-20251116-1234)
- barcode: VARCHAR(100) UNIQUE (same as order_number - printed on paper)
- branch_id: INT (Foreign Key)
- requested_by: INT (Foreign Key - User ID of manager/admin)
- order_date: TIMESTAMP
- status: VARCHAR(20) (pending, confirmed, shipped, delivered)
- notes: TEXT
```

### order_request_items Table
```sql
- item_id: INT (Primary Key)
- order_id: INT (Foreign Key)
- product_id: INT (Foreign Key)
- quantity: INT (quantity ordered)
```

### order_scans Table
```sql
- scan_id: INT (Primary Key)
- order_id: INT (Foreign Key)
- scanned_by: INT (Foreign Key - User ID of warehouse staff)
- scanned_at: TIMESTAMP (when barcode was scanned)
- device_info: TEXT
```

## File Structure

```
WarehouseAndBosSystem/
├── dashboard/
│   ├── order_request.php          # Create stock order (Manager/Admin)
│   ├── order_request_print.php    # Print paper with barcode (Manager/Admin)
│   └── order_history.php          # View orders (Manager/Admin)
├── admin/
│   ├── order_requests.php         # View all orders (Admin)
│   └── order_reports.php          # Reports (Admin)
└── setup_order_requests.php       # Database setup
```

## Workflow

### 1. Manager Creates Stock Order
```
Manager Login → Dashboard → Create Stock Order
↓
View Low Stock Items (auto-populated)
↓
Select items with checkboxes → Adjust quantities
↓
Add notes if needed → Submit Order
↓
System generates barcode (STOCK-YYYYMMDD-XXXX)
↓
Print Paper with Barcode at Top → Send to Warehouse
```

### 2. Warehouse Receives Paper Order
```
Warehouse Staff receives printed paper with barcode
↓
Barcode identifies the entire order
↓
Staff picks all items listed on the paper
↓
Prepares shipment and marks as shipped
```

### 3. Admin Tracks Orders
```
Admin Login → Admin Dashboard → Stock Orders
↓
See all orders from all branches
↓
See which manager created each order
↓
Track order status (Pending → Confirmed → Shipped → Delivered)
```

## Barcode Format

The barcode is printed on the paper and identifies the entire order:
```
STOCK-YYYYMMDD-XXXX
```

Example: `STOCK-20251116-1234`

- `STOCK` = Stock order prefix
- `YYYYMMDD` = Date (Year-Month-Day)
- `XXXX` = Random 4-digit number
- **This barcode is printed at the TOP of the paper**

## Status Flow

```
PENDING (Order created)
   ↓
CONFIRMED (Warehouse scans barcode)
   ↓
SHIPPED (Warehouse marks as shipped)
   ↓
DELIVERED (Branch receives order)
```

## Low Stock Detection

The system automatically identifies low stock items by comparing:
- **Current Stock** (sum of all branch inventory for that product)
- **Reorder Level** (set in product master data)

Items are shown if: `current_stock <= reorder_level`

Managers can adjust the suggested quantities before ordering.

## Security Features

✅ **Role-Based Access Control**
- Only managers can create orders
- Only warehouse staff can scan orders
- Only admins can view all orders

✅ **Audit Logging**
- All order creation is logged
- All scans are recorded with timestamp and user
- Admin can see who created and scanned each order

✅ **Data Validation**
- Barcode must be unique
- Order number must be unique
- Products must exist in system
- Quantities must be positive

## Troubleshooting

### Issue: "Order not found" when scanning
**Solution:** 
- Check if barcode is correct
- Ensure order exists in database
- Try manual entry of order number

### Issue: Barcode not printing correctly
**Solution:**
- Use Print function (Ctrl+P)
- Select appropriate paper size
- Ensure printer supports barcode fonts

### Issue: Can't create order
**Solution:**
- Ensure you're logged in as manager
- Check if products are available
- Verify branch is assigned to your user

## Future Enhancements

- [ ] Mobile app for warehouse scanning
- [ ] Real-time notifications
- [ ] Automatic email alerts
- [ ] SMS notifications
- [ ] Delivery tracking
- [ ] Return order requests
- [ ] Inventory sync with warehouse
- [ ] Barcode label printing
- [ ] QR code support
- [ ] Order forecasting

## Support

For issues or questions, contact:
- **Branch Manager Support:** admin@warehouse.local
- **Warehouse Support:** warehouse@warehouse.local
- **System Admin:** sysadmin@warehouse.local

---

**Last Updated:** November 16, 2025
**Version:** 1.0
