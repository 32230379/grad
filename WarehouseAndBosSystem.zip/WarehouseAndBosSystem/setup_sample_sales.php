<?php
require_once 'config.php';

echo "<h2>Creating Sample Sales Data</h2>";

// Get a cashier user
$cashier_query = "SELECT user_id FROM users WHERE role = 'cashier' LIMIT 1";
$cashier_result = mysqli_query($conn, $cashier_query);
$cashier = mysqli_fetch_assoc($cashier_result);

if (!$cashier) {
    echo "<p style='color: red;'>No cashier user found. Please create a cashier first.</p>";
    exit;
}

$cashier_id = $cashier['user_id'];

// Get products
$products_query = "SELECT product_id FROM products LIMIT 5";
$products_result = mysqli_query($conn, $products_query);
$products = [];
while ($product = mysqli_fetch_assoc($products_result)) {
    $products[] = $product['product_id'];
}

if (empty($products)) {
    echo "<p style='color: red;'>No products found. Please add products first.</p>";
    exit;
}

// Create sample transactions for the last 30 days
$payment_methods = ['cash', 'card', 'mobile', 'credit'];
$transaction_count = 0;

for ($i = 0; $i < 20; $i++) {
    $sale_date = date('Y-m-d', strtotime("-" . rand(0, 29) . " days"));
    $sale_time = sprintf("%02d:%02d:%02d", rand(9, 17), rand(0, 59), rand(0, 59));
    $transaction_number = 'TXN-' . date('Ymd') . '-' . str_pad($i + 1, 4, '0', STR_PAD_LEFT);
    $payment_method = $payment_methods[array_rand($payment_methods)];
    
    $subtotal = rand(1000, 50000);
    $discount = rand(0, 500);
    $tax = ($subtotal - $discount) * 0.1;
    $total = $subtotal - $discount + $tax;
    
    $insert_query = "INSERT INTO sales_transactions 
                     (transaction_number, sale_date, sale_time, cashier_id, subtotal, discount, tax, total_amount, payment_method, payment_status) 
                     VALUES ('$transaction_number', '$sale_date', '$sale_time', $cashier_id, $subtotal, $discount, $tax, $total, '$payment_method', 'paid')";
    
    if (mysqli_query($conn, $insert_query)) {
        $transaction_id = mysqli_insert_id($conn);
        
        // Add 1-3 items to each transaction
        $num_items = rand(1, 3);
        for ($j = 0; $j < $num_items; $j++) {
            $product_id = $products[array_rand($products)];
            $quantity = rand(1, 5);
            $unit_price = rand(500, 10000);
            $item_discount = rand(0, 200);
            $item_subtotal = ($unit_price * $quantity) - $item_discount;
            
            $item_query = "INSERT INTO sales_items 
                          (transaction_id, product_id, quantity, unit_price, discount, subtotal) 
                          VALUES ($transaction_id, $product_id, $quantity, $unit_price, $item_discount, $item_subtotal)";
            
            mysqli_query($conn, $item_query);
        }
        
        $transaction_count++;
        echo "<p style='color: green;'>✓ Created transaction: $transaction_number</p>";
    } else {
        echo "<p style='color: red;'>✗ Error creating transaction: " . mysqli_error($conn) . "</p>";
    }
}

echo "<hr>";
echo "<p style='color: green;'><strong>✓ Created $transaction_count sample transactions with sales items</strong></p>";
echo "<p><a href='bos/reports.php'>← Go to Sales Reports</a></p>";
?>
