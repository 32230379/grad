<?php
require_once 'config.php';

echo "<h2>Adding Sample Orders</h2>";

// Get a manager user (use user_id 5 which is the manager)
$manager_id = 5;
$manager_check = mysqli_query($conn, "SELECT user_id FROM users WHERE user_id = $manager_id");
if (!mysqli_fetch_assoc($manager_check)) {
    echo "<p style='color: red;'>Manager user not found.</p>";
    exit;
}

// Get a product
$product_query = "SELECT product_id FROM products LIMIT 1";
$product_result = mysqli_query($conn, $product_query);
$product = mysqli_fetch_assoc($product_result);

if (!$product) {
    echo "<p style='color: red;'>No products found. Please add products first.</p>";
    exit;
}

$product_id = $product['product_id'];

// Create sample orders
for ($i = 1; $i <= 3; $i++) {
    $order_number = "ORD-" . date('Ymd') . "-" . str_pad($i, 4, '0', STR_PAD_LEFT);
    $barcode = "STOCK-" . date('Ymd') . "-" . str_pad($i, 4, '0', STR_PAD_LEFT);
    $branch_id = 1;
    
    $insert_query = "INSERT INTO order_requests (order_number, barcode, branch_id, requested_by, status) 
                     VALUES ('$order_number', '$barcode', $branch_id, $manager_id, 'pending')";
    
    if (mysqli_query($conn, $insert_query)) {
        $order_id = mysqli_insert_id($conn);
        
        // Add items to order
        $item_query = "INSERT INTO order_request_items (order_id, product_id, quantity) 
                       VALUES ($order_id, $product_id, " . (10 + $i) . ")";
        
        if (mysqli_query($conn, $item_query)) {
            echo "<p style='color: green;'>✓ Created order: $order_number (ID: $order_id)</p>";
        } else {
            echo "<p style='color: red;'>✗ Error adding items: " . mysqli_error($conn) . "</p>";
        }
    } else {
        echo "<p style='color: red;'>✗ Error creating order: " . mysqli_error($conn) . "</p>";
    }
}

echo "<hr>";
echo "<p><a href='receiver/dashboard.php'>← Go to Receiver Dashboard</a></p>";
?>
