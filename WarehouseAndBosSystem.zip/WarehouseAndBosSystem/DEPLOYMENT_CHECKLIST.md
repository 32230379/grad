# Shelf Management System - Deployment Checklist

## Pre-Deployment ✅

- [ ] Backup current database
- [ ] Backup current code
- [ ] Review all changes in IMPLEMENTATION_SUMMARY.md
- [ ] Test in development environment first

---

## Database Setup ✅

- [ ] Run `setup_shelf_system.php`
  ```
  http://localhost/WarehouseAndBosSystem/setup_shelf_system.php
  ```
- [ ] Verify all tables created:
  ```sql
  SHOW TABLES LIKE 'shelf_%';
  ```
- [ ] Verify columns added:
  ```sql
  SHOW COLUMNS FROM branch_inventory;
  ```
- [ ] Verify views created:
  ```sql
  SHOW FULL TABLES WHERE TABLE_TYPE LIKE 'VIEW';
  ```

---

## File Verification ✅

### New Files (Should Exist)
- [ ] `/api/shelf_transfer.php`
- [ ] `/api/get_alerts.php`
- [ ] `/api/acknowledge_alert.php`
- [ ] `/bos/shelf_management.php`
- [ ] `/setup_shelf_system.php`
- [ ] `/database_schema_with_shelf.sql`
- [ ] `/SHELF_MANAGEMENT_GUIDE.md`
- [ ] `/SHELF_SYSTEM_QUICK_START.md`
- [ ] `/IMPLEMENTATION_SUMMARY.md`
- [ ] `/DEPLOYMENT_CHECKLIST.md`

### Modified Files (Check Changes)
- [ ] `/bos/api_checkout.php` - Verify shelf stock deduction logic
- [ ] `/functions.php` - Verify new alert functions

---

## Functionality Testing ✅

### Test 1: Database Setup
```sql
-- Verify shelf_transfers table
SELECT COUNT(*) FROM shelf_transfers;

-- Verify shelf_stock_alerts table
SELECT COUNT(*) FROM shelf_stock_alerts;

-- Verify shelf_stock_history table
SELECT COUNT(*) FROM shelf_stock_history;

-- Verify branch_inventory columns
SELECT on_shelf_quantity, shelf_min_level, shelf_reorder_level 
FROM branch_inventory LIMIT 1;
```

### Test 2: Shelf Management UI
- [ ] Login as manager
- [ ] Navigate to `/bos/shelf_management.php`
- [ ] Page loads without errors
- [ ] All products display correctly
- [ ] Status indicators show (OK, LOW, CRITICAL)

### Test 3: Transfer Functionality
- [ ] Click "Transfer" button
- [ ] Modal opens correctly
- [ ] Enter quantity and submit
- [ ] Transfer completes successfully
- [ ] Quantities update correctly
- [ ] Transfer appears in history

### Test 4: Checkout Integration
- [ ] Login as cashier
- [ ] Add items to cart
- [ ] Process checkout
- [ ] Verify shelf stock deducted (not inventory)
- [ ] Verify shelf_stock_history record created

### Test 5: Alert Generation
- [ ] Manually reduce shelf stock below threshold
- [ ] Verify alert appears in shelf_stock_alerts table
- [ ] Verify alert appears in manager dashboard
- [ ] Acknowledge alert
- [ ] Verify alert marked as read

### Test 6: API Endpoints
- [ ] Test GET `/api/shelf_transfer.php?action=get_status&product_id=1`
- [ ] Test GET `/api/shelf_transfer.php?action=get_all`
- [ ] Test GET `/api/get_alerts.php?type=all`
- [ ] Test POST `/api/shelf_transfer.php` with valid data
- [ ] Test POST `/api/acknowledge_alert.php` with valid data

---

## Performance Testing ✅

- [ ] Load shelf management page with 100+ products
- [ ] Verify page loads in < 3 seconds
- [ ] Test transfer with large quantity
- [ ] Test checkout with multiple items
- [ ] Monitor database query performance

---

## Security Testing ✅

- [ ] Verify only managers can access shelf management
- [ ] Verify only managers can create transfers
- [ ] Verify only managers can acknowledge alerts
- [ ] Test with invalid user role (should be denied)
- [ ] Test with invalid product ID (should be denied)
- [ ] Test with invalid quantity (should be denied)
- [ ] Verify all queries use prepared statements

---

## Data Integrity Testing ✅

- [ ] Verify inventory never goes negative
- [ ] Verify shelf stock never goes negative
- [ ] Verify transfer reduces inventory and increases shelf
- [ ] Verify sale reduces shelf only
- [ ] Verify history records all changes
- [ ] Verify no duplicate alerts within 1 hour

---

## Documentation Review ✅

- [ ] SHELF_MANAGEMENT_GUIDE.md is complete
- [ ] SHELF_SYSTEM_QUICK_START.md is clear
- [ ] IMPLEMENTATION_SUMMARY.md is accurate
- [ ] Code comments are present
- [ ] API documentation is clear

---

## User Training ✅

- [ ] Train managers on shelf management
- [ ] Train cashiers on new checkout flow
- [ ] Provide quick reference guides
- [ ] Set up help documentation
- [ ] Create video tutorials (optional)

---

## Monitoring Setup ✅

- [ ] Set up alert notifications
- [ ] Configure email alerts (optional)
- [ ] Set up logging for transfers
- [ ] Set up logging for alerts
- [ ] Create monitoring dashboard

---

## Backup & Rollback ✅

- [ ] Create database backup before deployment
- [ ] Create code backup before deployment
- [ ] Document rollback procedure
- [ ] Test rollback procedure
- [ ] Store backups securely

---

## Post-Deployment ✅

### Day 1
- [ ] Monitor system for errors
- [ ] Check alert generation
- [ ] Verify transfers working
- [ ] Monitor checkout process
- [ ] Collect user feedback

### Day 7
- [ ] Review transfer history
- [ ] Review alert history
- [ ] Check for any issues
- [ ] Optimize thresholds if needed
- [ ] Generate usage report

### Day 30
- [ ] Full system audit
- [ ] Performance review
- [ ] Data integrity check
- [ ] User satisfaction survey
- [ ] Plan improvements

---

## Troubleshooting Guide ✅

### Issue: Setup script fails
**Solution:**
1. Check database permissions
2. Verify MySQL version (5.7+)
3. Check for existing tables
4. Review error messages
5. Contact admin if needed

### Issue: Shelf management page won't load
**Solution:**
1. Verify user is logged in as manager
2. Check PHP error logs
3. Verify database connection
4. Clear browser cache
5. Check file permissions

### Issue: Transfers not working
**Solution:**
1. Verify inventory has stock
2. Check database tables exist
3. Review error messages
4. Check user permissions
5. Verify API endpoints accessible

### Issue: Alerts not appearing
**Solution:**
1. Verify shelf_stock_alerts table exists
2. Check stock levels vs thresholds
3. Verify alert creation logic
4. Check for duplicate alert prevention
5. Review database for alerts

---

## Sign-Off ✅

- [ ] Database admin: _________________ Date: _______
- [ ] System admin: _________________ Date: _______
- [ ] Manager: _________________ Date: _______
- [ ] Project lead: _________________ Date: _______

---

## Deployment Date & Time

**Date:** _______________
**Time:** _______________
**Deployed By:** _______________
**Approved By:** _______________

---

## Post-Deployment Notes

```
[Space for notes about deployment, issues, and resolutions]




```

---

## Emergency Contacts

**Database Admin:** _______________
**System Admin:** _______________
**Project Lead:** _______________
**Support Team:** _______________

---

## Rollback Procedure (If Needed)

1. Stop application
2. Restore database from backup
3. Restore code from backup
4. Restart application
5. Verify system working
6. Document issue
7. Contact support team

---

## Success Criteria

✅ All tests passed
✅ No critical errors
✅ Users trained
✅ Documentation complete
✅ Monitoring active
✅ Backups created
✅ Sign-offs obtained

---

**Deployment Status:** ☐ NOT STARTED  ☐ IN PROGRESS  ☐ COMPLETE

**Last Updated:** _______________
**Next Review:** _______________

---

For questions or issues, refer to:
- SHELF_MANAGEMENT_GUIDE.md
- IMPLEMENTATION_SUMMARY.md
- SHELF_SYSTEM_QUICK_START.md
