<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashierOrManager();

$user = getUserInfo();

// Get inventory for this branch
$inventory_query = "SELECT p.product_id, p.product_code, p.product_name, 
                           SUM(bi.quantity) as total_stock, bi.selling_price, bi.expiry_date
                    FROM branch_inventory bi
                    JOIN products p ON bi.product_id = p.product_id
                    GROUP BY p.product_id
                    ORDER BY p.product_name";
$inventory_result = mysqli_query($conn, $inventory_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory - BOS</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            font-size: 24px;
        }

        .back-link {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 600;
            transition: background 0.3s;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .card h2 {
            font-size: 18px;
            margin-bottom: 15px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }

        .search-box {
            margin-bottom: 20px;
        }

        .search-box input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        .search-box input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .table-wrapper {
            overflow-x: auto;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table thead {
            background: #f9f9f9;
            border-bottom: 2px solid #667eea;
        }

        .table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            font-size: 13px;
            text-transform: uppercase;
        }

        .table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }

        .table tbody tr:hover {
            background: #f9f9f9;
        }

        .stock-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .stock-high {
            background: #d4edda;
            color: #155724;
        }

        .stock-medium {
            background: #fff3cd;
            color: #856404;
        }

        .stock-low {
            background: #f8d7da;
            color: #721c24;
        }

        .price {
            color: #2ecc71;
            font-weight: 600;
        }

        .expiry-warning {
            color: #f39c12;
            font-weight: 600;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .stat-card h3 {
            font-size: 28px;
            margin-bottom: 5px;
        }

        .stat-card p {
            font-size: 12px;
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📦 Inventory</h1>
            <a href="<?php echo isAdmin() ? '../admin/dashboard.php' : (isManager() ? '../dashboard.php' : 'index.php'); ?>" class="back-link">← Back to Dashboard</a>
        </div>

        <!-- Statistics -->
        <div class="stats">
            <?php
            // Total items
            $total_items = mysqli_num_rows(mysqli_query($conn, "SELECT DISTINCT product_id FROM branch_inventory"));
            
            // Total stock
            $total_stock = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(quantity) as total FROM branch_inventory"))['total'] ?? 0;
            
            // Low stock items (less than 10 units)
            $low_stock = mysqli_num_rows(mysqli_query($conn, "SELECT product_id FROM branch_inventory GROUP BY product_id HAVING SUM(quantity) < 10"));
            ?>
            <div class="stat-card">
                <h3><?php echo $total_items; ?></h3>
                <p>Total Products</p>
            </div>
            <div class="stat-card">
                <h3><?php echo number_format($total_stock); ?></h3>
                <p>Total Units</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $low_stock; ?></h3>
                <p>Low Stock Items</p>
            </div>
        </div>

        <div class="card">
            <h2>📊 Current Stock Levels</h2>
            <div class="search-box">
                <input type="text" id="searchInput" placeholder="Search by product name or code..." onkeyup="filterTable()">
            </div>

            <?php if (mysqli_num_rows($inventory_result) > 0): ?>
                <div class="table-wrapper">
                    <table class="table" id="inventoryTable">
                        <thead>
                            <tr>
                                <th>Product Code</th>
                                <th>Product Name</th>
                                <th>Stock</th>
                                <th>Unit Price</th>
                                <th>Expiry Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($item = mysqli_fetch_assoc($inventory_result)): 
                                $stock_class = $item['total_stock'] > 50 ? 'stock-high' : ($item['total_stock'] > 10 ? 'stock-medium' : 'stock-low');
                            ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($item['product_code']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td>
                                        <span class="stock-badge <?php echo $stock_class; ?>">
                                            <?php echo $item['total_stock']; ?> units
                                        </span>
                                    </td>
                                    <td class="price">₱<?php echo number_format($item['selling_price'], 2); ?></td>
                                    <td>
                                        <?php if ($item['expiry_date']): 
                                            $days_left = round((strtotime($item['expiry_date']) - time()) / (60 * 60 * 24));
                                            if ($days_left < 0):
                                        ?>
                                            <span class="expiry-warning">⚠️ Expired</span>
                                        <?php elseif ($days_left < 30): ?>
                                            <span class="expiry-warning">⚠️ <?php echo $days_left; ?> days</span>
                                        <?php else: ?>
                                            <?php echo date('M d, Y', strtotime($item['expiry_date'])); ?>
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <span style="color: #999;">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>No inventory items found</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function filterTable() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            const table = document.getElementById('inventoryTable');
            const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');

            for (let row of rows) {
                const code = row.cells[0].textContent.toLowerCase();
                const name = row.cells[1].textContent.toLowerCase();
                
                if (code.includes(searchTerm) || name.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        }
    </script>
</body>
</html>
