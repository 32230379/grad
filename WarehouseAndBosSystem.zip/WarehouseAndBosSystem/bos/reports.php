<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashierOrManager();

$user = getUserInfo();

// Get date range from request
$start_date = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
$end_date = $_GET['end_date'] ?? date('Y-m-d');

// Get sales summary (show all sales for the date range)
$summary_query = "SELECT 
                    COUNT(*) as total_transactions,
                    SUM(total_amount) as total_sales,
                    SUM(tax) as total_tax,
                    AVG(total_amount) as avg_transaction,
                    COUNT(DISTINCT DATE(sale_date)) as days_with_sales
                  FROM sales_transactions
                  WHERE sale_date BETWEEN ? AND ?";

$stmt = mysqli_prepare($conn, $summary_query);
mysqli_stmt_bind_param($stmt, "ss", $start_date, $end_date);
mysqli_stmt_execute($stmt);
$summary_result = mysqli_stmt_get_result($stmt);
$summary = mysqli_fetch_assoc($summary_result);
mysqli_stmt_close($stmt);

// Get sales by payment method
$payment_query = "SELECT payment_method, COUNT(*) as count, SUM(total_amount) as total
                 FROM sales_transactions
                 WHERE sale_date BETWEEN ? AND ?
                 GROUP BY payment_method";

$stmt = mysqli_prepare($conn, $payment_query);
mysqli_stmt_bind_param($stmt, "ss", $start_date, $end_date);
mysqli_stmt_execute($stmt);
$payment_result = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

// Get top selling products
$top_products_query = "SELECT p.product_name, p.product_code, SUM(si.quantity) as total_qty, SUM(si.subtotal) as total_revenue
                      FROM sales_items si
                      JOIN products p ON si.product_id = p.product_id
                      JOIN sales_transactions st ON si.transaction_id = st.transaction_id
                      WHERE st.sale_date BETWEEN ? AND ?
                      GROUP BY p.product_id, p.product_name, p.product_code
                      ORDER BY total_qty DESC
                      LIMIT 10";

$stmt = mysqli_prepare($conn, $top_products_query);
mysqli_stmt_bind_param($stmt, "ss", $start_date, $end_date);
mysqli_stmt_execute($stmt);
$top_products_result = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

// Get daily sales
$daily_query = "SELECT sale_date, COUNT(*) as transactions, SUM(total_amount) as daily_total
               FROM sales_transactions
               WHERE sale_date BETWEEN ? AND ?
               GROUP BY sale_date
               ORDER BY sale_date DESC";

$stmt = mysqli_prepare($conn, $daily_query);
mysqli_stmt_bind_param($stmt, "ss", $start_date, $end_date);
mysqli_stmt_execute($stmt);
$daily_result = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Reports - BOS</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            font-size: 24px;
        }
        
        .back-link {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 600;
        }
        
        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
        }
        
        .filter-section {
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .filter-section input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .filter-section button {
            padding: 8px 16px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .filter-section button:hover {
            background: #5568d3;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card h3 {
            font-size: 28px;
            color: #667eea;
            margin-bottom: 5px;
        }
        
        .stat-card p {
            font-size: 12px;
            color: #999;
        }
        
        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .card h2 {
            font-size: 18px;
            margin-bottom: 15px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }
        
        .table-wrapper {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        table thead {
            background: #f9f9f9;
            border-bottom: 2px solid #667eea;
        }
        
        table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            font-size: 13px;
        }
        
        table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }
        
        table tbody tr:hover {
            background: #f9f9f9;
        }
        
        .print-button {
            display: inline-block;
            padding: 10px 20px;
            background: #2ecc71;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 15px;
        }
        
        .print-button:hover {
            background: #27ae60;
        }
        
        @media print {
            .filter-section, .print-button, .back-link {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Sales Reports</h1>
            <a href="<?php echo isAdmin() ? '../admin/dashboard.php' : (isManager() ? '../dashboard.php' : 'index.php'); ?>" class="back-link">← Back to Dashboard</a>
        </div>
        
        <div class="filter-section">
            <form method="GET" style="display: flex; gap: 15px; align-items: center;">
                <label>From: <input type="date" name="start_date" value="<?php echo $start_date; ?>"></label>
                <label>To: <input type="date" name="end_date" value="<?php echo $end_date; ?>"></label>
                <button type="submit">Filter</button>
            </form>
            <button class="print-button" onclick="window.print()">🖨️ Print Report</button>
        </div>
        
        <!-- Summary Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3><?php echo $summary['total_transactions'] ?? 0; ?></h3>
                <p>Total Transactions</p>
            </div>
            <div class="stat-card">
                <h3>₱<?php echo number_format($summary['total_sales'] ?? 0, 2); ?></h3>
                <p>Total Sales</p>
            </div>
            <div class="stat-card">
                <h3>₱<?php echo number_format($summary['avg_transaction'] ?? 0, 2); ?></h3>
                <p>Average Transaction</p>
            </div>
            <div class="stat-card">
                <h3>₱<?php echo number_format($summary['total_tax'] ?? 0, 2); ?></h3>
                <p>Total Tax Collected</p>
            </div>
        </div>
        
        <!-- Payment Methods -->
        <div class="card">
            <h2>💳 Sales by Payment Method</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Payment Method</th>
                            <th>Transactions</th>
                            <th>Total Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($payment_result)): ?>
                            <tr>
                                <td><strong><?php echo strtoupper($row['payment_method']); ?></strong></td>
                                <td><?php echo $row['count']; ?></td>
                                <td>₱<?php echo number_format($row['total'], 2); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Top Products -->
        <div class="card">
            <h2>🏆 Top Selling Products</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Product Code</th>
                            <th>Product Name</th>
                            <th>Quantity Sold</th>
                            <th>Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($top_products_result)): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($row['product_code']); ?></strong></td>
                                <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                                <td><?php echo $row['total_qty']; ?> units</td>
                                <td>₱<?php echo number_format($row['total_revenue'], 2); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Daily Sales -->
        <div class="card">
            <h2>📅 Daily Sales Summary</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Transactions</th>
                            <th>Daily Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($daily_result)): ?>
                            <tr>
                                <td><strong><?php echo date('M d, Y', strtotime($row['sale_date'])); ?></strong></td>
                                <td><?php echo $row['transactions']; ?></td>
                                <td>₱<?php echo number_format($row['daily_total'], 2); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
