<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashier();

$user = getUserInfo();

// Get sales history for this cashier
$history_query = "SELECT st.*, COUNT(si.item_id) as item_count 
                  FROM sales_transactions st 
                  LEFT JOIN sales_items si ON st.transaction_id = si.transaction_id 
                  WHERE st.cashier_id = {$_SESSION['user_id']} 
                  GROUP BY st.transaction_id 
                  ORDER BY st.created_at DESC 
                  LIMIT 100";
$history_result = mysqli_query($conn, $history_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales History - BOS</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 24px; }
        .back-link { background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border-radius: 5px; text-decoration: none; font-weight: 600; }
        .back-link:hover { background: rgba(255,255,255,0.3); }
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 20px; }
        .table { width: 100%; border-collapse: collapse; }
        .table thead { background: #f9f9f9; border-bottom: 2px solid #667eea; }
        .table th { padding: 12px; text-align: left; font-weight: 600; }
        .table td { padding: 12px; border-bottom: 1px solid #eee; }
        .table tbody tr:hover { background: #f9f9f9; }
        .amount { color: #2ecc71; font-weight: 600; }
        .status-badge { display: inline-block; padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .status-paid { background: #d4edda; color: #155724; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📈 Sales History</h1>
            <a href="index.php" class="back-link">← Back</a>
        </div>
        <div class="card">
            <table class="table">
                <thead>
                    <tr>
                        <th>Transaction #</th>
                        <th>Date</th>
                        <th>Items</th>
                        <th>Amount</th>
                        <th>Payment</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($trans = mysqli_fetch_assoc($history_result)): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($trans['transaction_number']); ?></strong></td>
                            <td><?php echo date('M d, Y H:i', strtotime($trans['created_at'])); ?></td>
                            <td><?php echo $trans['item_count']; ?></td>
                            <td class="amount">₱<?php echo number_format($trans['total_amount'], 2); ?></td>
                            <td><?php echo ucfirst($trans['payment_method']); ?></td>
                            <td><span class="status-badge status-<?php echo $trans['payment_status']; ?>"><?php echo ucfirst($trans['payment_status']); ?></span></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
