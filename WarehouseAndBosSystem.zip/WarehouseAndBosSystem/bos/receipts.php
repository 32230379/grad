<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashierOrManager();

$user = getUserInfo();

// Get search/filter parameters
$search = $_GET['search'] ?? '';
$date_filter = $_GET['date'] ?? '';

// Build query
$query = "SELECT st.*, COUNT(si.item_id) as item_count
          FROM sales_transactions st
          LEFT JOIN sales_items si ON st.transaction_id = si.transaction_id
          WHERE st.cashier_id = ?";

$params = [$user['user_id']];
$types = "i";

if ($date_filter) {
    $query .= " AND DATE(st.sale_date) = ?";
    $params[] = $date_filter;
    $types .= "s";
}

if ($search) {
    $query .= " AND st.transaction_number LIKE ?";
    $params[] = "%$search%";
    $types .= "s";
}

$query .= " GROUP BY st.transaction_id ORDER BY st.created_at DESC LIMIT 100";

$stmt = mysqli_prepare($conn, $query);
if (!$stmt) {
    die('Prepare failed: ' . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipts - BOS</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            font-size: 24px;
        }
        
        .back-link {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 600;
        }
        
        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
        }
        
        .filter-section {
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .filter-section input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .filter-section button {
            padding: 8px 16px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .filter-section button:hover {
            background: #5568d3;
        }
        
        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        
        .table-wrapper {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        table thead {
            background: #f9f9f9;
            border-bottom: 2px solid #667eea;
        }
        
        table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            font-size: 13px;
        }
        
        table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }
        
        table tbody tr:hover {
            background: #f9f9f9;
        }
        
        .action-btn {
            display: inline-block;
            padding: 6px 12px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 12px;
            margin-right: 5px;
        }
        
        .action-btn:hover {
            background: #5568d3;
        }
        
        .action-btn.print {
            background: #2ecc71;
        }
        
        .action-btn.print:hover {
            background: #27ae60;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }
        
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .status-paid {
            background: #d4edda;
            color: #155724;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧾 Receipts</h1>
            <a href="index.php" class="back-link">← Back to Dashboard</a>
        </div>
        
        <div class="filter-section">
            <form method="GET" style="display: flex; gap: 10px; align-items: center; flex: 1;">
                <input type="text" name="search" placeholder="Search by transaction number..." value="<?php echo htmlspecialchars($search); ?>">
                <input type="date" name="date" value="<?php echo htmlspecialchars($date_filter); ?>">
                <button type="submit">Search</button>
                <a href="receipts.php" style="padding: 8px 16px; background: #ddd; color: #333; text-decoration: none; border-radius: 4px;">Clear</a>
            </form>
        </div>
        
        <div class="card">
            <div class="table-wrapper">
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Transaction #</th>
                                <th>Date & Time</th>
                                <th>Items</th>
                                <th>Total Amount</th>
                                <th>Payment Method</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($row['transaction_number']); ?></strong></td>
                                    <td><?php echo date('M d, Y H:i', strtotime($row['sale_date'] . ' ' . $row['sale_time'])); ?></td>
                                    <td><?php echo $row['item_count']; ?> items</td>
                                    <td><strong>₱<?php echo number_format($row['total_amount'], 2); ?></strong></td>
                                    <td><?php echo strtoupper($row['payment_method']); ?></td>
                                    <td><span class="status-badge status-paid"><?php echo strtoupper($row['payment_status']); ?></span></td>
                                    <td>
                                        <a href="receipt.php?id=<?php echo $row['transaction_id']; ?>" class="action-btn">View</a>
                                        <a href="receipt.php?id=<?php echo $row['transaction_id']; ?>" class="action-btn print" onclick="window.open('receipt.php?id=<?php echo $row['transaction_id']; ?>', '_blank'); return false;">Print</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <p>📭 No receipts found</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
