<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashierOrManager();

$user = getUserInfo();
$message = '';
$error = '';

// Get products for this branch with inventory and shelf stock
$products_query = "SELECT 
                    p.product_id, 
                    p.product_name, 
                    p.product_code, 
                    bi.selling_price, 
                    bi.quantity as inventory_stock,
                    COALESCE(bi.on_shelf_quantity, 0) as shelf_stock,
                    (bi.quantity + COALESCE(bi.on_shelf_quantity, 0)) as total_stock
                   FROM products p
                   JOIN branch_inventory bi ON p.product_id = bi.product_id
                   WHERE bi.branch_id = ?
                   ORDER BY p.product_name";

$stmt = mysqli_prepare($conn, $products_query);
mysqli_stmt_bind_param($stmt, "i", $user['branch_id']);
mysqli_stmt_execute($stmt);
$products_result = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Point of Sale - BOS</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            font-size: 24px;
        }

        .back-link {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 600;
            transition: background 0.3s;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .main-grid {
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 20px;
            margin-bottom: 20px;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .card h2 {
            font-size: 18px;
            margin-bottom: 15px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }

        .search-box {
            margin-bottom: 20px;
        }

        .search-box input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        .search-box input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 10px;
            max-height: 600px;
            overflow-y: auto;
        }

        .product-item {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            background: white;
        }

        .product-item:hover {
            border-color: #667eea;
            background: #f9f9f9;
            transform: translateY(-2px);
        }
        
        .product-item.out-of-stock {
            opacity: 0.5;
            cursor: not-allowed;
            background: #f5f5f5;
        }
        
        .product-item.out-of-stock:hover {
            border-color: #ddd;
            background: #f5f5f5;
            transform: none;
        }

        .product-name {
            font-weight: 600;
            font-size: 13px;
            margin-bottom: 5px;
            color: #333;
        }

        .product-code {
            font-size: 11px;
            color: #999;
            margin-bottom: 5px;
        }

        .product-price {
            color: #2ecc71;
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .product-stock {
            font-size: 11px;
            color: #666;
        }

        .cart-section {
            position: sticky;
            top: 20px;
        }

        .cart-items {
            max-height: 400px;
            overflow-y: auto;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .cart-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
        }

        .cart-item:last-child {
            border-bottom: none;
        }

        .cart-item-name {
            flex: 1;
            font-weight: 600;
        }

        .cart-item-qty {
            width: 40px;
            text-align: center;
            margin: 0 5px;
        }

        .cart-item-total {
            color: #2ecc71;
            font-weight: 600;
            min-width: 60px;
            text-align: right;
        }

        .remove-btn {
            background: #e74c3c;
            color: white;
            border: none;
            padding: 4px 8px;
            border-radius: 3px;
            cursor: pointer;
            font-size: 11px;
            margin-left: 5px;
        }

        .remove-btn:hover {
            background: #c0392b;
        }

        .cart-summary {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .summary-row.total {
            border-top: 2px solid #ddd;
            padding-top: 8px;
            font-weight: 600;
            font-size: 16px;
            color: #2ecc71;
        }

        .btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn-primary {
            background: #2ecc71;
            color: white;
            margin-bottom: 10px;
        }

        .btn-primary:hover {
            background: #27ae60;
        }

        .btn-secondary {
            background: #ddd;
            color: #333;
        }

        .btn-secondary:hover {
            background: #ccc;
        }

        .empty-cart {
            text-align: center;
            padding: 30px 10px;
            color: #999;
        }

        .empty-cart-icon {
            font-size: 36px;
            margin-bottom: 10px;
        }

        .alert {
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        .qty-input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 13px;
            margin-top: 5px;
        }

        .qty-input:focus {
            outline: none;
            border-color: #667eea;
        }

        .payment-section {
            display: none;
        }

        .payment-section.active {
            display: block;
        }

        .payment-methods {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 15px;
        }

        .payment-method {
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }

        .payment-method:hover {
            border-color: #667eea;
        }

        .payment-method.selected {
            border-color: #667eea;
            background: #f0f4ff;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>💳 Point of Sale</h1>
            <a href="index.php" class="back-link">← Back to Dashboard</a>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-info">✓ <?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error">✗ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="main-grid">
            <!-- Products Section -->
            <div class="card">
                <h2>🛍️ Available Products</h2>
                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="Search products..." onkeyup="filterProducts()">
                </div>
                <div class="products-grid" id="productsGrid">
                    <?php while ($product = mysqli_fetch_assoc($products_result)): ?>
                        <div class="product-item <?php echo $product['shelf_stock'] <= 0 ? 'out-of-stock' : ''; ?>" 
                             onclick="<?php echo $product['shelf_stock'] > 0 ? "addToCart({$product['product_id']}, '" . addslashes(htmlspecialchars($product['product_name'])) . "', {$product['selling_price']}, {$product['shelf_stock']})" : "alert('Out of stock on shelf. Available in inventory: {$product['inventory_stock']}')" ?>">
                            <div class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></div>
                            <div class="product-code"><?php echo htmlspecialchars($product['product_code']); ?></div>
                            <div class="product-price">₱<?php echo number_format($product['selling_price'], 2); ?></div>
                            <div class="product-stock">
                                <?php if ($product['shelf_stock'] > 0): ?>
                                    <div style="font-size: 11px; margin-bottom: 3px;">
                                        <span style="color: #2ecc71; font-weight: bold;">Shelf: <?php echo $product['shelf_stock']; ?></span>
                                    </div>
                                    <div style="font-size: 10px; color: #999;">
                                        Inv: <?php echo $product['inventory_stock']; ?>
                                    </div>
                                <?php else: ?>
                                    <div style="color: #e74c3c; font-weight: bold; font-size: 11px;">Out of Shelf</div>
                                    <div style="font-size: 10px; color: #999;">
                                        Inv: <?php echo $product['inventory_stock']; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>

            <!-- Cart Section -->
            <div class="card cart-section">
                <h2>🛒 Shopping Cart</h2>
                
                <div class="cart-items" id="cartItems">
                    <div class="empty-cart">
                        <div class="empty-cart-icon">📭</div>
                        <p>Cart is empty</p>
                    </div>
                </div>

                <div class="cart-summary" id="cartSummary" style="display: none;">
                    <div class="summary-row">
                        <span>Subtotal:</span>
                        <span id="subtotal">₱0.00</span>
                    </div>
                    <div class="summary-row">
                        <span>Discount:</span>
                        <span id="discount">₱0.00</span>
                    </div>
                    <div class="summary-row">
                        <span>Tax (12%):</span>
                        <span id="tax">₱0.00</span>
                    </div>
                    <div class="summary-row total">
                        <span>Total:</span>
                        <span id="total">₱0.00</span>
                    </div>
                </div>

                <div class="payment-section" id="paymentSection">
                    <h3 style="font-size: 14px; margin-bottom: 10px;">Payment Method</h3>
                    <div class="payment-methods">
                        <div class="payment-method selected" onclick="selectPayment('cash')">💵 Cash</div>
                        <div class="payment-method" onclick="selectPayment('card')">💳 Card</div>
                        <div class="payment-method" onclick="selectPayment('mobile')">📱 Mobile</div>
                        <div class="payment-method" onclick="selectPayment('credit')">📋 Credit</div>
                    </div>
                </div>

                <button class="btn btn-primary" id="checkoutBtn" onclick="checkout()" style="display: none;">
                    Complete Sale
                </button>
                <button class="btn btn-secondary" onclick="clearCart()">Clear Cart</button>
            </div>
        </div>
    </div>

    <script>
        let cart = [];
        let selectedPayment = 'cash';

        function addToCart(productId, productName, price, stock) {
            const existingItem = cart.find(item => item.id === productId);
            
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push({
                    id: productId,
                    name: productName,
                    price: price,
                    quantity: 1,
                    stock: stock
                });
            }
            
            updateCart();
        }

        function removeFromCart(productId) {
            cart = cart.filter(item => item.id !== productId);
            updateCart();
        }

        function updateQuantity(productId, newQty) {
            const item = cart.find(item => item.id === productId);
            if (item) {
                const qty = parseInt(newQty);
                if (qty > 0 && qty <= item.stock) {
                    item.quantity = qty;
                    updateCart();
                } else {
                    alert('Invalid quantity');
                }
            }
        }

        function updateCart() {
            const cartItemsDiv = document.getElementById('cartItems');
            const cartSummary = document.getElementById('cartSummary');
            const checkoutBtn = document.getElementById('checkoutBtn');
            const paymentSection = document.getElementById('paymentSection');

            if (cart.length === 0) {
                cartItemsDiv.innerHTML = '<div class="empty-cart"><div class="empty-cart-icon">📭</div><p>Cart is empty</p></div>';
                cartSummary.style.display = 'none';
                checkoutBtn.style.display = 'none';
                paymentSection.style.display = 'none';
                return;
            }

            let html = '';
            let subtotal = 0;

            cart.forEach(item => {
                const itemTotal = item.price * item.quantity;
                subtotal += itemTotal;
                html += `
                    <div class="cart-item">
                        <div class="cart-item-name">${item.name}</div>
                        <input type="number" class="cart-item-qty" value="${item.quantity}" min="1" max="${item.stock}" onchange="updateQuantity(${item.id}, this.value)">
                        <div class="cart-item-total">₱${itemTotal.toFixed(2)}</div>
                        <button class="remove-btn" onclick="removeFromCart(${item.id})">Remove</button>
                    </div>
                `;
            });

            cartItemsDiv.innerHTML = html;

            const tax = subtotal * 0.12;
            const total = subtotal + tax;

            document.getElementById('subtotal').textContent = '₱' + subtotal.toFixed(2);
            document.getElementById('discount').textContent = '₱0.00';
            document.getElementById('tax').textContent = '₱' + tax.toFixed(2);
            document.getElementById('total').textContent = '₱' + total.toFixed(2);

            cartSummary.style.display = 'block';
            checkoutBtn.style.display = 'block';
            paymentSection.style.display = 'block';
        }

        function selectPayment(method) {
            selectedPayment = method;
            document.querySelectorAll('.payment-method').forEach(el => el.classList.remove('selected'));
            event.target.classList.add('selected');
        }

        function checkout() {
            if (cart.length === 0) {
                alert('Cart is empty');
                return;
            }
            
            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            const tax = subtotal * 0.12;
            const total = subtotal + tax;
            
            const checkoutData = {
                items: cart,
                payment_method: selectedPayment,
                subtotal: subtotal,
                tax: tax,
                total: total
            };
            
            fetch('api_checkout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(checkoutData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Sale completed successfully!\nTransaction ID: ' + data.transaction_number + '\nTotal: ₱' + data.total.toFixed(2));
                    clearCart();
                    // Redirect to receipt page
                    window.location.href = 'receipt.php?id=' + data.transaction_id;
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                alert('Error processing sale: ' + error);
            });
        }

        function clearCart() {
            cart = [];
            updateCart();
        }

        function filterProducts() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            const products = document.querySelectorAll('.product-item');
            
            products.forEach(product => {
                const name = product.querySelector('.product-name').textContent.toLowerCase();
                const code = product.querySelector('.product-code').textContent.toLowerCase();
                
                if (name.includes(searchTerm) || code.includes(searchTerm)) {
                    product.style.display = '';
                } else {
                    product.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>
