<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashier();

$user = getUserInfo();
$search_term = isset($_GET['q']) ? sanitizeInput($_GET['q']) : '';
$results = [];

if (!empty($search_term)) {
    // Search inventory - simple query without category join
    $inventory_query = "SELECT p.product_id, p.product_code, p.product_name,
                               SUM(bi.quantity) as total_stock, bi.selling_price, bi.expiry_date
                        FROM branch_inventory bi
                        JOIN products p ON bi.product_id = p.product_id
                        WHERE (p.product_code LIKE '%$search_term%' OR p.product_name LIKE '%$search_term%')
                        GROUP BY p.product_id
                        ORDER BY p.product_name";
    $results = mysqli_query($conn, $inventory_query);
    
    if (!$results) {
        // If query fails, show error message
        die('Database Error: ' . mysqli_error($conn));
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Inventory - BOS</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; }
        .header h1 { font-size: 24px; }
        .back-link { background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border-radius: 5px; text-decoration: none; font-weight: 600; }
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 20px; margin-bottom: 20px; }
        .search-box { display: flex; gap: 10px; margin-bottom: 20px; }
        .search-box input { flex: 1; padding: 12px; border: 1px solid #ddd; border-radius: 5px; font-size: 14px; }
        .search-box input:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102,126,234,0.1); }
        .search-box button { background: #667eea; color: white; padding: 12px 30px; border: none; border-radius: 5px; cursor: pointer; font-weight: 600; }
        .search-box button:hover { background: #5568d3; }
        .results-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px; }
        .product-card { background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px; transition: all 0.3s; }
        .product-card:hover { border-color: #667eea; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .product-name { font-weight: 600; color: #333; margin-bottom: 8px; }
        .product-code { color: #999; font-size: 12px; margin-bottom: 8px; }
        .product-category { color: #667eea; font-size: 12px; margin-bottom: 10px; }
        .product-price { color: #2ecc71; font-weight: 600; font-size: 16px; margin-bottom: 8px; }
        .product-stock { color: #666; font-size: 13px; margin-bottom: 8px; }
        .stock-badge { display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
        .stock-high { background: #d4edda; color: #155724; }
        .stock-medium { background: #fff3cd; color: #856404; }
        .stock-low { background: #f8d7da; color: #721c24; }
        .no-results { text-align: center; padding: 40px; color: #999; }
        .no-results-icon { font-size: 48px; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 Search Inventory</h1>
            <a href="index.php" class="back-link">← Back</a>
        </div>

        <div class="card">
            <form method="GET" action="" class="search-box">
                <input type="text" name="q" placeholder="Search by product name or code..." value="<?php echo htmlspecialchars($search_term); ?>" autofocus>
                <button type="submit">Search</button>
            </form>

            <?php if (!empty($search_term)): ?>
                <?php if (mysqli_num_rows($results) > 0): ?>
                    <div class="results-grid">
                        <?php while ($product = mysqli_fetch_assoc($results)): 
                            $stock_class = $product['total_stock'] > 50 ? 'stock-high' : ($product['total_stock'] > 10 ? 'stock-medium' : 'stock-low');
                        ?>
                            <div class="product-card">
                                <div class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></div>
                                <div class="product-code">Code: <?php echo htmlspecialchars($product['product_code']); ?></div>
                                <div class="product-price">₱<?php echo number_format($product['selling_price'], 2); ?></div>
                                <div class="product-stock">
                                    <span class="stock-badge <?php echo $stock_class; ?>">
                                        <?php echo $product['total_stock']; ?> units
                                    </span>
                                </div>
                                <?php if ($product['expiry_date']): 
                                    $days_left = round((strtotime($product['expiry_date']) - time()) / (60 * 60 * 24));
                                ?>
                                    <div style="font-size: 12px; color: <?php echo $days_left < 30 ? '#f39c12' : '#666'; ?>; margin-top: 8px;">
                                        Expires: <?php echo date('M d, Y', strtotime($product['expiry_date'])); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="no-results">
                        <div class="no-results-icon">🔍</div>
                        <p>No products found matching "<?php echo htmlspecialchars($search_term); ?>"</p>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="no-results">
                    <div class="no-results-icon">🔎</div>
                    <p>Enter a product name or code to search</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
