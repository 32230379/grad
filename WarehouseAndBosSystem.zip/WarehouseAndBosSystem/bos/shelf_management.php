<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireManager();

$user = getUserInfo();
$branch_id = $user['branch_id'];

// Get shelf stock status
$query = "SELECT 
            bi.inventory_id,
            bi.product_id,
            p.product_name,
            p.product_code,
            bi.quantity as inventory_qty,
            bi.on_shelf_quantity as shelf_qty,
            (bi.quantity + bi.on_shelf_quantity) as total_qty,
            bi.shelf_min_level,
            bi.shelf_reorder_level,
            p.reorder_level as inventory_reorder_level,
            p.min_stock_level as inventory_min_level,
            CASE 
                WHEN bi.on_shelf_quantity <= bi.shelf_min_level THEN 'CRITICAL'
                WHEN bi.on_shelf_quantity <= bi.shelf_reorder_level THEN 'LOW'
                ELSE 'OK'
            END as shelf_status,
            CASE 
                WHEN bi.quantity <= p.min_stock_level THEN 'CRITICAL'
                WHEN bi.quantity <= p.reorder_level THEN 'LOW'
                ELSE 'OK'
            END as inventory_status
          FROM branch_inventory bi
          JOIN products p ON bi.product_id = p.product_id
          WHERE bi.branch_id = ?
          ORDER BY bi.on_shelf_quantity ASC";

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $branch_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$items = [];
while ($row = mysqli_fetch_assoc($result)) {
    $items[] = $row;
}

mysqli_stmt_close($stmt);

// Get recent transfers
$transfer_query = "SELECT 
                    st.transfer_id,
                    st.product_id,
                    p.product_name,
                    st.quantity_transferred,
                    st.from_location,
                    st.to_location,
                    u.full_name as transferred_by,
                    st.transfer_date,
                    st.notes
                  FROM shelf_transfers st
                  JOIN products p ON st.product_id = p.product_id
                  JOIN users u ON st.transferred_by = u.user_id
                  WHERE st.branch_id = ?
                  ORDER BY st.transfer_date DESC
                  LIMIT 10";

$transfer_stmt = mysqli_prepare($conn, $transfer_query);
mysqli_stmt_bind_param($transfer_stmt, "i", $branch_id);
mysqli_stmt_execute($transfer_stmt);
$transfer_result = mysqli_stmt_get_result($transfer_stmt);

$transfers = [];
while ($row = mysqli_fetch_assoc($transfer_result)) {
    $transfers[] = $row;
}

mysqli_stmt_close($transfer_stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shelf Management - Branch System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .shelf-container {
            padding: 20px;
            max-width: 1400px;
            margin: 0 auto;
        }

        .shelf-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #007bff;
            padding-bottom: 15px;
        }

        .shelf-header h1 {
            margin: 0;
            color: #333;
        }

        .alert-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }

        .alert-card {
            padding: 15px;
            border-radius: 8px;
            color: white;
            text-align: center;
        }

        .alert-card.critical {
            background-color: #dc3545;
        }

        .alert-card.high {
            background-color: #fd7e14;
        }

        .alert-card.medium {
            background-color: #ffc107;
            color: #333;
        }

        .alert-card h3 {
            margin: 0 0 5px 0;
            font-size: 14px;
            font-weight: normal;
        }

        .alert-card .count {
            font-size: 28px;
            font-weight: bold;
        }

        .shelf-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .shelf-table thead {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
        }

        .shelf-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
        }

        .shelf-table td {
            padding: 12px;
            border-bottom: 1px solid #dee2e6;
        }

        .shelf-table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            text-align: center;
            min-width: 70px;
        }

        .status-badge.ok {
            background-color: #d4edda;
            color: #155724;
        }

        .status-badge.low {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-badge.critical {
            background-color: #f8d7da;
            color: #721c24;
        }

        .transfer-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: background-color 0.3s;
        }

        .transfer-btn:hover {
            background-color: #0056b3;
        }

        .transfer-btn:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }

        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 1px solid #dee2e6;
            padding-bottom: 10px;
        }

        .modal-header h2 {
            margin: 0;
            color: #333;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }

        .close-btn:hover {
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .btn-primary {
            background-color: #007bff;
            color: white;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #545b62;
        }

        .transfers-section {
            margin-top: 40px;
        }

        .transfers-section h2 {
            color: #333;
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
        }

        .transfers-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .transfers-table thead {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
        }

        .transfers-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
        }

        .transfers-table td {
            padding: 12px;
            border-bottom: 1px solid #dee2e6;
        }

        .transfers-table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .timestamp {
            font-size: 12px;
            color: #666;
        }

        .no-data {
            text-align: center;
            padding: 40px;
            color: #999;
        }

        .stock-info {
            display: flex;
            gap: 20px;
            font-size: 13px;
        }

        .stock-info div {
            display: flex;
            flex-direction: column;
        }

        .stock-info label {
            font-weight: 600;
            color: #666;
        }

        .stock-info value {
            color: #333;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="shelf-container">
        <div class="shelf-header">
            <h1>📦 Shelf Management</h1>
            <a href="<?php echo isAdmin() ? '../admin/dashboard.php' : '../dashboard.php'; ?>" style="color: #007bff; text-decoration: none;">← Back to Dashboard</a>
        </div>

        <div class="alert-summary">
            <div class="alert-card critical">
                <h3>Critical Shelf Stock</h3>
                <div class="count" id="critical-count">0</div>
            </div>
            <div class="alert-card high">
                <h3>Low Shelf Stock</h3>
                <div class="count" id="low-count">0</div>
            </div>
            <div class="alert-card medium">
                <h3>Total Products</h3>
                <div class="count"><?php echo count($items); ?></div>
            </div>
        </div>

        <h2 style="color: #333; margin-bottom: 15px;">Shelf Stock Status</h2>
        <table class="shelf-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Inventory</th>
                    <th>On Shelf</th>
                    <th>Total</th>
                    <th>Shelf Status</th>
                    <th>Inventory Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($items)): ?>
                    <tr>
                        <td colspan="7" class="no-data">No products found</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($item['product_name']); ?></strong>
                                <br>
                                <small style="color: #999;"><?php echo htmlspecialchars($item['product_code']); ?></small>
                            </td>
                            <td><?php echo intval($item['inventory_qty']); ?></td>
                            <td><?php echo intval($item['shelf_qty']); ?></td>
                            <td><?php echo intval($item['total_qty']); ?></td>
                            <td>
                                <span class="status-badge <?php echo strtolower($item['shelf_status']); ?>">
                                    <?php echo $item['shelf_status']; ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge <?php echo strtolower($item['inventory_status']); ?>">
                                    <?php echo $item['inventory_status']; ?>
                                </span>
                            </td>
                            <td>
                                <button class="transfer-btn" onclick="openTransferModal(<?php echo $item['product_id']; ?>, '<?php echo addslashes(htmlspecialchars($item['product_name'])); ?>', <?php echo intval($item['inventory_qty']); ?>)" <?php echo intval($item['inventory_qty']) <= 0 ? 'disabled' : ''; ?>>
                                    Transfer
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="transfers-section">
            <h2>Recent Transfers</h2>
            <table class="transfers-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Transferred By</th>
                        <th>Date & Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($transfers)): ?>
                        <tr>
                            <td colspan="6" class="no-data">No transfers yet</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($transfers as $transfer): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($transfer['product_name']); ?></td>
                                <td><?php echo intval($transfer['quantity_transferred']); ?></td>
                                <td><?php echo htmlspecialchars($transfer['from_location']); ?></td>
                                <td><?php echo htmlspecialchars($transfer['to_location']); ?></td>
                                <td><?php echo htmlspecialchars($transfer['transferred_by']); ?></td>
                                <td class="timestamp"><?php echo date('M d, Y H:i', strtotime($transfer['transfer_date'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Transfer Modal -->
    <div id="transferModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Transfer to Shelf</h2>
                <button class="close-btn" onclick="closeTransferModal()">×</button>
            </div>
            <form id="transferForm">
                <div class="form-group">
                    <label>Product</label>
                    <input type="text" id="productName" readonly style="background-color: #f5f5f5;">
                </div>
                <div class="form-group">
                    <label>Available Inventory</label>
                    <input type="text" id="availableInventory" readonly style="background-color: #f5f5f5;">
                </div>
                <div class="form-group">
                    <label for="quantity">Quantity to Transfer *</label>
                    <input type="number" id="quantity" name="quantity" min="1" required>
                </div>
                <div class="form-group">
                    <label for="notes">Notes (Optional)</label>
                    <textarea id="notes" name="notes" placeholder="Add any notes about this transfer..."></textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeTransferModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Transfer</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let currentProductId = null;

        function openTransferModal(productId, productName, availableInventory) {
            currentProductId = productId;
            document.getElementById('productName').value = productName;
            document.getElementById('availableInventory').value = availableInventory;
            document.getElementById('quantity').max = availableInventory;
            document.getElementById('quantity').value = '';
            document.getElementById('notes').value = '';
            document.getElementById('transferModal').classList.add('active');
        }

        function closeTransferModal() {
            document.getElementById('transferModal').classList.remove('active');
            currentProductId = null;
        }

        // Update alert counts
        function updateAlertCounts() {
            const items = <?php echo json_encode($items ?? []); ?>;
            let criticalCount = 0;
            let lowCount = 0;

            if (items && Array.isArray(items)) {
                items.forEach(item => {
                    if (item.shelf_status === 'CRITICAL') {
                        criticalCount++;
                    } else if (item.shelf_status === 'LOW') {
                        lowCount++;
                    }
                });
            }

            const criticalEl = document.getElementById('critical-count');
            const lowEl = document.getElementById('low-count');
            if (criticalEl) criticalEl.textContent = criticalCount;
            if (lowEl) lowEl.textContent = lowCount;
        }

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            // Attach form submit listener
            const transferForm = document.getElementById('transferForm');
            if (transferForm) {
                transferForm.addEventListener('submit', async function(e) {
                    e.preventDefault();

                    const quantity = parseInt(document.getElementById('quantity').value);
                    const notes = document.getElementById('notes').value;

                    if (quantity <= 0) {
                        alert('Please enter a valid quantity');
                        return;
                    }

                    try {
                        const response = await fetch('../api/shelf_transfer.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                product_id: currentProductId,
                                quantity: quantity,
                                notes: notes
                            })
                        });

                        const data = await response.json();

                        if (data.success) {
                            alert('Transfer completed successfully!');
                            closeTransferModal();
                            location.reload();
                        } else {
                            alert('Error: ' + data.message);
                        }
                    } catch (error) {
                        alert('Error: ' + error.message);
                    }
                });
            }

            // Attach modal click listener
            const transferModal = document.getElementById('transferModal');
            if (transferModal) {
                transferModal.addEventListener('click', function(e) {
                    if (e.target === this) {
                        closeTransferModal();
                    }
                });
            }

            // Update counts
            updateAlertCounts();
        });
    </script>
</body>
</html>
