<?php
// Prevent any output before JSON
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', '0');

// Initialize error buffer
$error_buffer = '';

// Custom error handler to catch PHP errors
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    global $error_buffer;
    $error_buffer = "Error: $errstr in $errfile on line $errline";
    return true;
});

// Shutdown handler to catch fatal errors
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Fatal error: ' . $error['message'] . ' in ' . $error['file'] . ' on line ' . $error['line']]);
        exit();
    }
});

require_once '../config.php';
require_once '../functions.php';

// Set header before any potential output
header('Content-Type: application/json; charset=utf-8');

// Clear any buffered output
ob_end_clean();
ob_start();

// Check authentication
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit();
}

if (!isCashier() && !isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Cashier access required']);
    exit();
}

$user = getUserInfo();
if (!$user) {
    echo json_encode(['success' => false, 'message' => 'User information not found']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if ($data === null) {
        echo json_encode(['success' => false, 'message' => 'Invalid JSON input: ' . json_last_error_msg()]);
        exit();
    }
    
    $items = $data['items'] ?? [];
    $payment_method = $data['payment_method'] ?? 'cash';
    $subtotal = floatval($data['subtotal'] ?? 0);
    $tax = floatval($data['tax'] ?? 0);
    $total = floatval($data['total'] ?? 0);
    
    if (empty($items) || $total <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid cart data']);
        exit();
    }
    
    // Begin transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Generate transaction number
        $transaction_number = generateNumber('TXN', 'sales_transactions', 'transaction_number');
        
        // Insert sales transaction
        $sale_date = date('Y-m-d');
        $sale_time = date('H:i:s');
        $cashier_id = $user['user_id'];
        
        $transaction_query = "INSERT INTO sales_transactions 
                              (transaction_number, sale_date, sale_time, cashier_id, subtotal, tax, total_amount, payment_method, payment_status)
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = mysqli_prepare($conn, $transaction_query);
        if (!$stmt) {
            throw new Exception('Prepare failed: ' . mysqli_error($conn));
        }
        
        $payment_status = 'paid';
        
        mysqli_stmt_bind_param($stmt, "sssidddss", 
            $transaction_number, $sale_date, $sale_time, $cashier_id, 
            $subtotal, $tax, $total, $payment_method, $payment_status);
        
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception('Failed to insert transaction: ' . mysqli_error($conn));
        }
        
        $transaction_id = mysqli_insert_id($conn);
        mysqli_stmt_close($stmt);
        
        // Insert sales items and update shelf stock
        foreach ($items as $item) {
            $product_id = intval($item['id']);
            $quantity = intval($item['quantity']);
            $unit_price = floatval($item['price']);
            $item_subtotal = $unit_price * $quantity;
            
            // Check shelf stock availability
            $check_query = "SELECT inventory_id, on_shelf_quantity, quantity as inventory_qty FROM branch_inventory 
                           WHERE product_id = ? AND branch_id = ? LIMIT 1";
            $check_stmt = mysqli_prepare($conn, $check_query);
            if (!$check_stmt) {
                throw new Exception('Prepare failed: ' . mysqli_error($conn));
            }
            
            $branch_id = $user['branch_id'];
            mysqli_stmt_bind_param($check_stmt, "ii", $product_id, $branch_id);
            
            if (!mysqli_stmt_execute($check_stmt)) {
                throw new Exception('Failed to check shelf stock: ' . mysqli_error($conn));
            }
            
            $check_result = mysqli_stmt_get_result($check_stmt);
            $stock_row = mysqli_fetch_assoc($check_result);
            mysqli_stmt_close($check_stmt);
            
            if (!$stock_row) {
                throw new Exception("Product $product_id not found in inventory");
            }
            
            // Check if enough shelf stock
            if ($stock_row['on_shelf_quantity'] < $quantity) {
                throw new Exception("Insufficient shelf stock for product $product_id. Available: {$stock_row['on_shelf_quantity']}, Requested: $quantity");
            }
            
            // Insert sales item
            $item_query = "INSERT INTO sales_items (transaction_id, product_id, quantity, unit_price, subtotal)
                          VALUES (?, ?, ?, ?, ?)";
            
            $stmt = mysqli_prepare($conn, $item_query);
            if (!$stmt) {
                throw new Exception('Prepare failed: ' . mysqli_error($conn));
            }
            
            mysqli_stmt_bind_param($stmt, "iiidd", $transaction_id, $product_id, $quantity, $unit_price, $item_subtotal);
            
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception('Failed to insert sales item: ' . mysqli_error($conn));
            }
            
            mysqli_stmt_close($stmt);
            
            // Update shelf stock - reduce on_shelf_quantity only
            $update_query = "UPDATE branch_inventory SET on_shelf_quantity = on_shelf_quantity - ? WHERE product_id = ? AND branch_id = ? LIMIT 1";
            $stmt = mysqli_prepare($conn, $update_query);
            if (!$stmt) {
                throw new Exception('Prepare failed: ' . mysqli_error($conn));
            }
            
            mysqli_stmt_bind_param($stmt, "iii", $quantity, $product_id, $branch_id);
            
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception('Failed to update shelf stock: ' . mysqli_error($conn));
            }
            
            mysqli_stmt_close($stmt);
            
            // Calculate new shelf quantity for reference
            $old_shelf_qty = $stock_row['on_shelf_quantity'];
            $new_shelf_qty = $old_shelf_qty - $quantity;
            
            // Try to record in shelf stock history if table exists
            $history_query = "INSERT INTO shelf_stock_history 
                             (branch_id, product_id, action, quantity_change, old_shelf_qty, new_shelf_qty, performed_by, reference_id, reference_type)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $action = 'sale';
            $reference_type = 'sales_transaction';
            $performed_by = $user['user_id'];
            $history_stmt = mysqli_prepare($conn, $history_query);
            if ($history_stmt) {
                mysqli_stmt_bind_param($history_stmt, "iisiiiiis", $branch_id, $product_id, $action, $quantity, $old_shelf_qty, $new_shelf_qty, $performed_by, $transaction_id, $reference_type);
                mysqli_stmt_execute($history_stmt);
                mysqli_stmt_close($history_stmt);
            }
        }
        
        // Commit transaction
        mysqli_commit($conn);
        
        // Log activity (wrapped in try-catch to prevent errors from breaking JSON response)
        try {
            logActivity($user['user_id'], 'Sale Completed', 'Sales', "Transaction $transaction_number completed for ₱" . number_format($total, 2));
        } catch (Exception $log_error) {
            // Silently fail - don't break the sale
        }
        
        echo json_encode([
            'success' => true, 
            'message' => 'Sale completed successfully',
            'transaction_id' => $transaction_id,
            'transaction_number' => $transaction_number,
            'total' => $total
        ]);
        
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $error_msg = $e->getMessage();
        if (!empty($error_buffer)) {
            $error_msg = $error_buffer . ' | ' . $error_msg;
        }
        echo json_encode(['success' => false, 'message' => $error_msg]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

// Ensure output is clean
ob_end_flush();
?>
