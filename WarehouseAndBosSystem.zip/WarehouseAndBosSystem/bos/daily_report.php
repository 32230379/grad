<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashier();

$user = getUserInfo();
$today = date('Y-m-d');

// Get today's sales summary
$summary_query = "SELECT COUNT(*) as transactions, SUM(total_amount) as total_sales, SUM(discount) as total_discount, SUM(tax) as total_tax
                  FROM sales_transactions 
                  WHERE cashier_id = {$_SESSION['user_id']} AND sale_date = '$today'";
$summary_result = mysqli_query($conn, $summary_query);
$summary = mysqli_fetch_assoc($summary_result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Report - BOS</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; }
        .header h1 { font-size: 24px; }
        .back-link { background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border-radius: 5px; text-decoration: none; font-weight: 600; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .stat-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }
        .stat-card h3 { font-size: 28px; margin-bottom: 5px; }
        .stat-card p { font-size: 12px; opacity: 0.9; }
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 20px; }
        .btn { background: #667eea; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; margin-top: 20px; }
        .btn:hover { background: #5568d3; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Daily Report - <?php echo date('M d, Y'); ?></h1>
            <a href="index.php" class="back-link">← Back</a>
        </div>
        <div class="stats">
            <div class="stat-card">
                <h3><?php echo $summary['transactions'] ?? 0; ?></h3>
                <p>Transactions</p>
            </div>
            <div class="stat-card">
                <h3>₱<?php echo number_format($summary['total_sales'] ?? 0, 2); ?></h3>
                <p>Total Sales</p>
            </div>
            <div class="stat-card">
                <h3>₱<?php echo number_format($summary['total_discount'] ?? 0, 2); ?></h3>
                <p>Discounts</p>
            </div>
            <div class="stat-card">
                <h3>₱<?php echo number_format($summary['total_tax'] ?? 0, 2); ?></h3>
                <p>Tax</p>
            </div>
        </div>
        <div class="card">
            <p style="color: #666; text-align: center;">Detailed daily report coming soon!</p>
            <a href="index.php" class="btn">Return to Dashboard</a>
        </div>
    </div>
</body>
</html>
