<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashierOrManager();

$user = getUserInfo();
$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = intval($_POST['product_id'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 0);
    $return_reason = mysqli_real_escape_string($conn, $_POST['return_reason'] ?? '');
    $notes = mysqli_real_escape_string($conn, $_POST['notes'] ?? '');
    
    if ($product_id && $quantity > 0 && !empty($return_reason)) {
        // Get product info
        $product_query = "SELECT p.product_name, p.product_code FROM products p WHERE p.product_id = $product_id";
        $product_result = mysqli_query($conn, $product_query);
        $product = mysqli_fetch_assoc($product_result);
        
        if ($product) {
            // Create alert for admin/manager
            $alert_message = "Return Request: {$product['product_name']} (Code: {$product['product_code']}) - Qty: $quantity - Reason: $return_reason - Notes: $notes - Reported by: {$user['full_name']}";
            
            $alert_query = "INSERT INTO alerts (alert_type, priority, product_id, title, message, is_read) 
                           VALUES ('system', 'high', $product_id, 'Product Return Request', '$alert_message', FALSE)";
            
            if (mysqli_query($conn, $alert_query)) {
                // Log activity
                logActivity($user['user_id'], 'Create Return Request', 'Returns', "Return request for product $product_id - Qty: $quantity - Reason: $return_reason");
                $message = "✓ Return request submitted successfully! Admin/Manager will review and add to next order.";
            } else {
                $error = "Error submitting return request: " . mysqli_error($conn);
            }
        } else {
            $error = "Product not found";
        }
    } else {
        $error = "Please fill in all required fields";
    }
}

// Get products for dropdown
$products_query = "SELECT product_id, product_name, product_code FROM products ORDER BY product_name";
$products_result = mysqli_query($conn, $products_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Returns - BOS</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; color: #333; }
        .container { max-width: 1000px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 24px; }
        .back-link { background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border-radius: 5px; text-decoration: none; font-weight: 600; transition: background 0.3s; }
        .back-link:hover { background: rgba(255,255,255,0.3); }
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 30px; margin-bottom: 20px; }
        .card h2 { margin-bottom: 20px; color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 600; color: #333; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; font-size: 14px; font-family: inherit; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .btn { background: #667eea; color: white; padding: 12px 24px; border: none; border-radius: 5px; cursor: pointer; font-weight: 600; transition: background 0.3s; }
        .btn:hover { background: #5568d3; }
        .btn-secondary { background: #95a5a6; }
        .btn-secondary:hover { background: #7f8c8d; }
        .alert { padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .return-reasons { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-top: 10px; }
        .reason-btn { padding: 10px; border: 2px solid #ddd; background: white; border-radius: 5px; cursor: pointer; transition: all 0.3s; font-weight: 600; }
        .reason-btn:hover { border-color: #667eea; background: #f0f4ff; }
        .reason-btn.active { border-color: #667eea; background: #667eea; color: white; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        @media (max-width: 768px) { .form-row { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>↩️ Product Returns</h1>
            <a href="<?php echo isAdmin() ? '../admin/dashboard.php' : (isManager() ? '../dashboard.php' : 'index.php'); ?>" class="back-link">← Back to Dashboard</a>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success">✓ <?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">✗ <?php echo $error; ?></div>
        <?php endif; ?>

        <div class="card">
            <h2>📦 Submit Return Request</h2>
            <p style="margin-bottom: 20px; color: #666;">Report damaged, expired, or defective items. Your request will be sent to Admin/Manager for review and will be included in the next warehouse order.</p>
            
            <form method="POST" action="">
                <div class="form-row">
                    <div class="form-group">
                        <label for="product_id">Product *</label>
                        <select id="product_id" name="product_id" required>
                            <option value="">-- Select Product --</option>
                            <?php while ($product = mysqli_fetch_assoc($products_result)): ?>
                                <option value="<?php echo $product['product_id']; ?>">
                                    <?php echo htmlspecialchars($product['product_name'] . ' (' . $product['product_code'] . ')'); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="quantity">Quantity *</label>
                        <input type="number" id="quantity" name="quantity" min="1" required placeholder="Enter quantity">
                    </div>
                </div>

                <div class="form-group">
                    <label>Return Reason *</label>
                    <div class="return-reasons">
                        <button type="button" class="reason-btn" onclick="selectReason(this, 'Damaged')">🔨 Damaged</button>
                        <button type="button" class="reason-btn" onclick="selectReason(this, 'Expired')">⏰ Expired</button>
                        <button type="button" class="reason-btn" onclick="selectReason(this, 'Defective')">❌ Defective</button>
                        <button type="button" class="reason-btn" onclick="selectReason(this, 'Wrong Item')">❓ Wrong Item</button>
                        <button type="button" class="reason-btn" onclick="selectReason(this, 'Recall')">🚨 Recall</button>
                        <button type="button" class="reason-btn" onclick="selectReason(this, 'Other')">📝 Other</button>
                    </div>
                    <input type="hidden" id="return_reason" name="return_reason" required>
                </div>

                <div class="form-group">
                    <label for="notes">Additional Notes</label>
                    <textarea id="notes" name="notes" placeholder="Describe the issue in detail (optional)"></textarea>
                </div>

                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn">✓ Submit Return Request</button>
                    <button type="reset" class="btn btn-secondary">↻ Clear Form</button>
                </div>
            </form>
        </div>

        <div class="card">
            <h2>ℹ️ How It Works</h2>
            <ol style="line-height: 1.8; color: #666;">
                <li><strong>Report the Issue:</strong> Select the product, quantity, and reason for return</li>
                <li><strong>Admin/Manager Review:</strong> Your request will be sent as an alert to Admin and Manager</li>
                <li><strong>Order Inclusion:</strong> The return will be added to the next warehouse order request with all details</li>
                <li><strong>Warehouse Processing:</strong> The warehouse will process the return and update inventory</li>
            </ol>
        </div>
    </div>

    <script>
        function selectReason(button, reason) {
            // Remove active class from all buttons
            document.querySelectorAll('.reason-btn').forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            button.classList.add('active');
            // Set the hidden input value
            document.getElementById('return_reason').value = reason;
        }
    </script>
</body>
</html>
