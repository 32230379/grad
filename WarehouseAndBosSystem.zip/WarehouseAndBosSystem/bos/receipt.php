<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashierOrManager();

$transaction_id = intval($_GET['id'] ?? 0);

if (!$transaction_id) {
    die('Invalid transaction ID');
}

// Get transaction details
$transaction_query = "SELECT st.*, u.full_name as cashier_name
                     FROM sales_transactions st
                     JOIN users u ON st.cashier_id = u.user_id
                     WHERE st.transaction_id = ?";

$stmt = mysqli_prepare($conn, $transaction_query);
mysqli_stmt_bind_param($stmt, "i", $transaction_id);
mysqli_stmt_execute($stmt);
$transaction_result = mysqli_stmt_get_result($stmt);
$transaction = mysqli_fetch_assoc($transaction_result);
mysqli_stmt_close($stmt);

if (!$transaction) {
    die('Transaction not found');
}

// Get transaction items
$items_query = "SELECT si.*, p.product_code, p.product_name
               FROM sales_items si
               JOIN products p ON si.product_id = p.product_id
               WHERE si.transaction_id = ?";

$stmt = mysqli_prepare($conn, $items_query);
mysqli_stmt_bind_param($stmt, "i", $transaction_id);
mysqli_stmt_execute($stmt);
$items_result = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt - <?php echo $transaction['transaction_number']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Courier New', monospace;
            background: #f5f5f5;
            padding: 20px;
        }
        
        .header-nav {
            max-width: 400px;
            margin: 0 auto 15px;
            display: flex;
            gap: 10px;
        }
        
        .back-button {
            flex: 1;
            padding: 10px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        
        .back-button:hover {
            background: #5568d3;
        }
        
        .receipt-container {
            max-width: 400px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border: 1px solid #ddd;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .receipt-header {
            text-align: center;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        
        .receipt-header h1 {
            font-size: 18px;
            margin-bottom: 5px;
        }
        
        .receipt-header p {
            font-size: 12px;
            color: #666;
        }
        
        .receipt-info {
            font-size: 12px;
            margin-bottom: 15px;
            border-bottom: 1px dashed #999;
            padding-bottom: 10px;
        }
        
        .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        
        .receipt-items {
            margin-bottom: 15px;
            border-bottom: 1px dashed #999;
            padding-bottom: 10px;
        }
        
        .item-header {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr;
            font-weight: bold;
            font-size: 11px;
            margin-bottom: 5px;
            border-bottom: 1px solid #999;
            padding-bottom: 5px;
        }
        
        .item-row {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr;
            font-size: 11px;
            margin-bottom: 3px;
        }
        
        .item-name {
            word-wrap: break-word;
        }
        
        .item-qty, .item-total {
            text-align: right;
        }
        
        .receipt-summary {
            font-size: 12px;
            margin-bottom: 15px;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        
        .summary-row.total {
            font-weight: bold;
            font-size: 14px;
            border-top: 2px solid #333;
            border-bottom: 2px solid #333;
            padding: 5px 0;
        }
        
        .receipt-footer {
            text-align: center;
            font-size: 11px;
            color: #666;
            margin-top: 15px;
        }
        
        .payment-method {
            text-align: center;
            font-size: 12px;
            margin-bottom: 10px;
            padding: 10px;
            background: #f9f9f9;
            border-radius: 4px;
        }
        
        .print-button {
            display: block;
            width: 100%;
            padding: 10px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            margin-top: 15px;
        }
        
        .print-button:hover {
            background: #5568d3;
        }
        
        @media print {
            body {
                background: white;
                padding: 0;
            }
            .receipt-container {
                box-shadow: none;
                border: none;
                max-width: 100%;
            }
            .print-button {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="header-nav">
        <a href="receipts.php" class="back-button">← Back to Receipts</a>
    </div>
    
    <div class="receipt-container">
        <div class="receipt-header">
            <h1>RECEIPT</h1>
            <p><?php echo $transaction['transaction_number']; ?></p>
        </div>
        
        <div class="receipt-info">
            <div class="info-row">
                <span>Date:</span>
                <span><?php echo date('M d, Y', strtotime($transaction['sale_date'])); ?></span>
            </div>
            <div class="info-row">
                <span>Time:</span>
                <span><?php echo date('H:i:s', strtotime($transaction['sale_time'])); ?></span>
            </div>
            <div class="info-row">
                <span>Cashier:</span>
                <span><?php echo htmlspecialchars($transaction['cashier_name']); ?></span>
            </div>
        </div>
        
        <div class="receipt-items">
            <div class="item-header">
                <div>Item</div>
                <div>Qty</div>
                <div>Total</div>
            </div>
            
            <?php while ($item = mysqli_fetch_assoc($items_result)): ?>
                <div class="item-row">
                    <div class="item-name"><?php echo htmlspecialchars($item['product_name']); ?></div>
                    <div class="item-qty"><?php echo $item['quantity']; ?></div>
                    <div class="item-total">₱<?php echo number_format($item['subtotal'], 2); ?></div>
                </div>
                <div style="font-size: 10px; color: #999; margin-bottom: 5px;">
                    @ ₱<?php echo number_format($item['unit_price'], 2); ?> each
                </div>
            <?php endwhile; ?>
        </div>
        
        <div class="receipt-summary">
            <div class="summary-row">
                <span>Subtotal:</span>
                <span>₱<?php echo number_format($transaction['subtotal'], 2); ?></span>
            </div>
            <div class="summary-row">
                <span>Tax (12%):</span>
                <span>₱<?php echo number_format($transaction['tax'], 2); ?></span>
            </div>
            <div class="summary-row total">
                <span>TOTAL:</span>
                <span>₱<?php echo number_format($transaction['total_amount'], 2); ?></span>
            </div>
        </div>
        
        <div class="payment-method">
            <strong>Payment Method:</strong> <?php echo strtoupper($transaction['payment_method']); ?>
        </div>
        
        <div class="receipt-footer">
            <p>Thank you for your purchase!</p>
            <p>Please keep this receipt for your records.</p>
            <p style="margin-top: 10px; font-size: 10px;">
                <?php echo date('M d, Y H:i:s'); ?>
            </p>
        </div>
        
        <button class="print-button" onclick="window.print()">🖨️ Print Receipt</button>
    </div>
</body>
</html>
