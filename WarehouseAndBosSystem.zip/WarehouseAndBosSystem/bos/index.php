<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashierOrManager();

$user = getUserInfo();

// Get today's sales
$today = date('Y-m-d');
$sales_query = "SELECT COUNT(*) as total_transactions, COALESCE(SUM(total_amount), 0) as total_sales 
                FROM sales_transactions 
                WHERE sale_date = '$today' AND cashier_id = {$_SESSION['user_id']}";
$sales_result = mysqli_query($conn, $sales_query);
$sales_data = mysqli_fetch_assoc($sales_result);

// Get recent transactions
$recent_query = "SELECT st.*, COUNT(si.item_id) as item_count 
                 FROM sales_transactions st 
                 LEFT JOIN sales_items si ON st.transaction_id = si.transaction_id 
                 WHERE st.cashier_id = {$_SESSION['user_id']} 
                 GROUP BY st.transaction_id 
                 ORDER BY st.created_at DESC 
                 LIMIT 10";
$recent_result = mysqli_query($conn, $recent_query);

// Get low stock items (less than 10 units)
$low_stock_query = "SELECT p.product_id, p.product_name, COALESCE(SUM(bi.quantity), 0) as current_stock
                    FROM products p 
                    LEFT JOIN branch_inventory bi ON p.product_id = bi.product_id 
                    GROUP BY p.product_id, p.product_name
                    HAVING current_stock < 10 
                    LIMIT 5";
$low_stock_result = mysqli_query($conn, $low_stock_query);
if (!$low_stock_result) {
    // Fallback: just get an empty result set
    $low_stock_result = mysqli_query($conn, "SELECT 0 as product_id, 'No low stock items' as product_name, 0 as current_stock WHERE 0");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BOS - Branch Operating System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .header h1 {
            font-size: 32px;
            margin-bottom: 5px;
        }

        .header p {
            font-size: 14px;
            opacity: 0.9;
        }

        .user-section {
            text-align: right;
        }

        .user-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .user-role {
            background: rgba(255, 255, 255, 0.2);
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-block;
            margin-bottom: 10px;
        }

        .btn-logout {
            background: rgba(255, 255, 255, 0.3);
            color: white;
            padding: 8px 16px;
            border: 1px solid white;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-logout:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 25px;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
        }

        .card h2 {
            font-size: 16px;
            margin-bottom: 15px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }

        .stat-card {
            text-align: center;
        }

        .stat-value {
            font-size: 36px;
            font-weight: 700;
            color: #667eea;
            margin: 15px 0;
        }

        .stat-label {
            color: #666;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: #f0f0f0;
            color: #333;
        }

        .btn-secondary:hover {
            background: #e0e0e0;
        }

        .btn-success {
            background: #2ecc71;
            color: white;
        }

        .btn-success:hover {
            background: #27ae60;
        }

        .btn-warning {
            background: #f39c12;
            color: white;
        }

        .btn-warning:hover {
            background: #d68910;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        .table thead {
            background: #f9f9f9;
            border-bottom: 2px solid #667eea;
        }

        .table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            text-transform: uppercase;
            font-size: 12px;
        }

        .table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }

        .table tbody tr:hover {
            background: #f9f9f9;
        }

        .amount {
            color: #2ecc71;
            font-weight: 600;
        }

        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-paid {
            background: #d4edda;
            color: #155724;
        }

        .status-partial {
            background: #fff3cd;
            color: #856404;
        }

        .status-pending {
            background: #f8d7da;
            color: #721c24;
        }

        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }

        .empty-state-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }

        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .quick-stat {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .quick-stat h3 {
            font-size: 28px;
            margin-bottom: 5px;
        }

        .quick-stat p {
            font-size: 12px;
            opacity: 0.9;
        }

        .section-title {
            font-size: 20px;
            font-weight: 600;
            margin: 30px 0 20px 0;
            color: #333;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }

        .warning-list {
            list-style: none;
        }

        .warning-list li {
            padding: 10px;
            border-left: 3px solid #f39c12;
            background: #fffbf0;
            margin-bottom: 10px;
            border-radius: 3px;
        }

        .warning-list strong {
            color: #f39c12;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <div class="navbar" style="background: white; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); padding: 15px 20px; margin-bottom: 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
            <div class="navbar-left" style="display: flex; gap: 10px; align-items: center;">
                <a href="<?php echo isAdmin() ? '../admin/dashboard.php' : (isManager() ? '../dashboard.php' : 'index.php'); ?>" class="btn" style="background: #667eea; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px;">📊 Dashboard</a>
                <?php if (isAdmin() || isManager()): ?>
                    <a href="inventory.php" class="btn btn-secondary" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px;">📦 Inventory</a>
                    <a href="reports.php" class="btn btn-secondary" style="background: #95a5a6; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px;">📈 Reports</a>
                <?php endif; ?>
            </div>
            
            <div class="navbar-right" style="display: flex; gap: 10px; align-items: center;">
                <div class="user-info" style="display: flex; align-items: center; gap: 10px; padding: 0 15px; border-right: 1px solid #eee;">
                    <div>
                        <strong style="color: #333;"><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                        <small style="color: #999;"><?php echo isAdmin() ? 'Admin' : (isManager() ? 'Manager' : 'Cashier'); ?></small>
                    </div>
                </div>
                <a href="../logout.php" class="btn btn-danger" style="background: #e74c3c; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px;">🚪 Logout</a>
            </div>
        </div>
        
        <!-- Header -->
        <div class="header">
            <div>
                <h1>💳 Branch Operating System (BOS)</h1>
                <p>Cashier Dashboard & Point of Sale</p>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="quick-stats">
            <div class="quick-stat">
                <h3><?php echo $sales_data['total_transactions']; ?></h3>
                <p>Today's Transactions</p>
            </div>
            <div class="quick-stat">
                <h3>₱<?php echo number_format($sales_data['total_sales'], 2); ?></h3>
                <p>Today's Sales</p>
            </div>
            <div class="quick-stat">
                <h3><?php echo htmlspecialchars($user['full_name']); ?></h3>
                <p>Cashier</p>
            </div>
        </div>

        <!-- Main Actions -->
        <div class="dashboard-grid">
            <div class="card">
                <h2>🛒 Point of Sale</h2>
                <p style="color: #666; margin-bottom: 15px; font-size: 14px;">Process customer transactions</p>
                <div class="action-buttons">
                    <a href="sales.php" class="btn btn-primary">New Sale</a>
                    <a href="sales_history.php" class="btn btn-secondary">History</a>
                </div>
            </div>

            <div class="card">
                <h2>📦 Inventory</h2>
                <p style="color: #666; margin-bottom: 15px; font-size: 14px;">Check stock levels</p>
                <div class="action-buttons">
                    <a href="inventory.php" class="btn btn-primary">View Stock</a>
                    <a href="inventory_search.php" class="btn btn-secondary">Search</a>
                </div>
            </div>

            <div class="card">
                <h2>🧾 Receipts</h2>
                <p style="color: #666; margin-bottom: 15px; font-size: 14px;">Manage receipts and returns</p>
                <div class="action-buttons">
                    <a href="receipts.php" class="btn btn-primary">View Receipts</a>
                    <a href="returns.php" class="btn btn-secondary">Returns</a>
                </div>
            </div>

            <div class="card">
                <h2>📊 Reports</h2>
                <p style="color: #666; margin-bottom: 15px; font-size: 14px;">View sales reports and analytics</p>
                <div class="action-buttons">
                    <a href="reports.php" class="btn btn-primary">Sales Reports</a>
                    <a href="reports.php?start_date=<?php echo date('Y-m-01'); ?>&end_date=<?php echo date('Y-m-d'); ?>" class="btn btn-secondary">This Month</a>
                </div>
            </div>

            <div class="card">
                <h2>⚙️ Settings</h2>
                <p style="color: #666; margin-bottom: 15px; font-size: 14px;">Account settings</p>
                <div class="action-buttons">
                    <a href="profile.php" class="btn btn-primary">My Profile</a>
                    <a href="change_password.php" class="btn btn-secondary">Change Password</a>
                </div>
            </div>

            <div class="card">
                <h2>ℹ️ Help</h2>
                <p style="color: #666; margin-bottom: 15px; font-size: 14px;">System information</p>
                <div class="action-buttons">
                    <a href="help.php" class="btn btn-primary">Help Center</a>
                    <a href="../login_new.php" class="btn btn-secondary">Back to Login</a>
                </div>
            </div>
        </div>

        <!-- Recent Transactions -->
        <div class="section-title">📈 Recent Transactions (Today)</div>
        <div class="card">
            <?php if (mysqli_num_rows($recent_result) > 0): ?>
                <div class="table-wrapper">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Transaction #</th>
                                <th>Time</th>
                                <th>Items</th>
                                <th>Amount</th>
                                <th>Payment</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($trans = mysqli_fetch_assoc($recent_result)): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($trans['transaction_number']); ?></strong></td>
                                    <td><?php echo date('H:i:s', strtotime($trans['sale_time'])); ?></td>
                                    <td><?php echo $trans['item_count']; ?> items</td>
                                    <td class="amount">₱<?php echo number_format($trans['total_amount'], 2); ?></td>
                                    <td><?php echo ucfirst($trans['payment_method']); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $trans['payment_status']; ?>">
                                            <?php echo ucfirst($trans['payment_status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">📭</div>
                    <p>No transactions yet today</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Low Stock Alert -->
        <?php if (mysqli_num_rows($low_stock_result) > 0): ?>
            <div class="section-title">⚠️ Low Stock Items</div>
            <div class="alert alert-warning">
                <strong>Attention:</strong> The following items are running low on stock and may need to be reordered.
            </div>
            <div class="card">
                <ul class="warning-list">
                    <?php while ($item = mysqli_fetch_assoc($low_stock_result)): ?>
                        <li>
                            <strong><?php echo htmlspecialchars($item['product_name']); ?></strong><br>
                            Current Stock: <?php echo $item['current_stock']; ?> units
                        </li>
                    <?php endwhile; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- System Info -->
        <div style="margin-top: 40px; padding: 20px; background: #f9f9f9; border-radius: 8px; text-align: center; color: #999; font-size: 13px;">
            <p>Branch Operating System v1.0 | Last Updated: <?php echo date('M d, Y H:i:s'); ?></p>
            <p>For support, contact your branch manager or system administrator</p>
        </div>
    </div>
</body>
</html>
