<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashier();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help Center - BOS</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        .container { max-width: 900px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; }
        .header h1 { font-size: 24px; }
        .back-link { background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border-radius: 5px; text-decoration: none; font-weight: 600; }
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 30px; margin-bottom: 20px; }
        .card h2 { color: #333; margin-bottom: 15px; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
        .faq-item { margin-bottom: 20px; }
        .faq-question { font-weight: 600; color: #333; cursor: pointer; padding: 10px; background: #f9f9f9; border-radius: 5px; }
        .faq-question:hover { background: #f0f0f0; }
        .faq-answer { padding: 10px; color: #666; display: none; margin-top: 10px; }
        .faq-answer.active { display: block; }
        .contact-info { background: #f0f4ff; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; }
        .contact-info p { margin-bottom: 10px; color: #333; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>❓ Help Center</h1>
            <a href="index.php" class="back-link">← Back</a>
        </div>

        <div class="card">
            <h2>📖 Frequently Asked Questions</h2>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">How do I process a sale?</div>
                <div class="faq-answer">
                    1. Click "New Sale" from the dashboard<br>
                    2. Search for products or click to add them<br>
                    3. Adjust quantities as needed<br>
                    4. Select payment method<br>
                    5. Click "Complete Sale"
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">How do I check inventory?</div>
                <div class="faq-answer">
                    1. Click "View Stock" from the dashboard<br>
                    2. Use the search box to find products<br>
                    3. View stock levels, prices, and expiry dates<br>
                    4. Items in red indicate low stock
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">How do I change my password?</div>
                <div class="faq-answer">
                    1. Click "My Profile" from the dashboard<br>
                    2. Click "Change Password"<br>
                    3. Enter your current password<br>
                    4. Enter your new password twice<br>
                    5. Click "Update Password"
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">What payment methods are available?</div>
                <div class="faq-answer">
                    The system supports four payment methods:<br>
                    • Cash<br>
                    • Card<br>
                    • Mobile Payment<br>
                    • Credit
                </div>
            </div>

            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">How do I view my sales history?</div>
                <div class="faq-answer">
                    1. Click "History" from the dashboard<br>
                    2. View all your transactions<br>
                    3. See transaction numbers, amounts, and payment status
                </div>
            </div>
        </div>

        <div class="card">
            <h2>📞 Contact Support</h2>
            <div class="contact-info">
                <p><strong>Need help?</strong> Contact your branch manager or system administrator</p>
                <p>Email: support@branch.com</p>
                <p>Phone: +1-800-BRANCH-1</p>
                <p>Hours: Monday - Friday, 9:00 AM - 5:00 PM</p>
            </div>
        </div>

        <div class="card">
            <h2>💡 Tips & Tricks</h2>
            <ul style="margin-left: 20px; color: #666;">
                <li>Use keyboard shortcuts for faster navigation</li>
                <li>Check low stock alerts regularly</li>
                <li>Review your daily reports for performance insights</li>
                <li>Keep your password secure and change it regularly</li>
                <li>Log out when leaving your workstation</li>
            </ul>
        </div>
    </div>

    <script>
        function toggleFAQ(element) {
            const answer = element.nextElementSibling;
            answer.classList.toggle('active');
        }
    </script>
</body>
</html>
