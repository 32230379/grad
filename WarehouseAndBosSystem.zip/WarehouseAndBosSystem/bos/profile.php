<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();
requireCashier();

$user = getUserInfo();

// Get user details
$user_query = "SELECT * FROM users WHERE user_id = {$_SESSION['user_id']}";
$user_result = mysqli_query($conn, $user_query);
$user_data = mysqli_fetch_assoc($user_result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - BOS</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; }
        .header h1 { font-size: 24px; }
        .back-link { background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border-radius: 5px; text-decoration: none; font-weight: 600; }
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 30px; }
        .profile-header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #667eea; padding-bottom: 20px; }
        .avatar { font-size: 64px; margin-bottom: 15px; }
        .profile-name { font-size: 24px; font-weight: 600; color: #333; margin-bottom: 5px; }
        .profile-role { color: #667eea; font-weight: 600; }
        .info-group { margin-bottom: 20px; }
        .info-label { color: #666; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 5px; }
        .info-value { color: #333; font-size: 16px; font-weight: 500; }
        .btn { background: #667eea; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; margin-top: 20px; width: 100%; }
        .btn:hover { background: #5568d3; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>👤 My Profile</h1>
            <a href="index.php" class="back-link">← Back</a>
        </div>
        <div class="card">
            <div class="profile-header">
                <div class="avatar">👤</div>
                <div class="profile-name"><?php echo htmlspecialchars($user_data['full_name']); ?></div>
                <div class="profile-role">Cashier</div>
            </div>

            <div class="info-group">
                <div class="info-label">Username</div>
                <div class="info-value"><?php echo htmlspecialchars($user_data['username']); ?></div>
            </div>

            <div class="info-group">
                <div class="info-label">Email</div>
                <div class="info-value"><?php echo htmlspecialchars($user_data['email']); ?></div>
            </div>

            <div class="info-group">
                <div class="info-label">Phone</div>
                <div class="info-value"><?php echo htmlspecialchars($user_data['phone'] ?? 'N/A'); ?></div>
            </div>

            <div class="info-group">
                <div class="info-label">Member Since</div>
                <div class="info-value"><?php echo date('M d, Y', strtotime($user_data['created_at'])); ?></div>
            </div>

            <div class="info-group">
                <div class="info-label">Last Login</div>
                <div class="info-value"><?php echo $user_data['last_login'] ? date('M d, Y H:i:s', strtotime($user_data['last_login'])) : 'Never'; ?></div>
            </div>

            <a href="change_password.php" class="btn">Change Password</a>
        </div>
    </div>
</body>
</html>
