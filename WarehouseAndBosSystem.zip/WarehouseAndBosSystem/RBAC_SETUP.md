# Role-Based Access Control (RBAC) System Setup Guide

## Overview

This is a complete role-based authentication system for the Branch Management Application with three user roles:
- **Admin**: Full system access, user management, audit logs
- **Manager**: Branch operations, inventory, sales, reports
- **Cashier**: Point of Sale (BOS), inventory view, sales processing

## System Architecture

### Database Structure
- **roles**: Defines available roles (admin, manager, cashier)
- **permissions**: Defines system permissions
- **role_permissions**: Maps permissions to roles
- **users**: Enhanced with `is_admin` and `created_by` fields
- **user_audit_log**: Tracks all user management actions

### File Structure
```
warehouse+bos system/
├── login_new.php              # Enhanced login with role selection
├── logout.php                 # Logout handler
├── dashboard.php              # Manager dashboard
├── functions.php              # Updated with RBAC functions
├── config.php                 # Database configuration
├── admin/
│   ├── users.php             # User management panel
│   └── audit_logs.php        # Audit log viewer
├── bos/
│   ├── index.php             # Cashier dashboard
│   ├── sales.php             # Point of Sale
│   ├── inventory.php         # Inventory view
│   ├── sales_history.php     # Sales history (placeholder)
│   ├── receipts.php          # Receipts (placeholder)
│   ├── returns.php           # Returns (placeholder)
│   ├── daily_report.php      # Daily report (placeholder)
│   ├── summary.php           # Summary (placeholder)
│   ├── profile.php           # Profile (placeholder)
│   ├── change_password.php   # Change password (placeholder)
│   └── help.php              # Help center (placeholder)
└── database_schema_rbac.sql   # RBAC database schema
```

## Installation Steps

### Step 1: Database Setup

1. Open phpMyAdmin (http://localhost/phpmyadmin)
2. Create a new database named `branch_system`
3. Import the RBAC schema:
   - Go to SQL tab
   - Copy and paste contents of `database_schema_rbac.sql`
   - Click "Go"

**Or use command line:**
```bash
mysql -u root -p < database_schema_rbac.sql
```

### Step 2: Verify Configuration

Check `config.php` settings:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'branch_system');
```

### Step 3: Access the System

1. Navigate to: `http://localhost/warehouse+bos%20system/login_new.php`
2. Select your role (Admin, Manager, or Cashier)
3. Enter credentials (see Default Users below)

## Default Users

All default passwords are: **admin123**

| Username | Password | Role | Access |
|----------|----------|------|--------|
| admin | admin123 | Admin | `/admin/users.php` |
| manager | admin123 | Manager | `/dashboard.php` |
| cashier | admin123 | Cashier | `/bos/index.php` |

## User Roles & Permissions

### Admin Role
- ✅ Create/Edit/Delete users
- ✅ Manage roles and permissions
- ✅ View audit logs
- ✅ System settings
- ✅ Access to all modules

### Manager Role
- ✅ View dashboard
- ✅ Manage inventory
- ✅ Manage sales
- ✅ Manage receiving
- ✅ View reports
- ✅ Manage branch staff
- ❌ Cannot manage users
- ❌ Cannot access admin panel

### Cashier Role
- ✅ Process sales transactions
- ✅ View inventory
- ✅ Access BOS system
- ✅ View receipts
- ❌ Cannot manage inventory
- ❌ Cannot access admin panel
- ❌ Cannot access manager dashboard

## Login Flow

```
User visits login_new.php
    ↓
Step 1: Select Role (Admin/Manager/Cashier)
    ↓
Step 2: Enter Username & Password
    ↓
Verify credentials & role match
    ↓
Admin → /admin/users.php
Manager → /dashboard.php
Cashier → /bos/index.php
```

## Admin Panel Features

### User Management (`/admin/users.php`)
- **Add New User**: Create managers or cashiers
- **View All Users**: See all system users
- **Deactivate/Activate**: Toggle user status
- **Delete User**: Remove users (except main admin)
- **Statistics**: View user counts by role

### Audit Logs (`/admin/audit_logs.php`)
- View all user management actions
- Track user creation, updates, deletions
- See IP addresses and timestamps
- View before/after values for changes
- Pagination support

## BOS (Branch Operating System) Features

### Cashier Dashboard (`/bos/index.php`)
- Today's transaction count
- Today's sales total
- Quick access to POS
- Inventory status
- Low stock alerts
- Recent transactions

### Point of Sale (`/bos/sales.php`)
- Search products
- Add items to cart
- Adjust quantities
- Calculate totals with tax
- Select payment method
- Complete transactions

### Inventory View (`/bos/inventory.php`)
- View all products
- Stock levels with color coding
- Unit prices
- Expiry date tracking
- Search functionality
- Low stock warnings

## Authentication Functions

### Available Functions in `functions.php`

```php
// Check if user is logged in
isLoggedIn()

// Check if user is admin
isAdmin()

// Check if user is manager
isManager()

// Check if user is cashier
isCashier()

// Require login (redirect if not)
requireLogin()

// Require admin access
requireAdmin()

// Require manager access
requireManager()

// Require cashier access
requireCashier()

// Log user activity
logActivity($user_id, $action, $module, $description)

// Log audit trail
auditLog($user_id, $action, $description, $old_values, $new_values)
```

## Creating New Users

### Via Admin Panel
1. Login as Admin
2. Go to `/admin/users.php`
3. Fill in the "Add New User" form
4. Select role (Manager or Cashier)
5. Assign to branch (optional)
6. Click "Create User"

### Via Database
```sql
INSERT INTO users (username, password, full_name, email, phone, role, branch_id, is_active, created_by) 
VALUES (
    'newuser',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',  -- password: admin123
    'New User',
    'newuser@branch.com',
    '+1234567890',
    'manager',  -- or 'cashier'
    1,
    1,
    1  -- created by admin (user_id = 1)
);
```

## Protecting Pages

To protect a page with role-based access:

```php
<?php
require_once 'config.php';
require_once 'functions.php';

// Require login
requireLogin();

// Require specific role
requireManager();  // or requireAdmin(), requireCashier()

// Now page content is protected
?>
```

## Session Variables

After login, these session variables are available:

```php
$_SESSION['user_id']      // User ID
$_SESSION['username']     // Username
$_SESSION['full_name']    // Full name
$_SESSION['role']         // Role (admin, manager, cashier)
$_SESSION['is_admin']     // Boolean: is admin?
$_SESSION['branch_id']    // Branch ID (null for admin)
$_SESSION['branch_name']  // Branch name
```

## Logout

Navigate to `/logout.php` or click the Logout button. This will:
- Destroy session
- Clear all session variables
- Redirect to login page

## Security Features

✅ **Password Hashing**: Uses bcrypt (PASSWORD_BCRYPT)
✅ **SQL Injection Prevention**: Uses prepared statements
✅ **Session Management**: Secure session handling
✅ **Audit Logging**: All user actions tracked
✅ **Role-Based Access**: Strict permission checking
✅ **IP Tracking**: Logs user IP addresses
✅ **User Agent Tracking**: Logs browser information

## Troubleshooting

### Issue: "Access denied" error
- **Solution**: Check user role and permissions
- Verify user is assigned correct role
- Check if user is active (is_active = 1)

### Issue: Login redirects to login page
- **Solution**: Check database connection
- Verify credentials are correct
- Check if user exists in database
- Verify password hash is correct

### Issue: Can't access admin panel
- **Solution**: Only admin users can access
- Verify user has `is_admin = 1` in database
- Check role is set to 'admin'

### Issue: Cashier can't access BOS
- **Solution**: Verify user role is 'cashier'
- Check if user is active
- Verify branch is assigned

## Future Enhancements

- [ ] Two-factor authentication
- [ ] Password reset functionality
- [ ] Role-based menu system
- [ ] Permission-based feature access
- [ ] Session timeout warnings
- [ ] Login attempt tracking
- [ ] IP whitelist/blacklist
- [ ] User activity dashboard

## Support

For issues or questions:
1. Check audit logs in admin panel
2. Review error messages
3. Verify database structure
4. Check user permissions
5. Review session variables

## License

This system is part of the Branch Management Application.
