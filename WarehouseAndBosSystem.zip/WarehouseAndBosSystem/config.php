<?php
// BRANCH SYSTEM CONFIGURATION (PART 2)
// Separate from Warehouse System (Part 1)

// Database Configuration - BRANCH ONLY
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'branch_system');  // Changed to branch_system

// Application Configuration
define('SITE_URL', 'http://localhost/warehouse+bos%20system/');
define('SITE_NAME', 'Branch System');

// Warehouse API Configuration (for communication with Part 1)
define('WAREHOUSE_API_URL', 'http://localhost/warehouse_system/api/');
define('WAREHOUSE_API_KEY', 'your-api-key-here'); // Get this from warehouse admin

// Session Configuration
define('SESSION_TIMEOUT', 3600); // 1 hour

// Create database connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}

mysqli_set_charset($conn, 'utf8mb4');

// Timezone
date_default_timezone_set('UTC');

// Start session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
