<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();

$user = getUserInfo();
if ($user['role'] !== 'receiver') {
    die('Access denied. Only receivers can access this page.');
}

// Get received orders
$receipts_query = "SELECT r.*, o.order_number, o.barcode, u.full_name as requested_by_name 
                   FROM order_receipts r 
                   JOIN order_requests o ON r.order_id = o.order_id 
                   JOIN users u ON o.requested_by = u.user_id 
                   ORDER BY r.receipt_date DESC";
$receipts = mysqli_query($conn, $receipts_query);

// Add CSS for item status badges
$item_status_colors = [
    'received' => '#d1e7dd',
    'partial' => '#fff3cd',
    'damaged' => '#f8d7da',
    'not_received' => '#e2e3e5'
];

$item_status_text_colors = [
    'received' => '#0f5132',
    'partial' => '#856404',
    'damaged' => '#721c24',
    'not_received' => '#383d41'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Received History</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; color: #333; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        
        .navbar { background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 15px 20px; margin-bottom: 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; }
        .navbar-left { display: flex; gap: 10px; align-items: center; }
        .navbar-right { display: flex; gap: 10px; align-items: center; }
        .btn { background: #667eea; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; }
        .btn:hover { background: #5568d3; }
        .btn-secondary { background: #95a5a6; }
        .btn-secondary:hover { background: #7f8c8d; }
        .btn-danger { background: #e74c3c; }
        .btn-danger:hover { background: #c0392b; }
        .btn-view {
            background: #4b7bec;
            padding: 6px 14px;
            font-size: 12px;
            border-radius: 20px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-view:hover {
            background: #3867d6;
        }
        
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .header h1 { font-size: 28px; margin-bottom: 5px; }
        
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 20px; margin-bottom: 20px; }
        .card h2 { margin-bottom: 15px; color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
        
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f5f5f5; padding: 12px; text-align: left; font-weight: 600; border-bottom: 2px solid #ddd; }
        td { padding: 12px; border-bottom: 1px solid #eee; }
        tr:hover { background: #f9f9f9; }
        
        .status-badge { display: inline-block; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .status-completed { background: #d1e7dd; color: #0f5132; }
        
        .user-info { display: flex; align-items: center; gap: 10px; padding: 0 15px; border-right: 1px solid #eee; }
        .user-info strong { color: #333; }
        .user-info small { color: #999; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <div class="navbar">
            <div class="navbar-left">
                <a href="dashboard.php" class="btn">📦 Dashboard</a>
                <a href="received_history.php" class="btn">📋 History</a>
            </div>
            
            <div class="navbar-right">
                <div class="user-info">
                    <div>
                        <strong><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                        <small>Receiver</small>
                    </div>
                </div>
                <a href="../logout.php" class="btn btn-danger">🚪 Logout</a>
            </div>
        </div>

        <!-- Header -->
        <div class="header">
            <h1>📋 Received Orders History</h1>
            <p>View all received orders and their details</p>
        </div>

        <!-- Receipts Table -->
        <div class="card">
            <h2>📥 Received Orders</h2>
            
            <?php if (mysqli_num_rows($receipts) > 0): ?>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Barcode</th>
                                <th>Requested By</th>
                                <th>Receipt Date</th>
                                <th>Receipt Status</th>
                                <th>Item Statuses</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($receipt = mysqli_fetch_assoc($receipts)): ?>
                                <?php
                                // Get item statuses for this receipt
                                $items_query = "SELECT status, COUNT(*) as count FROM receipt_items WHERE receipt_id = {$receipt['receipt_id']} GROUP BY status";
                                $items_result = mysqli_query($conn, $items_query);
                                $item_statuses = [];
                                while ($item = mysqli_fetch_assoc($items_result)) {
                                    $item_statuses[$item['status']] = $item['count'];
                                }
                                ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($receipt['order_number']); ?></strong></td>
                                    <td><code><?php echo htmlspecialchars($receipt['barcode']); ?></code></td>
                                    <td><?php echo htmlspecialchars($receipt['requested_by_name']); ?></td>
                                    <td><?php echo date('M d, Y H:i', strtotime($receipt['receipt_date'])); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $receipt['status']; ?>">
                                            <?php echo ucfirst($receipt['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                                            <?php foreach ($item_statuses as $status => $count): ?>
                                                <span class="status-badge" style="background: <?php echo $item_status_colors[$status]; ?>; color: <?php echo $item_status_text_colors[$status]; ?>;">
                                                    <?php echo ucfirst(str_replace('_', ' ', $status)); ?> (<?php echo $count; ?>)
                                                </span>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <a href="view_receipt.php?receipt_id=<?php echo $receipt['receipt_id']; ?>" class="btn btn-view">📋 View</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p style="color: #666; text-align: center; padding: 20px;">No received orders yet</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
