<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();

$user = getUserInfo();
if ($user['role'] !== 'receiver') {
    die('Access denied. Only receivers can access this page.');
}

// Get pending orders
$pending_orders_query = "SELECT o.*, u.full_name as requested_by_name 
                        FROM order_requests o 
                        JOIN users u ON o.requested_by = u.user_id 
                        WHERE o.status IN ('pending', 'sent')
                        ORDER BY o.order_date DESC";
$pending_orders = mysqli_query($conn, $pending_orders_query);

// Get received orders (today)
$today = date('Y-m-d');
$received_today_query = "SELECT COUNT(*) as count FROM order_receipts WHERE DATE(receipt_date) = '$today'";
$received_today = mysqli_fetch_assoc(mysqli_query($conn, $received_today_query))['count'] ?? 0;

// Get total received
$total_received_query = "SELECT COUNT(*) as count FROM order_receipts";
$total_received_result = mysqli_query($conn, $total_received_query);
$total_received = $total_received_result ? mysqli_fetch_assoc($total_received_result)['count'] : 0;

// Get pending to receive
$pending_to_receive_query = "SELECT COUNT(*) as count FROM order_requests WHERE status IN ('pending', 'sent')";
$pending_to_receive_result = mysqli_query($conn, $pending_to_receive_query);
$pending_to_receive = $pending_to_receive_result ? mysqli_fetch_assoc($pending_to_receive_result)['count'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receiver Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; color: #333; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        
        .navbar { background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 15px 20px; margin-bottom: 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; }
        .navbar-left { display: flex; gap: 10px; align-items: center; }
        .navbar-right { display: flex; gap: 10px; align-items: center; }
        .btn { background: #667eea; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; }
        .btn:hover { background: #5568d3; }
        .btn-secondary { background: #95a5a6; }
        .btn-secondary:hover { background: #7f8c8d; }
        .btn-danger { background: #e74c3c; }
        .btn-danger:hover { background: #c0392b; }
        
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .header h1 { font-size: 28px; margin-bottom: 5px; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .stat-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); text-align: center; }
        .stat-card h3 { font-size: 32px; color: #667eea; margin-bottom: 10px; }
        .stat-card p { color: #666; font-size: 14px; }
        
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 20px; margin-bottom: 20px; }
        .card h2 { margin-bottom: 15px; color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
        
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f5f5f5; padding: 12px; text-align: left; font-weight: 600; border-bottom: 2px solid #ddd; }
        td { padding: 12px; border-bottom: 1px solid #eee; }
        tr:hover { background: #f9f9f9; }
        
        .status-badge { display: inline-block; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-sent { background: #cfe2ff; color: #084298; }
        .status-received { background: #d1e7dd; color: #0f5132; }
        .status-partial { background: #f8d7da; color: #842029; }
        
        .user-info { display: flex; align-items: center; gap: 10px; padding: 0 15px; border-right: 1px solid #eee; }
        .user-info strong { color: #333; }
        .user-info small { color: #999; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <div class="navbar">
            <div class="navbar-left">
                <a href="dashboard.php" class="btn">📦 Dashboard</a>
                <a href="received_history.php" class="btn btn-secondary">📋 History</a>
            </div>
            
            <div class="navbar-right">
                <div class="user-info">
                    <div>
                        <strong><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                        <small>Receiver</small>
                    </div>
                </div>
                <a href="../logout.php" class="btn btn-danger">🚪 Logout</a>
            </div>
        </div>

        <!-- Header -->
        <div class="header">
            <h1>📦 Receiver Dashboard</h1>
            <p>Manage incoming warehouse orders and update inventory</p>
        </div>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3><?php echo $pending_to_receive; ?></h3>
                <p>Pending Orders</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $received_today; ?></h3>
                <p>Received Today</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $total_received; ?></h3>
                <p>Total Received</p>
            </div>
        </div>

        <!-- Pending Orders -->
        <div class="card">
            <h2>📥 Pending Orders to Receive</h2>
            
            <?php if (mysqli_num_rows($pending_orders) > 0): ?>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Barcode</th>
                                <th>Requested By</th>
                                <th>Order Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($order = mysqli_fetch_assoc($pending_orders)): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($order['order_number']); ?></strong></td>
                                    <td><code><?php echo htmlspecialchars($order['barcode']); ?></code></td>
                                    <td><?php echo htmlspecialchars($order['requested_by_name']); ?></td>
                                    <td><?php echo date('M d, Y H:i', strtotime($order['order_date'])); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $order['status']; ?>">
                                            <?php echo ucfirst($order['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="receive_order.php?order_id=<?php echo $order['order_id']; ?>" class="btn" style="padding: 6px 12px; font-size: 12px;">📥 Receive</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p style="color: #666; text-align: center; padding: 20px;">No pending orders to receive</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
