<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();

$user = getUserInfo();
if ($user['role'] !== 'receiver') {
    die('Access denied. Only receivers can access this page.');
}

$receipt_id = isset($_GET['receipt_id']) ? (int)$_GET['receipt_id'] : 0;
$error = '';

if (!$receipt_id) {
    $error = 'No receipt selected';
}

// Get receipt details
if ($receipt_id) {
    $receipt_query = "SELECT r.*, o.order_number, o.barcode, u.full_name as requested_by_name 
                      FROM order_receipts r 
                      JOIN order_requests o ON r.order_id = o.order_id 
                      JOIN users u ON o.requested_by = u.user_id 
                      WHERE r.receipt_id = $receipt_id";
    $receipt_result = mysqli_query($conn, $receipt_query);
    $receipt = mysqli_fetch_assoc($receipt_result);
    
    if (!$receipt) {
        $error = 'Receipt not found';
    }
    
    // Get receipt items
    if (!$error) {
        $items_query = "SELECT ri.*, p.product_name, p.product_code 
                        FROM receipt_items ri 
                        JOIN products p ON ri.product_id = p.product_id 
                        WHERE ri.receipt_id = $receipt_id";
        $items_result = mysqli_query($conn, $items_query);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Receipt</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; color: #333; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        
        .navbar { background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 15px 20px; margin-bottom: 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; }
        .navbar-left { display: flex; gap: 10px; align-items: center; }
        .navbar-right { display: flex; gap: 10px; align-items: center; }
        .btn { background: #667eea; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; }
        .btn:hover { background: #5568d3; }
        .btn-secondary { background: #95a5a6; }
        .btn-secondary:hover { background: #7f8c8d; }
        .btn-danger { background: #e74c3c; }
        .btn-danger:hover { background: #c0392b; }
        
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .header h1 { font-size: 28px; margin-bottom: 5px; }
        
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 20px; margin-bottom: 20px; }
        .card h2 { margin-bottom: 15px; color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
        
        .alert { padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        
        .receipt-info { background: #f9f9f9; padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid #667eea; }
        .receipt-info strong { color: #333; }
        .receipt-info p { margin: 5px 0; font-size: 14px; }
        
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f5f5f5; padding: 12px; text-align: left; font-weight: 600; border-bottom: 2px solid #ddd; }
        td { padding: 12px; border-bottom: 1px solid #eee; }
        tr:hover { background: #f9f9f9; }
        
        .status-badge { display: inline-block; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .status-received { background: #d1e7dd; color: #0f5132; }
        .status-partial { background: #fff3cd; color: #856404; }
        .status-damaged { background: #f8d7da; color: #721c24; }
        .status-not_received { background: #e2e3e5; color: #383d41; }
        
        .user-info { display: flex; align-items: center; gap: 10px; padding: 0 15px; border-right: 1px solid #eee; }
        .user-info strong { color: #333; }
        .user-info small { color: #999; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <div class="navbar">
            <div class="navbar-left">
                <a href="dashboard.php" class="btn">📦 Dashboard</a>
                <a href="received_history.php" class="btn btn-secondary">📋 History</a>
            </div>
            
            <div class="navbar-right">
                <div class="user-info">
                    <div>
                        <strong><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                        <small>Receiver</small>
                    </div>
                </div>
                <a href="../logout.php" class="btn btn-danger">🚪 Logout</a>
            </div>
        </div>

        <!-- Header -->
        <div class="header">
            <h1>📋 Receipt Details</h1>
            <p>View received order details</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">✗ <?php echo htmlspecialchars($error); ?></div>
            <a href="received_history.php" class="btn">← Back to History</a>
        <?php else: ?>
            <!-- Receipt Information -->
            <div class="receipt-info">
                <strong>📦 Receipt Details:</strong><br>
                <p><strong>Receipt ID:</strong> <?php echo $receipt['receipt_id']; ?></p>
                <p><strong>Order #:</strong> <?php echo htmlspecialchars($receipt['order_number']); ?></p>
                <p><strong>Barcode:</strong> <code><?php echo htmlspecialchars($receipt['barcode']); ?></code></p>
                <p><strong>Requested By:</strong> <?php echo htmlspecialchars($receipt['requested_by_name']); ?></p>
                <p><strong>Receipt Date:</strong> <?php echo date('M d, Y H:i', strtotime($receipt['receipt_date'])); ?></p>
                <p><strong>Status:</strong> <span class="status-badge status-<?php echo $receipt['status']; ?>"><?php echo ucfirst($receipt['status']); ?></span></p>
                <?php if ($receipt['notes']): ?>
                    <p><strong>Notes:</strong> <?php echo htmlspecialchars($receipt['notes']); ?></p>
                <?php endif; ?>
            </div>

            <!-- Received Items -->
            <div class="card">
                <h2>📋 Received Items</h2>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Code</th>
                                <th>Quantity Received</th>
                                <th>Status</th>
                                <th>Notes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if (mysqli_num_rows($items_result) > 0) {
                                while ($item = mysqli_fetch_assoc($items_result)): 
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td><code><?php echo htmlspecialchars($item['product_code']); ?></code></td>
                                    <td><strong><?php echo $item['quantity_received']; ?></strong></td>
                                    <td>
                                        <span class="status-badge status-<?php echo str_replace(' ', '_', $item['status']); ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $item['status'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($item['notes'] ?? 'N/A'); ?></td>
                                </tr>
                            <?php 
                                endwhile;
                            } else {
                                echo "<tr><td colspan='5' style='text-align: center; color: #999;'>No items in this receipt</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="card">
                <a href="received_history.php" class="btn">← Back to History</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
