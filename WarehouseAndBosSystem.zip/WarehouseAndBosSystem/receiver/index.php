<?php
// Redirect to dashboard
header('Location: dashboard.php');
exit;
?>
