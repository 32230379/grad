<?php
require_once '../config.php';
require_once '../functions.php';

requireLogin();

$user = getUserInfo();
if ($user['role'] !== 'receiver') {
    die('Access denied. Only receivers can access this page.');
}

$message = '';
$error = '';
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

// Get pending orders list (for when no order_id is provided)
$pending_orders_query = "SELECT o.*, u.full_name as requested_by_name 
                        FROM order_requests o 
                        JOIN users u ON o.requested_by = u.user_id 
                        WHERE o.status IN ('pending', 'sent')
                        ORDER BY o.order_date DESC";
$pending_orders = mysqli_query($conn, $pending_orders_query);

// Get order details
if ($order_id) {
    $order_query = "SELECT o.*, u.full_name as requested_by_name 
                    FROM order_requests o 
                    JOIN users u ON o.requested_by = u.user_id 
                    WHERE o.order_id = $order_id";
    $order_result = mysqli_query($conn, $order_query);
    $order = mysqli_fetch_assoc($order_result);
    
    if (!$order) {
        $error = 'Order not found';
    }
    
    // Get order items
    $items_query = "SELECT ori.*, p.product_name, p.product_code 
                    FROM order_request_items ori 
                    JOIN products p ON ori.product_id = p.product_id 
                    WHERE ori.order_id = $order_id";
    $items_result = mysqli_query($conn, $items_query);
} else {
    $error = 'No order selected - please select an order from the list below';
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] === 'receive_order') {
    $order_id = (int)$_POST['order_id'];
    $received_items = isset($_POST['items']) ? $_POST['items'] : [];
    $notes = mysqli_real_escape_string($conn, $_POST['notes'] ?? '');
    
    if (empty($received_items)) {
        $error = 'Please add at least one received item';
    } else {
        // Begin transaction
        mysqli_begin_transaction($conn);
        
        try {
            $receipt_date = date('Y-m-d H:i:s');
            
            // Get branch_id from order
            $order_branch_query = "SELECT branch_id FROM order_requests WHERE order_id = $order_id";
            $order_branch_result = mysqli_query($conn, $order_branch_query);
            
            if (!$order_branch_result) {
                throw new Exception('Database error: ' . mysqli_error($conn));
            }
            
            $order_branch = mysqli_fetch_assoc($order_branch_result);
            $branch_id = $order_branch ? $order_branch['branch_id'] : 1; // Default to branch 1 if not found
            
            // Create receipt record
            $receipt_query = "INSERT INTO order_receipts (order_id, received_by, receipt_date, notes, status) 
                             VALUES ($order_id, {$user['user_id']}, '$receipt_date', '$notes', 'completed')";
            
            if (!mysqli_query($conn, $receipt_query)) {
                throw new Exception('Failed to create receipt');
            }
            
            $receipt_id = mysqli_insert_id($conn);
            
            // Process each received item
            foreach ($received_items as $item) {
                $product_id = (int)$item['product_id'];
                $quantity_received = (int)$item['quantity_received'];
                $item_status = mysqli_real_escape_string($conn, $item['status']);
                $item_notes = mysqli_real_escape_string($conn, $item['notes'] ?? '');
                
                // Insert receipt item
                $receipt_item_query = "INSERT INTO receipt_items (receipt_id, product_id, quantity_received, status, notes) 
                                      VALUES ($receipt_id, $product_id, $quantity_received, '$item_status', '$item_notes')";
                
                if (!mysqli_query($conn, $receipt_item_query)) {
                    throw new Exception('Failed to add receipt item');
                }
                
                // Update inventory (add received items)
                if ($item_status === 'received' || $item_status === 'partial') {
                    // First check if record exists
                    $check_inventory = "SELECT inventory_id FROM branch_inventory WHERE product_id = $product_id AND branch_id = $branch_id LIMIT 1";
                    $check_result = mysqli_query($conn, $check_inventory);
                    
                    if ($check_result && mysqli_num_rows($check_result) > 0) {
                        // Update existing record
                        $inventory_query = "UPDATE branch_inventory SET quantity = quantity + $quantity_received WHERE product_id = $product_id AND branch_id = $branch_id";
                        if (!mysqli_query($conn, $inventory_query)) {
                            throw new Exception('Failed to update inventory: ' . mysqli_error($conn));
                        }
                    } else {
                        // Create new record
                        $insert_inventory_query = "INSERT INTO branch_inventory (branch_id, product_id, quantity) VALUES ($branch_id, $product_id, $quantity_received)";
                        if (!mysqli_query($conn, $insert_inventory_query)) {
                            throw new Exception('Failed to create inventory record: ' . mysqli_error($conn));
                        }
                    }
                }
            }
            
            // Update order status
            $update_order_query = "UPDATE order_requests SET status = 'received' WHERE order_id = $order_id";
            if (!mysqli_query($conn, $update_order_query)) {
                throw new Exception('Failed to update order status');
            }
            
            // Commit transaction
            mysqli_commit($conn);
            
            // Log activity
            logActivity($user['user_id'], 'Receive Order', 'Orders', "Received order $order_id");
            
            $message = "✓ Order received successfully! Inventory has been updated.";
            
            // Redirect after 2 seconds
            header("refresh:2;url=dashboard.php");
            
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receive Order</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; color: #333; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        
        .navbar { background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 15px 20px; margin-bottom: 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; }
        .navbar-left { display: flex; gap: 10px; align-items: center; }
        .navbar-right { display: flex; gap: 10px; align-items: center; }
        .btn { background: #667eea; color: white; padding: 10px 16px; text-decoration: none; border-radius: 4px; font-size: 14px; border: none; cursor: pointer; }
        .btn:hover { background: #5568d3; }
        .btn-secondary { background: #95a5a6; }
        .btn-secondary:hover { background: #7f8c8d; }
        .btn-danger { background: #e74c3c; }
        .btn-danger:hover { background: #c0392b; }
        
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .header h1 { font-size: 28px; margin-bottom: 5px; }
        
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 20px; margin-bottom: 20px; }
        .card h2 { margin-bottom: 15px; color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
        
        .alert { padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        
        .order-info { background: #f9f9f9; padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left: 4px solid #667eea; }
        .order-info strong { color: #333; }
        .order-info p { margin: 5px 0; font-size: 14px; }
        
        .table-wrapper { overflow-x: auto; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f5f5f5; padding: 12px; text-align: left; font-weight: 600; border-bottom: 2px solid #ddd; }
        td { padding: 12px; border-bottom: 1px solid #eee; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 600; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); }
        
        .item-row { background: #f9f9f9; padding: 15px; border-radius: 5px; margin-bottom: 10px; border-left: 3px solid #667eea; }
        .item-row h4 { margin-bottom: 10px; color: #333; }
        .item-row-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; }
        
        .user-info { display: flex; align-items: center; gap: 10px; padding: 0 15px; border-right: 1px solid #eee; }
        .user-info strong { color: #333; }
        .user-info small { color: #999; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <div class="navbar">
            <div class="navbar-left">
                <a href="dashboard.php" class="btn">📦 Dashboard</a>
                <a href="received_history.php" class="btn btn-secondary">📋 History</a>
            </div>
            
            <div class="navbar-right">
                <div class="user-info">
                    <div>
                        <strong><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                        <small>Receiver</small>
                    </div>
                </div>
                <a href="../logout.php" class="btn btn-danger">🚪 Logout</a>
            </div>
        </div>

        <!-- Header -->
        <div class="header">
            <h1>📥 Receive Order</h1>
            <p>Record received items and update inventory</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success">✓ <?php echo $message; ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error">✗ <?php echo $error; ?></div>
        <?php endif; ?>

        <?php if (!$error && $order): ?>
            <!-- Order Information -->
            <div class="order-info">
                <strong>📦 Order Details:</strong><br>
                <p><strong>Order #:</strong> <?php echo htmlspecialchars($order['order_number']); ?></p>
                <p><strong>Barcode:</strong> <code><?php echo htmlspecialchars($order['barcode']); ?></code></p>
                <p><strong>Requested By:</strong> <?php echo htmlspecialchars($order['requested_by_name']); ?></p>
                <p><strong>Order Date:</strong> <?php echo date('M d, Y H:i', strtotime($order['order_date'])); ?></p>
                <p><strong>Status:</strong> <?php echo ucfirst($order['status']); ?></p>
            </div>

            <!-- Ordered Items -->
            <div class="card">
                <h2>📋 Ordered Items (Expected)</h2>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Code</th>
                                <th>Ordered Qty</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            mysqli_data_seek($items_result, 0);
                            while ($item = mysqli_fetch_assoc($items_result)): 
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td><code><?php echo htmlspecialchars($item['product_code']); ?></code></td>
                                    <td><strong><?php echo $item['quantity']; ?></strong></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Receive Form -->
            <form method="POST" action="">
                <input type="hidden" name="action" value="receive_order">
                <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">

                <div class="card">
                    <h2>✓ Record Received Items</h2>
                    
                    <div id="items-container">
                        <?php 
                        mysqli_data_seek($items_result, 0);
                        $item_index = 0;
                        while ($item = mysqli_fetch_assoc($items_result)): 
                        ?>
                            <div class="item-row">
                                <h4>📦 <?php echo htmlspecialchars($item['product_name']); ?> (Ordered: <?php echo $item['quantity']; ?>)</h4>
                                
                                <input type="hidden" name="items[<?php echo $item_index; ?>][product_id]" value="<?php echo $item['product_id']; ?>">
                                
                                <div class="item-row-grid">
                                    <div class="form-group">
                                        <label>Quantity Received *</label>
                                        <input type="number" name="items[<?php echo $item_index; ?>][quantity_received]" min="0" value="<?php echo $item['quantity']; ?>" required>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Status *</label>
                                        <select name="items[<?php echo $item_index; ?>][status]" required>
                                            <option value="received">✓ Received</option>
                                            <option value="partial">⚠️ Partial</option>
                                            <option value="damaged">❌ Damaged</option>
                                            <option value="not_received">📭 Not Received</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label>Notes (Optional)</label>
                                    <textarea name="items[<?php echo $item_index; ?>][notes]" rows="2" placeholder="Any issues or notes about this item..."></textarea>
                                </div>
                            </div>
                        <?php 
                        $item_index++;
                        endwhile; 
                        ?>
                    </div>
                </div>

                <div class="card">
                    <div class="form-group">
                        <label for="notes">General Notes (Optional)</label>
                        <textarea id="notes" name="notes" rows="3" placeholder="Any general notes about this delivery..."></textarea>
                    </div>

                    <div style="display: flex; gap: 10px;">
                        <button type="submit" class="btn">✓ Confirm Receipt</button>
                        <a href="dashboard.php" class="btn btn-secondary">← Cancel</a>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
