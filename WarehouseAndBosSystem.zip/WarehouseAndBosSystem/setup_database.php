<?php
require_once 'config.php';

echo "<h2>Database Setup</h2>";

// Read the SQL file
$sql_file = file_get_contents('database_schema_complete.sql');

// Split by semicolon and execute each statement
$statements = array_filter(array_map('trim', explode(';', $sql_file)));

$success_count = 0;
$error_count = 0;

foreach ($statements as $statement) {
    if (empty($statement)) continue;
    
    if (mysqli_multi_query($conn, $statement)) {
        $success_count++;
        // Clear results
        while (mysqli_next_result($conn)) {
            if ($result = mysqli_store_result($conn)) {
                mysqli_free_result($result);
            }
        }
    } else {
        $error_count++;
        echo "<p style='color:red;'><strong>Error:</strong> " . mysqli_error($conn) . "</p>";
    }
}

echo "<p style='color:green;'><strong>Success:</strong> $success_count statements executed</p>";
if ($error_count > 0) {
    echo "<p style='color:orange;'><strong>Errors:</strong> $error_count statements failed (may be expected for INSERT IGNORE)</p>";
}

// Verify users were created
echo "<hr>";
echo "<h3>Verifying Users</h3>";

$result = mysqli_query($conn, "SELECT user_id, username, role, is_active FROM users");
$user_count = mysqli_num_rows($result);

echo "<p>Users found: <strong>$user_count</strong></p>";

if ($user_count > 0) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>ID</th><th>Username</th><th>Role</th><th>Active</th></tr>";
    
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['user_id'] . "</td>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['role'] . "</td>";
        echo "<td>" . ($row['is_active'] ? 'Yes' : 'No') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<hr>";
    echo "<h3>Test Login Credentials</h3>";
    echo "<p><strong>Admin:</strong> username: <code>admin</code>, password: <code>admin123</code></p>";
    echo "<p><strong>Manager:</strong> username: <code>manager</code>, password: <code>admin123</code></p>";
    echo "<p><strong>Cashier:</strong> username: <code>cashier</code>, password: <code>admin123</code></p>";
    echo "<p><a href='login_new.php'>Go to Login</a></p>";
} else {
    echo "<p style='color:red;'>No users found. Database setup may have failed.</p>";
}
?>
