<?php
require_once 'config.php';

echo "<h2>Table Structure Check</h2>";

$tables = ['order_requests', 'branch_inventory', 'order_receipts', 'receipt_items'];

foreach ($tables as $table) {
    echo "<h3>$table</h3>";
    $result = mysqli_query($conn, "DESCRIBE $table");
    
    if (!$result) {
        echo "<p style='color: red;'>Error: " . mysqli_error($conn) . "</p>";
        continue;
    }
    
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    echo "<br>";
}

// Check sample data
echo "<h3>Sample order_requests data</h3>";
$result = mysqli_query($conn, "SELECT * FROM order_requests LIMIT 1");
if ($row = mysqli_fetch_assoc($result)) {
    echo "<pre>";
    print_r($row);
    echo "</pre>";
} else {
    echo "<p>No data in order_requests</p>";
}
?>
