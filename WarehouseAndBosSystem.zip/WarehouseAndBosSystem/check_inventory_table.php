<?php
require_once 'config.php';

echo "Checking branch_inventory table structure:\n";
$result = mysqli_query($conn, "DESCRIBE branch_inventory");
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo $row['Field'] . " - " . $row['Type'] . "\n";
    }
} else {
    echo "Error: " . mysqli_error($conn) . "\n";
}

echo "\n\nChecking products table structure:\n";
$result = mysqli_query($conn, "DESCRIBE products");
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo $row['Field'] . " - " . $row['Type'] . "\n";
    }
} else {
    echo "Error: " . mysqli_error($conn) . "\n";
}
?>
