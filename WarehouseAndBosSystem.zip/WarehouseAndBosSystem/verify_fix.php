<?php
require_once 'config.php';

$result = mysqli_query($conn, "SELECT user_id, username, role, is_active FROM users");
echo "Current Users:\n";
while($row = mysqli_fetch_assoc($result)) {
    echo "ID: {$row['user_id']}, Username: {$row['username']}, Role: [{$row['role']}], Active: " . ($row['is_active'] ? 'Yes' : 'No') . "\n";
}
?>
