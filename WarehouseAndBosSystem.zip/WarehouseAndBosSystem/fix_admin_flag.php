<?php
require_once 'config.php';

echo "Checking admin user...\n";
$admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT user_id, username, is_admin FROM users WHERE username = 'admin'"));

if ($admin) {
    echo "Admin user found:\n";
    echo "  ID: {$admin['user_id']}\n";
    echo "  Username: {$admin['username']}\n";
    echo "  is_admin: {$admin['is_admin']}\n\n";
    
    if (!$admin['is_admin']) {
        echo "Setting is_admin flag...\n";
        $update = mysqli_query($conn, "UPDATE users SET is_admin = 1 WHERE user_id = {$admin['user_id']}");
        if ($update) {
            echo "✓ Admin flag set successfully\n";
        } else {
            echo "✗ Error: " . mysqli_error($conn) . "\n";
        }
    } else {
        echo "✓ Admin flag already set\n";
    }
} else {
    echo "Admin user not found!\n";
}

echo "\n\nFinal check:\n";
$admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT user_id, username, is_admin FROM users WHERE username = 'admin'"));
echo "Admin is_admin flag: " . ($admin['is_admin'] ? 'TRUE ✓' : 'FALSE ✗') . "\n";
?>
