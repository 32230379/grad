<?php
require_once 'config.php';
require_once 'functions.php';

requireLogin();
requireManager();

$user = getUserInfo();

// Get today's date
$today = date('Y-m-d');

// Get sales summary for today
$today_sales_query = "SELECT COUNT(*) as transactions, SUM(total_amount) as total
                      FROM sales_transactions
                      WHERE sale_date = ?";
$stmt = mysqli_prepare($conn, $today_sales_query);
mysqli_stmt_bind_param($stmt, "s", $today);
mysqli_stmt_execute($stmt);
$today_sales = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

// Get this month's sales
$month_start = date('Y-m-01');
$month_sales_query = "SELECT COUNT(*) as transactions, SUM(total_amount) as total
                      FROM sales_transactions
                      WHERE sale_date BETWEEN ? AND ?";
$stmt = mysqli_prepare($conn, $month_sales_query);
mysqli_stmt_bind_param($stmt, "ss", $month_start, $today);
mysqli_stmt_execute($stmt);
$month_sales = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

// Get inventory summary
$inventory_query = "SELECT COUNT(DISTINCT product_id) as total_products,
                           SUM(quantity) as total_stock
                    FROM branch_inventory";
$inventory_result = mysqli_query($conn, $inventory_query);
$inventory_summary = mysqli_fetch_assoc($inventory_result);

// Get low stock items
$low_stock_query = "SELECT p.product_id, p.product_name, p.product_code, SUM(bi.quantity) as current_stock
                    FROM branch_inventory bi
                    JOIN products p ON bi.product_id = p.product_id
                    GROUP BY p.product_id, p.product_name, p.product_code
                    HAVING current_stock < 10
                    ORDER BY current_stock ASC
                    LIMIT 10";
$low_stock_items = mysqli_query($conn, $low_stock_query);

// Get top selling products this month
$top_products_query = "SELECT p.product_name, p.product_code, SUM(si.quantity) as qty_sold, SUM(si.subtotal) as revenue
                       FROM sales_items si
                       JOIN products p ON si.product_id = p.product_id
                       JOIN sales_transactions st ON si.transaction_id = st.transaction_id
                       WHERE st.sale_date BETWEEN ? AND ?
                       GROUP BY p.product_id, p.product_name, p.product_code
                       ORDER BY qty_sold DESC
                       LIMIT 5";
$stmt = mysqli_prepare($conn, $top_products_query);
mysqli_stmt_bind_param($stmt, "ss", $month_start, $today);
mysqli_stmt_execute($stmt);
$top_products = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

// Get sales by payment method
$payment_query = "SELECT payment_method, COUNT(*) as count, SUM(total_amount) as total
                  FROM sales_transactions
                  WHERE sale_date = ?
                  GROUP BY payment_method";
$stmt = mysqli_prepare($conn, $payment_query);
mysqli_stmt_bind_param($stmt, "s", $today);
mysqli_stmt_execute($stmt);
$payment_methods = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

// Get cashier performance
$cashier_query = "SELECT u.full_name, COUNT(st.transaction_id) as transactions, SUM(st.total_amount) as total
                  FROM sales_transactions st
                  JOIN users u ON st.cashier_id = u.user_id
                  WHERE st.sale_date = ?
                  GROUP BY st.cashier_id, u.full_name
                  ORDER BY total DESC";
$stmt = mysqli_prepare($conn, $cashier_query);
mysqli_stmt_bind_param($stmt, "s", $today);
mysqli_stmt_execute($stmt);
$cashier_performance = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

// Get expiring items
$expiring_query = "SELECT p.product_name, bi.batch_number, bi.expiry_date, bi.quantity,
                          DATEDIFF(bi.expiry_date, CURDATE()) as days_left
                   FROM branch_inventory bi
                   JOIN products p ON bi.product_id = p.product_id
                   WHERE bi.expiry_date IS NOT NULL
                   AND bi.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                   AND bi.quantity > 0
                   ORDER BY bi.expiry_date ASC
                   LIMIT 10";
$expiring_items = mysqli_query($conn, $expiring_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Dashboard - <?php echo SITE_NAME; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        
        .header h1 {
            font-size: 32px;
            margin-bottom: 5px;
        }
        
        .header p {
            font-size: 16px;
            opacity: 0.9;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border-left: 4px solid #667eea;
        }
        
        .stat-card h3 {
            font-size: 28px;
            color: #667eea;
            margin-bottom: 5px;
        }
        
        .stat-card p {
            font-size: 14px;
            color: #999;
        }
        
        .stat-card.orange {
            border-left-color: #f39c12;
        }
        
        .stat-card.orange h3 {
            color: #f39c12;
        }
        
        .stat-card.red {
            border-left-color: #e74c3c;
        }
        
        .stat-card.red h3 {
            color: #e74c3c;
        }
        
        .stat-card.green {
            border-left-color: #2ecc71;
        }
        
        .stat-card.green h3 {
            color: #2ecc71;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        
        .card h2 {
            font-size: 18px;
            margin-bottom: 15px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }
        
        .table-wrapper {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        
        table thead {
            background: #f9f9f9;
            border-bottom: 2px solid #667eea;
        }
        
        table th {
            padding: 10px;
            text-align: left;
            font-weight: 600;
            color: #333;
        }
        
        table td {
            padding: 10px;
            border-bottom: 1px solid #eee;
        }
        
        table tbody tr:hover {
            background: #f9f9f9;
        }
        
        .empty-state {
            text-align: center;
            padding: 30px;
            color: #999;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .badge-low {
            background: #f8d7da;
            color: #721c24;
        }
        
        .badge-critical {
            background: #f5c6cb;
            color: #721c24;
        }
        
        .text-danger {
            color: #e74c3c;
            font-weight: 600;
        }
        
        .text-warning {
            color: #f39c12;
            font-weight: 600;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-left {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .navbar-right {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 16px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .btn:hover {
            background: #5568d3;
        }
        
        .btn-secondary {
            background: #95a5a6;
        }
        
        .btn-secondary:hover {
            background: #7f8c8d;
        }
        
        .btn-danger {
            background: #e74c3c;
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        .btn-success {
            background: #2ecc71;
        }
        
        .btn-success:hover {
            background: #27ae60;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0 15px;
            border-right: 1px solid #eee;
        }
        
        .user-info strong {
            color: #333;
        }
        
        .user-info small {
            color: #999;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Bar -->
        <div class="navbar">
            <div class="navbar-left">
                <a href="dashboard.php" class="btn">📊 Dashboard</a>
                <a href="bos/shelf_management.php" class="btn btn-secondary">📦 Shelf Management</a>
                <a href="bos/inventory.php" class="btn btn-secondary">📦 Inventory</a>
                <a href="bos/reports.php" class="btn btn-secondary">📈 Reports</a>
                <a href="dashboard/order_request.php" class="btn btn-success">📋 Stock Order</a>
            </div>
            
            <div class="navbar-right">
                <div class="user-info">
                    <div>
                        <strong><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                        <small><?php echo ucfirst($user['role']); ?></small>
                    </div>
                </div>
                <a href="logout.php" class="btn btn-danger">🚪 Logout</a>
            </div>
        </div>
        
        <div class="header">
            <h1>📊 Manager Dashboard</h1>
            <p>Welcome back, <?php echo htmlspecialchars($user['full_name']); ?>! Here's your branch overview.</p>
        </div>
        
        <!-- Key Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3><?php echo $today_sales['transactions'] ?? 0; ?></h3>
                <p>Today's Transactions</p>
            </div>
            
            <div class="stat-card green">
                <h3>₱<?php echo number_format($today_sales['total'] ?? 0, 2); ?></h3>
                <p>Today's Sales</p>
            </div>
            
            <div class="stat-card green">
                <h3>₱<?php echo number_format($month_sales['total'] ?? 0, 2); ?></h3>
                <p>This Month's Sales</p>
            </div>
            
            <div class="stat-card">
                <h3><?php echo $inventory_summary['total_products'] ?? 0; ?></h3>
                <p>Total Products</p>
            </div>
            
            <div class="stat-card">
                <h3><?php echo number_format($inventory_summary['total_stock'] ?? 0); ?></h3>
                <p>Total Stock Units</p>
            </div>
            
            <div class="stat-card orange">
                <h3><?php echo mysqli_num_rows($low_stock_items); ?></h3>
                <p>Low Stock Items</p>
            </div>
        </div>
        
        <!-- Main Dashboard Content -->
        <div class="dashboard-grid">
            <!-- Today's Sales by Payment Method -->
            <div class="card">
                <h2>💳 Today's Sales by Payment Method</h2>
                <div class="table-wrapper">
                    <?php if (mysqli_num_rows($payment_methods) > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Payment Method</th>
                                    <th>Transactions</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($payment = mysqli_fetch_assoc($payment_methods)): ?>
                                    <tr>
                                        <td><strong><?php echo strtoupper($payment['payment_method']); ?></strong></td>
                                        <td><?php echo $payment['count']; ?></td>
                                        <td>₱<?php echo number_format($payment['total'], 2); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">No sales today</div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Cashier Performance -->
            <div class="card">
                <h2>👥 Cashier Performance (Today)</h2>
                <div class="table-wrapper">
                    <?php if (mysqli_num_rows($cashier_performance) > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Cashier</th>
                                    <th>Transactions</th>
                                    <th>Total Sales</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($cashier = mysqli_fetch_assoc($cashier_performance)): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($cashier['full_name']); ?></strong></td>
                                        <td><?php echo $cashier['transactions']; ?></td>
                                        <td>₱<?php echo number_format($cashier['total'], 2); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">No sales today</div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Top Selling Products -->
            <div class="card">
                <h2>🏆 Top Selling Products (This Month)</h2>
                <div class="table-wrapper">
                    <?php if (mysqli_num_rows($top_products) > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Qty Sold</th>
                                    <th>Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($product = mysqli_fetch_assoc($top_products)): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($product['product_name']); ?></strong></td>
                                        <td><?php echo $product['qty_sold']; ?> units</td>
                                        <td>₱<?php echo number_format($product['revenue'], 2); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">No sales this month</div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Low Stock Items -->
            <div class="card">
                <h2>📦 Low Stock Items</h2>
                <div class="table-wrapper">
                    <?php if (mysqli_num_rows($low_stock_items) > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Code</th>
                                    <th>Current Stock</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($item = mysqli_fetch_assoc($low_stock_items)): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($item['product_name']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($item['product_code']); ?></td>
                                        <td><span class="text-danger"><?php echo $item['current_stock']; ?> units</span></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">All items are well stocked</div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Expiring Items -->
            <div class="card">
                <h2>⏰ Expiring Items (30 Days)</h2>
                <div class="table-wrapper">
                    <?php if (mysqli_num_rows($expiring_items) > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Batch</th>
                                    <th>Expiry Date</th>
                                    <th>Days Left</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($item = mysqli_fetch_assoc($expiring_items)): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                        <td><?php echo htmlspecialchars($item['batch_number']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($item['expiry_date'])); ?></td>
                                        <td><span class="<?php echo $item['days_left'] <= 7 ? 'text-danger' : 'text-warning'; ?>"><?php echo $item['days_left']; ?> days</span></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">No items expiring soon</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
