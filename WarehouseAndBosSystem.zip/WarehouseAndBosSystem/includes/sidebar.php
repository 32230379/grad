<?php
$current_page = basename($_SERVER['PHP_SELF'], '.php');
$user_role = $_SESSION['role'];
$base_path = (strpos($_SERVER['PHP_SELF'], '/bos/') !== false) ? '../' : './';
?>
<aside class="sidebar" id="sidebar">
    <nav class="sidebar-nav">
        <a href="<?php echo $base_path; ?>bos/index.php" class="nav-item <?php echo $current_page == 'index' ? 'active' : ''; ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="3" width="7" height="7"/>
                <rect x="14" y="3" width="7" height="7"/>
                <rect x="14" y="14" width="7" height="7"/>
                <rect x="3" y="14" width="7" height="7"/>
            </svg>
            <span>Dashboard</span>
        </a>
        
        <a href="<?php echo $base_path; ?>bos/inventory.php" class="nav-item <?php echo $current_page == 'inventory' ? 'active' : ''; ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>
            </svg>
            <span>Inventory</span>
        </a>
        
        <a href="<?php echo $base_path; ?>bos/sales.php" class="nav-item <?php echo $current_page == 'sales' ? 'active' : ''; ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="12" y1="1" x2="12" y2="23"/>
                <path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/>
            </svg>
            <span>Sales</span>
        </a>
        
        <a href="<?php echo $base_path; ?>bos/sales_history.php" class="nav-item <?php echo $current_page == 'sales_history' ? 'active' : ''; ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
                <polyline points="9 22 9 12 15 12 15 22"/>
            </svg>
            <span>Sales History</span>
        </a>
        
        <a href="<?php echo $base_path; ?>bos/daily_report.php" class="nav-item <?php echo $current_page == 'daily_report' ? 'active' : ''; ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 3v18h18"/>
                <path d="M18 17V9"/>
                <path d="M13 17V5"/>
                <path d="M8 17v-3"/>
            </svg>
            <span>Daily Report</span>
        </a>
        
        <a href="<?php echo $base_path; ?>bos/profile.php" class="nav-item <?php echo $current_page == 'profile' ? 'active' : ''; ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
                <circle cx="12" cy="7" r="4"/>
            </svg>
            <span>Profile</span>
        </a>
        
        <a href="<?php echo $base_path; ?>bos/change_password.php" class="nav-item <?php echo $current_page == 'change_password' ? 'active' : ''; ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0110 0v4"/>
            </svg>
            <span>Change Password</span>
        </a>
        
        <a href="<?php echo $base_path; ?>logout.php" class="nav-item">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                <polyline points="16 17 21 12 16 7"/>
                <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            <span>Logout</span>
        </a>
    </nav>
</aside>
