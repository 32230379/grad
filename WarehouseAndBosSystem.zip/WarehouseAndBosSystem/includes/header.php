<?php
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<header class="main-header">
    <div class="header-left">
        <button class="menu-toggle" onclick="toggleSidebar()">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="3" y1="12" x2="21" y2="12"/>
                <line x1="3" y1="6" x2="21" y2="6"/>
                <line x1="3" y1="18" x2="21" y2="18"/>
            </svg>
        </button>
        <h1 class="site-title"><?php echo SITE_NAME; ?></h1>
    </div>
    
    <div class="header-right">
        <div class="header-branch">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
            </svg>
            <span><?php echo htmlspecialchars($_SESSION['branch_name'] ?? 'No Branch'); ?></span>
        </div>
        
        <div class="header-alerts" onclick="window.location.href='alerts.php'">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                <path d="M13.73 21a2 2 0 01-3.46 0"/>
            </svg>
            <?php
            $unread_alerts = mysqli_fetch_assoc(
                mysqli_query($conn, "SELECT COUNT(*) as count FROM alerts WHERE is_read = 0")
            )['count'];
            if ($unread_alerts > 0):
            ?>
                <span class="badge-count"><?php echo $unread_alerts; ?></span>
            <?php endif; ?>
        </div>
        
        <div class="header-user">
            <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?></div>
            <div class="user-info">
                <span class="user-name"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                <span class="user-role"><?php echo ucfirst(str_replace('_', ' ', $_SESSION['role'])); ?></span>
            </div>
            <div class="user-dropdown">
                <a href="profile.php">Profile</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>
</header>
