<?php
require_once 'config.php';

echo "<h2>Fixing User Roles</h2>";

// Fix admin user
$admin_update = "UPDATE users SET role = 'admin' WHERE username = 'admin'";
if (mysqli_query($conn, $admin_update)) {
    echo "<p style='color: green;'>✓ Updated admin user role to 'admin'</p>";
} else {
    echo "<p style='color: red;'>✗ Error updating admin: " . mysqli_error($conn) . "</p>";
}

// Fix manager user
$manager_update = "UPDATE users SET role = 'manager' WHERE username = 'manager'";
if (mysqli_query($conn, $manager_update)) {
    echo "<p style='color: green;'>✓ Updated manager user role to 'manager'</p>";
} else {
    echo "<p style='color: red;'>✗ Error updating manager: " . mysqli_error($conn) . "</p>";
}

echo "<hr>";
echo "<h3>Updated Credentials:</h3>";
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Username</th><th>Role</th><th>Password</th></tr>";

$result = mysqli_query($conn, "SELECT username, role FROM users WHERE username IN ('admin', 'manager', 'cashier', 'receiver') ORDER BY username");
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td><strong>" . htmlspecialchars($row['username']) . "</strong></td>";
    echo "<td>" . htmlspecialchars($row['role']) . "</td>";
    echo "<td>admin123</td>";
    echo "</tr>";
}

echo "</table>";

echo "<hr>";
echo "<p><a href='login_new.php'>← Go to Login</a></p>";
?>
