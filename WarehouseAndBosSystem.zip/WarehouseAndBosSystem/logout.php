<?php
session_start();

require_once 'config.php';

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $ip = $_SERVER['REMOTE_ADDR'];
    
    // Log activity
    mysqli_query($conn, "INSERT INTO activity_logs (user_id, action, module, description, ip_address) 
                        VALUES ($user_id, 'Logout', 'Authentication', 'User logged out', '$ip')");
}

// Destroy session
session_destroy();

// Redirect to login
header('Location: login.php');
exit();
?>
