<?php
require_once 'config.php';

echo "<h2>Current Login Credentials</h2>";
echo "<p>Password for all test accounts: <strong>admin123</strong></p>";
echo "<hr>";

$result = mysqli_query($conn, "SELECT user_id, username, role FROM users ORDER BY user_id");

echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Username</th><th>Role</th><th>Password</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td><strong>" . htmlspecialchars($row['username']) . "</strong></td>";
    echo "<td>" . htmlspecialchars($row['role'] ?: 'N/A') . "</td>";
    echo "<td>admin123</td>";
    echo "</tr>";
}

echo "</table>";

echo "<hr>";
echo "<p><strong>Note:</strong> All accounts use the password: <code>admin123</code></p>";
echo "<p>If login is failing, it could be because:</p>";
echo "<ul>";
echo "<li>The role field is empty (NULL) for some users</li>";
echo "<li>The password hash is corrupted</li>";
echo "<li>The login script has an issue</li>";
echo "</ul>";
?>
