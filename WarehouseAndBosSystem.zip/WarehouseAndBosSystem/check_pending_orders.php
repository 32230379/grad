<?php
require_once 'config.php';

echo "<h2>Checking Pending Orders</h2>";

// Check all orders
echo "<h3>All Orders:</h3>";
$result = mysqli_query($conn, "SELECT order_id, order_number, barcode, status FROM order_requests ORDER BY order_id DESC");

if (mysqli_num_rows($result) > 0) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>Order ID</th><th>Order Number</th><th>Barcode</th><th>Status</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['order_id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['order_number']) . "</td>";
        echo "<td>" . htmlspecialchars($row['barcode']) . "</td>";
        echo "<td>" . htmlspecialchars($row['status']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No orders found</p>";
}

echo "<hr>";
echo "<h3>Pending Orders (for receiver):</h3>";
$pending = mysqli_query($conn, "SELECT o.order_id, o.order_number, o.barcode, o.status, u.full_name 
                                FROM order_requests o 
                                JOIN users u ON o.requested_by = u.user_id 
                                WHERE o.status IN ('pending', 'sent')");

if (mysqli_num_rows($pending) > 0) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>Order ID</th><th>Order Number</th><th>Status</th><th>Requested By</th></tr>";
    while ($row = mysqli_fetch_assoc($pending)) {
        echo "<tr>";
        echo "<td>" . $row['order_id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['order_number']) . "</td>";
        echo "<td>" . htmlspecialchars($row['status']) . "</td>";
        echo "<td>" . htmlspecialchars($row['full_name']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>No pending orders found!</p>";
    echo "<p>This is why the receiver dashboard shows no orders to receive.</p>";
}

echo "<hr>";
echo "<p><a href='receiver/dashboard.php'>← Go to Receiver Dashboard</a></p>";
?>
