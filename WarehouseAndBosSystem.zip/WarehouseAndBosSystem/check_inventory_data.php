<?php
require_once 'config.php';
require_once 'functions.php';

requireLogin();
requireManager();

$user = getUserInfo();
$branch_id = $user['branch_id'];

echo "<h2>Inventory Data Check for Branch: $branch_id</h2>";

// Check if branch_inventory table has data
$query = "SELECT 
            bi.inventory_id,
            bi.product_id,
            p.product_name,
            p.product_code,
            bi.quantity,
            bi.on_shelf_quantity,
            bi.shelf_min_level,
            bi.shelf_reorder_level
          FROM branch_inventory bi
          LEFT JOIN products p ON bi.product_id = p.product_id
          WHERE bi.branch_id = ?";

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $branch_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

echo "<table border='1' cellpadding='10'>";
echo "<tr>
        <th>Product ID</th>
        <th>Product Name</th>
        <th>Inventory Qty</th>
        <th>Shelf Qty</th>
        <th>Shelf Min Level</th>
        <th>Status</th>
      </tr>";

$count = 0;
while ($row = mysqli_fetch_assoc($result)) {
    $count++;
    $status = intval($row['quantity']) > 0 ? '✅ CAN TRANSFER' : '❌ NO INVENTORY';
    echo "<tr>
            <td>{$row['product_id']}</td>
            <td>{$row['product_name']}</td>
            <td>{$row['quantity']}</td>
            <td>{$row['on_shelf_quantity']}</td>
            <td>{$row['shelf_min_level']}</td>
            <td>{$status}</td>
          </tr>";
}

echo "</table>";

if ($count == 0) {
    echo "<p style='color: red; font-weight: bold;'>⚠️ NO INVENTORY DATA FOUND!</p>";
    echo "<p>You need to add products to the branch_inventory table first.</p>";
    echo "<p><a href='bos/inventory.php'>Go to Inventory Management</a></p>";
} else {
    echo "<p style='color: green;'>✅ Found $count products in inventory</p>";
}

mysqli_stmt_close($stmt);
?>
