<?php
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

requireLogin();

$user = getUserInfo();
// branch_id removed - single branch system
$user_id = $user['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Create new return
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['items'])) {
        jsonResponse(false, 'No items provided');
    }
    
    $return_date = mysqli_real_escape_string($conn, $data['return_date']);
    $reason = mysqli_real_escape_string($conn, $data['reason']);
    $total_items = count($data['items']);
    
    // Generate return number
    $return_number = generateNumber('RET', 'returns_to_warehouse', 'return_number');
    
    // Begin transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Insert return
        $query = "INSERT INTO returns_to_warehouse (return_number, branch_id, return_date, total_items, reason, created_by, status) 
                  VALUES ('$return_number', $branch_id, '$return_date', $total_items, '$reason', $user_id, 'pending')";
        
        if (!mysqli_query($conn, $query)) {
            throw new Exception('Failed to create return');
        }
        
        $return_id = mysqli_insert_id($conn);
        
        // Insert items and update inventory
        foreach ($data['items'] as $item) {
            $product_id = intval($item['product_id']);
            $batch_number = mysqli_real_escape_string($conn, $item['batch_number']);
            $quantity = intval($item['quantity']);
            $return_reason = mysqli_real_escape_string($conn, $item['return_reason']);
            $condition_notes = mysqli_real_escape_string($conn, $item['condition_notes'] ?? '');
            
            // Verify stock availability
            $check_query = "SELECT quantity FROM branch_inventory 
                           WHERE product_id = $product_id 
                           AND batch_number = '$batch_number'";
            $check_result = mysqli_query($conn, $check_query);
            $stock = mysqli_fetch_assoc($check_result);
            
            if (!$stock || $stock['quantity'] < $quantity) {
                throw new Exception('Insufficient stock for return');
            }
            
            // Insert return item
            $item_query = "INSERT INTO return_items (
                            return_id, product_id, batch_number, quantity,
                            return_reason, condition_notes
                          ) VALUES (
                            $return_id, $product_id, '$batch_number', $quantity,
                            '$return_reason', '$condition_notes'
                          )";
            
            if (!mysqli_query($conn, $item_query)) {
                throw new Exception('Failed to add return item');
            }
            
            // Update inventory (deduct returned items)
            if (!updateInventory( $product_id, $batch_number, $quantity, 'subtract')) {
                throw new Exception('Failed to update inventory');
            }
        }
        
        // Commit transaction
        mysqli_commit($conn);
        
        // Log activity
        logActivity($user_id, 'Create Return', 'Returns', "Created return $return_number");
        
        // Create alert
        createAlert( 'system', 'New Return Created', "Return $return_number created with $total_items items", 'medium');
        
        jsonResponse(true, 'Return created successfully', ['return_id' => $return_id, 'return_number' => $return_number]);
        
    } catch (Exception $e) {
        mysqli_rollback($conn);
        jsonResponse(false, $e->getMessage());
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get return details
    $return_id = intval($_GET['id'] ?? 0);
    
    if ($return_id) {
        $query = "SELECT r.*, u.full_name as created_by_name
                  FROM returns_to_warehouse r
                  JOIN users u ON r.created_by = u.user_id
                  
                  WHERE r.return_id = $return_id ";
        
        $result = mysqli_query($conn, $query);
        
        if ($row = mysqli_fetch_assoc($result)) {
            // Get items
            $items_query = "SELECT ri.*, p.product_name, p.product_code
                           FROM return_items ri
                           JOIN products p ON ri.product_id = p.product_id
                           WHERE ri.return_id = $return_id";
            
            $items_result = mysqli_query($conn, $items_query);
            $items = [];
            
            while ($item = mysqli_fetch_assoc($items_result)) {
                $items[] = $item;
            }
            
            $row['items'] = $items;
            
            jsonResponse(true, 'Return retrieved', $row);
        } else {
            jsonResponse(false, 'Return not found');
        }
    } else {
        jsonResponse(false, 'Invalid return ID');
    }
}
?>
