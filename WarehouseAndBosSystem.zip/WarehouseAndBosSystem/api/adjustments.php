<?php
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

requireLogin();

$user = getUserInfo();
// branch_id removed - single branch system
$user_id = $user['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Create new adjustment
    $data = json_decode(file_get_contents('php://input'), true);
    
    $product_id = intval($data['product_id']);
    $batch_number = mysqli_real_escape_string($conn, $data['batch_number'] ?? '');
    $adjustment_type = mysqli_real_escape_string($conn, $data['adjustment_type']);
    $adjustment_quantity = intval($data['adjustment_quantity']);
    $adjustment_date = mysqli_real_escape_string($conn, $data['adjustment_date']);
    $reason = mysqli_real_escape_string($conn, $data['reason']);
    
    // Get current quantity
    $stock_query = "SELECT quantity FROM branch_inventory 
                    WHERE product_id = $product_id 
                    AND batch_number = '$batch_number'";
    $stock_result = mysqli_query($conn, $stock_query);
    $stock = mysqli_fetch_assoc($stock_result);
    
    if (!$stock) {
        jsonResponse(false, 'Product not found in inventory');
    }
    
    $quantity_before = $stock['quantity'];
    $quantity_after = $quantity_before + $adjustment_quantity;
    
    if ($quantity_after < 0) {
        jsonResponse(false, 'Adjustment would result in negative stock');
    }
    
    // Generate adjustment number
    $adjustment_number = generateNumber('ADJ', 'inventory_adjustments', 'adjustment_number');
    
    // Begin transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Insert adjustment
        $query = "INSERT INTO inventory_adjustments (
                    adjustment_number, branch_id, product_id, batch_number,
                    adjustment_type, quantity_before, adjustment_quantity,
                    quantity_after, reason, adjusted_by, adjustment_date
                  ) VALUES (
                    '$adjustment_number', $branch_id, $product_id, '$batch_number',
                    '$adjustment_type', $quantity_before, $adjustment_quantity,
                    $quantity_after, '$reason', $user_id, '$adjustment_date'
                  )";
        
        if (!mysqli_query($conn, $query)) {
            throw new Exception('Failed to create adjustment');
        }
        
        $adjustment_id = mysqli_insert_id($conn);
        
        // Update inventory
        $operation = $adjustment_quantity > 0 ? 'add' : 'subtract';
        $abs_quantity = abs($adjustment_quantity);
        
        if (!updateInventory( $product_id, $batch_number, $abs_quantity, $operation)) {
            throw new Exception('Failed to update inventory');
        }
        
        // Commit transaction
        mysqli_commit($conn);
        
        // Log activity
        $product_name = mysqli_fetch_assoc(mysqli_query($conn, "SELECT product_name FROM products WHERE product_id = $product_id"))['product_name'];
        logActivity($user_id, 'Inventory Adjustment', 'Adjustments', "Adjusted $product_name by $adjustment_quantity ($adjustment_type)");
        
        // Create alert if significant adjustment
        if (abs($adjustment_quantity) > 10) {
            createAlert( 'system', 'Inventory Adjusted', "Adjustment $adjustment_number created for $product_name", 'low');
        }
        
        jsonResponse(true, 'Adjustment created successfully', ['adjustment_id' => $adjustment_id, 'adjustment_number' => $adjustment_number]);
        
    } catch (Exception $e) {
        mysqli_rollback($conn);
        jsonResponse(false, $e->getMessage());
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get adjustment details
    $adjustment_id = intval($_GET['id'] ?? 0);
    
    if ($adjustment_id) {
        $query = "SELECT a.*, p.product_name, p.product_code, u.full_name as adjusted_by_name
                  FROM inventory_adjustments a
                  JOIN products p ON a.product_id = p.product_id
                  JOIN users u ON a.adjusted_by = u.user_id
                  WHERE a.adjustment_id = $adjustment_id ";
        
        $result = mysqli_query($conn, $query);
        
        if ($row = mysqli_fetch_assoc($result)) {
            jsonResponse(true, 'Adjustment retrieved', $row);
        } else {
            jsonResponse(false, 'Adjustment not found');
        }
    } else {
        jsonResponse(false, 'Invalid adjustment ID');
    }
}
?>
