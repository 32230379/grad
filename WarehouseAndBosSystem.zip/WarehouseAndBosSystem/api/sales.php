<?php
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

requireLogin();
checkRole(['admin', 'branch_manager', 'cashier']);

$user = getUserInfo();
// branch_id removed - single branch system
$user_id = $user['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Create new sale
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['items'])) {
        jsonResponse(false, 'No items in cart');
    }
    
    // Calculate totals
    $subtotal = 0;
    foreach ($data['items'] as $item) {
        $subtotal += $item['unit_price'] * $item['quantity'];
    }
    
    $discount = floatval($data['discount'] ?? 0);
    $tax = 0; // Can be calculated as percentage if needed
    $total = $subtotal - $discount + $tax;
    
    // Generate transaction number
    $transaction_number = generateNumber('TXN', 'sales_transactions', 'transaction_number');
    $sale_date = date('Y-m-d');
    $sale_time = date('H:i:s');
    $payment_method = mysqli_real_escape_string($conn, $data['payment_method']);
    $customer_name = mysqli_real_escape_string($conn, $data['customer_name'] ?? '');
    $customer_phone = mysqli_real_escape_string($conn, $data['customer_phone'] ?? '');
    
    // Begin transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Insert transaction
        $query = "INSERT INTO sales_transactions (
                    transaction_number, branch_id, sale_date, sale_time, cashier_id,
                    customer_name, customer_phone, subtotal, discount, tax, total_amount,
                    payment_method, payment_status
                  ) VALUES (
                    '$transaction_number', $branch_id, '$sale_date', '$sale_time', $user_id,
                    '$customer_name', '$customer_phone', $subtotal, $discount, $tax, $total,
                    '$payment_method', 'paid'
                  )";
        
        if (!mysqli_query($conn, $query)) {
            throw new Exception('Failed to create transaction');
        }
        
        $transaction_id = mysqli_insert_id($conn);
        
        // Insert items and update inventory
        foreach ($data['items'] as $item) {
            $product_id = intval($item['product_id']);
            $batch_number = mysqli_real_escape_string($conn, $item['batch_number']);
            $quantity = intval($item['quantity']);
            $unit_price = floatval($item['unit_price']);
            $item_discount = floatval($item['discount'] ?? 0);
            $item_subtotal = ($unit_price * $quantity) - $item_discount;
            
            // Insert sale item
            $item_query = "INSERT INTO sales_items (
                            transaction_id, product_id, batch_number, quantity,
                            unit_price, discount, subtotal
                          ) VALUES (
                            $transaction_id, $product_id, '$batch_number', $quantity,
                            $unit_price, $item_discount, $item_subtotal
                          )";
            
            if (!mysqli_query($conn, $item_query)) {
                throw new Exception('Failed to add item');
            }
            
            // Update inventory
            if (!updateInventory( $product_id, $batch_number, $quantity, 'subtract')) {
                throw new Exception('Failed to update inventory - insufficient stock');
            }
        }
        
        // Commit transaction
        mysqli_commit($conn);
        
        // Log activity
        logActivity($user_id, 'Complete Sale', 'Sales', "Completed sale $transaction_number - Total: $$total");
        
        // Check low stock after sale
        checkLowStock();
        
        jsonResponse(true, 'Sale completed successfully', [
            'transaction_id' => $transaction_id,
            'transaction_number' => $transaction_number,
            'total' => $total
        ]);
        
    } catch (Exception $e) {
        mysqli_rollback($conn);
        jsonResponse(false, $e->getMessage());
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get transaction details
    $transaction_id = intval($_GET['id'] ?? 0);
    
    if ($transaction_id) {
        $query = "SELECT st.*, u.full_name as cashier_name, b.branch_name
                  FROM sales_transactions st
                  JOIN users u ON st.cashier_id = u.user_id
                  JOIN branches b ON st.branch_id = b.branch_id
                  WHERE st.transaction_id = $transaction_id ";
        
        $result = mysqli_query($conn, $query);
        
        if ($row = mysqli_fetch_assoc($result)) {
            // Get items
            $items_query = "SELECT si.*, p.product_name, p.product_code
                           FROM sales_items si
                           JOIN products p ON si.product_id = p.product_id
                           WHERE si.transaction_id = $transaction_id";
            
            $items_result = mysqli_query($conn, $items_query);
            $items = [];
            
            while ($item = mysqli_fetch_assoc($items_result)) {
                $items[] = $item;
            }
            
            $row['items'] = $items;
            
            jsonResponse(true, 'Transaction retrieved', $row);
        } else {
            jsonResponse(false, 'Transaction not found');
        }
    } else {
        jsonResponse(false, 'Invalid transaction ID');
    }
}
?>
