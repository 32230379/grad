<?php
/**
 * Acknowledge Alert API
 * Marks shelf stock alerts as read/acknowledged by manager
 */

require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

requireLogin();
requireManager();

$user = getUserInfo();
$branch_id = $user['branch_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $alert_id = intval($data['alert_id'] ?? 0);
    $action = $data['action'] ?? 'acknowledge'; // acknowledge or dismiss
    
    if ($alert_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid alert ID']);
        exit();
    }
    
    // Verify alert belongs to user's branch
    $verify_query = "SELECT alert_id FROM shelf_stock_alerts WHERE alert_id = ? AND branch_id = ?";
    $verify_stmt = mysqli_prepare($conn, $verify_query);
    mysqli_stmt_bind_param($verify_stmt, "ii", $alert_id, $branch_id);
    mysqli_stmt_execute($verify_stmt);
    $verify_result = mysqli_stmt_get_result($verify_stmt);
    
    if (mysqli_num_rows($verify_result) == 0) {
        echo json_encode(['success' => false, 'message' => 'Alert not found']);
        exit();
    }
    
    mysqli_stmt_close($verify_stmt);
    
    // Update alert
    if ($action == 'acknowledge') {
        $update_query = "UPDATE shelf_stock_alerts 
                        SET is_read = TRUE, acknowledged_by = ?, acknowledged_at = NOW()
                        WHERE alert_id = ?";
        
        $update_stmt = mysqli_prepare($conn, $update_query);
        $user_id = $user['user_id'];
        mysqli_stmt_bind_param($update_stmt, "ii", $user_id, $alert_id);
        
        if (mysqli_stmt_execute($update_stmt)) {
            logActivity($user['user_id'], 'Alert Acknowledged', 'Alerts', "Alert $alert_id acknowledged");
            echo json_encode(['success' => true, 'message' => 'Alert acknowledged']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update alert']);
        }
        
        mysqli_stmt_close($update_stmt);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} else if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    // Acknowledge multiple alerts
    $data = json_decode(file_get_contents('php://input'), true);
    
    $alert_ids = $data['alert_ids'] ?? [];
    
    if (empty($alert_ids)) {
        echo json_encode(['success' => false, 'message' => 'No alert IDs provided']);
        exit();
    }
    
    $placeholders = implode(',', array_fill(0, count($alert_ids), '?'));
    $update_query = "UPDATE shelf_stock_alerts 
                    SET is_read = TRUE, acknowledged_by = ?, acknowledged_at = NOW()
                    WHERE alert_id IN ($placeholders) AND branch_id = ?";
    
    $update_stmt = mysqli_prepare($conn, $update_query);
    
    // Build bind parameters
    $user_id = $user['user_id'];
    $types = 'i' . str_repeat('i', count($alert_ids)) . 'i';
    $params = array_merge([$user_id], $alert_ids, [$branch_id]);
    
    $update_stmt->bind_param($types, ...$params);
    
    if (mysqli_stmt_execute($update_stmt)) {
        logActivity($user['user_id'], 'Alerts Acknowledged', 'Alerts', "Acknowledged " . count($alert_ids) . " alerts");
        echo json_encode(['success' => true, 'message' => 'Alerts acknowledged']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update alerts']);
    }
    
    mysqli_stmt_close($update_stmt);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
