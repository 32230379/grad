<?php
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

requireLogin();

$user = getUserInfo();
// branch_id removed - single branch system
$user_id = $user['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if canceling
    if (isset($_GET['action']) && $_GET['action'] == 'cancel') {
        $request_id = intval($_GET['id']);
        
        $query = "UPDATE restock_requests SET status = 'cancelled' 
                  WHERE request_id = $request_id  
                  AND status IN ('draft', 'pending')";
        
        if (mysqli_query($conn, $query)) {
            logActivity($user_id, 'Cancel Request', 'Restock', "Cancelled restock request #$request_id");
            jsonResponse(true, 'Request cancelled successfully');
        } else {
            jsonResponse(false, 'Failed to cancel request');
        }
        exit;
    }
    
    // Create new restock request
    $data = json_decode(file_get_contents('php://input'), true);
    
    $required_date = mysqli_real_escape_string($conn, $data['required_date'] ?? '');
    $priority = mysqli_real_escape_string($conn, $data['priority']);
    $notes = mysqli_real_escape_string($conn, $data['notes'] ?? '');
    $status = mysqli_real_escape_string($conn, $data['status']);
    
    // Validate items
    if (empty($data['items'])) {
        jsonResponse(false, 'No items provided');
    }
    
    // Generate request number
    $request_number = generateNumber('RQ', 'restock_requests', 'request_number');
    $request_date = date('Y-m-d');
    $total_items = count($data['items']);
    
    // Begin transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Insert request
        $query = "INSERT INTO restock_requests (request_number, branch_id, requested_by, request_date, required_date, status, priority, total_items, notes) 
                  VALUES ('$request_number', $branch_id, $user_id, '$request_date', '$required_date', '$status', '$priority', $total_items, '$notes')";
        
        if (!mysqli_query($conn, $query)) {
            throw new Exception('Failed to create request');
        }
        
        $request_id = mysqli_insert_id($conn);
        
        // Insert items
        foreach ($data['items'] as $item) {
            $product_id = intval($item['product_id']);
            $quantity = intval($item['quantity']);
            $reason = mysqli_real_escape_string($conn, $item['reason'] ?? '');
            
            // Get current stock
            $stock_query = "SELECT SUM(quantity) as current_stock 
                           FROM branch_inventory 
                           WHERE product_id = $product_id";
            $stock_result = mysqli_query($conn, $stock_query);
            $current_stock = mysqli_fetch_assoc($stock_result)['current_stock'] ?? 0;
            
            $item_query = "INSERT INTO restock_request_items (request_id, product_id, requested_quantity, current_stock, reason) 
                          VALUES ($request_id, $product_id, $quantity, $current_stock, '$reason')";
            
            if (!mysqli_query($conn, $item_query)) {
                throw new Exception('Failed to add item');
            }
        }
        
        // Commit transaction
        mysqli_commit($conn);
        
        // Log activity
        logActivity($user_id, 'Create Restock Request', 'Restock', "Created restock request $request_number");
        
        // Create alert if pending
        if ($status == 'pending') {
            createAlert( 'system', 'New Restock Request', "New restock request $request_number submitted", 'medium');
        }
        
        jsonResponse(true, 'Restock request created successfully', ['request_id' => $request_id, 'request_number' => $request_number]);
        
    } catch (Exception $e) {
        mysqli_rollback($conn);
        jsonResponse(false, $e->getMessage());
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get request details
    $request_id = intval($_GET['id'] ?? 0);
    
    if ($request_id) {
        $query = "SELECT r.*, u.full_name as requested_by_name
                  FROM restock_requests r
                  JOIN users u ON r.requested_by = u.user_id
                  
                  WHERE r.request_id = $request_id ";
        
        $result = mysqli_query($conn, $query);
        
        if ($row = mysqli_fetch_assoc($result)) {
            // Get items
            $items_query = "SELECT ri.*, p.product_name, p.product_code, p.unit
                           FROM restock_request_items ri
                           JOIN products p ON ri.product_id = p.product_id
                           WHERE ri.request_id = $request_id";
            
            $items_result = mysqli_query($conn, $items_query);
            $items = [];
            
            while ($item = mysqli_fetch_assoc($items_result)) {
                $items[] = $item;
            }
            
            $row['items'] = $items;
            
            jsonResponse(true, 'Request retrieved', $row);
        } else {
            jsonResponse(false, 'Request not found');
        }
    } else {
        jsonResponse(false, 'Invalid request ID');
    }
}
?>
