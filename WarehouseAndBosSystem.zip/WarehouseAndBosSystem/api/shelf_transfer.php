<?php
/**
 * Shelf Transfer API
 * Handles transfers of products from inventory (back stock) to shelf (customer area)
 */

// Prevent any output before JSON
ob_start();

require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// Clear any buffered output
ob_end_clean();

requireLogin();
requireManager();

$user = getUserInfo();
$branch_id = $user['branch_id'];

// =============================================
// GET - Retrieve shelf stock status
// =============================================

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $action = $_GET['action'] ?? '';
    
    if ($action == 'get_status') {
        // Get shelf stock status for a product
        $product_id = intval($_GET['product_id'] ?? 0);
        
        if ($product_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
            exit();
        }
        
        $query = "SELECT 
                    bi.inventory_id,
                    bi.product_id,
                    p.product_name,
                    p.product_code,
                    bi.quantity as inventory_qty,
                    bi.on_shelf_quantity as shelf_qty,
                    bi.shelf_min_level,
                    bi.shelf_reorder_level,
                    p.reorder_level as inventory_reorder_level,
                    p.min_stock_level as inventory_min_level,
                    bi.batch_number,
                    bi.location
                  FROM branch_inventory bi
                  JOIN products p ON bi.product_id = p.product_id
                  WHERE bi.branch_id = ? AND bi.product_id = ?";
        
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "ii", $branch_id, $product_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if ($row = mysqli_fetch_assoc($result)) {
            echo json_encode([
                'success' => true,
                'data' => $row
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Product not found']);
        }
        mysqli_stmt_close($stmt);
        
    } else if ($action == 'get_all') {
        // Get all shelf stock status for branch
        $query = "SELECT 
                    bi.inventory_id,
                    bi.product_id,
                    p.product_name,
                    p.product_code,
                    bi.quantity as inventory_qty,
                    bi.on_shelf_quantity as shelf_qty,
                    (bi.quantity + bi.on_shelf_quantity) as total_qty,
                    bi.shelf_min_level,
                    bi.shelf_reorder_level,
                    p.reorder_level as inventory_reorder_level,
                    p.min_stock_level as inventory_min_level,
                    CASE 
                        WHEN bi.on_shelf_quantity <= bi.shelf_min_level THEN 'CRITICAL'
                        WHEN bi.on_shelf_quantity <= bi.shelf_reorder_level THEN 'LOW'
                        ELSE 'OK'
                    END as shelf_status,
                    CASE 
                        WHEN bi.quantity <= p.min_stock_level THEN 'CRITICAL'
                        WHEN bi.quantity <= p.reorder_level THEN 'LOW'
                        ELSE 'OK'
                    END as inventory_status
                  FROM branch_inventory bi
                  JOIN products p ON bi.product_id = p.product_id
                  WHERE bi.branch_id = ?
                  ORDER BY bi.on_shelf_quantity ASC";
        
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $branch_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        $items = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $items[] = $row;
        }
        
        echo json_encode([
            'success' => true,
            'data' => $items
        ]);
        mysqli_stmt_close($stmt);
        
    } else if ($action == 'get_transfers') {
        // Get transfer history
        $product_id = intval($_GET['product_id'] ?? 0);
        $limit = intval($_GET['limit'] ?? 50);
        
        $query = "SELECT 
                    st.transfer_id,
                    st.product_id,
                    p.product_name,
                    st.quantity_transferred,
                    st.from_location,
                    st.to_location,
                    u.full_name as transferred_by,
                    st.transfer_date,
                    st.notes
                  FROM shelf_transfers st
                  JOIN products p ON st.product_id = p.product_id
                  JOIN users u ON st.transferred_by = u.user_id
                  WHERE st.branch_id = ?";
        
        if ($product_id > 0) {
            $query .= " AND st.product_id = ?";
        }
        
        $query .= " ORDER BY st.transfer_date DESC LIMIT ?";
        
        if ($product_id > 0) {
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "iii", $branch_id, $product_id, $limit);
        } else {
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "ii", $branch_id, $limit);
        }
        
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        $transfers = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $transfers[] = $row;
        }
        
        echo json_encode([
            'success' => true,
            'data' => $transfers
        ]);
        mysqli_stmt_close($stmt);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
}

// =============================================
// POST - Create shelf transfer
// =============================================

else if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $product_id = intval($data['product_id'] ?? 0);
    $quantity = intval($data['quantity'] ?? 0);
    $notes = $data['notes'] ?? '';
    
    if ($product_id <= 0 || $quantity <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid product or quantity']);
        exit();
    }
    
    try {
        // Get current inventory
        $check_query = "SELECT inventory_id, quantity, on_shelf_quantity 
                       FROM branch_inventory 
                       WHERE branch_id = ? AND product_id = ?";
        
        $stmt = mysqli_prepare($conn, $check_query);
        if (!$stmt) {
            throw new Exception('Database error: ' . mysqli_error($conn));
        }
        
        mysqli_stmt_bind_param($stmt, "ii", $branch_id, $product_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if (!$row = mysqli_fetch_assoc($result)) {
            mysqli_stmt_close($stmt);
            throw new Exception('Product not found in inventory');
        }
        
        $inventory_id = $row['inventory_id'];
        $current_inventory = intval($row['quantity']);
        $current_shelf = intval($row['on_shelf_quantity']);
        
        mysqli_stmt_close($stmt);
        
        // Check if enough inventory
        if ($current_inventory < $quantity) {
            throw new Exception("Insufficient inventory. Available: $current_inventory, Requested: $quantity");
        }
        
        // Update inventory quantities
        $new_inventory = $current_inventory - $quantity;
        $new_shelf = $current_shelf + $quantity;
        
        $update_query = "UPDATE branch_inventory 
                        SET quantity = ?, on_shelf_quantity = ?
                        WHERE inventory_id = ?";
        
        $stmt = mysqli_prepare($conn, $update_query);
        if (!$stmt) {
            throw new Exception('Database error: ' . mysqli_error($conn));
        }
        
        mysqli_stmt_bind_param($stmt, "iii", $new_inventory, $new_shelf, $inventory_id);
        
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception('Failed to update inventory: ' . mysqli_error($conn));
        }
        
        mysqli_stmt_close($stmt);
        
        // Try to record transfer if table exists
        $transfer_query = "INSERT INTO shelf_transfers 
                          (branch_id, product_id, quantity_transferred, from_location, to_location, transferred_by, notes)
                          VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $to_location = 'SHELF';
        $from_location = 'INVENTORY';
        $transferred_by = $user['user_id'];
        
        $stmt = mysqli_prepare($conn, $transfer_query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "iisssss", $branch_id, $product_id, $quantity, $from_location, $to_location, $transferred_by, $notes);
            mysqli_stmt_execute($stmt);
            $transfer_id = mysqli_insert_id($conn);
            mysqli_stmt_close($stmt);
        }
        
        // Log activity
        logActivity($user['user_id'], 'Shelf Transfer', 'Inventory', "Transferred $quantity units of product $product_id to shelf");
        
        echo json_encode([
            'success' => true,
            'message' => 'Transfer completed successfully',
            'new_inventory_qty' => $new_inventory,
            'new_shelf_qty' => $new_shelf
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

// Ensure output is clean
ob_end_flush();
?>
