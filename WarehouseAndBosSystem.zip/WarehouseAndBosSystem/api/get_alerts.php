<?php
/**
 * Get Alerts API
 * Retrieves shelf stock and inventory alerts for branch managers
 */

require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

requireLogin();
requireManager();

$user = getUserInfo();
$branch_id = $user['branch_id'];

$type = $_GET['type'] ?? 'all'; // all, shelf, inventory, unread
$limit = intval($_GET['limit'] ?? 20);

$query = "SELECT 
            ssa.alert_id,
            ssa.product_id,
            p.product_name,
            p.product_code,
            ssa.alert_type,
            ssa.priority,
            ssa.title,
            ssa.message,
            ssa.current_shelf_qty,
            ssa.current_inventory_qty,
            ssa.shelf_min_level,
            ssa.inventory_min_level,
            ssa.is_read,
            ssa.created_at,
            u.full_name as acknowledged_by
          FROM shelf_stock_alerts ssa
          JOIN products p ON ssa.product_id = p.product_id
          LEFT JOIN users u ON ssa.acknowledged_by = u.user_id
          WHERE ssa.branch_id = ?";

if ($type == 'unread') {
    $query .= " AND ssa.is_read = FALSE";
} else if ($type == 'shelf') {
    $query .= " AND ssa.alert_type IN ('shelf_low_stock', 'shelf_critical')";
} else if ($type == 'inventory') {
    $query .= " AND ssa.alert_type IN ('inventory_low_stock', 'inventory_critical')";
}

$query .= " ORDER BY 
            CASE 
                WHEN ssa.priority = 'critical' THEN 1
                WHEN ssa.priority = 'high' THEN 2
                WHEN ssa.priority = 'medium' THEN 3
                ELSE 4
            END,
            ssa.created_at DESC
          LIMIT ?";

$stmt = mysqli_prepare($conn, $query);
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . mysqli_error($conn)]);
    exit();
}

mysqli_stmt_bind_param($stmt, "ii", $branch_id, $limit);

if (!mysqli_stmt_execute($stmt)) {
    echo json_encode(['success' => false, 'message' => 'Query failed: ' . mysqli_error($conn)]);
    exit();
}

$result = mysqli_stmt_get_result($stmt);

$alerts = [];
while ($row = mysqli_fetch_assoc($result)) {
    $alerts[] = $row;
}

mysqli_stmt_close($stmt);

// Get summary counts
$summary_query = "SELECT 
                    COUNT(CASE WHEN is_read = FALSE THEN 1 END) as unread_count,
                    COUNT(CASE WHEN alert_type IN ('shelf_low_stock', 'shelf_critical') THEN 1 END) as shelf_alerts,
                    COUNT(CASE WHEN alert_type IN ('inventory_low_stock', 'inventory_critical') THEN 1 END) as inventory_alerts,
                    COUNT(CASE WHEN priority = 'critical' THEN 1 END) as critical_count
                  FROM shelf_stock_alerts
                  WHERE branch_id = ?";

$summary_stmt = mysqli_prepare($conn, $summary_query);
mysqli_stmt_bind_param($summary_stmt, "i", $branch_id);
mysqli_stmt_execute($summary_stmt);
$summary_result = mysqli_stmt_get_result($summary_stmt);
$summary = mysqli_fetch_assoc($summary_result);
mysqli_stmt_close($summary_stmt);

echo json_encode([
    'success' => true,
    'data' => $alerts,
    'summary' => $summary
]);
?>
