<?php
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

requireLogin();

$user = getUserInfo();
// branch_id removed - single branch system

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Create new shipment
    $data = json_decode(file_get_contents('php://input'), true);
    
    $expected_delivery_date = mysqli_real_escape_string($conn, $data['expected_delivery_date']);
    $notes = mysqli_real_escape_string($conn, $data['notes'] ?? '');
    $user_id = $user['user_id'];
    
    // Generate shipment number
    $shipment_number = generateNumber('SH', 'shipments', 'shipment_number');
    $shipment_date = date('Y-m-d');
    
    // Insert shipment
    $query = "INSERT INTO shipments (shipment_number, branch_id, shipment_date, expected_delivery_date, notes, created_by, status) 
              VALUES ('$shipment_number', $branch_id, '$shipment_date', '$expected_delivery_date', '$notes', $user_id, 'pending')";
    
    if (mysqli_query($conn, $query)) {
        $shipment_id = mysqli_insert_id($conn);
        
        // Log activity
        logActivity($user_id, 'Create Shipment', 'Receiving', "Created shipment $shipment_number");
        
        jsonResponse(true, 'Shipment created successfully', ['shipment_id' => $shipment_id, 'shipment_number' => $shipment_number]);
    } else {
        jsonResponse(false, 'Failed to create shipment: ' . mysqli_error($conn));
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    // Update shipment
    $data = json_decode(file_get_contents('php://input'), true);
    $shipment_id = intval($data['shipment_id']);
    
    $updates = [];
    if (isset($data['status'])) {
        $status = mysqli_real_escape_string($conn, $data['status']);
        $updates[] = "status = '$status'";
        
        if ($status == 'delivered') {
            $updates[] = "actual_delivery_date = CURDATE()";
        }
    }
    
    if (isset($data['received_by'])) {
        $updates[] = "received_by = " . intval($data['received_by']);
    }
    
    if (!empty($updates)) {
        $query = "UPDATE shipments SET " . implode(', ', $updates) . " WHERE shipment_id = $shipment_id ";
        
        if (mysqli_query($conn, $query)) {
            logActivity($user['user_id'], 'Update Shipment', 'Receiving', "Updated shipment #$shipment_id");
            jsonResponse(true, 'Shipment updated successfully');
        } else {
            jsonResponse(false, 'Failed to update shipment');
        }
    } else {
        jsonResponse(false, 'No updates provided');
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get shipment details
    $shipment_id = intval($_GET['id'] ?? 0);
    
    if ($shipment_id) {
        $query = "SELECT s.*, u.full_name as created_by_name
                  FROM shipments s
                  LEFT JOIN users u ON s.created_by = u.user_id
                  WHERE s.shipment_id = $shipment_id ";
        
        $result = mysqli_query($conn, $query);
        
        if ($row = mysqli_fetch_assoc($result)) {
            // Get items
            $items_query = "SELECT si.*, p.product_name, p.product_code
                           FROM shipment_items si
                           JOIN products p ON si.product_id = p.product_id
                           WHERE si.shipment_id = $shipment_id";
            
            $items_result = mysqli_query($conn, $items_query);
            $items = [];
            
            while ($item = mysqli_fetch_assoc($items_result)) {
                $items[] = $item;
            }
            
            $row['items'] = $items;
            
            jsonResponse(true, 'Shipment retrieved', $row);
        } else {
            jsonResponse(false, 'Shipment not found');
        }
    } else {
        jsonResponse(false, 'Invalid shipment ID');
    }
}
?>
