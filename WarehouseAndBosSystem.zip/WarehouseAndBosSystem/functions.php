<?php
require_once 'config.php';

// =============================================
// AUTHENTICATION FUNCTIONS
// =============================================

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

function checkRole($allowed_roles) {
    if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], $allowed_roles)) {
        header('HTTP/1.0 403 Forbidden');
        echo json_encode(['success' => false, 'message' => 'Access denied']);
        exit();
    }
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
}

function isManager() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'manager';
}

function isCashier() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'cashier';
}

function isReceiver() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'receiver';
}

function requireReceiver() {
    if (!isReceiver()) {
        header('HTTP/1.0 403 Forbidden');
        echo json_encode(['success' => false, 'message' => 'Receiver access required']);
        exit();
    }
}

function requireAdmin() {
    if (!isAdmin()) {
        header('HTTP/1.0 403 Forbidden');
        echo json_encode(['success' => false, 'message' => 'Admin access required']);
        exit();
    }
}

function requireManager() {
    if (!isManager() && !isAdmin()) {
        header('HTTP/1.0 403 Forbidden');
        echo json_encode(['success' => false, 'message' => 'Manager access required']);
        exit();
    }
}

function requireCashier() {
    if (!isCashier() && !isAdmin()) {
        header('HTTP/1.0 403 Forbidden');
        echo json_encode(['success' => false, 'message' => 'Cashier access required']);
        exit();
    }
}

function requireCashierOrManager() {
    if (!isCashier() && !isManager() && !isAdmin()) {
        header('HTTP/1.0 403 Forbidden');
        echo json_encode(['success' => false, 'message' => 'Access required']);
        exit();
    }
}

function getUserInfo() {
    if (isLoggedIn()) {
        return [
            'user_id' => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'full_name' => $_SESSION['full_name'],
            'role' => $_SESSION['role'],
            'branch_id' => $_SESSION['branch_id']
        ];
    }
    return null;
}

function logActivity($user_id, $action, $module, $description = '') {
    global $conn;
    $ip_address = $_SERVER['REMOTE_ADDR'];
    
    $query = "INSERT INTO activity_logs (user_id, action, module, description, ip_address) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "issss", $user_id, $action, $module, $description, $ip_address);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

function auditLog($user_id, $action, $description = '', $old_values = null, $new_values = null) {
    global $conn;
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    $old_json = $old_values ? json_encode($old_values) : null;
    $new_json = $new_values ? json_encode($new_values) : null;
    
    $query = "INSERT INTO user_audit_log (user_id, action, description, old_values, new_values, ip_address, user_agent) 
              VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "issssss", $user_id, $action, $description, $old_json, $new_json, $ip_address, $user_agent);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

// =============================================
// UTILITY FUNCTIONS
// =============================================

function generateNumber($prefix, $table, $column) {
    global $conn;
    $year = date('Y');
    $month = date('m');
    
    $query = "SELECT MAX(CAST(SUBSTRING($column, -5) AS UNSIGNED)) as max_num 
              FROM $table 
              WHERE $column LIKE '$prefix-$year$month-%'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    
    $next_num = ($row['max_num'] ?? 0) + 1;
    return $prefix . '-' . $year . $month . '-' . str_pad($next_num, 5, '0', STR_PAD_LEFT);
}

function jsonResponse($success, $message = '', $data = null) {
    header('Content-Type: application/json');
    $response = ['success' => $success, 'message' => $message];
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response);
    exit();
}

function sanitizeInput($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($conn, $data);
}

function formatDate($date) {
    return date('Y-m-d', strtotime($date));
}

function formatDateTime($datetime) {
    return date('Y-m-d H:i:s', strtotime($datetime));
}

function formatMoney($amount) {
    return number_format($amount, 2);
}

// =============================================
// ALERT FUNCTIONS
// =============================================

function createAlert($alert_type, $title, $message, $priority = 'medium', $product_id = null) {
    global $conn;
    
    $stmt = $conn->prepare("INSERT INTO alerts (alert_type, priority, product_id, title, message) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiss", $alert_type, $priority, $product_id, $title, $message);
    $result = $stmt->execute();
    $stmt->close();
    
    return $result;
}

function createShelfAlert($branch_id, $alert_type, $title, $message, $priority = 'medium', $product_id = null) {
    global $conn;
    
    // Check if alert already exists for this product and type to avoid duplicates
    $check_query = "SELECT alert_id FROM shelf_stock_alerts 
                   WHERE branch_id = ? AND product_id = ? AND alert_type = ? AND is_read = FALSE
                   AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)";
    
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("iis", $branch_id, $product_id, $alert_type);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    // Only create alert if one doesn't already exist in the last hour
    if ($check_result->num_rows == 0) {
        $stmt = $conn->prepare("INSERT INTO shelf_stock_alerts (branch_id, product_id, alert_type, priority, title, message) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iissss", $branch_id, $product_id, $alert_type, $priority, $title, $message);
        $result = $stmt->execute();
        $stmt->close();
        return $result;
    }
    
    $check_stmt->close();
    return false;
}

function checkLowStock() {
    global $conn;
    
    // Check inventory stock levels
    $query = "SELECT p.product_id, p.product_name, bi.quantity as inventory_qty, p.reorder_level, p.min_stock_level, bi.branch_id
              FROM branch_inventory bi
              JOIN products p ON bi.product_id = p.product_id
              WHERE bi.quantity <= p.min_stock_level AND p.is_active = TRUE";
    
    $result = mysqli_query($conn, $query);
    
    while ($row = mysqli_fetch_assoc($result)) {
        $alert_type = $row['inventory_qty'] <= 0 ? 'inventory_critical' : 'inventory_low_stock';
        $priority = $row['inventory_qty'] <= 0 ? 'critical' : 'high';
        
        createShelfAlert(
            $row['branch_id'],
            $alert_type,
            "Low Inventory Stock Alert",
            "Product {$row['product_name']} inventory is below minimum level. Current: {$row['inventory_qty']}, Min Level: {$row['min_stock_level']}",
            $priority,
            $row['product_id']
        );
    }
}

function checkLowShelfStock() {
    global $conn;
    
    // Check shelf stock levels
    $query = "SELECT p.product_id, p.product_name, bi.on_shelf_quantity as shelf_qty, bi.shelf_min_level, bi.shelf_reorder_level, bi.branch_id
              FROM branch_inventory bi
              JOIN products p ON bi.product_id = p.product_id
              WHERE bi.on_shelf_quantity <= bi.shelf_min_level AND p.is_active = TRUE";
    
    $result = mysqli_query($conn, $query);
    
    while ($row = mysqli_fetch_assoc($result)) {
        $alert_type = $row['shelf_qty'] <= 0 ? 'shelf_critical' : 'shelf_low_stock';
        $priority = $row['shelf_qty'] <= 0 ? 'critical' : 'high';
        
        createShelfAlert(
            $row['branch_id'],
            $alert_type,
            "Low Shelf Stock Alert",
            "Product {$row['product_name']} shelf stock is below minimum level. Current: {$row['shelf_qty']}, Min Level: {$row['shelf_min_level']}. Please refill from inventory.",
            $priority,
            $row['product_id']
        );
    }
}

function checkExpiringItems() {
    global $conn;
    
    $query = "SELECT bi.inventory_id, p.product_id, p.product_name, bi.batch_number, bi.expiry_date, bi.quantity
              FROM branch_inventory bi
              JOIN products p ON bi.product_id = p.product_id
              WHERE bi.expiry_date IS NOT NULL
              AND bi.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
              AND bi.quantity > 0";
    
    $result = mysqli_query($conn, $query);
    
    while ($row = mysqli_fetch_assoc($result)) {
        $days_left = round((strtotime($row['expiry_date']) - time()) / (60 * 60 * 24));
        $priority = $days_left <= 7 ? 'critical' : 'high';
        
        createAlert(
            'expiry_warning',
            'Expiry Warning',
            "Product {$row['product_name']} (Batch: {$row['batch_number']}) expires in {$days_left} days",
            $priority,
            $row['product_id']
        );
    }
}

// =============================================
// INVENTORY FUNCTIONS
// =============================================

function updateInventory($product_id, $batch_number, $quantity, $operation = 'add') {
    global $conn;
    
    // Check if inventory record exists
    $check_query = "SELECT inventory_id, quantity FROM branch_inventory 
                    WHERE product_id = $product_id 
                    AND batch_number = '$batch_number'";
    $result = mysqli_query($conn, $check_query);
    
    if (mysqli_num_rows($result) > 0) {
        // Update existing record
        $row = mysqli_fetch_assoc($result);
        $new_quantity = $operation == 'add' ? ($row['quantity'] + $quantity) : ($row['quantity'] - $quantity);
        
        if ($new_quantity < 0) {
            return false; // Insufficient stock
        }
        
        $update_query = "UPDATE branch_inventory SET quantity = $new_quantity WHERE inventory_id = {$row['inventory_id']}";
        return mysqli_query($conn, $update_query);
    } else {
        // Insert new record (only for add operation)
        if ($operation == 'add') {
            $insert_query = "INSERT INTO branch_inventory (product_id, batch_number, quantity) 
                            VALUES ($product_id, '$batch_number', $quantity)";
            return mysqli_query($conn, $insert_query);
        }
        return false;
    }
}

// =============================================
// REPORTING FUNCTIONS
// =============================================

function getDashboardStats() {
    global $conn;
    
    $stats = [];
    
    // Total products
    $result = mysqli_query($conn, "SELECT COUNT(DISTINCT product_id) as total FROM branch_inventory");
    $stats['total_products'] = mysqli_fetch_assoc($result)['total'];
    
    // Low stock items
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM v_low_stock_items");
    $stats['low_stock_items'] = mysqli_fetch_assoc($result)['total'];
    
    // Expiring items (30 days)
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM v_expiring_items");
    $stats['expiring_items'] = mysqli_fetch_assoc($result)['total'];
    
    // Pending shipments FROM warehouse
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM incoming_shipments WHERE status IN ('pending', 'in_transit')");
    $stats['pending_shipments'] = mysqli_fetch_assoc($result)['total'];
    
    // Pending restock requests TO warehouse
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM restock_requests WHERE status = 'pending'");
    $stats['pending_requests'] = mysqli_fetch_assoc($result)['total'];
    
    // Today's sales
    $today = date('Y-m-d');
    $result = mysqli_query($conn, "SELECT COALESCE(SUM(total_amount), 0) as total FROM sales_transactions WHERE sale_date = '$today'");
    $stats['today_sales'] = mysqli_fetch_assoc($result)['total'];
    
    // Unread alerts
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM alerts WHERE is_read = 0");
    $stats['unread_alerts'] = mysqli_fetch_assoc($result)['total'];
    
    return $stats;
}
?>
