<?php
require_once 'config.php';

echo "Users table structure:\n";
$result = mysqli_query($conn, "DESCRIBE users");
while($row = mysqli_fetch_assoc($result)) {
    echo $row['Field'] . " - " . $row['Type'] . " - " . ($row['Null'] == 'YES' ? 'NULL' : 'NOT NULL') . "\n";
}

echo "\n\nChecking role column specifically:\n";
$result = mysqli_query($conn, "SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='users' AND COLUMN_NAME='role'");
$col = mysqli_fetch_assoc($result);
echo "Role column type: " . $col['COLUMN_TYPE'] . "\n";

echo "\n\nTrying direct SQL update:\n";
$test = mysqli_query($conn, "UPDATE users SET role = 'manager' WHERE user_id = 5");
if ($test) {
    echo "Update executed\n";
} else {
    echo "Update failed: " . mysqli_error($conn) . "\n";
}

echo "\n\nFinal check:\n";
$result = mysqli_query($conn, "SELECT user_id, username, role FROM users WHERE user_id = 5");
$row = mysqli_fetch_assoc($result);
echo "User 5: username=" . $row['username'] . ", role=[" . $row['role'] . "]\n";
?>
