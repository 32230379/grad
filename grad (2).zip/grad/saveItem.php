<?php
include "db_connect.php";

$message = "";

// Add minimum_quantity column if it doesn't exist
$check_column = mysqli_query($conn, "SHOW COLUMNS FROM adddesc LIKE 'minimum_quantity'");
if (mysqli_num_rows($check_column) == 0) {
    mysqli_query($conn, "ALTER TABLE adddesc ADD COLUMN minimum_quantity int(11) DEFAULT 20 AFTER description");
}

if (isset($_POST['save'])) {
    $barcode = mysqli_real_escape_string($conn, $_POST['barcode']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $minimum_quantity = intval($_POST['minimum_quantity'] ?? 20);

    // تحقق إذا الكود موجود بالفعل
    $check = mysqli_query($conn, "SELECT * FROM adddesc WHERE barcode='$barcode'");
    if (mysqli_num_rows($check) > 0) {
        $message = "❌ This item already exists.";
    } else {
        $sql = "INSERT INTO adddesc (barcode, name, description, minimum_quantity) VALUES ('$barcode', '$name', '$description', $minimum_quantity)";
        if (mysqli_query($conn, $sql)) {
            $message = "✅ Item saved successfully.";
        } else {
            $message = "❌ Database error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Item Description</title>
<style>
body { font-family: Arial; background: linear-gradient(135deg, #f5f9ff 0%, #e8f4fd 100%); }
form { background: #fff; padding: 25px; border-radius: 10px; box-shadow: 0 0 10px #ccc; width: 300px; margin: 20px auto; }
h2 { text-align: center; color: #333; }
input, textarea, button { width: 100%; padding: 8px; margin: 6px 0; border: 1px solid #ccc; border-radius: 5px; }
button { background: #007bff; color: white; cursor: pointer; border: none; }
button:hover { background: #0056b3; }
.message { text-align: center; font-weight: bold; margin-top: 10px; }
</style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <div class="main-content">
<form method="POST">
    <h2>Add Item</h2>
    <input type="text" name="barcode" placeholder="Item Barcode" required>
    <input type="text" name="name" placeholder="Item Name" required>
    <textarea name="description" placeholder="Description" required></textarea>
    <input type="number" name="minimum_quantity" placeholder="Minimum Quantity (Reorder Level)" value="20" min="1" required>
    <button type="submit" name="save">Save</button>
    <?php if($message): ?>
        <div class="message"><?= $message ?></div>
    <?php endif; ?>
</form>
        </div>
    </div>
</body>
</html>