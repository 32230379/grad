<?php
session_start();
include 'db_connect.php';

// Check if zone tracking columns exist, if not add them
$check_completed_zones = $conn->query("SHOW COLUMNS FROM lowering_orders LIKE 'completed_zones'");
if ($check_completed_zones->num_rows == 0) {
    $conn->query("ALTER TABLE `lowering_orders` ADD COLUMN `completed_zones` TEXT DEFAULT NULL COMMENT 'Comma-separated list of completed zones (e.g., A,B,C)' AFTER `created_by`");
}
$check_assigned_user = $conn->query("SHOW COLUMNS FROM lowering_orders LIKE 'assigned_user'");
if ($check_assigned_user->num_rows == 0) {
    $conn->query("ALTER TABLE `lowering_orders` ADD COLUMN `assigned_user` VARCHAR(100) DEFAULT NULL COMMENT 'Username assigned to this zone' AFTER `completed_zones`");
}
$check_assigned_zone = $conn->query("SHOW COLUMNS FROM lowering_orders LIKE 'assigned_zone'");
if ($check_assigned_zone->num_rows == 0) {
    $conn->query("ALTER TABLE `lowering_orders` ADD COLUMN `assigned_zone` VARCHAR(10) DEFAULT NULL COMMENT 'Zone assigned to user' AFTER `assigned_user`");
}

// Get all lowering orders
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'pending';
$query = "SELECT lo.*, 
                 COALESCE(ad.description, ad.name, lo.item_barcode) as item_description,
                 CASE 
                     WHEN lo.completed_zones IS NULL OR lo.completed_zones = '' THEN ''
                     ELSE lo.completed_zones
                 END as completed_zones_list
          FROM lowering_orders lo
          LEFT JOIN adddesc ad ON lo.item_barcode = ad.barcode";
          
if ($status_filter !== 'all') {
    $query .= " WHERE lo.status = ?";
    $query .= " ORDER BY lo.priority ASC, lo.created_at ASC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $status_filter);
} else {
    $query .= " ORDER BY lo.priority ASC, lo.created_at ASC";
    $stmt = $conn->prepare($query);
}

$stmt->execute();
$orders_result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lowering Orders Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f9ff 0%, #e8f4fd 100%);
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 20px;
        }
        h1 {
            color: #2c3e50;
            margin-bottom: 20px;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
        }
        .filters {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .filters a {
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 5px;
            background: #ecf0f1;
            color: #2c3e50;
            transition: all 0.3s;
        }
        .filters a.active {
            background: #3498db;
            color: white;
        }
        .filters a:hover {
            background: #2980b9;
            color: white;
        }
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            font-weight: bold;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #34495e;
            color: white;
            font-weight: bold;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        .badge.pending {
            background: #ffc107;
            color: #000;
        }
        .badge.in_progress {
            background: #17a2b8;
            color: white;
        }
        .badge.completed {
            background: #28a745;
            color: white;
        }
        .badge.cancelled {
            background: #dc3545;
            color: white;
        }
        .priority {
            font-weight: bold;
            color: #e74c3c;
        }
        .execute-form {
            display: inline-block;
        }
        .execute-form input[type="number"] {
            width: 80px;
            padding: 5px;
            margin: 0 5px;
        }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #3498db;
            color: white;
        }
        .btn-primary:hover {
            background: #2980b9;
        }
        .no-orders {
            text-align: center;
            padding: 40px;
            color: #7f8c8d;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <div class="main-content">
    <div class="container">
        <h1>Lowering Orders Management</h1>
        
        <?php if (isset($message)): ?>
            <div class="message <?php echo $message_type; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <div class="filters">
            <strong>Filter by Status:</strong>
            <a href="?status=all" class="<?php echo $status_filter === 'all' ? 'active' : ''; ?>">All</a>
            <a href="?status=pending" class="<?php echo $status_filter === 'pending' ? 'active' : ''; ?>">Pending</a>
            <a href="?status=in_progress" class="<?php echo $status_filter === 'in_progress' ? 'active' : ''; ?>">In Progress</a>
            <a href="?status=completed" class="<?php echo $status_filter === 'completed' ? 'active' : ''; ?>">Completed</a>
        </div>
        
        <?php if ($orders_result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Item Barcode</th>
                        <th>Description</th>
                        <th>From Location</th>
                        <th>To Location</th>
                        <th>Quantity at Source</th>
                        <th>Quantity Moved</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Completed Zones</th>
                        <th>Created At</th>
                        <th>Lowered By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($order = $orders_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $order['id']; ?></td>
                            <td><?php echo htmlspecialchars($order['item_barcode']); ?></td>
                            <td><?php echo htmlspecialchars($order['item_description'] ?? '-'); ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($order['from_full_location'] ?? ($order['from_zone'] . '-' . $order['from_location_code'])); ?></strong>
                            </td>
                            <td>
                                <?php echo htmlspecialchars(($order['to_zone'] ?? '-') . ($order['to_location_code'] ? '-' . $order['to_location_code'] : ' (Not set)')); ?>
                            </td>
                            <td><?php echo $order['quantity_at_source'] ?? $order['quantity_to_lower'] ?? '-'; ?></td>
                            <td><?php echo $order['quantity_moved'] ?? $order['quantity_lowered'] ?? 0; ?></td>
                            <td class="priority"><?php echo $order['priority']; ?></td>
                            <td>
                                <span class="badge <?php echo $order['status']; ?>">
                                    <?php 
                                    $status_text = [
                                        'pending' => 'Pending',
                                        'in_progress' => 'In Progress',
                                        'completed' => 'Completed',
                                        'cancelled' => 'Cancelled'
                                    ];
                                    echo $status_text[$order['status']] ?? $order['status'];
                                    ?>
                                </span>
                            </td>
                            <td>
                                <?php 
                                $completed_zones = [];
                                if (!empty($order['completed_zones_list'])) {
                                    $completed_zones = array_map('trim', explode(',', $order['completed_zones_list']));
                                    echo implode(', ', $completed_zones);
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                            <td><?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></td>
                            <td><?php echo htmlspecialchars($order['lowered_by'] ?? '-'); ?></td>
                            <td>
                                <?php if ($order['status'] !== 'completed' && $order['status'] !== 'cancelled'): ?>
                                    <span style="color: #7f8c8d;">Use Lowering Page to Execute</span>
                                <?php else: ?>
                                    <span style="color: #7f8c8d;">Completed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-orders">
                No lowering orders <?php echo $status_filter !== 'all' ? 'with selected status' : ''; ?>
            </div>
        <?php endif; ?>
    </div>
        </div>
    </div>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>