<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'manager') {
    header("Location: login.php?role=manager");
    exit();
}
include 'db_connect.php';

if (!isset($_GET['plate_id']) || empty($_GET['plate_id'])) {
    header("Location: loaded_plates.php");
    exit();
}

$plate_id = mysqli_real_escape_string($conn, $_GET['plate_id']);

// Get plate information
$plate_query = "
    SELECT 
        pv.*,
        COUNT(DISTINCT pl.item_barcode) as item_count,
        SUM(COALESCE(pvi.qc_quantity, pl.quantity_picked)) as total_quantity
    FROM plate_verifications pv
    LEFT JOIN picking_log pl ON pv.plate_id = pl.plate_id
    LEFT JOIN plate_verification_items pvi ON pv.plate_id = pvi.plate_id AND pl.item_barcode = pvi.item_barcode
    WHERE pv.plate_id = ?
    GROUP BY pv.plate_id
";
$stmt = $conn->prepare($plate_query);
$stmt->bind_param("s", $plate_id);
$stmt->execute();
$plate_result = $stmt->get_result();

if ($plate_result->num_rows === 0) {
    header("Location: loaded_plates.php");
    exit();
}

$plate = $plate_result->fetch_assoc();
$stmt->close();

// Get plate items
$items_query = "
    SELECT 
        pl.item_barcode,
        pl.location_code,
        pl.quantity_picked,
        pvi.qc_quantity,
        COALESCE(ad.name, ad.description, pl.item_barcode) as item_name,
        pl.picked_by
    FROM picking_log pl
    LEFT JOIN plate_verification_items pvi ON pl.plate_id = pvi.plate_id AND pl.item_barcode = pvi.item_barcode
    LEFT JOIN adddesc ad ON pl.item_barcode = ad.barcode
    WHERE pl.plate_id = ?
    ORDER BY pl.item_barcode
";
$items_stmt = $conn->prepare($items_query);
$items_stmt->bind_param("s", $plate_id);
$items_stmt->execute();
$items_result = $items_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plate Details - <?php echo htmlspecialchars($plate_id); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 5px;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #6c757d;
        }
        .btn-back {
            padding: 8px 15px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            display: inline-block;
            margin-bottom: 20px;
        }
        .btn-back:hover {
            background: #5a6268;
        }
        .info-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
        }
        .info-item {
            margin-bottom: 10px;
        }
        .info-label {
            font-weight: bold;
            color: #666;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .info-value {
            color: #333;
            font-size: 16px;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: bold;
            background: #28a745;
            color: white;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #343a40;
            color: white;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background: #f8f9fa;
        }
        tr:hover {
            background: #e9ecef;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <div class="main-content">
            <div class="container">
                <a href="loaded_plates.php" class="btn-back">← Back to Loaded Plates</a>
                
                <h1>📦 Plate Details: <?php echo htmlspecialchars($plate_id); ?></h1>
                
                <div class="info-section">
                    <h2 style="margin-bottom: 15px; color: #333;">Plate Information</h2>
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Plate ID</div>
                            <div class="info-value"><strong><?php echo htmlspecialchars($plate['plate_id']); ?></strong></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Work ID</div>
                            <div class="info-value"><?php echo htmlspecialchars($plate['work_id'] ?? '-'); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Branch</div>
                            <div class="info-value"><?php echo htmlspecialchars($plate['branch'] ?? '-'); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Status</div>
                            <div class="info-value">
                                <span class="status-badge"><?php echo ucfirst($plate['plate_status']); ?></span>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">QC Verified By</div>
                            <div class="info-value"><?php echo htmlspecialchars($plate['verified_by'] ?? '-'); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">QC Verified At</div>
                            <div class="info-value"><?php echo $plate['verified_at'] ? date('Y-m-d H:i:s', strtotime($plate['verified_at'])) : '-'; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Loaded By</div>
                            <div class="info-value"><?php echo htmlspecialchars($plate['loaded_by'] ?? '-'); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Loaded At</div>
                            <div class="info-value"><?php echo $plate['ready_for_load_at'] ? date('Y-m-d H:i:s', strtotime($plate['ready_for_load_at'])) : '-'; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Total Items</div>
                            <div class="info-value"><strong><?php echo $plate['item_count']; ?></strong></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Total Quantity</div>
                            <div class="info-value"><strong><?php echo $plate['total_quantity']; ?></strong></div>
                        </div>
                    </div>
                </div>
                
                <h2 style="margin-top: 30px; margin-bottom: 15px; color: #333;">Plate Items</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Item Barcode</th>
                            <th>Item Name</th>
                            <th>Location</th>
                            <th>Picked Quantity</th>
                            <th>QC Quantity</th>
                            <th>Picked By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($items_result->num_rows > 0) {
                            while ($item = $items_result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($item['item_barcode']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($item['item_name'] ?? '-'); ?></td>
                                    <td><?php echo htmlspecialchars($item['location_code'] ?? '-'); ?></td>
                                    <td><?php echo $item['quantity_picked']; ?></td>
                                    <td><strong><?php echo $item['qc_quantity'] ?? $item['quantity_picked']; ?></strong></td>
                                    <td><?php echo htmlspecialchars($item['picked_by'] ?? '-'); ?></td>
                                </tr>
                                <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 40px; color: #999;">No items found</td>
                            </tr>
                            <?php
                        }
                        $items_stmt->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>

