<?php
session_start();
header('Content-Type: application/json');
include 'db_connect.php';

// Check if tables exist
$table_check = $conn->query("SHOW TABLES LIKE 'purchase_orders'");
if ($table_check->num_rows == 0) {
    echo json_encode(['success' => true, 'orders' => []]);
    exit;
}

$query = "
    SELECT 
        po.*,
        s.supplier_name,
        COUNT(poi.id) as item_count
    FROM purchase_orders po
    LEFT JOIN suppliers s ON po.supplier_id = s.id
    LEFT JOIN purchase_order_items poi ON po.id = poi.po_id
    GROUP BY po.id
    ORDER BY po.order_date DESC, po.id DESC
";

$result = $conn->query($query);
$orders = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = [
            'id' => $row['id'],
            'po_number' => $row['po_number'],
            'supplier_name' => $row['supplier_name'] ?? 'Unknown Supplier',
            'order_date' => $row['order_date'],
            'expected_delivery_date' => $row['expected_delivery_date'],
            'status' => $row['status'] ?? 'pending',
            'total_amount' => $row['total_amount'] ?? 0,
            'item_count' => $row['item_count']
        ];
    }
}

echo json_encode(['success' => true, 'orders' => $orders]);
$conn->close();
?>
