<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'quantity controller') {
    header("Location: login.php?role=quantity controller");
    exit();
}
include 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.7, maximum-scale=0.7">
    <title>Quantity Controller - Plate Verification</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background: white;
            padding: 5px;
            transform: scale(0.85);
            transform-origin: top center;
            width: 100%;
        }
        .container {
            width: 100%;
            max-width: 450px;
            margin: 0 auto;
            background: white;
            border: 2px solid #2c3e50;
            border-radius: 10px;
            overflow: hidden;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 12px;
            text-align: center;
            border-bottom: 2px solid #2c3e50;
        }
        .header h2 {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .content {
            padding: 12px;
            background: white;
        }
        .scanner-section {
            text-align: center;
            margin-bottom: 15px;
            padding: 12px;
            border: 2px dashed #ccc;
            border-radius: 8px;
            background: #fafafa;
        }
        .field {
            margin-bottom: 12px;
        }
        .field label {
            display: block;
            font-weight: bold;
            margin-bottom: 4px;
            color: #333;
            font-size: 14px;
        }
        .field input {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            background: white;
        }
        .info-box {
            background: white;
            border: 2px solid #2c3e50;
            border-radius: 5px;
            padding: 12px;
            margin: 12px 0;
        }
        .info-line {
            margin-bottom: 6px;
            padding: 4px 0;
            border-bottom: 1px solid #eee;
            font-size: 13px;
        }
        .info-line:last-child {
            border-bottom: none;
        }
        .items-list {
            max-height: 300px;
            overflow-y: auto;
            margin: 10px 0;
        }
        .item-row {
            padding: 8px;
            border-bottom: 1px solid #eee;
            font-size: 12px;
            background: #f8f9fa;
            margin-bottom: 5px;
            border-radius: 4px;
        }
        .item-row.verified {
            background: #d4edda;
        }
        .item-row.variance {
            background: #fff3cd;
        }
        .status-complete {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
            margin: 10px 0;
        }
        .status-variance {
            background: #fff3cd;
            color: #856404;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
            margin: 10px 0;
        }
        .status-ready {
            background: #d1ecf1;
            color: #0c5460;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
            margin: 10px 0;
        }
        .btn {
            padding: 10px;
            border: 2px solid;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            background: white;
            font-weight: bold;
            width: 100%;
            margin-top: 10px;
        }
        .btn-primary {
            border-color: #007bff;
            color: #007bff;
        }
        .btn-primary:hover {
            background: #007bff;
            color: white;
        }
        .barcode-input {
            text-align: center;
            font-size: 16px;
            letter-spacing: 1px;
        }
        .message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
        }
        .success {
            background: #d4edda;
            color: #155724;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
        }
        .warning {
            background: #fff3cd;
            color: #856404;
        }
        .progress-info {
            text-align: center;
            font-size: 12px;
            color: #666;
            margin: 10px 0;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        .modal-content {
            background: white;
            border-radius: 8px;
            padding: 20px;
            max-width: 500px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }
        .close-modal {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #666;
        }
        .edit-item-row {
            padding: 10px;
            border-bottom: 1px solid #eee;
            margin-bottom: 10px;
        }
        .edit-item-row input {
            width: 80px;
            padding: 5px;
            margin-left: 5px;
        }
        .btn-variance {
            background: #ffc107;
            border-color: #ffc107;
            color: #212529;
        }
        .btn-variance:hover {
            background: #e0a800;
            border-color: #e0a800;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Quality Control (QC)</h2>
            <p>Verify Physical Quantity vs Picker Entry</p>
            <?php if (isset($_SESSION['user_name'])): ?>
            <p style="font-size: 12px; margin-top: 5px;">Welcome, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></p>
            <a href="logout.php" style="color: #fff; text-decoration: none; font-size: 12px; margin-top: 5px; display: inline-block; padding: 5px 10px; background: rgba(255,255,255,0.2); border-radius: 3px;">Logout</a>
            <?php endif; ?>
        </div>
        
        <div class="content">
            <!-- Plate Scanner Section -->
            <div class="scanner-section" id="plate-scanner-section">
                <div class="field">
                    <label>Scan Prepared Plate ID</label>
                    <input type="text" id="plate-id-input" placeholder="Enter Plate ID (e.g., L-000123)" class="barcode-input" autocomplete="off">
                </div>
            </div>
            
            <!-- Plate Information -->
            <div id="plate-info" style="display: none;">
                <div class="info-box">
                    <div class="info-line"><strong>Plate ID:</strong> <span id="plate-id-display">-</span></div>
                    <div class="info-line"><strong>Branch:</strong> <span id="branch-display">-</span></div>
                </div>
                
                <!-- Progress Info -->
                <div class="progress-info" id="progress-info">
                    Verified: <span id="verified-count">0</span> / <span id="total-count">0</span> items
                </div>
                
                <!-- Item Scanner Section -->
                <div class="scanner-section" id="item-scanner-section">
                    <div class="field">
                        <label>Scan Item Barcode</label>
                        <input type="text" id="item-barcode-input" placeholder="Scan item barcode" class="barcode-input" autocomplete="off">
                    </div>
                    <div class="field">
                        <label>Enter Physical Quantity Counted</label>
                        <input type="number" id="quantity-input" placeholder="Enter physical quantity on plate" min="0" autocomplete="off">
                        <small style="color: #666; font-size: 12px;">Count the actual physical items on the plate</small>
                    </div>
                </div>
                
                <!-- Items List -->
                <div class="field">
                    <label>Items on Plate:</label>
                    <div class="items-list" id="items-list">
                        <!-- Items will be displayed here -->
                    </div>
                </div>
                
                <!-- Verification Status -->
                <div id="verification-status"></div>
                
                <!-- Action Buttons -->
                <button class="btn btn-primary" id="complete-btn" style="display: none;">Complete Verification</button>
                <button class="btn btn-success" id="approve-btn" style="display: none; background: #28a745; border-color: #28a745; color: white;">Approve Order</button>
                <button class="btn btn-ready" id="ready-for-load-btn" style="display: none; background: #17a2b8; border-color: #17a2b8; color: white;">Ready for Load</button>
                <button class="btn btn-variance" id="variance-btn" style="display: none;">Variance</button>
                <button class="btn btn-primary" id="new-plate-btn" style="display: none; margin-top: 10px;">Scan New Plate</button>
            </div>
            
            <div id="message-area"></div>
        </div>
    </div>

    <!-- Variance Modal -->
    <div class="modal" id="variance-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Edit Quantities</h3>
                <button class="close-modal" id="close-variance-modal">&times;</button>
            </div>
            <div id="variance-items-list">
                <!-- Items with editable quantities will be displayed here -->
            </div>
            <div style="margin-top: 15px;">
                <button class="btn btn-primary" id="save-variance-btn">Save Changes</button>
                <button class="btn btn-primary" style="background: #6c757d; border-color: #6c757d; color: white; margin-top: 10px;" id="cancel-variance-btn">Cancel</button>
            </div>
        </div>
    </div>

    <script>
        let currentPlateId = '';
        let plateData = null;
        let verifiedItems = {}; // Store verified quantities: {item_barcode: {qc_quantity, picked_quantity, verified}}
        
        // Auto-submit on Enter key for plate ID
        document.getElementById('plate-id-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && this.value.trim()) {
                loadPlateData(this.value.trim());
            }
        });
        
        // Auto-submit on Enter key for item barcode
        document.getElementById('item-barcode-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && this.value.trim()) {
                const itemBarcode = this.value.trim();
                document.getElementById('quantity-input').focus();
            }
        });
        
        // Auto-submit on Enter key for quantity
        document.getElementById('quantity-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && this.value.trim()) {
                const itemBarcode = document.getElementById('item-barcode-input').value.trim();
                const quantity = parseInt(this.value.trim());
                
                if (!itemBarcode) {
                    showMessage('Please scan item barcode first', 'error');
                    return;
                }
                
                if (isNaN(quantity) || quantity < 0) {
                    showMessage('Please enter a valid quantity', 'error');
                    return;
                }
                
                verifyItem(itemBarcode, quantity);
            }
        });
        
        // Load plate data
        function loadPlateData(plateId) {
            currentPlateId = plateId;
            verifiedItems = {};
            
            fetch(`get_plate_data.php?plate_id=${encodeURIComponent(plateId)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        plateData = data;
                        displayPlateInfo(data);
                        showMessage('Plate loaded successfully. Start scanning items.', 'success');
                    } else {
                        showMessage(data.message || 'Plate not found', 'error');
                        resetPlateInfo();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Failed to load plate data', 'error');
                    resetPlateInfo();
                });
        }
        
        // Display plate information
        function displayPlateInfo(data) {
            document.getElementById('plate-id-display').textContent = data.plate_id;
            document.getElementById('branch-display').textContent = data.branch || 'N/A';
            document.getElementById('total-count').textContent = data.items.length;
            
            // Debug: Log the data to see what we're getting
            console.log('Plate data received:', data);
            console.log('Verification status:', data.verification_status);
            
            // Initialize verified items with saved QC quantities if they exist
            let verifiedCount = 0;
            data.items.forEach(item => {
                // Check if qc_quantity exists (can be 0, so we check for null/undefined specifically)
                // Also check if verification_status exists, which means plate was verified
                const hasQcQuantity = (item.qc_quantity !== null && item.qc_quantity !== undefined && item.qc_quantity !== '');
                const qcQty = hasQcQuantity ? parseInt(item.qc_quantity) : null;
                
                // If plate is verified but qc_quantity is null, it might be a data issue
                // But we still mark it as verified if verification_status exists
                const isVerified = hasQcQuantity || (data.verification_status && data.verification_status !== null);
                
                verifiedItems[item.item_barcode] = {
                    qc_quantity: qcQty,
                    picked_quantity: item.quantity_picked,
                    required_quantity: item.quantity_required,
                    description: item.description || 'N/A',
                    location_code: item.location_code || 'N/A',
                    verified: isVerified
                };
                
                if (hasQcQuantity) {
                    verifiedCount++;
                }
                
                // Debug: Log each item
                console.log(`Item ${item.item_barcode}: qc_quantity=${item.qc_quantity}, hasQcQuantity=${hasQcQuantity}, isVerified=${isVerified}`);
            });
            
            document.getElementById('verified-count').textContent = verifiedCount;
            
            // Display items list immediately
            updateItemsList();
            
            // Show plate info section
            document.getElementById('plate-info').style.display = 'block';
            document.getElementById('plate-scanner-section').style.display = 'none';
            document.getElementById('item-scanner-section').style.display = 'block';
            document.getElementById('variance-btn').style.display = 'block'; // Always show variance button
            
            // Check plate status first - if ready_to_load or loaded, QC cannot access
            if (data.plate_status === 'ready_to_load' || data.plate_status === 'loaded') {
                const statusDiv = document.getElementById('verification-status');
                if (data.plate_status === 'ready_to_load') {
                    statusDiv.innerHTML = '<div class="status-ready">✓ This plate is ready for load. QC cannot edit it anymore.</div>';
                } else {
                    statusDiv.innerHTML = '<div class="status-complete">✓ This plate has been loaded.</div>';
                }
                document.getElementById('approve-btn').style.display = 'none';
                document.getElementById('complete-btn').style.display = 'none';
                document.getElementById('ready-for-load-btn').style.display = 'none';
                document.getElementById('variance-btn').style.display = 'none';
                document.getElementById('item-scanner-section').style.display = 'none';
                document.getElementById('new-plate-btn').style.display = 'block';
                return; // Stop here, don't allow editing
            }
            
            // Check if already verified (but not ready_to_load or loaded)
            if (data.verification_status) {
                const statusDiv = document.getElementById('verification-status');
                if (data.verification_status === 'complete') {
                    statusDiv.innerHTML = '<div class="status-complete">✓ This plate has been verified and approved (Complete)</div>';
                } else if (data.verification_status === 'variance') {
                    statusDiv.innerHTML = '<div class="status-variance">⚠ This plate has been verified with variance</div>';
                }
                document.getElementById('approve-btn').style.display = 'none';
                document.getElementById('complete-btn').style.display = 'none';
                document.getElementById('ready-for-load-btn').style.display = 'block';
                document.getElementById('new-plate-btn').style.display = 'block';
            } else {
                // Plate not verified yet - QC can verify it
                // Check completion status
                checkCompletion();
            }
            
            // Focus on item barcode input
            setTimeout(() => {
                document.getElementById('item-barcode-input').focus();
            }, 100);
        }
        
        // Update items list display
        function updateItemsList() {
            const itemsList = document.getElementById('items-list');
            itemsList.innerHTML = '';
            
            Object.keys(verifiedItems).forEach(barcode => {
                const item = verifiedItems[barcode];
                const itemRow = document.createElement('div');
                itemRow.className = 'item-row';
                
                if (item.verified) {
                    // Compare as numbers to ensure accurate comparison
                    const qcQty = parseInt(item.qc_quantity) || 0;
                    const pickedQty = parseInt(item.picked_quantity) || 0;
                    
                    if (qcQty === pickedQty) {
                        itemRow.classList.add('verified');
                    } else {
                        itemRow.classList.add('variance');
                    }
                }
                
                let statusText = '';
                let varianceInfo = '';
                if (item.verified) {
                    // Compare as numbers to ensure accurate comparison
                    const qcQty = parseInt(item.qc_quantity) || 0;
                    const pickedQty = parseInt(item.picked_quantity) || 0;
                    
                    if (qcQty === pickedQty) {
                        statusText = '✓ Match';
                    } else {
                        const difference = qcQty - pickedQty;
                        const diffText = difference > 0 ? `+${difference}` : `${difference}`;
                        statusText = `⚠ Variance Detected`;
                        varianceInfo = `<br><span style="color: #dc3545; font-weight: bold;">Difference: ${diffText} (Picker entered: ${pickedQty}, Physical count: ${qcQty})</span>`;
                    }
                } else {
                    statusText = '⏳ Pending';
                }
                
                itemRow.innerHTML = `
                    <strong>${barcode}</strong> - ${item.description}<br>
                    Required: ${item.required_quantity} | Picker Entered: ${item.picked_quantity} | Physical Count (QC): ${item.qc_quantity !== null ? item.qc_quantity : 'Not counted yet'} | ${statusText}${varianceInfo}
                `;
                itemsList.appendChild(itemRow);
            });
            
            // Update progress
            const verifiedCount = Object.values(verifiedItems).filter(item => item.verified).length;
            document.getElementById('verified-count').textContent = verifiedCount;
            
            // Check if all items are verified
            checkCompletion();
        }
        
        // Verify item
        function verifyItem(itemBarcode, qcQuantity) {
            if (!verifiedItems[itemBarcode]) {
                showMessage('Item not found in this plate', 'error');
                document.getElementById('item-barcode-input').value = '';
                document.getElementById('quantity-input').value = '';
                document.getElementById('item-barcode-input').focus();
                return;
            }
            
            const item = verifiedItems[itemBarcode];
            // Ensure quantity is a number, not a string
            item.qc_quantity = parseInt(qcQuantity);
            item.verified = true;
            
            // Debug: Log the verification
            console.log(`Verified item ${itemBarcode} with QC quantity: ${item.qc_quantity}`);
            
            // Update display
            updateItemsList();
            checkCompletion();
            
            // Clear inputs and focus on next item
            document.getElementById('item-barcode-input').value = '';
            document.getElementById('quantity-input').value = '';
            document.getElementById('item-barcode-input').focus();
            
            // Show message with variance details
            const qcQty = parseInt(qcQuantity) || 0;
            const pickedQty = parseInt(item.picked_quantity) || 0;
            
            if (qcQty === pickedQty) {
                showMessage(`Item ${itemBarcode} verified - Match! Physical count (${qcQty}) matches picker's entry (${pickedQty})`, 'success');
            } else {
                const difference = qcQty - pickedQty;
                const diffText = difference > 0 ? `+${difference}` : `${difference}`;
                showMessage(`Item ${itemBarcode} - Variance detected! Picker entered: ${pickedQty}, Physical count: ${qcQty}, Difference: ${diffText}`, 'warning');
            }
        }
        
        // Check completion
        function checkCompletion() {
            const allVerified = Object.values(verifiedItems).every(item => item.verified);
            // Compare as numbers to ensure accurate comparison
            const allMatch = Object.values(verifiedItems).every(item => {
                const qcQty = parseInt(item.qc_quantity) || 0;
                const pickedQty = parseInt(item.picked_quantity) || 0;
                return qcQty === pickedQty;
            });
            
            const statusDiv = document.getElementById('verification-status');
            
            // Variance button is always visible when plate is loaded
            document.getElementById('variance-btn').style.display = 'block';
            
            if (allVerified) {
                // Show Approve Order button when all items are verified
                document.getElementById('approve-btn').style.display = 'block';
                
                if (allMatch) {
                    statusDiv.innerHTML = '<div class="status-complete">✓ Complete - All physical quantities match picker entries!</div>';
                    document.getElementById('complete-btn').style.display = 'block';
                } else {
                    statusDiv.innerHTML = '<div class="status-variance">⚠ Variance detected - Physical quantities do not match picker entries.</div>';
                    document.getElementById('complete-btn').style.display = 'none';
                }
            } else {
                statusDiv.innerHTML = '';
                document.getElementById('complete-btn').style.display = 'none';
                document.getElementById('approve-btn').style.display = 'none';
            }
        }
        
        // Complete verification button
        document.getElementById('complete-btn').addEventListener('click', function() {
            if (!currentPlateId) {
                showMessage('No plate loaded', 'error');
                return;
            }
            
            // Check if all items are verified and match
            const allVerified = Object.values(verifiedItems).every(item => item.verified);
            const allMatch = Object.values(verifiedItems).every(item => item.qc_quantity === item.picked_quantity);
            
            if (!allVerified) {
                showMessage('Please verify all items first', 'error');
                return;
            }
            
            if (!allMatch) {
                showMessage('Cannot complete - there are variances. Please use Variance button.', 'error');
                return;
            }
            
            verifyPlate(currentPlateId, false); // false = no variance
        });
        
        // Variance button - open modal to edit quantities
        document.getElementById('variance-btn').addEventListener('click', function() {
            if (!currentPlateId || !plateData) {
                showMessage('No plate loaded', 'error');
                return;
            }
            
            openVarianceModal();
        });
        
        // Open variance modal
        function openVarianceModal() {
            const modal = document.getElementById('variance-modal');
            const itemsList = document.getElementById('variance-items-list');
            itemsList.innerHTML = '';
            
            // Display all items with editable quantities
            Object.keys(verifiedItems).forEach(barcode => {
                const item = verifiedItems[barcode];
                const itemRow = document.createElement('div');
                itemRow.className = 'edit-item-row';
                itemRow.innerHTML = `
                    <div style="margin-bottom: 5px;">
                        <strong>${barcode}</strong> - ${item.description}<br>
                        <small style="color: #666;">Picker entered: ${item.picked_quantity} | Required: ${item.required_quantity}</small>
                    </div>
                    <div>
                        <label>Physical Quantity Counted:</label>
                        <input type="number" 
                               id="edit-qty-${barcode}" 
                               value="${item.qc_quantity !== null ? item.qc_quantity : ''}" 
                               min="0" 
                               placeholder="Count physical items"
                               style="width: 100px; padding: 5px; margin-left: 5px;">
                    </div>
                `;
                itemsList.appendChild(itemRow);
            });
            
            modal.style.display = 'flex';
        }
        
        // Close variance modal
        document.getElementById('close-variance-modal').addEventListener('click', function() {
            document.getElementById('variance-modal').style.display = 'none';
        });
        
        document.getElementById('cancel-variance-btn').addEventListener('click', function() {
            document.getElementById('variance-modal').style.display = 'none';
        });
        
        // Close modal when clicking outside
        document.getElementById('variance-modal').addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
        
        // Save variance changes
        document.getElementById('save-variance-btn').addEventListener('click', function() {
            // Update all quantities from modal
            Object.keys(verifiedItems).forEach(barcode => {
                const input = document.getElementById(`edit-qty-${barcode}`);
                if (input && input.value.trim() !== '') {
                    const qty = parseInt(input.value.trim());
                    if (!isNaN(qty) && qty >= 0) {
                        verifiedItems[barcode].qc_quantity = qty;
                        verifiedItems[barcode].verified = true;
                    }
                } else {
                    // If quantity is cleared, mark as not verified
                    verifiedItems[barcode].qc_quantity = null;
                    verifiedItems[barcode].verified = false;
                }
            });
            
            // Update display
            updateItemsList();
            checkCompletion();
            
            // Close modal
            document.getElementById('variance-modal').style.display = 'none';
            
            showMessage('Quantities updated successfully', 'success');
        });
        
        // Approve Order button
        document.getElementById('approve-btn').addEventListener('click', function() {
            if (!currentPlateId) {
                showMessage('No plate loaded', 'error');
                return;
            }
            
            // Check if all items are verified
            const allVerified = Object.values(verifiedItems).every(item => item.verified);
            
            if (!allVerified) {
                showMessage('Please verify all items first', 'error');
                return;
            }
            
            // Check if there are variances (compare as numbers)
            const hasVariance = Object.values(verifiedItems).some(item => {
                const qcQty = parseInt(item.qc_quantity) || 0;
                const pickedQty = parseInt(item.picked_quantity) || 0;
                return qcQty !== pickedQty;
            });
            
            // Confirm approval
            const confirmMsg = hasVariance 
                ? 'There are variances detected. Do you want to approve this order with variances?'
                : 'Do you want to approve this order?';
            
            if (confirm(confirmMsg)) {
                approveOrder(currentPlateId, hasVariance);
            }
        });
        
        // Approve order function
        function approveOrder(plateId, hasVariance) {
            // Prepare QC quantities object - include all items even if quantity is 0
            const qcQuantities = {};
            Object.keys(verifiedItems).forEach(barcode => {
                const item = verifiedItems[barcode];
                // Include quantity even if it's 0, but not if it's null/undefined
                if (item.qc_quantity !== null && item.qc_quantity !== undefined) {
                    qcQuantities[barcode] = item.qc_quantity;
                }
            });
            
            // Debug: Log what we're sending
            console.log('Saving QC quantities:', qcQuantities);
            console.log('Verified items:', verifiedItems);
            
            fetch('verify_plate.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `plate_id=${encodeURIComponent(plateId)}&has_variance=${hasVariance ? '1' : '0'}&qc_quantities=${encodeURIComponent(JSON.stringify(qcQuantities))}`
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage(data.message || 'Order approved successfully', 'success');
                        document.getElementById('complete-btn').style.display = 'none';
                        document.getElementById('approve-btn').style.display = 'none';
                        document.getElementById('variance-btn').style.display = 'none';
                        document.getElementById('new-plate-btn').style.display = 'block';
                    } else {
                        showMessage(data.message || 'Failed to approve order', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Failed to approve order', 'error');
                });
        }
        
        // Verify plate
        function verifyPlate(plateId, hasVariance) {
            // Prepare QC quantities object - include all items even if quantity is 0
            const qcQuantities = {};
            Object.keys(verifiedItems).forEach(barcode => {
                const item = verifiedItems[barcode];
                // Include quantity even if it's 0, but not if it's null/undefined
                if (item.qc_quantity !== null && item.qc_quantity !== undefined) {
                    qcQuantities[barcode] = item.qc_quantity;
                }
            });
            
            // Debug: Log what we're sending
            console.log('Saving QC quantities (verifyPlate):', qcQuantities);
            
            fetch('verify_plate.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `plate_id=${encodeURIComponent(plateId)}&has_variance=${hasVariance ? '1' : '0'}&qc_quantities=${encodeURIComponent(JSON.stringify(qcQuantities))}`
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage(data.message || 'Plate verified successfully', 'success');
                        document.getElementById('complete-btn').style.display = 'none';
                        document.getElementById('approve-btn').style.display = 'none';
                        document.getElementById('variance-btn').style.display = 'none';
                        document.getElementById('new-plate-btn').style.display = 'block';
                    } else {
                        showMessage(data.message || 'Failed to verify plate', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Failed to verify plate', 'error');
                });
        }
        
        // New plate button
        document.getElementById('new-plate-btn').addEventListener('click', function() {
            resetPlateInfo();
        });
        
        // Reset plate info
        function resetPlateInfo() {
            currentPlateId = '';
            plateData = null;
            verifiedItems = {};
            document.getElementById('plate-id-input').value = '';
            document.getElementById('item-barcode-input').value = '';
            document.getElementById('quantity-input').value = '';
            document.getElementById('plate-info').style.display = 'none';
            document.getElementById('plate-scanner-section').style.display = 'block';
            document.getElementById('item-scanner-section').style.display = 'none';
            document.getElementById('complete-btn').style.display = 'none';
            document.getElementById('approve-btn').style.display = 'none';
            document.getElementById('ready-for-load-btn').style.display = 'none';
            document.getElementById('variance-btn').style.display = 'none';
            document.getElementById('new-plate-btn').style.display = 'none';
            document.getElementById('plate-id-input').focus();
        }
        
        // Ready for Load button
        document.getElementById('ready-for-load-btn').addEventListener('click', function() {
            if (!currentPlateId) {
                showMessage('No plate loaded', 'error');
                return;
            }
            
            // Check if plate is verified
            if (!plateData || !plateData.verification_status) {
                showMessage('Please verify and approve the plate first', 'error');
                return;
            }
            
            // Confirm
            if (confirm('Mark this plate as Ready for Load? QC will not be able to edit it after this.')) {
                markPlateAsReadyForLoad(currentPlateId);
            }
        });
        
        // Mark plate as ready for load
        function markPlateAsReadyForLoad(plateId) {
            fetch('mark_ready_for_load.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `plate_id=${encodeURIComponent(plateId)}`
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage(data.message || 'Plate marked as Ready for Load successfully', 'success');
                        document.getElementById('complete-btn').style.display = 'none';
                        document.getElementById('approve-btn').style.display = 'none';
                        document.getElementById('ready-for-load-btn').style.display = 'none';
                        document.getElementById('variance-btn').style.display = 'none';
                        document.getElementById('item-scanner-section').style.display = 'none';
                        document.getElementById('new-plate-btn').style.display = 'block';
                        
                        // Update status display
                        const statusDiv = document.getElementById('verification-status');
                        statusDiv.innerHTML = '<div class="status-ready">✓ This plate is ready for load. QC cannot edit it anymore.</div>';
                    } else {
                        showMessage(data.message || 'Failed to mark plate as ready for load', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Failed to mark plate as ready for load', 'error');
                });
        }
        
        // Show message
        function showMessage(message, type) {
            const messageArea = document.getElementById('message-area');
            messageArea.innerHTML = `<div class="message ${type}">${message}</div>`;
            
            setTimeout(() => {
                messageArea.innerHTML = '';
            }, 3000);
        }
        
        // Focus on plate input on load
        document.getElementById('plate-id-input').focus();
        
        // Check if plate_id is provided in URL
        const urlParams = new URLSearchParams(window.location.search);
        const plateIdFromUrl = urlParams.get('plate_id');
        if (plateIdFromUrl) {
            // Auto-load plate if plate_id is in URL
            document.getElementById('plate-id-input').value = plateIdFromUrl;
            loadPlateData(plateIdFromUrl);
        }
    </script>
</body>
</html>
