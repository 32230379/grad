<?php
header('Content-Type: application/json');
include 'db_connect.php';

if (!isset($_GET['plate_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Plate ID is required'
    ]);
    exit;
}

$plate_id = trim($_GET['plate_id']);

// Get plate verification data - must be ready_to_load
$stmt = $conn->prepare("
    SELECT 
        pv.plate_id,
        pv.work_id,
        pv.branch,
        pv.verified_by as qc_name,
        pv.verified_at,
        pv.plate_status
    FROM plate_verifications pv
    WHERE pv.plate_id = ?
    AND pv.plate_status = 'ready_to_load'
    LIMIT 1
");

$stmt->bind_param("s", $plate_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Plate not found or not ready for loading. Only plates with status "ready_to_load" can be loaded.'
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

$plate_info = $result->fetch_assoc();
$work_id = $plate_info['work_id'];
$stmt->close();

// Get picker name from picking_log
$picker_stmt = $conn->prepare("
    SELECT DISTINCT pl.picked_by
    FROM picking_log pl
    WHERE pl.plate_id = ? AND pl.picked_by IS NOT NULL
    LIMIT 1
");
$picker_stmt->bind_param("s", $plate_id);
$picker_stmt->execute();
$picker_result = $picker_stmt->get_result();
$picker_name = 'System'; // Default if not found
if ($picker_result->num_rows > 0) {
    $picker_row = $picker_result->fetch_assoc();
    $picker_name = $picker_row['picked_by'];
}
$picker_stmt->close();

// Get all items for this plate with QC quantities
// Use QC quantity from plate_verification_items (final verified quantity)
$items_stmt = $conn->prepare("
    SELECT 
        pl.item_barcode,
        pl.quantity_picked as picker_quantity,
        COALESCE(pvi.qc_quantity, pl.quantity_picked) as qc_quantity,
        pl.location_code,
        COALESCE(ad.description, ad.name, pl.item_barcode) as description
    FROM picking_log pl
    LEFT JOIN plate_verification_items pvi ON pl.plate_id = pvi.plate_id 
        AND pl.item_barcode = pvi.item_barcode
    LEFT JOIN adddesc ad ON pl.item_barcode = ad.barcode
    WHERE pl.plate_id = ?
    ORDER BY pl.item_barcode
");

$items_stmt->bind_param("s", $plate_id);
$items_stmt->execute();
$items_result = $items_stmt->get_result();

$items = [];
while ($row = $items_result->fetch_assoc()) {
    // Use QC quantity as the final quantity to load
    $row['quantity_picked'] = intval($row['qc_quantity']); // For display
    $items[] = $row;
}
$items_stmt->close();

echo json_encode([
    'success' => true,
    'plate_id' => $plate_info['plate_id'],
    'work_id' => $plate_info['work_id'],
    'branch' => $plate_info['branch'],
    'qc_name' => $plate_info['qc_name'] ?? 'Unknown',
    'picker_name' => $picker_name,
    'verified_at' => $plate_info['verified_at'],
    'plate_status' => $plate_info['plate_status'],
    'items' => $items
]);

$conn->close();
?>

