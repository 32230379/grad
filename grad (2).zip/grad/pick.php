<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'picker') {
    header("Location: login.php?role=picker");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.7, maximum-scale=0.7">
    <title>Warehouse Picking System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background: white;
            padding: 5px;
            transform: scale(0.85);
            transform-origin: top center;
            width: 100%;
        }
        .container {
            width: 100%;
            max-width: 450px;
            margin: 0 auto;
            background: white;
            border: 2px solid #2c3e50;
            border-radius: 10px;
            overflow: hidden;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 12px;
            text-align: center;
            border-bottom: 2px solid #2c3e50;
        }
        .header h2 {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .header p {
            font-size: 14px;
        }
        .content {
            padding: 12px;
            background: white;
        }
        .scanner-section {
            text-align: center;
            margin-bottom: 15px;
            padding: 12px;
            border: 2px dashed #ccc;
            border-radius: 8px;
            background: #fafafa;
        }
        .scanner-icon {
            font-size: 30px;
            margin-bottom: 8px;
        }
        .field {
            margin-bottom: 12px;
        }
        .field label {
            display: block;
            font-weight: bold;
            margin-bottom: 4px;
            color: #333;
            font-size: 14px;
        }
        .field input {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            background: white;
        }
        .location-display {
            background: #f8f9fa;
            border: 2px solid #2c3e50;
            border-radius: 5px;
            padding: 12px;
            margin-bottom: 12px;
            font-size: 14px;
        }
        .location-display div {
            margin-bottom: 5px;
        }
        .location-display strong {
            display: inline-block;
            min-width: 140px;
            margin-right: 8px;
        }
        .info-box {
            background: white;
            border: 2px solid #2c3e50;
            border-radius: 5px;
            padding: 12px;
            margin: 12px 0;
        }
        .info-line {
            margin-bottom: 6px;
            padding: 4px 0;
            border-bottom: 1px solid #eee;
            font-size: 13px;
        }
        .info-line:last-child {
            border-bottom: none;
        }
        .buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-top: 15px;
        }
        .btn {
            padding: 10px;
            border: 2px solid;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            background: white;
            font-weight: bold;
        }
        .btn-ok {
            border-color: #28a745;
            color: #28a745;
        }
        .btn-cancel {
            border-color: #dc3545;
            color: #dc3545;
        }
        .btn-override {
            border-color: #ffc107;
            color: #ffc107;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border: 2px solid #2c3e50;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            max-height: 70vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 10px;
        }
        .modal-header h3 {
            margin: 0;
            color: #2c3e50;
        }
        .close-modal {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #2c3e50;
        }
        .location-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .location-item {
            padding: 12px;
            margin: 8px 0;
            border: 2px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            background: white;
        }
        .location-item:hover {
            background: #f8f9fa;
            border-color: #ffc107;
        }
        .location-item.selected {
            background: #fff3cd;
            border-color: #ffc107;
        }
        .location-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .location-code {
            font-weight: bold;
            font-size: 16px;
            color: #2c3e50;
        }
        .location-details {
            font-size: 12px;
            color: #666;
        }
        .location-quantity {
            font-weight: bold;
            color: #28a745;
        }
        .btn-skip {
            border-color: #6c757d;
            color: #6c757d;
        }
        .btn-seal {
            border-color: #e74c3c;
            color: #e74c3c;
        }
        .btn-seal:hover {
            background: #e74c3c;
            color: white;
        }
        .action-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-top: 12px;
        }
        .status-available {
            color: #28a745;
            font-weight: bold;
        }
        .barcode-input {
            text-align: center;
            font-size: 16px;
            letter-spacing: 1px;
        }
        .item-input {
            text-align: center;
            font-size: 16px;
            font-weight: bold;
        }
        .scanner-section p {
            font-size: 12px;
            margin-top: 5px;
        }
        .work-id-section {
            margin-bottom: 15px;
            padding: 10px;
            border: 2px solid #2c3e50;
            border-radius: 5px;
            background: #f8f9fa;
        }
        .progress-bar {
            height: 10px;
            background: #e9ecef;
            border-radius: 5px;
            margin: 10px 0;
            overflow: hidden;
        }
        .progress {
            height: 100%;
            background: #28a745;
            transition: width 0.3s;
        }
        .message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
        }
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Picking Order</h2>
            <p id="branch-display">Pick - Dweir Branch</p>
            <?php if (isset($_SESSION['user_name'])): ?>
            <p style="font-size: 12px; margin-top: 5px;">Welcome, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></p>
            <a href="logout.php" style="color: #fff; text-decoration: none; font-size: 12px; margin-top: 5px; display: inline-block; padding: 5px 10px; background: rgba(255,255,255,0.2); border-radius: 3px;">Logout</a>
            <?php endif; ?>
        </div>
        
        <div class="content">
            <!-- Work ID Scanner Section -->
            <div class="work-id-section" id="work-id-section">
                <div class="field">
                    <label>Scan Work ID</label>
                    <input type="text" id="work-id-input" placeholder="Enter Work ID (e.g., workid-123)" class="barcode-input">
                </div>
                <button class="btn btn-ok" id="load-order-btn" style="width: 100%; margin-top: 8px;">Load Order</button>
            </div>
            
            <!-- Order Progress -->
            <div id="order-progress" style="display: none;">
                <div class="field">
                    <label>Order Progress</label>
                    <div class="progress-bar">
                        <div class="progress" id="progress-bar-fill" style="width: 0%"></div>
                    </div>
                    <div style="text-align: center; font-size: 12px;" id="progress-text">0/0 items picked</div>
                </div>
            </div>

            <!-- Location Display -->
            <div class="field" id="location-field" style="display: none;">
                <label>Location</label>
                <div class="location-display" id="location-display">
                    <div style="margin-bottom: 8px;">
                        <strong style="color: #007bff;">System Recommended:</strong>
                        <span id="system-location">-</span>
                    </div>
                    <div>
                        <strong style="color: #28a745;">Actual Location:</strong>
                        <span id="actual-location">-</span>
                    </div>
                </div>
            </div>

            <!-- Barcode Scanner Section -->
            <div class="scanner-section" id="scanner-section" style="display: none;">
                <div class="scanner-icon"></div>
                <div class="field">
                    <label>Scan Item Barcode</label>
                    <input type="text" class="barcode-input item-input" id="item-barcode-input" placeholder="Enter item number">
                </div>
                <p>Enter any item number</p>
            </div>
            
            <div class="field" id="plate-field" style="display: none;">
                <label>Virtual Plate ID (Scan Virtual Plate)</label>
                <input type="text" id="plate-input" placeholder="Scan virtual plate barcode" class="barcode-input" autocomplete="off">
                <small style="color: #666; font-size: 12px;">Scan virtual plate at first item - all picked items will be placed on this virtual plate</small>
            </div>
            
            <!-- Area field - shown when order is completed -->
            <div class="field" id="area-field" style="display: none;">
                <label>Scan Area (Optional - will use default area for branch if empty)</label>
                <input type="text" id="area-input" placeholder="Scan area barcode (or press Enter to use default)" class="barcode-input" autocomplete="off">
                <small style="color: #666; font-size: 12px;">Scan area where the prepared plate will be placed. If empty, system will use default area for your branch.</small>
            </div>
            
            <div class="info-box" id="item-info" style="display: none;">
                <div class="info-line"><strong>Item barcode:</strong> <span id="item-display">-</span></div>
                <div class="info-line"><strong>Description:</strong> <span id="description-display">-</span></div>
                <div class="info-line"><strong>Required Quantity:</strong> <span id="quantity-required-display">-</span></div>
                <div class="info-line"><strong>Expiry:</strong> <span id="expiry-display">-</span></div>
                <div class="info-line"><strong>Status:</strong> <span class="status-available" id="status-display">-</span></div>
            </div>
            
            <div class="field" id="quantity-field" style="display: none;">
                <label>Scanned Quantity</label>
                <input type="number" id="quantity-input" placeholder="Enter quantity" min="1" step="1" required>
            </div>
            
            <div class="buttons" id="action-buttons" style="display: none;">
                <button class="btn btn-ok" id="confirm-btn">OK</button>
                <button class="btn btn-cancel" id="cancel-btn">Cancel</button>
            </div>
            
            <div class="action-buttons" id="special-buttons" style="display: none;">
                <button class="btn btn-override" id="override-btn">Override Loc</button>
                <button class="btn btn-skip" id="skip-btn">Skip</button>
            </div>
            
            <div style="margin-top: 10px;">
                <button class="btn btn-seal" id="seal-btn" style="width: 100%; display: none;">Seal Plate</button>
            </div>
            
            <div id="message-area"></div>
        </div>
    </div>

    <!-- Location Selection Modal -->
    <div id="location-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Select Location</h3>
                <button class="close-modal" onclick="closeLocationModal()">&times;</button>
            </div>
            <div id="location-list-container">
                <p>Loading locations...</p>
            </div>
        </div>
    </div>

    <script>
        let currentWorkId = '';
        let currentItem = null;
        
        // Load order when work ID is entered
        document.getElementById('load-order-btn').addEventListener('click', function() {
            const workId = document.getElementById('work-id-input').value.trim();
            
            if (!workId) {
                showMessage('Please enter a Work ID', 'error');
                return;
            }
            
            loadPickingOrder(workId);
        });

        // Allow Enter key to load order
        document.getElementById('work-id-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                document.getElementById('load-order-btn').click();
            }
        });
        
        // Load picking order from server
        function loadPickingOrder(workId) {
            fetch(`get_picking_order.php?work_id=${encodeURIComponent(workId)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.current_item) {
                            currentWorkId = workId;
                            setupOrderInterface(data.order, data.current_item);
                            // Check if item is on high shelf
                            if (data.current_item.shelf_number !== null && data.current_item.shelf_number > 2) {
                                showMessage('Item found on high shelf (shelf ' + data.current_item.shelf_number + '). You can still pick it, but consider checking lowering orders.', 'warning');
                            } else {
                                showMessage('Order loaded successfully', 'success');
                            }
                        } else {
                            // Check if there are any pending items at all
                            if (data.order && data.order.total_items > data.order.picked_items) {
                                showMessage('No items available in inventory for the remaining pending items. Please check inventory or lowering orders.', 'warning');
                            } else {
                                showMessage('All items have been picked!', 'success');
                            }
                        }
                    } else {
                        showMessage(data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Failed to load order', 'error');
                });
        }
        
        // Set up the interface for the loaded order
        function setupOrderInterface(order, currentItem) {
            // Update header
            document.getElementById('branch-display').textContent = `Pick - ${order.branch || 'Dweir Branch'}`;
            
            // Show progress
            document.getElementById('order-progress').style.display = 'block';
            const progressPercent = order.total_items > 0 ? (order.picked_items / order.total_items) * 100 : 0;
            document.getElementById('progress-bar-fill').style.width = `${progressPercent}%`;
            document.getElementById('progress-text').textContent = 
                `${order.picked_items}/${order.total_items} items picked`;
            
            // Virtual Plate field - starts empty, user must scan virtual plate at first item
            // If plate already exists from previous items, show it (same virtual plate for all items)
            const plateInput = document.getElementById('plate-input');
            if (order.plate_id) {
                // Virtual plate already exists from previous items - show it
                plateInput.value = order.plate_id;
                plateInput.style.background = '#e8f5e8';
                plateInput.style.borderColor = '#28a745';
            } else {
                // No virtual plate yet - field is empty, user must scan virtual plate at first item
                plateInput.value = '';
            }
            
            // Show picking interface sections
            document.getElementById('location-field').style.display = 'block';
            document.getElementById('plate-field').style.display = 'block';
            document.getElementById('scanner-section').style.display = 'block';
            document.getElementById('item-info').style.display = 'block';
            document.getElementById('quantity-field').style.display = 'block';
            document.getElementById('action-buttons').style.display = 'grid';
            document.getElementById('special-buttons').style.display = 'grid';
            document.getElementById('seal-btn').style.display = 'block';
            
            // Hide work ID section
            document.getElementById('work-id-section').style.display = 'none';
            
            // If there's a current item, pre-fill the information
            if (currentItem) {
                setCurrentItem(currentItem);
            }
        }
        
        // Set the current item information
        function setCurrentItem(item) {
            currentItem = item;
            
            // Build system recommended location (from order/item data)
            // This is the location the system recommends based on priority
            let systemLocation = '';
            if (item.full_location_code) {
                systemLocation = item.full_location_code;
            } else {
                let zone = item.zone || 'A';
                const loc = item.location_code || 'N/A';
                systemLocation = `${zone}-${loc}`;
            }
            
            // Store system recommended location (first time only)
            if (!currentItem.system_location) {
                currentItem.system_location = systemLocation;
                currentItem.system_location_code = item.location_code;
            }
            
            // Actual location (may be overridden by picker)
            // Initially same as system location, but can be changed via override
            let actualLocation = currentItem.actual_location || systemLocation;
            let actualLocationCode = currentItem.actual_location_code || item.location_code;
            
            // Update display
            document.getElementById('system-location').textContent = systemLocation;
            document.getElementById('actual-location').textContent = actualLocation;
            
            // Update current item with actual location for processing
            currentItem.location_code = actualLocationCode;
            currentItem.zone = item.zone;
            currentItem.full_location_code = actualLocation;
            
            // Update item info
            document.getElementById('item-display').textContent = item.item_barcode || '-';
            document.getElementById('description-display').textContent = item.description || 'No description';
            document.getElementById('quantity-required-display').textContent = `${item.quantity_required || 0} piece`;
            
            // Format expiry date
            let expiryDate = item.expiry_date || 'N/A';
            if (expiryDate !== 'N/A' && expiryDate) {
                try {
                    const date = new Date(expiryDate);
                    if (!isNaN(date.getTime())) {
                        expiryDate = date.toLocaleDateString();
                    }
                } catch(e) {
                    // Keep original format if parsing fails
                }
            }
            document.getElementById('expiry-display').textContent = expiryDate;
            
            // Update status with color coding
            const statusEl = document.getElementById('status-display');
            statusEl.textContent = item.status || 'Available';
            if (item.status && item.status.includes('Out of Stock')) {
                statusEl.className = 'status-available';
                statusEl.style.color = '#dc3545';
            } else if (item.status && item.status.includes('Partial')) {
                statusEl.className = 'status-available';
                statusEl.style.color = '#ffc107';
            } else {
                statusEl.className = 'status-available';
                statusEl.style.color = '#28a745';
            }
            
            // Clear quantity input - picker must enter quantity manually
            const quantityInput = document.getElementById('quantity-input');
            quantityInput.value = ''; // Empty - picker must enter quantity
            quantityInput.max = item.available_quantity > 0 ? item.available_quantity : (parseInt(item.quantity_required) || 999999);
            quantityInput.min = 1;
            quantityInput.placeholder = `Enter quantity (Required: ${item.quantity_required || 0})`;
            quantityInput.style.background = 'white';
            quantityInput.style.borderColor = '#ddd';
            // Focus on quantity input after plate and item barcode are scanned
            setTimeout(() => {
                quantityInput.focus();
            }, 100);
            
            // Clear item barcode input and focus on plate first (if not scanned yet)
            document.getElementById('item-barcode-input').value = '';
            document.getElementById('item-barcode-input').style.background = 'white';
            document.getElementById('item-barcode-input').style.borderColor = '#ddd';
            
            // Focus on plate input if not scanned yet, otherwise focus on item barcode
            const plateInput = document.getElementById('plate-input');
            if (!plateInput.value.trim()) {
                setTimeout(() => {
                    plateInput.focus();
                }, 100);
            } else {
                setTimeout(() => {
            document.getElementById('item-barcode-input').focus();
                }, 100);
            }
        }
        
        // Handle virtual plate scanning - accept any virtual plate ID
        // Once scanned, same virtual plate is used for all items in this order
        // This is similar to receiving system where items are placed on a virtual plate
        document.getElementById('plate-input').addEventListener('input', function() {
            const scannedPlate = this.value.trim();
            
            if (scannedPlate) {
                // Virtual plate scanned - mark as green and move focus to item barcode
                this.style.background = '#e8f5e8';
                this.style.borderColor = '#28a745';
                // Auto-focus on item barcode after virtual plate is scanned
                setTimeout(() => {
                    document.getElementById('item-barcode-input').focus();
                }, 200);
            } else {
                this.style.background = 'white';
                this.style.borderColor = '#ddd';
            }
        });
        
        // Allow Enter key on plate input to move to item barcode
        document.getElementById('plate-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && this.value.trim()) {
            document.getElementById('item-barcode-input').focus();
        }
        });
        
        // Process item when barcode is scanned
        document.getElementById('item-barcode-input').addEventListener('input', function() {
            const itemBarcode = this.value.trim();
            
            if (itemBarcode && currentItem) {
                if (itemBarcode === currentItem.item_barcode) {
                this.style.background = '#e8f5e8';
                this.style.borderColor = '#28a745';
                    // Auto-submit if barcode matches (for barcode scanner)
                    setTimeout(() => {
                        if (this.value.trim() === currentItem.item_barcode) {
                            document.getElementById('confirm-btn').click();
                        }
                    }, 300);
                } else {
                    this.style.background = '#fff3cd';
                    this.style.borderColor = '#ffc107';
                    showMessage('Barcode does not match current item', 'error');
                }
            } else if (itemBarcode) {
                this.style.background = '#fff3cd';
                this.style.borderColor = '#ffc107';
            } else {
                this.style.background = 'white';
                this.style.borderColor = '#ddd';
            }
        });

        // Allow Enter key to confirm
        document.getElementById('item-barcode-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && this.value.trim()) {
                document.getElementById('confirm-btn').click();
            }
        });
        
        // Confirm button handler
        document.getElementById('confirm-btn').addEventListener('click', function() {
            const itemBarcode = document.getElementById('item-barcode-input').value.trim();
            const quantityInput = document.getElementById('quantity-input');
            const quantityValue = quantityInput.value.trim();
            const quantity = parseInt(quantityValue) || 0;
            const plateId = document.getElementById('plate-input').value.trim();
            
            if (!plateId) {
                showMessage('Please scan virtual plate barcode first', 'error');
                document.getElementById('plate-input').focus();
                return;
            }
            
            if (!itemBarcode) {
                showMessage('Please scan item barcode', 'error');
                document.getElementById('item-barcode-input').focus();
                return;
            }
            
            if (!quantityValue || quantity <= 0 || isNaN(quantity)) {
                showMessage('Please enter a valid quantity (number)', 'error');
                quantityInput.focus();
                quantityInput.select();
                return;
            }
            
            if (!currentItem || itemBarcode !== currentItem.item_barcode) {
                showMessage('Item barcode does not match the current item', 'error');
                return;
            }
            
            // Validate quantity doesn't exceed required
            const requiredQty = parseInt(currentItem.quantity_required) || 0;
            if (quantity > requiredQty) {
                showMessage(`Quantity (${quantity}) exceeds required quantity (${requiredQty})`, 'error');
                quantityInput.focus();
                quantityInput.select();
                return;
            }
            
            processItem(currentWorkId, itemBarcode, quantity, plateId);
        });

        // Cancel button handler
        document.getElementById('cancel-btn').addEventListener('click', function() {
            resetForm();
        });
        
        // Process item via AJAX
        function processItem(workId, itemBarcode, quantity, plateId) {
            const formData = new FormData();
            formData.append('work_id', workId);
            formData.append('item_barcode', itemBarcode);
            formData.append('quantity_picked', quantity);
            formData.append('target_lp', ''); // Empty target_lp
            formData.append('plate_id', plateId);
            
            // If location was overridden, pass the new location_code
            if (currentItem && currentItem.location_code) {
                formData.append('override_location_code', currentItem.location_code);
            }
            
            // Disable confirm button during processing
            const confirmBtn = document.getElementById('confirm-btn');
            confirmBtn.disabled = true;
            confirmBtn.textContent = 'Processing...';
            
            fetch('process_picking_item.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                confirmBtn.disabled = false;
                confirmBtn.textContent = 'OK';
                
                if (data.success) {
                    if (data.stock_warning) {
                        showMessage(data.message, 'warning');
                    } else {
                        showMessage(data.message || 'Item processed successfully', 'success');
                    }
                    // Reset form and load next item immediately
                    resetForm();
                    // Load next item immediately without delay
                    setTimeout(() => {
                        loadNextItem(workId);
                    }, 500);
                } else {
                    showMessage(data.message || 'Failed to process item', 'error');
                    // Re-enable inputs on error
                    document.getElementById('item-barcode-input').focus();
                }
            })
            .catch(error => {
                confirmBtn.disabled = false;
                confirmBtn.textContent = 'OK';
                console.error('Error:', error);
                showMessage('Failed to process item: ' + error.message, 'error');
                // Re-enable inputs on error
                document.getElementById('item-barcode-input').focus();
            });
        }
        
        // Load next item in the order
        function loadNextItem(workId) {
            fetch(`get_picking_order.php?work_id=${encodeURIComponent(workId)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.current_item) {
                        setCurrentItem(data.current_item);
                        // Update progress
                        const progressPercent = data.order.total_items > 0 ? (data.order.picked_items / data.order.total_items) * 100 : 0;
                        document.getElementById('progress-bar-fill').style.width = `${progressPercent}%`;
                        document.getElementById('progress-text').textContent = 
                            `${data.order.picked_items}/${data.order.total_items} items picked`;
                        // Focus on item barcode input for next item
                        setTimeout(() => {
                            document.getElementById('item-barcode-input').focus();
                        }, 200);
                    } else if (data.success) {
                        // All items picked - show area input
                        showMessage('All items in this order have been picked! Please scan area to place the prepared plate.', 'success');
                        showAreaInput(workId);
                    } else {
                        showMessage(data.message || 'Failed to load next item', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Failed to load next item', 'error');
                });
        }
        
        // Reset form fields (but keep plate_id - same plate for all items)
        function resetForm() {
            document.getElementById('item-barcode-input').value = '';
            document.getElementById('item-barcode-input').style.background = 'white';
            document.getElementById('item-barcode-input').style.borderColor = '#ddd';
            document.getElementById('quantity-input').value = '';
            document.getElementById('quantity-input').style.background = 'white';
            document.getElementById('quantity-input').style.borderColor = '#ddd';
            // Keep plate_id - don't clear it, same plate for all items in order
        }
        
        // Reset to work ID input (when order is complete)
        function resetToWorkIdInput() {
            document.getElementById('work-id-section').style.display = 'block';
            document.getElementById('order-progress').style.display = 'none';
            document.getElementById('location-field').style.display = 'none';
            document.getElementById('scanner-section').style.display = 'none';
            document.getElementById('item-info').style.display = 'none';
            document.getElementById('quantity-field').style.display = 'none';
            document.getElementById('action-buttons').style.display = 'none';
            document.getElementById('special-buttons').style.display = 'none';
            document.getElementById('seal-btn').style.display = 'none';
            document.getElementById('area-field').style.display = 'none';
            
            // Remove skip area button if exists
            const skipBtn = document.getElementById('skip-area-btn');
            if (skipBtn) {
                skipBtn.remove();
            }
            
            // Reset area label
            const areaLabel = document.querySelector('#area-field label');
            if (areaLabel) {
                areaLabel.textContent = 'Scan Area (Optional - will use default area for branch if empty)';
            }
            
            document.getElementById('work-id-input').value = '';
            document.getElementById('work-id-input').focus();
            currentWorkId = '';
            currentItem = null;
        }
        
        // Show area input when order is completed
        function showAreaInput(workId) {
            // Hide all picking fields
            document.getElementById('location-field').style.display = 'none';
            document.getElementById('scanner-section').style.display = 'none';
            document.getElementById('plate-field').style.display = 'none';
            document.getElementById('item-info').style.display = 'none';
            document.getElementById('quantity-field').style.display = 'none';
            document.getElementById('action-buttons').style.display = 'none';
            document.getElementById('special-buttons').style.display = 'none';
            
            // Show area field
            document.getElementById('area-field').style.display = 'block';
            document.getElementById('area-input').value = '';
            
            // Clear any existing event listeners and add new one
            const areaInput = document.getElementById('area-input');
            const newAreaInput = areaInput.cloneNode(true);
            areaInput.parentNode.replaceChild(newAreaInput, areaInput);
            
            // Focus on area input
            setTimeout(() => {
                document.getElementById('area-input').focus();
            }, 100);
            
            // Handle area scan (Enter key) or empty to use default
            document.getElementById('area-input').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    const areaValue = this.value.trim();
                    // If empty, use default area for branch (empty string will trigger default)
                    saveAreaForOrder(workId, areaValue);
                }
            });
            
            // Add a button to skip area input and use default
            const areaField = document.getElementById('area-field');
            let skipBtn = document.getElementById('skip-area-btn');
            if (skipBtn) {
                skipBtn.remove(); // Remove existing button if any
            }
            skipBtn = document.createElement('button');
            skipBtn.id = 'skip-area-btn';
            skipBtn.className = 'btn btn-ok';
            skipBtn.textContent = 'Use Default Area for Branch';
            skipBtn.style.width = '100%';
            skipBtn.style.marginTop = '10px';
            skipBtn.onclick = function() {
                saveAreaForOrder(workId, ''); // Empty area code = use default
            };
            areaField.appendChild(skipBtn);
        }
        
        // Save area for completed order (area can be empty to use default for branch)
        function saveAreaForOrder(workId, area) {
            // Area is optional - if empty, backend will use default area for branch
            
            const formData = new FormData();
            formData.append('work_id', workId);
            formData.append('area', area.trim());
            
            fetch('save_picking_area.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage(data.message || `Area '${area}' saved successfully!`, 'success');
                    document.getElementById('area-input').style.background = '#e8f5e8';
                    document.getElementById('area-input').style.borderColor = '#28a745';
                    
                    // Reset to work ID input after 2 seconds
                    // If there are remaining items, user can scan the same work ID again
                    setTimeout(() => {
                        resetToWorkIdInput();
                    }, 2000);
                } else {
                    showMessage(data.message || 'Failed to save area', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessage('Failed to save area', 'error');
            });
        }
        
        // Show message to user
        function showMessage(message, type) {
            const messageArea = document.getElementById('message-area');
            messageArea.innerHTML = `<div class="message ${type}">${message}</div>`;
            
            // Auto-hide success messages after 3 seconds
            if (type === 'success') {
                setTimeout(() => {
                    messageArea.innerHTML = '';
                }, 3000);
            }
        }
        
        // Input field focus effects
        const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.style.borderColor = '#2c3e50';
                this.style.background = '#f8f9fa';
            });
            
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.style.borderColor = '#ddd';
                    this.style.background = 'white';
                }
            });
        });

        // Quantity input validation
        document.getElementById('quantity-input').addEventListener('input', function() {
            if (this.value > 0) {
                this.style.background = '#e8f5e8';
                this.style.borderColor = '#28a745';
            } else {
                this.style.background = 'white';
                this.style.borderColor = '#ddd';
            }
        });
        
        // Special action buttons
        
        // Seal Plate button - close current plate and scan area
        document.getElementById('seal-btn').addEventListener('click', function() {
            if (!currentWorkId) {
                showMessage('No work order loaded', 'error');
                return;
            }
            
            const plateId = document.getElementById('plate-input').value.trim();
            if (!plateId) {
                showMessage('No plate is currently active', 'error');
                return;
            }
            
            if (confirm('Seal current plate? You will need to scan area for this plate, then scan the work ID again to continue with remaining items on a new plate.')) {
                sealPlate(currentWorkId, plateId);
            }
        });
        
        document.getElementById('skip-btn').addEventListener('click', function() {
            if (confirm('Are you sure you want to skip this item? It will be moved to the end of the order and picked after all other items.')) {
                if (currentWorkId && currentItem) {
                    // Move item to end of queue (will be picked last)
                    skipItem(currentWorkId, currentItem.item_barcode);
                }
            }
        });

        function skipItem(workId, itemBarcode) {
            const formData = new FormData();
            formData.append('work_id', workId);
            formData.append('item_barcode', itemBarcode);
            formData.append('action', 'skip');
            
            fetch('process_picking_item.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage(data.message || 'Item moved to end of queue', 'success');
                resetForm();
                    setTimeout(() => {
                        loadNextItem(workId);
                    }, 1000);
                } else {
                    showMessage(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessage('Failed to skip item', 'error');
            });
        }
        
        // Seal plate - close current plate, scan area, then allow new plate for remaining items
        function sealPlate(workId, plateId) {
            // Show area input to scan area for the current plate
            showAreaInputForSeal(workId, plateId);
        }
        
        // Show area input for sealing plate (optional - can skip and use default area for branch)
        function showAreaInputForSeal(workId, plateId) {
            // Hide all picking fields
            document.getElementById('location-field').style.display = 'none';
            document.getElementById('scanner-section').style.display = 'none';
            document.getElementById('plate-field').style.display = 'none';
            document.getElementById('item-info').style.display = 'none';
            document.getElementById('quantity-field').style.display = 'none';
            document.getElementById('action-buttons').style.display = 'none';
            document.getElementById('special-buttons').style.display = 'none';
            document.getElementById('seal-btn').style.display = 'none';
            
            // Show area field
            document.getElementById('area-field').style.display = 'block';
            document.getElementById('area-input').value = '';
            
            // Update label to indicate area is optional
            const areaLabel = document.querySelector('#area-field label');
            if (areaLabel) {
                areaLabel.textContent = 'Scan Area (Optional - will use default area for branch if empty)';
            }
            
            // Clear any existing event listeners and add new one
            const areaInput = document.getElementById('area-input');
            const newAreaInput = areaInput.cloneNode(true);
            areaInput.parentNode.replaceChild(newAreaInput, areaInput);
            
            // Focus on area input
            setTimeout(() => {
                document.getElementById('area-input').focus();
            }, 100);
            
            // Handle area scan for sealing plate (Enter key) or empty to use default
            document.getElementById('area-input').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    const areaValue = this.value.trim();
                    // If empty, use default area for branch (empty string will trigger default)
                    sealPlateWithArea(workId, plateId, areaValue);
                }
            });
            
            // Add a button to skip area input and use default
            const areaField = document.getElementById('area-field');
            let skipBtn = document.getElementById('skip-area-btn');
            if (!skipBtn) {
                skipBtn = document.createElement('button');
                skipBtn.id = 'skip-area-btn';
                skipBtn.className = 'btn btn-ok';
                skipBtn.textContent = 'Use Default Area for Branch';
                skipBtn.style.width = '100%';
                skipBtn.style.marginTop = '10px';
                skipBtn.onclick = function() {
                    sealPlateWithArea(workId, plateId, ''); // Empty area code = use default
                };
                areaField.appendChild(skipBtn);
            }
        }
        
        // Seal plate with area - remove plate_id from remaining items and save area (area can be empty to use default for branch)
        function sealPlateWithArea(workId, plateId, area) {
            // Area is optional - if empty, backend will use default area for branch
            
            const formData = new FormData();
            formData.append('work_id', workId);
            formData.append('plate_id', plateId);
            formData.append('area', area.trim());
            formData.append('action', 'seal_plate');
            
            fetch('process_picking_item.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage(data.message || `Plate '${plateId}' sealed and placed in area '${area}'. You can now scan the work ID again to continue with remaining items on a new plate.`, 'success');
                    document.getElementById('area-input').style.background = '#e8f5e8';
                    document.getElementById('area-input').style.borderColor = '#28a745';
                    
                    // Reset to work ID input after 2 seconds
                    setTimeout(() => {
                        resetToWorkIdInput();
                    }, 2000);
                } else {
                    showMessage(data.message || 'Failed to seal plate', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessage('Failed to seal plate', 'error');
            });
        }
        
        // Override location - show all available locations for this item
        document.getElementById('override-btn').addEventListener('click', function() {
            if (!currentItem || !currentItem.item_barcode) {
                showMessage('No item loaded', 'error');
                return;
            }
            
            // Load available locations for this item
            loadItemLocations(currentItem.item_barcode);
        });
        
        // Load available locations for an item from inventory
        function loadItemLocations(itemBarcode) {
            fetch(`get_item_locations.php?item_barcode=${encodeURIComponent(itemBarcode)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.locations && data.locations.length > 0) {
                        // Display modal with available locations from inventory
                        displayLocationModal(data.locations);
                    } else {
                        // Show error message from server or default message
                        const errorMsg = data.message || 'لا توجد مواقع متاحة لهذا العنصر في المستودع';
                        showMessage(errorMsg, 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('فشل تحميل المواقع المتاحة', 'error');
                });
        }
        
        // Display location selection modal
        function displayLocationModal(locations) {
            const container = document.getElementById('location-list-container');
            const currentLocation = document.getElementById('location-display').textContent;
            
            let html = '<ul class="location-list">';
            locations.forEach((loc, index) => {
                const isSelected = loc.full_location_code === currentLocation;
                const shelfInfo = loc.shelf_number !== null ? ` (Shelf ${loc.shelf_number})` : '';
                html += `
                    <li class="location-item ${isSelected ? 'selected' : ''}" 
                        onclick="selectLocation('${loc.location_code}', '${loc.zone}', '${loc.full_location_code}', ${loc.quantity})">
                        <div class="location-info">
                            <div>
                                <div class="location-code">${loc.full_location_code}</div>
                                <div class="location-details">${loc.location_code}${shelfInfo}</div>
                            </div>
                            <div class="location-quantity">Qty: ${loc.quantity}</div>
                        </div>
                    </li>
                `;
            });
            html += '</ul>';
            
            container.innerHTML = html;
            document.getElementById('location-modal').style.display = 'block';
        }
        
        // Select a location (override)
        function selectLocation(locationCode, zone, fullLocationCode, quantity) {
            // Update actual location (override)
            if (currentItem) {
                currentItem.actual_location = fullLocationCode;
                currentItem.actual_location_code = locationCode;
                currentItem.location_code = locationCode; // Update for processing
                currentItem.zone = zone;
                currentItem.full_location_code = fullLocationCode;
                currentItem.available_quantity = quantity;
            }
            
            // Update display - show actual location (overridden)
            document.getElementById('actual-location').textContent = fullLocationCode;
            
            // Close modal
            closeLocationModal();
            
            // Show success message
            showMessage(`Location overridden to: ${fullLocationCode} (Available: ${quantity} units)`, 'success');
        }
        
        // Close location modal
        function closeLocationModal() {
            document.getElementById('location-modal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('location-modal');
            if (event.target == modal) {
                closeLocationModal();
            }
        }
    </script>
</body>
</html>