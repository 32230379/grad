<?php
include 'db_connect.php';

// جلب بيانات السجل لتعديلها
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM inventory WHERE id = $id");
    $row = $result->fetch_assoc();
}

// تحديث السجل بعد التعديل
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $barcode = $_POST['item_barcode'];
    $location = $_POST['location_code'];
    $quantity = $_POST['quantity'];

    $stmt = $conn->prepare("UPDATE inventory SET item_barcode = ?, location_code = ?, quantity = ?, last_update = NOW() WHERE id = ?");
    $stmt->bind_param("ssii", $barcode, $location, $quantity, $id);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Record updated successfully'); window.location.href='manage_invuser.php';</script>";
    } else {
        echo "<script>alert('❌ Error while updating');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Inventory Record</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; text-align: center; }
        form { background: white; padding: 20px; border-radius: 10px; width: 350px; margin: 50px auto; box-shadow: 0 0 10px rgba(0,0,0,0.2); }
        input { width: 90%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 5px; }
        button { padding: 10px 20px; border: none; background: #007bff; color: white; border-radius: 5px; cursor: pointer; }
        button:hover { background: #0056b3; }
    </style>
</head>
<body>
    <h2>✏️ Edit Inventory Record</h2>
    <form method="POST">
        <input type="hidden" name="id" value="<?= $row['id'] ?>">
        <input type="text" name="item_barcode" value="<?= htmlspecialchars($row['item_barcode']) ?>" required>
        <input type="text" name="location_code" value="<?= htmlspecialchars($row['location_code']) ?>" placeholder="rack-shelf (e.g., 1-0, 2-3)" pattern="[0-9]+-[0-9]+" title="Format: rack-shelf (e.g., 1-0, 2-3)" required>
        <input type="number" name="quantity" value="<?= $row['quantity'] ?>" required>
        <button type="submit">Update</button>
    </form>
</body>
</html>
