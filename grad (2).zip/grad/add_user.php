<?php
include "db_connect.php";

// Check and update users table to include 'house keeper' role if not exists
$check_enum = $conn->query("SHOW COLUMNS FROM users WHERE Field = 'role'");
if ($check_enum && $row = $check_enum->fetch_assoc()) {
    $enum_values = $row['Type'];
    if (strpos($enum_values, 'house keeper') === false) {
        // Add 'house keeper' to enum
        $conn->query("ALTER TABLE `users` MODIFY COLUMN `role` enum('manager','receiver','loader','picker','quantity controller','putaway','house keeper') NOT NULL");
    }
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $plain_password = $_POST['password']; // النسخة العادية للتحقق من التكرار
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    // التحقق إذا كلمة السر نفسها موجودة مسبقاً
    $check = mysqli_query($conn, "SELECT * FROM users");
    $passwordExists = false;

    while ($row = mysqli_fetch_assoc($check)) {
        if (password_verify($plain_password, $row['password'])) {
            $passwordExists = true;
            break;
        }
    }

    if ($passwordExists) {
        $message = "<p style='color:red;'>Password already exists! Please choose another one.</p>";
    } else {
        $sql = "INSERT INTO users (name, password, role)
                VALUES ('$name', '$password', '$role')";
        if (mysqli_query($conn, $sql)) {
            $message = "<p style='color:green;'>User added successfully!</p>";
        } else {
            $message = "<p style='color:red;'>Error: " . mysqli_error($conn) . "</p>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add User</title>
  <style>
    body {
      font-family: Poppins, sans-serif;
      background: linear-gradient(135deg, #f5f9ff 0%, #e8f4fd 100%);
    }
    .form-box {
      background: #fff;
      padding: 25px 30px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      width: 350px;
      margin: 20px auto;
    }
    h2 { text-align: center; color: #333; }
    label { font-weight: 600; margin-top: 10px; display: block; }
    input, select {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 6px;
    }
    button {
      width: 100%;
      padding: 10px;
      background: #007bff;
      color: #fff;
      border: none;
      border-radius: 6px;
      margin-top: 15px;
      cursor: pointer;
      font-weight: bold;
    }
    button:hover { background: #0056b3; }
    p { text-align: center; font-size: 14px; }
  </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <div class="main-content">
<div class="form-box">
  <h2>Add New Employee</h2>
  <?php echo $message; ?>
  <form method="POST">
    <label>Name</label>
    <input type="text" name="name" required>

    <label>Password</label>
    <input type="password" name="password" required>

    <label>Role</label>
    <select name="role" required>
      <option value="manager">Manager</option>
      <option value="receiver">Receiver</option>
      <option value="loader">Loader</option>
      <option value="picker">Picker</option>
      <option value="putaway">Putaway</option>
      <option value="quantity controller">Quantity Controller</option>
      <option value="house keeper">House Keeper</option>
    </select>

    <button type="submit">Add User</button>
  </form>
</div>
        </div>
    </div>
</body>
</html>
