<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warehouse Management System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background: #f5f5f5;
            padding: 40px 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 40px;
            font-size: 28px;
        }
        .buttons {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .btn {
            display: block;
            padding: 15px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            text-align: center;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #0056b3;
        }
        .login-section {
            margin-top: 30px;
            padding-top: 30px;
            border-top: 1px solid #ddd;
            text-align: center;
        }
        .login-btn {
            display: inline-block;
            padding: 12px 30px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
        }
        .login-btn:hover {
            background: #5a6268;
        }
        .locate-section {
            margin-top: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .locate-section h2 {
            margin-bottom: 15px;
            color: #333;
            font-size: 20px;
        }
        .locate-input-group {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }
        .locate-input-group input {
            flex: 1;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .locate-input-group input:focus {
            outline: none;
            border-color: #007bff;
        }
        .locate-btn {
            padding: 12px 20px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
        }
        .locate-btn:hover {
            background: #218838;
        }
        .locations-result {
            margin-top: 15px;
            display: none;
        }
        .locations-list {
            list-style: none;
            padding: 0;
        }
        .location-item {
            background: white;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .location-info {
            flex: 1;
        }
        .location-code {
            font-weight: bold;
            font-size: 18px;
            color: #007bff;
            margin-bottom: 5px;
        }
        .location-details {
            color: #666;
            font-size: 14px;
        }
        .location-quantity {
            font-weight: bold;
            color: #28a745;
            font-size: 16px;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 5px;
            margin-top: 15px;
            display: none;
        }
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 5px;
            margin-top: 15px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Warehouse Management System</h1>
        
        <div class="buttons">
            <a href="login.php?role=receiver" class="btn">Receiver</a>
            <a href="login.php?role=picker" class="btn">Picker</a>
            <a href="login.php?role=loader" class="btn">Loader</a>
            <a href="login.php?role=quantity controller" class="btn">Quality Controller (QC)</a>
            <a href="login.php?role=putaway" class="btn">Putaway</a>
            <a href="login.php?role=house keeper" class="btn">House Keeper</a>
        </div>
        
        <div class="locate-section">
            <button class="btn" id="locate-item-btn" onclick="showLocateInput()" style="background: #28a745; margin-bottom: 15px;">
                Locate Item
            </button>
            <div id="locate-input-container" style="display: none;">
                <h2>Locate Item</h2>
                <div class="locate-input-group">
                    <input type="text" id="item-barcode-input" placeholder="Scan or enter item barcode" autofocus>
                    <button class="locate-btn" onclick="locateItem()">Locate</button>
                </div>
                <div id="error-message" class="error-message"></div>
                <div id="success-message" class="success-message"></div>
                <div id="locations-result" class="locations-result">
                    <h3 style="margin-bottom: 15px; color: #333;">Available Locations:</h3>
                    <ul id="locations-list" class="locations-list"></ul>
                </div>
            </div>
        </div>
        
        <div class="locate-section" style="margin-top: 20px;">
            <button class="btn" id="plate-content-btn" onclick="showPlateContentInput()" style="background: #17a2b8; margin-bottom: 15px;">
                Plate ID Content
            </button>
            <div id="plate-content-container" style="display: none;">
                <h2>Plate ID Content</h2>
                <div class="locate-input-group">
                    <input type="text" id="plate-id-input" placeholder="Scan or enter plate ID" autofocus>
                    <button class="locate-btn" onclick="getPlateContent()">Check</button>
                </div>
                <div id="plate-error-message" class="error-message"></div>
                <div id="plate-success-message" class="success-message"></div>
                <div id="plate-content-result" class="locations-result">
                    <div id="plate-info" style="margin-bottom: 15px; padding: 15px; background: #e9ecef; border-radius: 5px; display: none;">
                        <h3 style="margin-bottom: 10px; color: #333;">Plate Information:</h3>
                        <div id="plate-info-details"></div>
                    </div>
                    <h3 style="margin-bottom: 15px; color: #333;">Items Prepared:</h3>
                    <ul id="plate-items-list" class="locations-list"></ul>
                </div>
            </div>
        </div>
        
        <div class="login-section">
            <?php if (!isset($_SESSION['user_name'])): ?>
                <a href="login.php" class="login-btn">Login</a>
            <?php else: ?>
                <a href="warehouseM.php" class="login-btn">Manager Dashboard</a>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Track if Enter listener has been added
        let enterListenerAdded = false;

        // Show locate input when button is clicked
        function showLocateInput() {
            document.getElementById('locate-item-btn').style.display = 'none';
            document.getElementById('locate-input-container').style.display = 'block';
            // Focus on input after a short delay
            setTimeout(() => {
                const input = document.getElementById('item-barcode-input');
                input.focus();
                // Add Enter key listener only once
                if (!enterListenerAdded) {
                    input.addEventListener('keypress', function(e) {
                        if (e.key === 'Enter') {
                            locateItem();
                        }
                    });
                    enterListenerAdded = true;
                }
            }, 100);
        }

        function locateItem() {
            const itemBarcode = document.getElementById('item-barcode-input').value.trim();
            const errorDiv = document.getElementById('error-message');
            const successDiv = document.getElementById('success-message');
            const resultDiv = document.getElementById('locations-result');
            const locationsList = document.getElementById('locations-list');

            // Hide previous messages
            errorDiv.style.display = 'none';
            successDiv.style.display = 'none';
            resultDiv.style.display = 'none';

            if (!itemBarcode) {
                errorDiv.textContent = 'Please enter or scan item barcode';
                errorDiv.style.display = 'block';
                return;
            }

            // Fetch locations from API
            fetch(`get_item_locations.php?item_barcode=${encodeURIComponent(itemBarcode)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.locations && data.locations.length > 0) {
                        // Display locations
                        displayLocations(data.locations, itemBarcode);
                        successDiv.textContent = `Found ${data.locations.length} location(s) for item: ${itemBarcode}`;
                        successDiv.style.display = 'block';
                    } else {
                        errorDiv.textContent = data.message || `Item '${itemBarcode}' not found in inventory or out of stock`;
                        errorDiv.style.display = 'block';
                        locationsList.innerHTML = '';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    errorDiv.textContent = 'Failed to load locations. Please try again.';
                    errorDiv.style.display = 'block';
                    locationsList.innerHTML = '';
                });
        }

        function displayLocations(locations, itemBarcode) {
            const locationsList = document.getElementById('locations-list');
            const resultDiv = document.getElementById('locations-result');

            let html = '';
            locations.forEach((loc) => {
                const shelfInfo = loc.shelf_number !== null ? ` (Shelf ${loc.shelf_number})` : '';
                html += `
                    <li class="location-item">
                        <div class="location-info">
                            <div class="location-code">${loc.full_location_code || (loc.zone + '-' + loc.location_code)}</div>
                            <div class="location-details">${loc.location_code}${shelfInfo}</div>
                        </div>
                        <div class="location-quantity">Qty: ${loc.quantity}</div>
                    </li>
                `;
            });

            locationsList.innerHTML = html;
            resultDiv.style.display = 'block';

            // Clear input and refocus for next scan
            document.getElementById('item-barcode-input').value = '';
            setTimeout(() => {
                document.getElementById('item-barcode-input').focus();
            }, 100);
        }

        // Track if Enter listener has been added for plate content
        let plateEnterListenerAdded = false;

        // Show plate content input when button is clicked
        function showPlateContentInput() {
            document.getElementById('plate-content-btn').style.display = 'none';
            document.getElementById('plate-content-container').style.display = 'block';
            // Focus on input after a short delay
            setTimeout(() => {
                const input = document.getElementById('plate-id-input');
                input.focus();
                // Add Enter key listener only once
                if (!plateEnterListenerAdded) {
                    input.addEventListener('keypress', function(e) {
                        if (e.key === 'Enter') {
                            getPlateContent();
                        }
                    });
                    plateEnterListenerAdded = true;
                }
            }, 100);
        }

        function getPlateContent() {
            const plateId = document.getElementById('plate-id-input').value.trim();
            const errorDiv = document.getElementById('plate-error-message');
            const successDiv = document.getElementById('plate-success-message');
            const resultDiv = document.getElementById('plate-content-result');
            const itemsList = document.getElementById('plate-items-list');
            const plateInfo = document.getElementById('plate-info');
            const plateInfoDetails = document.getElementById('plate-info-details');

            // Hide previous messages
            errorDiv.style.display = 'none';
            successDiv.style.display = 'none';
            resultDiv.style.display = 'none';
            plateInfo.style.display = 'none';

            if (!plateId) {
                errorDiv.textContent = 'Please enter or scan plate ID';
                errorDiv.style.display = 'block';
                return;
            }

            // Fetch plate content from API
            fetch(`get_plate_content.php?plate_id=${encodeURIComponent(plateId)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.items && data.items.length > 0) {
                        // Display plate information
                        plateInfoDetails.innerHTML = `
                            <div><strong>Plate ID:</strong> ${data.plate_id}</div>
                            <div><strong>Work ID:</strong> ${data.work_id || 'N/A'}</div>
                            <div><strong>Branch:</strong> ${data.branch || 'N/A'}</div>
                            <div><strong>Area:</strong> ${data.area || 'N/A'}</div>
                            <div><strong>Picker:</strong> ${data.picker_name || 'System'}</div>
                            <div><strong>Total Items:</strong> ${data.total_items}</div>
                            <div><strong>Total Quantity:</strong> ${data.total_quantity}</div>
                            <div><strong>First Picked:</strong> ${data.first_picked_at ? new Date(data.first_picked_at).toLocaleString() : 'N/A'}</div>
                            <div><strong>Last Picked:</strong> ${data.last_picked_at ? new Date(data.last_picked_at).toLocaleString() : 'N/A'}</div>
                        `;
                        plateInfo.style.display = 'block';

                        // Display items
                        displayPlateItems(data.items);
                        successDiv.textContent = `Found ${data.items.length} item(s) on plate: ${plateId}`;
                        successDiv.style.display = 'block';
                        resultDiv.style.display = 'block';
                    } else {
                        errorDiv.textContent = data.message || `No items found on plate '${plateId}'`;
                        errorDiv.style.display = 'block';
                        itemsList.innerHTML = '';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    errorDiv.textContent = 'Failed to load plate content. Please try again.';
                    errorDiv.style.display = 'block';
                    itemsList.innerHTML = '';
                });
        }

        function displayPlateItems(items) {
            const itemsList = document.getElementById('plate-items-list');

            let html = '';
            items.forEach((item) => {
                const pickedDate = item.picked_at ? new Date(item.picked_at).toLocaleString() : 'N/A';
                html += `
                    <li class="location-item">
                        <div class="location-info">
                            <div>
                                <div class="location-code">${item.item_barcode}</div>
                                <div class="location-details">${item.description || 'No description'}</div>
                                <div style="font-size: 12px; color: #999; margin-top: 5px;">
                                    Location: ${item.location_code || 'N/A'} | Picked: ${pickedDate}
                                </div>
                            </div>
                            <div class="location-quantity">Qty: ${item.quantity_picked}</div>
                        </div>
                    </li>
                `;
            });

            itemsList.innerHTML = html;

            // Clear input and refocus for next scan
            document.getElementById('plate-id-input').value = '';
            setTimeout(() => {
                document.getElementById('plate-id-input').focus();
            }, 100);
        }
    </script>
</body>
</html>

