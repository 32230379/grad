<?php
include 'db_connect.php';

// Handle approve/reject transfer order
if (isset($_GET['action']) && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $order_id = intval($_GET['id']);
    $action = $_GET['action'];
    
    if ($action === 'approve') {
        $update_stmt = $conn->prepare("UPDATE picking_orders SET status = 'in_progress' WHERE id = ?");
        $update_stmt->bind_param("i", $order_id);
        if ($update_stmt->execute()) {
            $message = "<div class='alert alert-success'>Transfer order approved successfully!</div>";
        } else {
            $message = "<div class='alert alert-error'>Error approving order: " . $conn->error . "</div>";
        }
        $update_stmt->close();
    } elseif ($action === 'reject') {
        $update_stmt = $conn->prepare("UPDATE picking_orders SET status = 'cancelled' WHERE id = ?");
        $update_stmt->bind_param("i", $order_id);
        if ($update_stmt->execute()) {
            $message = "<div class='alert alert-success'>Transfer order rejected successfully!</div>";
        } else {
            $message = "<div class='alert alert-error'>Error rejecting order: " . $conn->error . "</div>";
        }
        $update_stmt->close();
    } elseif ($action === 'complete') {
        $update_stmt = $conn->prepare("UPDATE picking_orders SET status = 'completed' WHERE id = ?");
        $update_stmt->bind_param("i", $order_id);
        if ($update_stmt->execute()) {
            $message = "<div class='alert alert-success'>Transfer order marked as completed!</div>";
        } else {
            $message = "<div class='alert alert-error'>Error completing order: " . $conn->error . "</div>";
        }
        $update_stmt->close();
    }
}

// Get all transfer orders (picking orders) with QC status
$orders_query = "
    SELECT 
        po.id,
        po.work_id,
        po.branch,
        po.status,
        po.created_at,
        po.updated_at,
        COUNT(DISTINCT poi.id) as item_count,
        COALESCE(SUM(poi.quantity_required), 0) as total_quantity,
        COALESCE(SUM(CASE WHEN poi.status = 'picked' THEN 1 ELSE 0 END), 0) as picked_items,
        COALESCE(SUM(CASE WHEN poi.status = 'pending' THEN 1 ELSE 0 END), 0) as pending_items,
        COUNT(DISTINCT CASE WHEN poi.plate_id IS NOT NULL AND poi.plate_id != '' THEN poi.plate_id END) as total_plates,
        COUNT(DISTINCT CASE WHEN pv.plate_status IN ('verified', 'ready_to_load', 'loaded') THEN poi.plate_id END) as qc_verified_plates
    FROM picking_orders po
    LEFT JOIN picking_order_items poi ON po.work_id = poi.work_id
    LEFT JOIN plate_verifications pv ON poi.plate_id = pv.plate_id
    GROUP BY po.id
    ORDER BY po.created_at DESC
";
$orders_result = $conn->query($orders_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transfer Orders - Warehouse System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background: linear-gradient(135deg, #f5f9ff 0%, #e8f4fd 100%);
            color: #333;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #2c3e50;
        }
        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }
        .header-actions {
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #3498db;
            color: white;
        }
        .btn-primary:hover {
            background: #2980b9;
        }
        .btn-secondary {
            background: #95a5a6;
            color: white;
        }
        .btn-secondary:hover {
            background: #7f8c8d;
        }
        .btn-success {
            background: #27ae60;
            color: white;
        }
        .btn-success:hover {
            background: #229954;
        }
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        .btn-danger:hover {
            background: #c0392b;
        }
        .btn-warning {
            background: #f39c12;
            color: white;
        }
        .btn-warning:hover {
            background: #e67e22;
        }
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .filters {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .filter-group {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filter-group label {
            font-weight: 500;
        }
        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-card h3 {
            font-size: 32px;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        .stat-card p {
            color: #666;
            font-size: 14px;
        }
        .content-section {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: #2c3e50;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .status {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-in_progress { background: #d1ecf1; color: #0c5460; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        .action-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-approve {
            background: #27ae60;
            color: white;
        }
        .btn-approve:hover {
            background: #229954;
        }
        .btn-reject {
            background: #e74c3c;
            color: white;
        }
        .btn-reject:hover {
            background: #c0392b;
        }
        .btn-view {
            background: #3498db;
            color: white;
        }
        .btn-view:hover {
            background: #2980b9;
        }
        .btn-qc {
            background: #9b59b6;
            color: white;
        }
        .btn-qc:hover {
            background: #8e44ad;
        }
        .btn-print {
            background: #28a745;
            color: white;
        }
        .btn-print:hover {
            background: #218838;
        }
        .btn-complete {
            background: #f39c12;
            color: white;
        }
        .btn-complete:hover {
            background: #e67e22;
        }
        .no-data {
            text-align: center;
            padding: 40px;
            color: #999;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #3498db;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e0e0e0;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 5px;
        }
        .progress-fill {
            height: 100%;
            background: #27ae60;
            transition: width 0.3s;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <div class="main-content">
    <div class="container">
        
        <div class="header">
            <h1>🔄 Transfer Orders</h1>
            <div class="header-actions">
                <a href="print_all_work.php" class="btn btn-primary" target="_blank">🖨️ Print All Work</a>
                <a href="warehouseM.php" class="btn btn-secondary">📊 Dashboard</a>
            </div>
        </div>

        <?php if (isset($message)) echo $message; ?>

        <?php
        // Count orders by status
        $status_counts = [
            'pending' => 0,
            'in_progress' => 0,
            'completed' => 0,
            'cancelled' => 0
        ];
        $total_orders = 0;
        
        if ($orders_result && $orders_result->num_rows > 0) {
            mysqli_data_seek($orders_result, 0);
            while ($row = $orders_result->fetch_assoc()) {
                $total_orders++;
                $status = $row['status'];
                if (isset($status_counts[$status])) {
                    $status_counts[$status]++;
                }
            }
        }
        ?>

        <!-- Statistics Cards -->
        <div class="stats-cards">
            <div class="stat-card">
                <h3><?php echo $total_orders; ?></h3>
                <p>Total Orders</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $status_counts['pending']; ?></h3>
                <p>Pending</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $status_counts['in_progress']; ?></h3>
                <p>In Progress</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $status_counts['completed']; ?></h3>
                <p>Completed</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $status_counts['cancelled']; ?></h3>
                <p>Cancelled</p>
            </div>
        </div>

        <!-- Filters -->
        <div class="filters">
            <div class="filter-group">
                <label>Search Work ID:</label>
                <input type="text" id="work-id-filter" placeholder="Enter Work ID..." onkeyup="filterTable()" style="padding: 8px 12px; border: 2px solid #dee2e6; border-radius: 5px; font-size: 14px; width: 200px;">
                <label>Filter by Status:</label>
                <select id="status-filter" onchange="filterTable()">
                    <option value="all">All Status</option>
                    <option value="pending">Pending</option>
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                </select>
                <label>Filter by Branch:</label>
                <select id="branch-filter" onchange="filterTable()">
                    <option value="all">All Branches</option>
                    <?php
                    $branch_query = "SELECT DISTINCT branch FROM picking_orders WHERE branch IS NOT NULL ORDER BY branch";
                    $branch_result = $conn->query($branch_query);
                    while ($branch = $branch_result->fetch_assoc()) {
                        echo "<option value='" . htmlspecialchars($branch['branch']) . "'>" . htmlspecialchars($branch['branch']) . "</option>";
                    }
                    ?>
                </select>
            </div>
        </div>

        <!-- Orders Table -->
        <div class="content-section">
            <div class="section-header">
                <h2 class="section-title">All Transfer Orders</h2>
                <a href="print_all_work.php" class="btn btn-primary" target="_blank">🖨️ Print All Work</a>
            </div>
            <div class="table-container">
                <table id="orders-table">
                    <thead>
                        <tr>
                            <th>Work ID</th>
                            <th>Branch</th>
                            <th>Items</th>
                            <th>Total Quantity</th>
                            <th>Progress</th>
                            <th>QC Status</th>
                            <th>Status</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($orders_result && $orders_result->num_rows > 0) {
                            mysqli_data_seek($orders_result, 0);
                            while ($order = $orders_result->fetch_assoc()) {
                                $progress = $order['item_count'] > 0 ? round(($order['picked_items'] / $order['item_count']) * 100) : 0;
                                $status_class = 'status-' . $order['status'];
                                $status_display = ucwords(str_replace('_', ' ', $order['status']));
                                
                                // Calculate QC status
                                $total_plates = intval($order['total_plates'] ?? 0);
                                $qc_verified_plates = intval($order['qc_verified_plates'] ?? 0);
                                $qc_progress = $total_plates > 0 ? round(($qc_verified_plates / $total_plates) * 100) : 0;
                                
                                // Determine QC status display
                                if ($total_plates == 0) {
                                    $qc_status_display = "Not Started";
                                    $qc_status_class = "status-pending";
                                } elseif ($qc_verified_plates == 0) {
                                    $qc_status_display = "Pending";
                                    $qc_status_class = "status-pending";
                                } elseif ($qc_verified_plates < $total_plates) {
                                    $qc_status_display = "In Progress";
                                    $qc_status_class = "status-in_progress";
                                } else {
                                    $qc_status_display = "Completed";
                                    $qc_status_class = "status-completed";
                                }
                                
                                echo "<tr data-status='{$order['status']}' data-branch='" . htmlspecialchars($order['branch'] ?? '') . "' data-work-id='" . htmlspecialchars($order['work_id']) . "'>";
                                echo "<td><strong>{$order['work_id']}</strong></td>";
                                echo "<td>" . htmlspecialchars($order['branch'] ?? '-') . "</td>";
                                echo "<td>" . intval($order['item_count'] ?? 0) . " items</td>";
                                echo "<td>" . intval($order['total_quantity'] ?? 0) . "</td>";
                                echo "<td>";
                                echo "<div class='progress-bar'><div class='progress-fill' style='width: {$progress}%'></div></div>";
                                echo "<small>" . intval($order['picked_items'] ?? 0) . "/" . intval($order['item_count'] ?? 0) . " picked ({$progress}%)</small>";
                                echo "</td>";
                                echo "<td>";
                                if ($total_plates > 0) {
                                    echo "<div class='progress-bar'><div class='progress-fill' style='width: {$qc_progress}%'></div></div>";
                                    echo "<small>" . $qc_verified_plates . "/" . $total_plates . " plates verified ({$qc_progress}%)</small>";
                                    echo "<br><span class='status {$qc_status_class}' style='margin-top: 5px; display: inline-block;'>{$qc_status_display}</span>";
                                } else {
                                    echo "<span class='status {$qc_status_class}'>{$qc_status_display}</span>";
                                }
                                echo "</td>";
                                echo "<td><span class='status {$status_class}'>{$status_display}</span></td>";
                                echo "<td>" . date('Y-m-d H:i', strtotime($order['created_at'])) . "</td>";
                                echo "<td>" . date('Y-m-d H:i', strtotime($order['updated_at'])) . "</td>";
                                echo "<td>";
                                echo "<div class='action-buttons'>";
                                echo "<a href='view_order_details.php?work_id={$order['work_id']}' class='action-btn btn-view'>👁️ View</a>";
                                echo "<a href='view_order_details.php?work_id={$order['work_id']}&print=1' class='action-btn btn-print' target='_blank'>🖨️ Print</a>";
                                
                                // QC View button - show if there are plates
                                if ($total_plates > 0) {
                                    echo "<a href='view_qc_details.php?work_id={$order['work_id']}' class='action-btn btn-qc' title='View QC Details'>🔍 QC View</a>";
                                }
                                
                                if ($order['status'] === 'pending') {
                                    echo "<a href='transfer_orders.php?action=approve&id={$order['id']}' class='action-btn btn-approve' onclick=\"return confirm('Approve this transfer order?')\">✅ Approve</a>";
                                    echo "<a href='transfer_orders.php?action=reject&id={$order['id']}' class='action-btn btn-reject' onclick=\"return confirm('Reject this transfer order?')\">❌ Reject</a>";
                                } elseif ($order['status'] === 'in_progress') {
                                    if ($order['picked_items'] == $order['item_count'] && $order['item_count'] > 0) {
                                        echo "<a href='transfer_orders.php?action=complete&id={$order['id']}' class='action-btn btn-complete' onclick=\"return confirm('Mark this order as completed?')\">✅ Complete</a>";
                                    }
                                }
                                
                                echo "</div>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='10' class='no-data'>No transfer orders found. <a href='add_picking_order.php'>Create a new order</a></td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function filterTable() {
            const statusFilter = document.getElementById('status-filter').value;
            const branchFilter = document.getElementById('branch-filter').value;
            const workIdFilter = document.getElementById('work-id-filter').value.trim().toLowerCase();
            const rows = document.querySelectorAll('#orders-table tbody tr');
            
            rows.forEach(row => {
                const status = row.getAttribute('data-status');
                const branch = row.getAttribute('data-branch');
                const workId = (row.getAttribute('data-work-id') || '').toLowerCase();
                
                let show = true;
                
                if (statusFilter !== 'all' && status !== statusFilter) {
                    show = false;
                }
                
                if (branchFilter !== 'all' && branch !== branchFilter) {
                    show = false;
                }
                
                if (workIdFilter && !workId.includes(workIdFilter)) {
                    show = false;
                }
                
                row.style.display = show ? '' : 'none';
            });
        }
    </script>
        </div>
    </div>
</body>
</html>
<?php
$conn->close();
?>

