<?php
include 'db_connect.php';

// Handle delete user
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $user_id = intval($_GET['delete']);
    
    // Check if user exists
    $check_stmt = $conn->prepare("SELECT name FROM users WHERE id = ?");
    $check_stmt->bind_param("i", $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $user_name = $check_result->fetch_assoc()['name'];
        $check_stmt->close();
        
        // Delete user
        $delete_stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $delete_stmt->bind_param("i", $user_id);
        if ($delete_stmt->execute()) {
            $message = "<div class='alert alert-success'>User '{$user_name}' deleted successfully!</div>";
        } else {
            $message = "<div class='alert alert-error'>Error deleting user: " . $conn->error . "</div>";
        }
        $delete_stmt->close();
    } else {
        $message = "<div class='alert alert-error'>User not found!</div>";
        $check_stmt->close();
    }
}

// Get all users
$users_query = "SELECT id, name, role FROM users ORDER BY role, name";
$users_result = $conn->query($users_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Warehouse System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background: linear-gradient(135deg, #f5f9ff 0%, #e8f4fd 100%);
            color: #333;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #2c3e50;
        }
        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }
        .header-actions {
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #3498db;
            color: white;
        }
        .btn-primary:hover {
            background: #2980b9;
        }
        .btn-secondary {
            background: #95a5a6;
            color: white;
        }
        .btn-secondary:hover {
            background: #7f8c8d;
        }
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        .btn-danger:hover {
            background: #c0392b;
        }
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-card h3 {
            font-size: 32px;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        .stat-card p {
            color: #666;
            font-size: 14px;
        }
        .content-section {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: #2c3e50;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .role-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .role-manager { background: #e3f2fd; color: #1976d2; }
        .role-receiver { background: #e8f5e9; color: #388e3c; }
        .role-loader { background: #fff3e0; color: #f57c00; }
        .role-picker { background: #f3e5f5; color: #7b1fa2; }
        .role-quantity { background: #e0f2f1; color: #00796b; }
        .role-putaway { background: #fce4ec; color: #c2185b; }
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        .action-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }
        .btn-edit {
            background: #3498db;
            color: white;
        }
        .btn-edit:hover {
            background: #2980b9;
        }
        .btn-delete {
            background: #e74c3c;
            color: white;
        }
        .btn-delete:hover {
            background: #c0392b;
        }
        .no-data {
            text-align: center;
            padding: 40px;
            color: #999;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #3498db;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <div class="main-content">
    <div class="container">
        
        <div class="header">
            <h1>👥 User Management</h1>
            <div class="header-actions">
                <a href="add_user.php" class="btn btn-primary">➕ Add New User</a>
                <a href="warehouseM.php" class="btn btn-secondary">📊 Dashboard</a>
            </div>
        </div>

        <?php if (isset($message)) echo $message; ?>

        <?php
        // Count users by role
        $role_counts = [];
        $total_users = 0;
        if ($users_result && $users_result->num_rows > 0) {
            mysqli_data_seek($users_result, 0); // Reset pointer
            while ($row = $users_result->fetch_assoc()) {
                $total_users++;
                $role = $row['role'];
                if (!isset($role_counts[$role])) {
                    $role_counts[$role] = 0;
                }
                $role_counts[$role]++;
            }
        }
        ?>

        <!-- Statistics Cards -->
        <div class="stats-cards">
            <div class="stat-card">
                <h3><?php echo $total_users; ?></h3>
                <p>Total Users</p>
            </div>
            <?php
            $role_labels = [
                'manager' => 'Managers',
                'receiver' => 'Receivers',
                'loader' => 'Loaders',
                'picker' => 'Pickers',
                'quantity controller' => 'QC Controllers',
                'putaway' => 'Putaway Staff'
            ];
            foreach ($role_labels as $role => $label) {
                $count = isset($role_counts[$role]) ? $role_counts[$role] : 0;
                echo "<div class='stat-card'>";
                echo "<h3>{$count}</h3>";
                echo "<p>{$label}</p>";
                echo "</div>";
            }
            ?>
        </div>

        <!-- Users Table -->
        <div class="content-section">
            <div class="section-header">
                <h2 class="section-title">All Users</h2>
                <a href="add_user.php" class="btn btn-primary">➕ Add User</a>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Role</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($users_result && $users_result->num_rows > 0) {
                            mysqli_data_seek($users_result, 0); // Reset pointer
                            while ($user = $users_result->fetch_assoc()) {
                                $role_class = 'role-' . str_replace(' ', '-', $user['role']);
                                $role_display = ucwords($user['role']);
                                echo "<tr>";
                                echo "<td>{$user['id']}</td>";
                                echo "<td><strong>{$user['name']}</strong></td>";
                                echo "<td><span class='role-badge {$role_class}'>{$role_display}</span></td>";
                                echo "<td>";
                                echo "<div class='action-buttons'>";
                                echo "<button class='action-btn btn-edit' onclick=\"editUser({$user['id']}, '{$user['name']}', '{$user['role']}')\">✏️ Edit</button>";
                                echo "<button class='action-btn btn-delete' onclick=\"deleteUser({$user['id']}, '{$user['name']}')\">🗑️ Delete</button>";
                                echo "</div>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='4' class='no-data'>No users found. <a href='add_user.php'>Add a new user</a></td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
        </div>
    </div>

    <script>
        function deleteUser(userId, userName) {
            if (confirm(`Are you sure you want to delete user "${userName}"?\n\nThis action cannot be undone!`)) {
                window.location.href = `user_management.php?delete=${userId}`;
            }
        }

        function editUser(userId, userName, userRole) {
            window.location.href = `edit_user.php?id=${userId}`;
        }
    </script>
</body>
</html>
<?php
$conn->close();
?>




















