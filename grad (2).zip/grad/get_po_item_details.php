<?php
session_start();
header('Content-Type: application/json');
include 'db_connect.php';

if (!isset($_GET['po_id']) || !isset($_GET['item_barcode'])) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

$po_id = intval($_GET['po_id']);
$item_barcode = trim($_GET['item_barcode']);

// Get PO item details
$query = "
    SELECT 
        poi.id,
        poi.item_barcode,
        poi.quantity_ordered,
        COALESCE(poi.quantity_received, 0) as quantity_received,
        (poi.quantity_ordered - COALESCE(poi.quantity_received, 0)) as quantity_remaining
    FROM purchase_order_items poi
    WHERE poi.po_id = ? AND poi.item_barcode = ?
    LIMIT 1
";

$stmt = $conn->prepare($query);
$stmt->bind_param("is", $po_id, $item_barcode);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $item = $result->fetch_assoc();
    echo json_encode(['success' => true, 'item' => $item]);
} else {
    echo json_encode(['success' => false, 'message' => 'Item not found in this PO']);
}

$stmt->close();
$conn->close();
?>

