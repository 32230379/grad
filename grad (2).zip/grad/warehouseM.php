<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warehouse Manager Dashboard</title>
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --light-blue: #4A90E2;
            --light-blue-text: #5BA3F5;
            --light-blue-bg: #E8F4FD;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --light: #ecf0f1;
            --dark: #34495e;
            --text-primary: #2c3e50;
            --text-secondary: #5BA3F5;
            --text-muted: #7A9BC7;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f5f9ff 0%, #e8f4fd 100%);
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
            color: white;
            transition: all 0.3s;
            box-shadow: 4px 0 15px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 25px 20px;
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--secondary) 100%);
            text-align: center;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        
        .sidebar-header h2 {
            color: white;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0,0,0,0.2);
            font-size: 20px;
        }
        
        .sidebar-header p {
            color: rgba(255,255,255,0.9);
            font-size: 13px;
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 15px 0;
        }
        
        .menu-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: white;
        }
        
        .menu-item:hover, .menu-item.active {
            background: linear-gradient(90deg, var(--light-blue) 0%, var(--secondary) 100%);
            border-left: 4px solid white;
            padding-left: 16px;
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
            font-size: 18px;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding: 20px 25px;
            border-bottom: 3px solid var(--light-blue-bg);
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(91, 163, 245, 0.12);
        }
        
        .header h1 {
            color: var(--light-blue-text);
            font-size: 28px;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(91, 163, 245, 0.1);
        }
        
        .user-info {
            display: flex;
            align-items: center;
        }
        
        .user-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--secondary) 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            font-weight: bold;
            box-shadow: 0 4px 8px rgba(91, 163, 245, 0.3);
        }
        
        .user-info > div > div:first-child {
            color: var(--light-blue-text);
            font-weight: 600;
        }
        
        .user-info > div > div:last-child {
            font-size: 12px;
            color: var(--text-muted);
        }
        
        /* Dashboard Cards */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(91, 163, 245, 0.15);
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            border: 1px solid rgba(91, 163, 245, 0.1);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(91, 163, 245, 0.25);
            border-color: var(--light-blue-text);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
        }
        
        .icon-users { background: var(--light-blue-bg); color: var(--light-blue-text); }
        .icon-inventory { background: #e8f5e9; color: var(--success); }
        .icon-orders { background: #fff3e0; color: var(--warning); }
        .icon-alerts { background: #ffebee; color: var(--danger); }
        
        .stat-info h3 {
            font-size: 28px;
            margin-bottom: 5px;
            color: var(--light-blue-text);
            font-weight: 700;
        }
        
        .stat-info p {
            color: var(--text-muted);
            font-size: 14px;
            font-weight: 500;
        }
        
        /* Content Sections */
        .content-section {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 15px rgba(91, 163, 245, 0.12);
            border: 1px solid rgba(91, 163, 245, 0.1);
            transition: all 0.3s ease;
        }
        
        .content-section:hover {
            box-shadow: 0 6px 20px rgba(91, 163, 245, 0.18);
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--light-blue-bg);
        }
        
        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--light-blue-text);
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--secondary) 100%);
            color: white;
            box-shadow: 0 4px 6px rgba(91, 163, 245, 0.3);
            border: none;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, var(--secondary) 0%, var(--light-blue) 100%);
            box-shadow: 0 6px 12px rgba(91, 163, 245, 0.4);
            transform: translateY(-2px);
        }
        
        /* Table Styles */
        .table-container {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        th {
            background: var(--light-blue-bg);
            font-weight: 600;
            color: var(--light-blue-text);
            border-bottom: 2px solid var(--light-blue-text);
        }
        
        tr:hover {
            background: var(--light-blue-bg);
            transition: background 0.3s ease;
        }
        
        td {
            color: var(--text-primary);
        }
        
        td strong {
            color: var(--light-blue-text);
        }
        
        .status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
        }
        
        .status-pending { background: #fff3cd; color: #856404; }
        .status-approved { background: var(--light-blue-bg); color: var(--light-blue-text); font-weight: 600; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        .status-in_progress { background: var(--light-blue-bg); color: var(--light-blue-text); font-weight: 600; }
        
        .action-btn {
            background: none;
            border: none;
            cursor: pointer;
            margin-right: 5px;
            color: var(--light-blue-text);
            transition: all 0.3s ease;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .action-btn:hover {
            background: var(--light-blue-bg);
            color: var(--secondary);
            transform: scale(1.1);
        }
        
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e0e0e0;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 5px;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--light-blue) 0%, var(--secondary) 100%);
            transition: width 0.3s;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            width: 500px;
            max-width: 90%;
            padding: 25px;
            box-shadow: 0 8px 30px rgba(91, 163, 245, 0.25);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--light-blue-bg);
        }
        
        .modal-header h3 {
            color: var(--light-blue-text);
            font-size: 20px;
        }
        
        .close-modal {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: var(--text-muted);
            transition: color 0.3s;
        }
        
        .close-modal:hover {
            color: var(--light-blue-text);
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--text-primary);
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--light-blue-text);
        }
        
        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: var(--text-muted);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
            }
            
            .stats-cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>📊 Warehouse Manager Dashboard</h1>
                <div class="user-info">
                    <div class="user-avatar">WM</div>
                    <div>
                        <div>Warehouse Manager</div>
                        <div>Last login: Today, <?php echo date('H:i A'); ?></div>
                    </div>
                </div>
            </div>
            
            <!-- Stats Cards -->
            <div class="stats-cards" id="stats-cards">
                <div class="stat-card">
                    <div class="stat-icon icon-users">
                        👥
                    </div>
                    <div class="stat-info">
                        <h3 id="stat-users">-</h3>
                        <p>Total Users</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon icon-inventory">
                        📦
                    </div>
                    <div class="stat-info">
                        <h3 id="stat-items">-</h3>
                        <p>Items in Stock</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon icon-orders">
                        🔄
                    </div>
                    <div class="stat-info">
                        <h3 id="stat-pending-orders">-</h3>
                        <p>Pending Picking Orders</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon icon-alerts">
                        ⚠️
                    </div>
                    <div class="stat-info">
                        <h3 id="stat-low-stock">-</h3>
                        <p>Low Stock Items</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: #e1bee7; color: #7b1fa2;">
                        ✅
                    </div>
                    <div class="stat-info">
                        <h3 id="stat-ready-load">-</h3>
                        <p>Plates Ready for Load</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: #c8e6c9; color: #2e7d32;">
                        📥
                    </div>
                    <div class="stat-info">
                        <h3 id="stat-received-today">-</h3>
                        <p>Received Today</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: #fff9c4; color: #f57f17;">
                        ⬇️
                    </div>
                    <div class="stat-info">
                        <h3 id="stat-lowering">-</h3>
                        <p>Pending Lowering Orders</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: #b3e5fc; color: #0277bd;">
                        📍
                    </div>
                    <div class="stat-info">
                        <h3 id="stat-areas">-</h3>
                        <p>Active Areas</p>
                    </div>
                    </div>
                </div>
                
            <!-- Pending Picking Orders Section -->
            <div class="content-section">
                <div class="section-header">
                    <h2 class="section-title">Pending Picking Orders</h2>
                    <button class="btn btn-primary" onclick="window.location.href='transfer_orders.php'">View All</button>
                </div>
                <div class="table-container">
                    <table id="pending-orders-table">
                        <thead>
                            <tr>
                                <th>Work ID</th>
                                <th>Branch</th>
                                <th>Items</th>
                                <th>Total Quantity</th>
                                <th>Progress</th>
                                <th>Users</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="9" style="text-align: center; padding: 20px;">Loading...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Plates Ready for Load Section -->
            <div class="content-section">
                <div class="section-header">
                    <h2 class="section-title">Plates Ready for Load</h2>
                    <button class="btn btn-primary" onclick="window.location.href='loader.php'">View All</button>
                </div>
                <div class="table-container">
                    <table id="ready-plates-table">
                        <thead>
                            <tr>
                                <th>Plate ID</th>
                                <th>Work ID</th>
                                <th>Branch</th>
                                <th>Items</th>
                                <th>Total Quantity</th>
                                <th>QC Verified By</th>
                                <th>Verified At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 20px;">Loading...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Pending Lowering Orders Section -->
            <div class="content-section">
                <div class="section-header">
                    <h2 class="section-title">Pending Lowering Orders</h2>
                    <button class="btn btn-primary" onclick="window.location.href='lowering_orders.php'">View All</button>
                </div>
                <div class="table-container">
                    <table id="lowering-orders-table">
                        <thead>
                            <tr>
                                <th>Item Barcode</th>
                                <th>Item Name</th>
                                <th>From Location</th>
                                <th>Zone</th>
                                <th>Quantity</th>
                                <th>Priority</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 20px;">Loading...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Low Stock Items Section -->
            <div class="content-section">
                <div class="section-header">
                    <h2 class="section-title">Low Stock Items (Quantity < 10)</h2>
                    <button class="btn btn-primary" onclick="window.location.href='inv.php'">View All Inventory</button>
                </div>
                <div class="table-container">
                    <table id="low-stock-table">
                        <thead>
                            <tr>
                                <th>Item Barcode</th>
                                <th>Item Name</th>
                                <th>Location</th>
                                <th>Zone</th>
                                <th>Current Stock</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 20px;">Loading...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Recent Activities Section -->
            <div class="content-section">
                <div class="section-header">
                    <h2 class="section-title">Recent Activities (Today)</h2>
                    <button class="btn btn-primary" onclick="refreshDashboard()">🔄 Refresh</button>
                </div>
                <div class="table-container">
                    <table id="activities-table">
                        <thead>
                            <tr>
                                <th>Activity Type</th>
                                <th>Description</th>
                                <th>Reference</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="4" style="text-align: center; padding: 20px;">Loading...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Load dashboard data
        function loadDashboard() {
            fetch('get_dashboard_stats.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update stats
                        document.getElementById('stat-users').textContent = data.stats.total_users || 0;
                        document.getElementById('stat-items').textContent = data.stats.total_items || 0;
                        document.getElementById('stat-pending-orders').textContent = data.stats.pending_orders || 0;
                        document.getElementById('stat-low-stock').textContent = data.stats.low_stock || 0;
                        document.getElementById('stat-ready-load').textContent = data.stats.ready_to_load || 0;
                        document.getElementById('stat-received-today').textContent = data.stats.received_today || 0;
                        document.getElementById('stat-lowering').textContent = data.stats.pending_lowering || 0;
                        document.getElementById('stat-areas').textContent = data.stats.active_areas || 0;

                        // Update pending orders table
                        updateTable('pending-orders-table', data.recent_orders, (row) => {
                            const progress = row.item_count > 0 ? Math.round((row.picked_items || 0) / row.item_count * 100) : 0;
                            const pickers = row.pickers ? row.pickers.split(', ').filter((v, i, a) => a.indexOf(v) === i).join(', ') : '-';
                            const qcUsers = row.qc_users ? row.qc_users.split(', ').filter((v, i, a) => a.indexOf(v) === i).join(', ') : '-';
                            const receiverUsers = row.receiver_users ? row.receiver_users.split(', ').filter((v, i, a) => a.indexOf(v) === i).join(', ') : '-';
                            const putawayUsers = row.putaway_users ? row.putaway_users.split(', ').filter((v, i, a) => a.indexOf(v) === i).join(', ') : '-';
                            const loaderUsers = row.loader_users ? row.loader_users.split(', ').filter((v, i, a) => a.indexOf(v) === i).join(', ') : '-';
                            return `
                                <tr>
                                    <td><strong>${row.work_id}</strong></td>
                                    <td>${row.branch || '-'}</td>
                                    <td>${row.item_count || 0} items</td>
                                    <td>${row.total_quantity || 0}</td>
                                    <td>
                                        <div class="progress-bar"><div class="progress-fill" style="width: ${progress}%"></div></div>
                                        <small>${row.picked_items || 0}/${row.item_count || 0} picked (${progress}%)</small>
                                    </td>
                                    <td>
                                        <small><strong>Picker:</strong> ${pickers}</small><br>
                                        <small><strong>QC:</strong> ${qcUsers}</small><br>
                                        <small><strong>Receiver:</strong> ${receiverUsers}</small><br>
                                        <small><strong>Putaway:</strong> ${putawayUsers}</small><br>
                                        <small><strong>Loader:</strong> ${loaderUsers}</small>
                                    </td>
                                    <td><span class="status status-${row.status === 'pending' ? 'pending' : 'in_progress'}">${row.status.replace('_', ' ')}</span></td>
                                    <td>${new Date(row.created_at).toLocaleString()}</td>
                                    <td>
                                        <button class="action-btn" title="View Items" onclick="viewWorkOrderItems('${row.work_id}')">👁️</button>
                                    </td>
                                </tr>
                            `;
                        });

                        // Update ready plates table
                        updateTable('ready-plates-table', data.ready_plates, (row) => {
                            return `
                                <tr>
                                    <td><strong>${row.plate_id}</strong></td>
                                    <td>${row.work_id || '-'}</td>
                                    <td>${row.branch || '-'}</td>
                                    <td>${row.item_count || 0} items</td>
                                    <td>${row.total_quantity || 0}</td>
                                    <td>${row.verified_by || '-'}</td>
                                    <td>${row.verified_at ? new Date(row.verified_at).toLocaleString() : '-'}</td>
                                    <td>
                                        <button class="action-btn" title="View" onclick="window.location.href='loader.php'">👁️</button>
                                    </td>
                                </tr>
                            `;
                        });

                        // Update lowering orders table
                        updateTable('lowering-orders-table', data.pending_lowering, (row) => {
                            return `
                                <tr>
                                    <td><strong>${row.item_barcode}</strong></td>
                                    <td>${row.item_name || row.item_barcode}</td>
                                    <td>${row.from_location_code}</td>
                                    <td>${row.from_zone || '-'}</td>
                                    <td>${row.quantity_at_source}</td>
                                    <td><span class="status status-${row.priority <= 2 ? 'rejected' : 'pending'}">${row.priority}</span></td>
                                    <td>${new Date(row.created_at).toLocaleString()}</td>
                                    <td>
                                        <button class="action-btn" title="View" onclick="window.location.href='lowering_orders.php'">👁️</button>
                                    </td>
                                </tr>
                            `;
                        });

                        // Update low stock table
                        updateTable('low-stock-table', data.low_stock_items, (row) => {
                            return `
                                <tr>
                                    <td><strong>${row.item_barcode}</strong></td>
                                    <td>${row.item_name || row.item_barcode}</td>
                                    <td>${row.location_code}</td>
                                    <td>${row.zone || '-'}</td>
                                    <td><strong style="color: #e74c3c;">${row.quantity}</strong></td>
                                    <td><span class="status status-rejected">Low Stock</span></td>
                                    <td>
                                        <button class="action-btn" title="View" onclick="window.location.href='inv.php'">👁️</button>
                                    </td>
                                </tr>
                            `;
                        });

                        // Update activities table
                        updateTable('activities-table', data.recent_activities, (row) => {
                            return `
                                <tr>
                                    <td><span class="status status-${row.activity_type === 'Picking' ? 'approved' : row.activity_type === 'Receiving' ? 'completed' : 'pending'}">${row.activity_type}</span></td>
                                    <td>${row.description}</td>
                                    <td>${row.reference || '-'}</td>
                                    <td>${new Date(row.activity_date).toLocaleString()}</td>
                                </tr>
                            `;
                        });
                    }
                })
                .catch(error => {
                    console.error('Error loading dashboard:', error);
                });
        }

        function updateTable(tableId, data, rowTemplate) {
            const table = document.getElementById(tableId);
            const tbody = table.querySelector('tbody');
            
            if (data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="' + table.querySelectorAll('th').length + '" class="no-data">No data available</td></tr>';
            } else {
                tbody.innerHTML = data.map(rowTemplate).join('');
            }
        }

        function refreshDashboard() {
            loadDashboard();
        }

        function viewWorkOrderItems(workId) {
            // Open view_order_details.php in a new window/modal
            window.open('view_order_details.php?work_id=' + encodeURIComponent(workId), '_blank', 'width=1200,height=800,scrollbars=yes');
        }

        // Load dashboard on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadDashboard();
            
            // Auto-refresh every 30 seconds
            setInterval(loadDashboard, 30000);
        });
    </script>
</body>
</html>
