<?php
header('Content-Type: application/json');
include 'db_connect.php';

// Check if zones table exists
$table_check = $conn->query("SHOW TABLES LIKE 'zones'");
if ($table_check->num_rows == 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Zones table does not exist. Please run final.sql to create the database.',
        'zones' => []
    ]);
    $conn->close();
    exit;
}

// Get all zones
$stmt = $conn->prepare("SELECT id, zone_code, zone_name, description FROM zones ORDER BY zone_code");
if (!$stmt) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $conn->error,
        'zones' => []
    ]);
    $conn->close();
    exit;
}

$stmt->execute();
$result = $stmt->get_result();

$zones = [];
while ($row = $result->fetch_assoc()) {
    $zones[] = $row;
}

$stmt->close();
$conn->close();

if (empty($zones)) {
    echo json_encode([
        'success' => false,
        'message' => 'No zones found in database. Please add zones first.',
        'zones' => []
    ]);
} else {
    echo json_encode([
        'success' => true,
        'zones' => $zones
    ]);
}
?>
