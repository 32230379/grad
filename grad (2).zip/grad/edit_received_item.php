<?php
session_start();
include "db_connect.php";

// تأكد إنو المستخدم مسجّل دخول
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

// التحقق من وجود الـ id
if (!isset($_GET['id'])) {
    header("Location: ViewReceivedItems.php");
    exit();
}

$id = intval($_GET['id']);

// جلب بيانات العنصر الحالي
$query = "SELECT * FROM receiving WHERE id = $id";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    echo "Item not found.";
    exit();
}

$item = mysqli_fetch_assoc($result);

// تحديث البيانات لما المستخدم يضغط "Update"
if (isset($_POST['update'])) {
    $plate_id = mysqli_real_escape_string($conn, $_POST['plate_id']);
    $item_barcode = mysqli_real_escape_string($conn, $_POST['item_barcode']);
    $item_name = mysqli_real_escape_string($conn, $_POST['item_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $quantity = intval($_POST['quantity']);
    $expiry_date = mysqli_real_escape_string($conn, $_POST['expiry_date']);

    $update = "UPDATE receiving SET 
                plate_id='$plate_id',
                item_barcode='$item_barcode',
                item_name='$item_name',
                description='$description',
                quantity=$quantity,
                expiry_date='$expiry_date'
               WHERE id=$id";

    if (mysqli_query($conn, $update)) {
        header("Location: ViewReceivedItems.php");
        exit();
    } else {
        echo "Error updating item: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Received Item</title>
<style>
body {
  font-family: Poppins, sans-serif;
  background: #f5f7fa;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
form {
  background: #fff;
  padding: 20px 30px;
  border-radius: 10px;
  box-shadow: 0 0 10px #ccc;
}
input, button {
  width: 100%;
  padding: 8px;
  margin: 6px 0;
  border: 1px solid #ccc;
  border-radius: 6px;
}
button {
  background: #007bff;
  color: white;
  cursor: pointer;
  border: none;
}
button:hover {
  background: #0056b3;
}
</style>
</head>
<body>
<form method="POST">
  <h2>Edit Received Item</h2>
  <label>Plate ID</label>
  <input type="text" name="plate_id" value="<?php echo $item['plate_id']; ?>" required>

  <label>Item Barcode</label>
  <input type="text" name="item_barcode" value="<?php echo $item['item_barcode']; ?>" required>

  <label>Item Name</label>
  <input type="text" name="item_name" value="<?php echo $item['item_name']; ?>" required>

  <label>Description</label>
  <input type="text" name="description" value="<?php echo $item['description']; ?>" required>

  <label>Quantity</label>
  <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" required>

  <label>Expiry Date</label>
  <input type="date" name="expiry_date" value="<?php echo $item['expiry_date']; ?>">

  <button type="submit" name="update">Update</button>
  <a href="ViewReceivedItems.php" style="display:inline-block;margin-top:10px;text-decoration:none;color:#007bff;">Cancel</a>
</form>
</body>
</html>
