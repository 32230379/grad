<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'receiver') {
    header("Location: login.php?role=receiver");
    exit();
}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=0.7">
<title>Warehouse Receiving System</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial,sans-serif}
body{background:white;padding:5px;transform:scale(0.85);transform-origin:top center;width:100%}
.container{max-width:450px;margin:auto;background:white;border:2px solid #2c3e50;border-radius:10px;overflow:hidden}
.header{background:#2c3e50;color:#fff;padding:12px;text-align:center}
.content{padding:12px}
.scanner-section{text-align:center;margin-bottom:15px;padding:12px;border:2px dashed #ccc;border-radius:8px;background:#fafafa}
.field{margin-bottom:12px}
.field label{display:block;font-weight:bold;margin-bottom:4px}
.field input{width:100%;padding:10px;border:2px solid #ddd;border-radius:5px}
.info{background:#e8f4fd;border:1px solid #b8daff;border-radius:5px;padding:10px;margin:10px 0;font-size:13px}
.info-box{border:2px solid #2c3e50;border-radius:5px;padding:12px;margin:12px 0}
.info-line{margin-bottom:6px;border-bottom:1px solid #eee;padding:4px 0;font-size:13px}
.buttons{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:15px}
.btn{padding:10px;border:2px solid;border-radius:5px;font-size:14px;cursor:pointer;background:white;font-weight:bold}
.btn-ok{border-color:#28a745;color:#28a745}
.btn-add{border-color:#17a2b8;color:#17a2b8}
.barcode-input{text-align:center;font-size:16px}
.logout{display:block;text-align:center;margin-top:10px;color:red;text-decoration:none}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <p>Receiver - Main Warehouse</p>
    <p>Welcome, <strong><?php echo $_SESSION['user_name']; ?></strong></p>
  </div>

  <div class="content">

    <div class="scanner-section">
      <label>Scan Plate ID</label>
      <input type="text" id="plate-input" class="barcode-input" placeholder="Scan plate barcode">
    </div>

    <div class="info">
      <strong>Plate ID:</strong> <span id="plate-id-display">Waiting...</span><br>
      <strong>Receive Date:</strong> <span id="receive-date"></span>
    </div>

    <div class="field">
      <label>PO Number (Optional - Link to Purchase Order)</label>
      <select id="po-number" style="width:100%;padding:10px;border:2px solid #ddd;border-radius:5px">
        <option value="">Select PO Number (Optional)</option>
      </select>
    </div>

    <div class="scanner-section">
      <label>Scan Item Barcode</label>
      <input type="text" id="item-input" class="barcode-input" placeholder="Scan item barcode">
    </div>

    <div class="info-box">
      <div class="info-line"><strong>Item:</strong> <span id="item-display">-</span></div>
      <div class="info-line"><strong>Description:</strong> <span id="description-display">-</span></div>
      <div class="info-line" id="po-info" style="display:none;color:#17a2b8;font-weight:bold">
        <strong>PO Required Qty:</strong> <span id="po-required-qty">-</span> | 
        <strong>Already Received:</strong> <span id="po-received-qty">-</span> | 
        <strong>Remaining:</strong> <span id="po-remaining-qty">-</span>
      </div>
      <div class="info-line" id="po-complete-message" style="display:none;color:#28a745;font-weight:bold;background:#d4edda;padding:8px;border-radius:5px;margin-top:8px">
        ✅ <strong>PO Complete!</strong> All items have been received for this Purchase Order.
      </div>
    </div>

    <div class="field">
      <label>Quantity</label>
      <input type="number" id="quantity-input" min="1">
      <div id="quantity-error" style="color:red;font-size:12px;margin-top:5px;display:none"></div>
    </div>
    <div class="field">
      <label>Expiry Date</label>
      <input type="date" id="expiry-input">
    </div>

    <div class="buttons">
      <button class="btn btn-add">Add Item</button>
      <button class="btn btn-ok" onclick="window.location.href='ViewReceivedItems.php'">View</button>
    </div>
    <a href="logout.php" class="logout">Logout</a>
  </div>
</div>

<script>
document.getElementById("receive-date").textContent=new Date().toLocaleDateString();

// Load available Purchase Orders
function loadPurchaseOrders() {
  fetch('get_available_pos.php')
    .then(r => r.json())
    .then(d => {
      const select = document.getElementById('po-number');
      if (d.success && d.orders) {
        d.orders.forEach(po => {
          const option = document.createElement('option');
          option.value = po.id;
          option.textContent = po.po_number + ' - ' + (po.supplier_name || 'Unknown');
          select.appendChild(option);
        });
      }
    })
    .catch(err => console.error("Error loading POs:", err));
}

// Check if PO is complete
function checkPOCompleteStatus(poId) {
  if (!poId) {
    document.getElementById("po-complete-message").style.display = "none";
    return;
  }
  
  fetch(`check_po_complete.php?po_id=${poId}`)
    .then(r => r.json())
    .then(d => {
      if (d.success && d.is_complete) {
        document.getElementById("po-complete-message").style.display = "block";
      } else {
        document.getElementById("po-complete-message").style.display = "none";
      }
    })
    .catch(err => {
      console.error("Error checking PO status:", err);
      document.getElementById("po-complete-message").style.display = "none";
    });
}

// Load POs on page load
loadPurchaseOrders();

// Load PO item details when PO and item are selected
function loadPOItemDetails() {
  const poId = document.getElementById("po-number").value;
  const barcode = document.getElementById("item-input").value.trim();
  const errorDiv = document.getElementById("quantity-error");
  const itemInput = document.getElementById("item-input");
  
  if (poId && barcode) {
    fetch(`get_po_item_details.php?po_id=${poId}&item_barcode=${barcode}`)
      .then(r => r.json())
      .then(d => {
        if (d.success && d.item) {
          const required = parseInt(d.item.quantity_ordered) || 0;
          const received = parseInt(d.item.quantity_received) || 0;
          const remaining = required - received;
          
          document.getElementById("po-required-qty").textContent = required;
          document.getElementById("po-received-qty").textContent = received;
          document.getElementById("po-remaining-qty").textContent = remaining;
          document.getElementById("po-info").style.display = "block";
          
          // Set max quantity
          document.getElementById("quantity-input").max = remaining;
          document.getElementById("quantity-input").setAttribute("data-max-qty", remaining);
          document.getElementById("quantity-input").setAttribute("data-valid-item", "true");
          
          // Check if this item is complete
          if (remaining <= 0) {
            document.getElementById("quantity-input").disabled = true;
            document.getElementById("quantity-input").setAttribute("data-item-complete", "true");
          } else {
            document.getElementById("quantity-input").disabled = false;
            document.getElementById("quantity-input").removeAttribute("data-item-complete");
          }
          
          // Check overall PO status
          checkPOCompleteStatus(poId);
          
          // Clear error if item is valid
          errorDiv.style.display = "none";
          itemInput.style.borderColor = "#28a745";
          itemInput.style.backgroundColor = "#e8f5e8";
        } else {
          // Item not found in PO - show error
          document.getElementById("po-info").style.display = "none";
          document.getElementById("quantity-input").removeAttribute("max");
          document.getElementById("quantity-input").removeAttribute("data-max-qty");
          document.getElementById("quantity-input").removeAttribute("data-valid-item");
          
          errorDiv.textContent = "❌ Wrong barcode! This item is not in the selected PO.";
          errorDiv.style.display = "block";
          itemInput.style.borderColor = "red";
          itemInput.style.backgroundColor = "#ffe6e6";
        }
      })
      .catch(err => {
        console.error("Error loading PO item:", err);
        document.getElementById("po-info").style.display = "none";
        document.getElementById("quantity-input").removeAttribute("data-valid-item");
      });
  } else {
    document.getElementById("po-info").style.display = "none";
    document.getElementById("quantity-input").removeAttribute("max");
    document.getElementById("quantity-input").removeAttribute("data-max-qty");
    document.getElementById("quantity-input").removeAttribute("data-valid-item");
    errorDiv.style.display = "none";
    itemInput.style.borderColor = "#ddd";
    itemInput.style.backgroundColor = "white";
  }
}

document.getElementById("plate-input").addEventListener("input",()=>{
  document.getElementById("plate-id-display").textContent=document.getElementById("plate-input").value||"Waiting...";
});

document.getElementById("po-number").addEventListener("change", () => {
  const barcode = document.getElementById("item-input").value.trim();
  // If item is already scanned, validate it against new PO
  if (barcode) {
    loadPOItemDetails();
  } else {
    // Clear PO info if no item scanned
    document.getElementById("po-info").style.display = "none";
    document.getElementById("quantity-input").removeAttribute("max");
    document.getElementById("quantity-input").removeAttribute("data-max-qty");
    document.getElementById("quantity-input").removeAttribute("data-valid-item");
  }
});

document.getElementById("item-input").addEventListener("input",()=>{
  const barcode=document.getElementById("item-input").value.trim();
  const poId = document.getElementById("po-number").value;
  const itemInput = document.getElementById("item-input");
  const errorDiv = document.getElementById("quantity-error");
  
  if(barcode.length>0){
    fetch("get_item.php?barcode="+barcode)
      .then(r=>r.json())
      .then(d=>{
        document.getElementById("item-display").textContent=d.name;
        document.getElementById("description-display").textContent=d.description;
        
        // If PO is selected, validate item against PO
        if(poId) {
          loadPOItemDetails(); // This will check if item is in PO
        } else {
          // No PO selected, clear any errors
          errorDiv.style.display = "none";
          itemInput.style.borderColor = "#ddd";
          itemInput.style.backgroundColor = "white";
        }
      })
      .catch(err=>console.error("Fetch error:",err));
  }else{
    document.getElementById("item-display").textContent="-";
    document.getElementById("description-display").textContent="-";
    document.getElementById("po-info").style.display="none";
    errorDiv.style.display = "none";
    itemInput.style.borderColor = "#ddd";
    itemInput.style.backgroundColor = "white";
  }
});

// Validate quantity input
document.getElementById("quantity-input").addEventListener("input", function() {
  const qty = parseInt(this.value) || 0;
  const maxQty = parseInt(this.getAttribute("data-max-qty")) || null;
  const errorDiv = document.getElementById("quantity-error");
  
  if (maxQty !== null && qty > maxQty) {
    errorDiv.textContent = `❌ Quantity exceeds! Maximum allowed: ${maxQty}`;
    errorDiv.style.display = "block";
    this.style.borderColor = "red";
  } else {
    errorDiv.style.display = "none";
    this.style.borderColor = "#ddd";
  }
});

document.querySelector(".btn-add").addEventListener("click",()=>{
  const plate=document.getElementById("plate-input").value.trim();
  const barcode=document.getElementById("item-input").value.trim();
  const name=document.getElementById("item-display").textContent;
  const desc=document.getElementById("description-display").textContent;
  const qty=parseInt(document.getElementById("quantity-input").value) || 0;
  const exp=document.getElementById("expiry-input").value;
  const poId=document.getElementById("po-number").value;
  const maxQty=parseInt(document.getElementById("quantity-input").getAttribute("data-max-qty")) || null;
  const validItem=document.getElementById("quantity-input").getAttribute("data-valid-item");

  if(!plate||!barcode||!qty||!exp){alert("Please fill all fields");return;}

  // If PO is selected, validate that item is in PO
  if(poId && validItem !== "true"){
    alert("❌ Wrong barcode! This item is not in the selected PO. Please scan the correct item or remove the PO selection.");
    document.getElementById("item-input").focus();
    return;
  }

  // Validate quantity if PO is selected
  if(poId && maxQty !== null && qty > maxQty){
    alert("❌ Quantity exceeds! Maximum allowed: " + maxQty);
    document.getElementById("quantity-input").focus();
    return;
  }

  const formData=new FormData();
  formData.append("plate_id",plate);
  formData.append("barcode",barcode);
  formData.append("name",name);
  formData.append("description",desc);
  formData.append("quantity",qty);
  formData.append("expiry",exp);
  formData.append("po_id",poId || '');

  fetch("save_receiving.php",{method:"POST",body:formData})
    .then(r=>r.json())
    .then(d=>{
      if(d.status=="success"){
        const poId = document.getElementById("po-number").value;
        alert("✅ Item added successfully!");
        document.getElementById("item-input").value="";
        document.getElementById("item-display").textContent="-";
        document.getElementById("description-display").textContent="-";
        document.getElementById("quantity-input").value="";
        document.getElementById("expiry-input").value="";
        document.getElementById("po-info").style.display="none";
        document.getElementById("po-complete-message").style.display="none";
        
        // Check PO status after successful receive
        if(poId) {
          setTimeout(() => {
            checkPOCompleteStatus(poId);
            // If item is still scanned, reload PO details
            const barcode = document.getElementById("item-input").value.trim();
            if(barcode) {
              loadPOItemDetails();
            }
          }, 500);
        }
      }else{
        alert("❌ Error: "+d.msg);
      }
    });
});
</script>
</body>
</html>
