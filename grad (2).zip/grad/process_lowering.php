<?php
session_start();
header('Content-Type: application/json');
include 'db_connect.php';

// Add lowered_by column to lowering_orders if it doesn't exist
$check_column = $conn->query("SHOW COLUMNS FROM lowering_orders LIKE 'lowered_by'");
if ($check_column->num_rows == 0) {
    $conn->query("ALTER TABLE lowering_orders ADD COLUMN lowered_by varchar(100) DEFAULT NULL AFTER completed_at");
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

$lowering_id = isset($_POST['lowering_id']) ? intval($_POST['lowering_id']) : 0;
$item_barcode = isset($_POST['item_barcode']) ? trim($_POST['item_barcode']) : '';
$to_location_code = isset($_POST['to_location_code']) ? trim($_POST['to_location_code']) : '';
$to_zone = isset($_POST['to_zone']) ? trim($_POST['to_zone']) : '';
$auto_quantity = isset($_POST['auto_quantity']) ? true : false;

if ($lowering_id <= 0 || empty($item_barcode) || empty($to_location_code) || empty($to_zone)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid parameters. Please provide destination location and zone.'
    ]);
    exit;
}

// Validate location format (rack-shelf)
if (!preg_match('/^\d+-\d+$/', $to_location_code)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid location format. Please use rack-shelf format (e.g., 1-0, 2-0)'
    ]);
    exit;
}

// Get lowering order details
$stmt = $conn->prepare("SELECT * FROM lowering_orders WHERE id = ? AND status IN ('pending', 'in_progress')");
$stmt->bind_param("i", $lowering_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Lowering order not found or already completed'
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

$order = $result->fetch_assoc();
$stmt->close();

// Verify item barcode matches
if ($order['item_barcode'] !== $item_barcode) {
    echo json_encode([
        'success' => false,
        'message' => 'Barcode does not match the lowering order'
    ]);
    $conn->close();
    exit;
}

// Start transaction
$conn->begin_transaction();

try {
    // Get all quantity from source location (high shelf) - move everything automatically
    $check_stmt = $conn->prepare("SELECT quantity FROM inventory WHERE item_barcode = ? AND location_code = ?");
    $check_stmt->bind_param("ss", $item_barcode, $order['from_location_code']);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows === 0) {
        throw new Exception("Item not found at source location ({$order['from_location_code']})");
    }
    
    $source_inv = $check_result->fetch_assoc();
    $quantity_to_move = $source_inv['quantity']; // Move all available quantity
    
    if ($quantity_to_move <= 0) {
        throw new Exception("No quantity available at source location");
    }
    
    $check_stmt->close();
    
    // Update source inventory (set to 0 - all moved)
    $update_source = $conn->prepare("UPDATE inventory SET quantity = 0, last_update = NOW() WHERE item_barcode = ? AND location_code = ?");
    $update_source->bind_param("ss", $item_barcode, $order['from_location_code']);
    $update_source->execute();
    $update_source->close();
    
    // Update or create target inventory (add all quantity at low shelf)
    // Use to_location_code and to_zone from POST request (user selected destination)
    $check_target = $conn->prepare("SELECT quantity FROM inventory WHERE item_barcode = ? AND location_code = ?");
    $check_target->bind_param("ss", $item_barcode, $to_location_code);
    $check_target->execute();
    $target_result = $check_target->get_result();
    
    if ($target_result->num_rows > 0) {
        // Update existing inventory - add the moved quantity
        $target_inv = $target_result->fetch_assoc();
        $new_target_qty = $target_inv['quantity'] + $quantity_to_move;
        $update_target = $conn->prepare("UPDATE inventory SET quantity = ?, last_update = NOW() WHERE item_barcode = ? AND location_code = ?");
        $update_target->bind_param("iss", $new_target_qty, $item_barcode, $to_location_code);
        $update_target->execute();
        $update_target->close();
    } else {
        // Create new inventory record at target location with all moved quantity
        $insert_target = $conn->prepare("INSERT INTO inventory (item_barcode, location_code, zone, quantity, last_update) VALUES (?, ?, ?, ?, NOW())");
        $insert_target->bind_param("sssi", $item_barcode, $to_location_code, $to_zone, $quantity_to_move);
        $insert_target->execute();
        $insert_target->close();
    }
    $check_target->close();
    
    // Get current order info to check zone completion
    $check_order_stmt = $conn->prepare("SELECT from_zone, completed_zones, assigned_user, assigned_zone FROM lowering_orders WHERE id = ?");
    $check_order_stmt->bind_param("i", $lowering_id);
    $check_order_stmt->execute();
    $order_info_result = $check_order_stmt->get_result();
    $order_info = $order_info_result->fetch_assoc();
    $check_order_stmt->close();
    
    $from_zone = $order_info['from_zone'] ?? null;
    $completed_zones = [];
    if (!empty($order_info['completed_zones'])) {
        $completed_zones = array_map('trim', explode(',', $order_info['completed_zones']));
    }
    
    // Add from_zone to completed zones if not already there (automatic zone completion)
    $zone_completed = false;
    $order_fully_completed = false;
    if ($from_zone && !in_array($from_zone, $completed_zones)) {
        $completed_zones[] = $from_zone;
        $completed_zones_str = implode(',', $completed_zones);
        $zone_completed = true;
        // If from_zone is completed, mark order as completed and clear assignment
        $order_fully_completed = true;
    } else {
        $completed_zones_str = $order_info['completed_zones'] ?? '';
    }
    
    // Get user name from session
    $lowered_by = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'System';
    
    // Update lowering order - update location and quantity, mark zone as completed automatically
    // If from_zone is completed, mark order as completed and clear assignment (allow new zone selection)
    if ($order_fully_completed && $from_zone) {
        // Mark order as completed, clear assignment to allow new zone selection
        $update_order = $conn->prepare("UPDATE lowering_orders SET to_location_code = ?, to_zone = ?, quantity_moved = ?, completed_zones = ?, status = 'completed', completed_at = NOW(), lowered_by = ?, assigned_user = NULL, assigned_zone = NULL, updated_at = NOW() WHERE id = ?");
        $update_order->bind_param("ssisss", $to_location_code, $to_zone, $quantity_to_move, $completed_zones_str, $lowered_by, $lowering_id);
    } else if ($zone_completed) {
        // Zone completed but order not fully completed - clear assignment to allow new zone selection
        $update_order = $conn->prepare("UPDATE lowering_orders SET to_location_code = ?, to_zone = ?, quantity_moved = ?, completed_zones = ?, lowered_by = ?, assigned_user = NULL, assigned_zone = NULL, updated_at = NOW() WHERE id = ?");
        $update_order->bind_param("ssisss", $to_location_code, $to_zone, $quantity_to_move, $completed_zones_str, $lowered_by, $lowering_id);
    } else {
        // Just update location and quantity
        $update_order = $conn->prepare("UPDATE lowering_orders SET to_location_code = ?, to_zone = ?, quantity_moved = ?, lowered_by = ?, updated_at = NOW() WHERE id = ?");
        $update_order->bind_param("ssiss", $to_location_code, $to_zone, $quantity_to_move, $lowered_by, $lowering_id);
    }
    
    $update_order->execute();
    $update_order->close();
    
    // Commit transaction
    $conn->commit();
    
    $message = "Move completed successfully! All quantity ({$quantity_to_move} units) moved from {$order['from_full_location']} to {$to_zone}-{$to_location_code}.";
    if ($zone_completed) {
        $message .= " Zone {$from_zone} marked as completed automatically.";
    }
    if ($order_fully_completed) {
        $message .= " Order completed. You can now select a new zone if needed.";
    }
    
    echo json_encode([
        'success' => true,
        'message' => $message,
        'zone_completed' => $zone_completed,
        'order_completed' => $order_fully_completed,
        'completed_zone' => $from_zone,
        'quantity_moved' => $quantity_to_move
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}

$conn->close();
?>
