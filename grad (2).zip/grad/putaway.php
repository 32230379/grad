<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'putaway') {
    header("Location: login.php?role=putaway");
    exit();
}
include 'db_connect.php'; // تأكد إنو اسم الملف متل يلي عندك

$message = "";

// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $plate_id = $_POST['plate_id'];
    $to_location = trim($_POST['to_location']); // Format: rack-shelf (e.g., 1-0, 2-3)
    $zone = trim($_POST['zone']); // Zone code (A, B, C, D...)
    $moved_by = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'System'; // fallback in case session not set
    
    // Validate location format (rack-shelf)
    if (!preg_match('/^\d+-\d+$/', $to_location)) {
        $message = "⚠️ Invalid location format. Please use rack-shelf format (e.g., 1-0, 2-3)";
    } else {
        // 1️⃣ Get all received items for that plate
        $stmt = $conn->prepare("SELECT item_barcode, item_name, quantity FROM receiving WHERE plate_id = ?");
        $stmt->bind_param("s", $plate_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $item_barcode = $row['item_barcode'];
                $item_name = $row['item_name'];
                $quantity = $row['quantity'];

                // 2️⃣ Insert into putaway log
                $insert = $conn->prepare("INSERT INTO putaway (plate_id, item_barcode, item_name, quantity, from_location, to_location, zone, moved_by)
                                          VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $from_location = "Receiving Area"; // or null if not used
                $insert->bind_param("sssissss", $plate_id, $item_barcode, $item_name, $quantity, $from_location, $to_location, $zone, $moved_by);
                $insert->execute();

                // 3️⃣ Check if item exists in inventory at "rec" location (from receiving)
                $checkRecInv = $conn->prepare("SELECT * FROM inventory WHERE item_barcode = ? AND location_code = 'rec'");
                $checkRecInv->bind_param("s", $item_barcode);
                $checkRecInv->execute();
                $recInvResult = $checkRecInv->get_result();
                
                if ($recInvResult->num_rows > 0) {
                    // Item exists at "rec" location - move it to new location
                    $recInv = $recInvResult->fetch_assoc();
                    $recQuantity = $recInv['quantity'];
                    
                    // Check if item already exists at target location
                    $checkTargetInv = $conn->prepare("SELECT * FROM inventory WHERE item_barcode = ? AND location_code = ?");
                    $checkTargetInv->bind_param("ss", $item_barcode, $to_location);
                    $checkTargetInv->execute();
                    $targetInvResult = $checkTargetInv->get_result();

                    if ($targetInvResult->num_rows > 0) {
                        // Update existing inventory at target location
                        $updateTargetInv = $conn->prepare("UPDATE inventory SET quantity = quantity + ?, zone = ?, last_update = NOW() WHERE item_barcode = ? AND location_code = ?");
                        $updateTargetInv->bind_param("isss", $quantity, $zone, $item_barcode, $to_location);
                        $updateTargetInv->execute();
                        $updateTargetInv->close();
                    } else {
                        // Insert new inventory at target location
                        $insertTargetInv = $conn->prepare("INSERT INTO inventory (item_barcode, location_code, zone, quantity, last_update) VALUES (?, ?, ?, ?, NOW())");
                        $insertTargetInv->bind_param("sssi", $item_barcode, $to_location, $zone, $quantity);
                        $insertTargetInv->execute();
                        $insertTargetInv->close();
                    }
                    $checkTargetInv->close();
                    
                    // Remove or reduce quantity from "rec" location
                    if ($recQuantity <= $quantity) {
                        // Remove completely from "rec"
                        $deleteRecInv = $conn->prepare("DELETE FROM inventory WHERE item_barcode = ? AND location_code = 'rec'");
                        $deleteRecInv->bind_param("s", $item_barcode);
                        $deleteRecInv->execute();
                        $deleteRecInv->close();
                    } else {
                        // Reduce quantity at "rec"
                        $updateRecInv = $conn->prepare("UPDATE inventory SET quantity = quantity - ?, last_update = NOW() WHERE item_barcode = ? AND location_code = 'rec'");
                        $updateRecInv->bind_param("is", $quantity, $item_barcode);
                        $updateRecInv->execute();
                        $updateRecInv->close();
                    }
                } else {
                    // No "rec" location found - add directly to target location (normal flow)
                    $checkTargetInv = $conn->prepare("SELECT * FROM inventory WHERE item_barcode = ? AND location_code = ?");
                    $checkTargetInv->bind_param("ss", $item_barcode, $to_location);
                    $checkTargetInv->execute();
                    $targetInvResult = $checkTargetInv->get_result();
                    
                    if ($targetInvResult->num_rows > 0) {
                        $updateTargetInv = $conn->prepare("UPDATE inventory SET quantity = quantity + ?, zone = ?, last_update = NOW() WHERE item_barcode = ? AND location_code = ?");
                        $updateTargetInv->bind_param("isss", $quantity, $zone, $item_barcode, $to_location);
                        $updateTargetInv->execute();
                        $updateTargetInv->close();
                    } else {
                        $insertTargetInv = $conn->prepare("INSERT INTO inventory (item_barcode, location_code, zone, quantity, last_update) VALUES (?, ?, ?, ?, NOW())");
                        $insertTargetInv->bind_param("sssi", $item_barcode, $to_location, $zone, $quantity);
                        $insertTargetInv->execute();
                        $insertTargetInv->close();
                    }
                    $checkTargetInv->close();
                }
                $checkRecInv->close();
                
                // 4️⃣ Update receiving status to 'stored'
                $updateReceiving = $conn->prepare("UPDATE receiving SET status = 'stored' WHERE plate_id = ? AND item_barcode = ?");
                $updateReceiving->bind_param("ss", $plate_id, $item_barcode);
                $updateReceiving->execute();
                $updateReceiving->close();
            }
            $message = "✅ Put Away completed successfully for plate $plate_id → Location $to_location (Zone: $zone).";
        } else {
            $message = "⚠️ No received items found for this plate ID.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Put Away</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7fa;
            padding: 30px;
        }
        .container {
            max-width: 500px;
            background: white;
            margin: auto;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; color: #333; }
        label { font-weight: bold; display: block; margin-top: 15px; }
        input[type=text] {
            width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 8px;
        }
        button {
            margin-top: 20px; width: 100%; padding: 10px;
            background: #007bff; border: none; color: white;
            font-size: 16px; border-radius: 8px; cursor: pointer;
        }
        button:hover { background: #0056b3; }
        .msg { text-align: center; margin-top: 15px; color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Put Away Mode</h2>
        <?php if (isset($_SESSION['user_name'])): ?>
        <p style="text-align: center; margin: 10px 0; color: #333;">Welcome, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></p>
        <p style="text-align: center; margin-bottom: 15px;"><a href="logout.php" style="color: #dc3545; text-decoration: none; font-size: 14px;">Logout</a></p>
        <?php endif; ?>

        <form method="POST">
            <label>Scan / Enter Plate ID</label>
            <input type="text" name="plate_id" required placeholder="e.g., L-000123">

            <label>Scan / Enter Storage Location (Format: rack-shelf)</label>
            <input type="text" name="to_location" required placeholder="e.g., 1-0, 2-3" pattern="[0-9]+-[0-9]+" title="Format: rack-shelf (e.g., 1-0, 2-3)">

            <label>Zone</label>
            <select name="zone" required>
                <option value="">Select Zone</option>
                <?php
                $zones_query = $conn->query("SELECT zone_code, zone_name FROM zones ORDER BY zone_code");
                while ($zone = $zones_query->fetch_assoc()) {
                    echo "<option value='{$zone['zone_code']}'>{$zone['zone_code']} - {$zone['zone_name']}</option>";
                }
                ?>
            </select>

            <button type="submit">Confirm Move</button>
        </form>

        <?php if ($message): ?>
            <p class="msg"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
                                        