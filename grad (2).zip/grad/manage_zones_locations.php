<?php
session_start();
include 'db_connect.php';

$message = "";
$message_type = "";

// Handle Zone Creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_zone') {
    $zone_code = strtoupper(trim($_POST['zone_code']));
    $zone_name = trim($_POST['zone_name']);
    $description = trim($_POST['description']);
    
    if (empty($zone_code)) {
        $message = "Zone code is required";
        $message_type = "error";
    } else {
        $stmt = $conn->prepare("INSERT INTO zones (zone_code, zone_name, description) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $zone_code, $zone_name, $description);
        
        if ($stmt->execute()) {
            $message = "Zone created successfully!";
            $message_type = "success";
        } else {
            $message = "Error: " . $stmt->error;
            $message_type = "error";
        }
        $stmt->close();
    }
}

// Handle Location Creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_location') {
    $zone_id = intval($_POST['zone_id']);
    $rack_number = intval($_POST['rack_number']);
    $shelf_number = intval($_POST['shelf_number']);
    $area = trim($_POST['area']);
    
    if ($zone_id > 0 && $rack_number > 0 && $shelf_number >= 0) {
        $location_code = $rack_number . '-' . $shelf_number;
        
        // Get zone code
        $zone_stmt = $conn->prepare("SELECT zone_code FROM zones WHERE id = ?");
        $zone_stmt->bind_param("i", $zone_id);
        $zone_stmt->execute();
        $zone_result = $zone_stmt->get_result();
        $zone_row = $zone_result->fetch_assoc();
        $zone_code = $zone_row['zone_code'];
        $zone_stmt->close();
        
        $full_location_code = $zone_code . '-' . $location_code;
        
        $stmt = $conn->prepare("INSERT INTO locations (zone_id, rack_number, shelf_number, location_code, full_location_code, area) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiisss", $zone_id, $rack_number, $shelf_number, $location_code, $full_location_code, $area);
        
        if ($stmt->execute()) {
            $message = "Location created successfully!";
            $message_type = "success";
        } else {
            $message = "Error: " . $stmt->error;
            $message_type = "error";
        }
        $stmt->close();
    } else {
        $message = "Please fill all required fields";
        $message_type = "error";
    }
}

// Handle Bulk Location Creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'bulk_create') {
    $zone_id = intval($_POST['zone_id']);
    $rack_from = intval($_POST['rack_from']);
    $rack_to = intval($_POST['rack_to']);
    $shelf_from = intval($_POST['shelf_from']);
    $shelf_to = intval($_POST['shelf_to']);
    
    if ($zone_id > 0 && $rack_from > 0 && $rack_to >= $rack_from && $shelf_from >= 0 && $shelf_to >= $shelf_from) {
        // Get zone code
        $zone_stmt = $conn->prepare("SELECT zone_code FROM zones WHERE id = ?");
        $zone_stmt->bind_param("i", $zone_id);
        $zone_stmt->execute();
        $zone_result = $zone_stmt->get_result();
        $zone_row = $zone_result->fetch_assoc();
        $zone_code = $zone_row['zone_code'];
        $zone_stmt->close();
        
        $created = 0;
        $errors = 0;
        
        for ($rack = $rack_from; $rack <= $rack_to; $rack++) {
            for ($shelf = $shelf_from; $shelf <= $shelf_to; $shelf++) {
                $location_code = $rack . '-' . $shelf;
                $full_location_code = $zone_code . '-' . $location_code;
                
                $stmt = $conn->prepare("INSERT IGNORE INTO locations (zone_id, rack_number, shelf_number, location_code, full_location_code, area) VALUES (?, ?, ?, ?, ?, 'Auto Created')");
                $stmt->bind_param("iiiss", $zone_id, $rack, $shelf, $location_code, $full_location_code);
                
                if ($stmt->execute()) {
                    if ($stmt->affected_rows > 0) $created++;
                } else {
                    $errors++;
                }
                $stmt->close();
            }
        }
        
        $message = "Created {$created} locations" . ($errors > 0 ? " ({$errors} errors)" : "");
        $message_type = $errors > 0 ? "warning" : "success";
    }
}

// Get all zones
$zones_result = $conn->query("SELECT * FROM zones ORDER BY zone_code");

// Get all locations with zone info
$locations_result = $conn->query("
    SELECT l.*, z.zone_code, z.zone_name 
    FROM locations l 
    JOIN zones z ON l.zone_id = z.id 
    ORDER BY z.zone_code, l.rack_number, l.shelf_number
");
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المناطق والمواقع - Zones & Locations Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            padding: 20px;
            direction: rtl;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            margin-bottom: 30px;
            text-align: center;
            border-bottom: 3px solid #3498db;
            padding-bottom: 15px;
        }
        h2 {
            color: #34495e;
            margin: 30px 0 15px 0;
            padding: 10px;
            background: #ecf0f1;
            border-right: 4px solid #3498db;
        }
        .message {
            padding: 15px;
            margin: 15px 0;
            border-radius: 5px;
            font-weight: bold;
        }
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        .form-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #2c3e50;
        }
        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #3498db;
        }
        button {
            background: #3498db;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: background 0.3s;
        }
        button:hover {
            background: #2980b9;
        }
        .btn-danger {
            background: #e74c3c;
        }
        .btn-danger:hover {
            background: #c0392b;
        }
        .btn-success {
            background: #27ae60;
        }
        .btn-success:hover {
            background: #229954;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
        }
        th, td {
            padding: 12px;
            text-align: right;
            border: 1px solid #ddd;
        }
        th {
            background: #34495e;
            color: white;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background: #f8f9fa;
        }
        tr:hover {
            background: #e8f4f8;
        }
        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: bold;
        }
        .badge-zone {
            background: #3498db;
            color: white;
        }
        .badge-location {
            background: #27ae60;
            color: white;
        }
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 2px solid #ddd;
        }
        .tab {
            padding: 10px 20px;
            cursor: pointer;
            background: #ecf0f1;
            border: none;
            border-radius: 5px 5px 0 0;
            font-weight: bold;
        }
        .tab.active {
            background: #3498db;
            color: white;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🏢 إدارة المناطق والمواقع - Zones & Locations Management</h1>
        
        <?php if ($message): ?>
            <div class="message <?= $message_type ?>"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        
        <div class="tabs">
            <button class="tab active" onclick="showTab('zones')">المناطق - Zones</button>
            <button class="tab" onclick="showTab('locations')">المواقع - Locations</button>
            <button class="tab" onclick="showTab('bulk')">إنشاء جماعي - Bulk Create</button>
        </div>
        
        <!-- Zones Tab -->
        <div id="zones" class="tab-content active">
            <h2>إضافة منطقة جديدة - Add New Zone</h2>
            <div class="form-section">
                <form method="POST">
                    <input type="hidden" name="action" value="add_zone">
                    <div class="form-row">
                        <div class="form-group">
                            <label>رمز المنطقة - Zone Code * (A, B, C...)</label>
                            <input type="text" name="zone_code" required maxlength="10" placeholder="A">
                        </div>
                        <div class="form-group">
                            <label>اسم المنطقة - Zone Name</label>
                            <input type="text" name="zone_name" placeholder="Zone A">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>الوصف - Description</label>
                        <textarea name="description" rows="3" placeholder="وصف المنطقة"></textarea>
                    </div>
                    <button type="submit" class="btn-success">➕ إضافة منطقة - Add Zone</button>
                </form>
            </div>
            
            <h2>قائمة المناطق - Zones List</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>رمز المنطقة</th>
                        <th>اسم المنطقة</th>
                        <th>الوصف</th>
                        <th>تاريخ الإنشاء</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($zone = $zones_result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $zone['id'] ?></td>
                        <td><span class="badge badge-zone"><?= htmlspecialchars($zone['zone_code']) ?></span></td>
                        <td><?= htmlspecialchars($zone['zone_name'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($zone['description'] ?? '-') ?></td>
                        <td><?= $zone['created_at'] ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Locations Tab -->
        <div id="locations" class="tab-content">
            <h2>إضافة موقع جديد - Add New Location</h2>
            <div class="form-section">
                <form method="POST">
                    <input type="hidden" name="action" value="add_location">
                    <div class="form-row">
                        <div class="form-group">
                            <label>المنطقة - Zone *</label>
                            <select name="zone_id" required>
                                <option value="">اختر المنطقة</option>
                                <?php 
                                $zones_result->data_seek(0);
                                while ($zone = $zones_result->fetch_assoc()): 
                                ?>
                                <option value="<?= $zone['id'] ?>"><?= htmlspecialchars($zone['zone_code']) ?> - <?= htmlspecialchars($zone['zone_name'] ?? '') ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>رقم الرف - Rack Number *</label>
                            <input type="number" name="rack_number" required min="1" placeholder="1">
                        </div>
                        <div class="form-group">
                            <label>المستوى - Shelf Number * (0 = الأسفل)</label>
                            <input type="number" name="shelf_number" required min="0" placeholder="0">
                        </div>
                        <div class="form-group">
                            <label>المنطقة - Area</label>
                            <input type="text" name="area" placeholder="Storage Area">
                        </div>
                    </div>
                    <button type="submit" class="btn-success">➕ إضافة موقع - Add Location</button>
                </form>
            </div>
            
            <h2>قائمة المواقع - Locations List</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>المنطقة</th>
                        <th>الرف</th>
                        <th>المستوى</th>
                        <th>كود الموقع</th>
                        <th>الكود الكامل</th>
                        <th>المنطقة</th>
                        <th>الحالة</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($loc = $locations_result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $loc['id'] ?></td>
                        <td><span class="badge badge-zone"><?= htmlspecialchars($loc['zone_code']) ?></span></td>
                        <td><?= $loc['rack_number'] ?></td>
                        <td><?= $loc['shelf_number'] ?></td>
                        <td><?= htmlspecialchars($loc['location_code']) ?></td>
                        <td><span class="badge badge-location"><?= htmlspecialchars($loc['full_location_code']) ?></span></td>
                        <td><?= htmlspecialchars($loc['area'] ?? '-') ?></td>
                        <td><?= $loc['is_active'] ? '✅ نشط' : '❌ غير نشط' ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Bulk Create Tab -->
        <div id="bulk" class="tab-content">
            <h2>إنشاء مواقع بشكل جماعي - Bulk Create Locations</h2>
            <div class="form-section">
                <form method="POST">
                    <input type="hidden" name="action" value="bulk_create">
                    <div class="form-row">
                        <div class="form-group">
                            <label>المنطقة - Zone *</label>
                            <select name="zone_id" required>
                                <option value="">اختر المنطقة</option>
                                <?php 
                                $zones_result->data_seek(0);
                                while ($zone = $zones_result->fetch_assoc()): 
                                ?>
                                <option value="<?= $zone['id'] ?>"><?= htmlspecialchars($zone['zone_code']) ?> - <?= htmlspecialchars($zone['zone_name'] ?? '') ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>من الرف - Rack From *</label>
                            <input type="number" name="rack_from" required min="1" value="1">
                        </div>
                        <div class="form-group">
                            <label>إلى الرف - Rack To *</label>
                            <input type="number" name="rack_to" required min="1" value="5">
                        </div>
                        <div class="form-group">
                            <label>من المستوى - Shelf From * (0 = الأسفل)</label>
                            <input type="number" name="shelf_from" required min="0" value="0">
                        </div>
                        <div class="form-group">
                            <label>إلى المستوى - Shelf To *</label>
                            <input type="number" name="shelf_to" required min="0" value="3">
                        </div>
                    </div>
                    <p style="margin: 15px 0; color: #7f8c8d;">
                        <strong>مثال:</strong> Zone A, Racks 1-5, Shelves 0-3 سينشئ 20 موقع (A-1-0, A-1-1, A-1-2, A-1-3, A-2-0...)
                    </p>
                    <button type="submit" class="btn-success">🚀 إنشاء المواقع - Create Locations</button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function showTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');
        }
    </script>
</body>
</html>



