<?php
session_start();
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] != 'house keeper' && $_SESSION['user_role'] != 'manager')) {
    header("Location: login.php?role=house keeper");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.7, maximum-scale=0.7">
    <title>Lowering System - Move Items</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background: white;
            padding: 5px;
            transform: scale(0.85);
            transform-origin: top center;
            width: 100%;
        }
        .container {
            width: 100%;
            max-width: 450px;
            margin: 0 auto;
            background: white;
            border: 2px solid #2c3e50;
            border-radius: 10px;
            overflow: hidden;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 12px;
            text-align: center;
            border-bottom: 2px solid #2c3e50;
        }
        .header h2 {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .header p {
            font-size: 14px;
        }
        .content {
            padding: 12px;
            background: white;
        }
        .scanner-section {
            text-align: center;
            margin-bottom: 15px;
            padding: 12px;
            border: 2px dashed #ccc;
            border-radius: 8px;
            background: #fafafa;
        }
        .scanner-icon {
            font-size: 30px;
            margin-bottom: 8px;
        }
        .field {
            margin-bottom: 12px;
        }
        .field label {
            display: block;
            font-weight: bold;
            margin-bottom: 4px;
            color: #333;
            font-size: 14px;
        }
        .field input, .field select {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            background: white;
        }
        .location-display {
            background: #f8f9fa;
            border: 2px solid #2c3e50;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 12px;
            font-weight: bold;
            text-align: center;
            color: #2c3e50;
            font-size: 14px;
        }
        .info-box {
            background: white;
            border: 2px solid #2c3e50;
            border-radius: 5px;
            padding: 12px;
            margin: 12px 0;
        }
        .info-line {
            margin-bottom: 6px;
            padding: 4px 0;
            border-bottom: 1px solid #eee;
            font-size: 13px;
        }
        .info-line:last-child {
            border-bottom: none;
        }
        .buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-top: 15px;
        }
        .btn {
            padding: 10px;
            border: 2px solid;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            background: white;
            font-weight: bold;
        }
        .btn-ok {
            border-color: #28a745;
            color: #28a745;
        }
        .btn-ok:hover {
            background: #28a745;
            color: white;
        }
        .btn-cancel {
            border-color: #dc3545;
            color: #dc3545;
        }
        .btn-cancel:hover {
            background: #dc3545;
            color: white;
        }
        .btn-skip {
            border-color: #6c757d;
            color: #6c757d;
            width: 100%;
            margin-top: 10px;
        }
        .btn-skip:hover {
            background: #6c757d;
            color: white;
        }
        .barcode-input {
            text-align: center;
            font-size: 16px;
            letter-spacing: 1px;
        }
        .item-input {
            text-align: center;
            font-size: 16px;
            font-weight: bold;
        }
        .scanner-section p {
            font-size: 12px;
            margin-top: 5px;
            color: #666;
        }
        .message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            font-weight: bold;
            text-align: center;
            display: none;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .message.warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        .step-indicator {
            background: #e3f2fd;
            padding: 8px;
            border-radius: 5px;
            margin-bottom: 12px;
            font-weight: bold;
            color: #1976d2;
            font-size: 13px;
            text-align: center;
        }
        .no-order {
            text-align: center;
            padding: 40px 20px;
            color: #7f8c8d;
        }
        .no-order h3 {
            margin-bottom: 10px;
            color: #2c3e50;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>🧹 House Keeper - Lowering System</h2>
            <p>Move Items from High Shelf to Low Shelf</p>
            <?php if (isset($_SESSION['user_name'])): ?>
            <p style="font-size: 12px; margin-top: 5px;">Welcome, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></p>
            <a href="logout.php" style="color: #fff; text-decoration: none; font-size: 12px; margin-top: 5px; display: inline-block; padding: 5px 10px; background: rgba(255,255,255,0.2); border-radius: 3px;">Logout</a>
            <?php endif; ?>
        </div>
        <div class="content">
            <div class="message" id="message"></div>

            <!-- No Order Message -->
            <div id="no-order-section" class="no-order" style="display: none;">
                <h3>No Lowering Orders Available</h3>
                <p>All lowering orders have been completed or there are no pending orders.</p>
            </div>

            <!-- Initial Zone Selection (shown first) -->
            <div id="initial-zone-selection" style="display: none;">
                <div class="step-indicator">Select Zone to Start Working</div>
                <div class="info-box" style="margin-bottom: 15px;">
                    <div class="info-line">
                        <strong>Choose which zone you want to work on:</strong>
                    </div>
                    <div class="field" style="margin-top: 15px;">
                        <label>Select Zone</label>
                        <select id="initial-zone-select" required style="width: 100%; padding: 12px; font-size: 16px; border: 2px solid #2c3e50; border-radius: 5px;">
                            <option value="">-- Select Zone --</option>
                        </select>
                    </div>
                    <div class="buttons" style="margin-top: 15px;">
                        <button class="btn btn-ok" id="start-zone-btn" style="width: 100%;">Start Working on Selected Zone</button>
                    </div>
                </div>
            </div>

            <!-- Order Interface -->
            <div id="order-section" style="display: none;">
                <!-- Zone Selection Section (for order-specific zones) -->
                <div id="zone-selection-section" style="display: none;">
                    <div class="step-indicator">Select Zone to Work On</div>
                    <div class="info-box" style="margin-bottom: 15px;">
                        <div class="info-line">
                            <strong>Available Zones for this Order:</strong>
                        </div>
                        <div id="available-zones-list" style="margin-top: 10px;"></div>
                    </div>
                    <div class="field">
                        <label>Select Zone</label>
                        <select id="zone-select" required>
                            <option value="">Select Zone</option>
                        </select>
                    </div>
                    <div class="buttons">
                        <button class="btn btn-ok" id="assign-zone-btn">Start Working on Zone</button>
                    </div>
                    <div style="margin-top: 10px;">
                        <button class="btn btn-cancel" id="change-zone-btn">Change Zone</button>
                    </div>
                </div>

                <!-- Main Order Interface -->
                <div id="main-order-section" style="display: none;">
                    <div class="step-indicator">Step 1: Move from High Shelf to Low Shelf</div>
                    
                    <!-- Zone Info Display -->
                    <div class="info-box" style="background: #e3f2fd; border-color: #2196f3;">
                        <div class="info-line">
                            <strong>Working on Zone:</strong> <span id="current-zone-display">-</span>
                        </div>
                        <div class="info-line">
                            <strong>Completed Zones:</strong> <span id="completed-zones-display">None</span>
                        </div>
                        <div class="info-line" style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #2196f3;">
                            <button class="btn" id="change-zone-main-btn" style="border-color: #9b59b6; color: #9b59b6; width: 100%;">🔄 Change Zone</button>
                        </div>
                    </div>

                    <!-- From Location Display -->
                    <div class="field">
                        <label>From Location (High Shelf)</label>
                        <div class="location-display" id="from-location-display">-</div>
                    </div>

                <!-- To Location Input -->
                <div class="field">
                    <label>To Location (Low Shelf) - Format: rack-shelf</label>
                    <input type="text" id="to-location-input" placeholder="Enter rack-shelf (e.g., 1-0)" pattern="[0-9]+-[0-9]+" title="Format: rack-shelf (e.g., 1-0, 2-0)" required>
                </div>
                <div class="field">
                    <label>To Zone</label>
                    <select id="to-zone-select" required>
                        <option value="">Select Zone</option>
                        <!-- Zones will be loaded here -->
                    </select>
                </div>

                <!-- Item Info -->
                <div class="info-box">
                    <div class="info-line">
                        <strong>Item Barcode:</strong> <span id="item-display">-</span>
                    </div>
                    <div class="info-line">
                        <strong>Description:</strong> <span id="description-display">-</span>
                    </div>
                    <div class="info-line">
                        <strong>Quantity at Source:</strong> <span id="quantity-at-source-display">-</span>
                    </div>
                    <div class="info-line">
                        <strong>Priority:</strong> <span id="priority-display">-</span>
                    </div>
                </div>

                <div class="step-indicator">Step 2: Scan Item Barcode at Destination Location</div>

                <!-- Barcode Scanner Section -->
                <div class="scanner-section">
                    <div class="scanner-icon">📦</div>
                    <div class="field">
                        <label>Scan Item Barcode at Destination</label>
                        <input type="text" class="barcode-input item-input" id="item-barcode-input" placeholder="Scan item barcode at destination">
                    </div>
                    <p>Scan barcode after moving items to destination. All quantity from source will be moved automatically.</p>
                </div>

                <div class="buttons">
                    <button class="btn btn-ok" id="confirm-btn">Confirm Move</button>
                    <button class="btn btn-cancel" id="cancel-btn">Cancel</button>
                </div>

                    <div style="margin-top: 10px;">
                        <button class="btn btn-skip" id="skip-btn">Skip This Order</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let currentOrder = null;
        let zones = [];
        let currentZone = null;
        let allZones = [];

        // Load zones on page load
        window.addEventListener('DOMContentLoaded', function() {
            // Load zones first, then show zone selection
            loadZones().then(() => {
                showInitialZoneSelection();
            });
        });

        // Load zones from database
        function loadZones() {
            return fetch('get_zones.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.zones) {
                        zones = data.zones;
                        const zoneSelect = document.getElementById('to-zone-select');
                        if (zoneSelect) {
                            zoneSelect.innerHTML = '<option value="">Select Zone</option>';
                            zones.forEach(zone => {
                                const option = document.createElement('option');
                                option.value = zone.zone_code;
                                option.textContent = `${zone.zone_code} - ${zone.zone_name}`;
                                zoneSelect.appendChild(option);
                            });
                        }
                        return true;
                    } else {
                        console.error('Failed to load zones:', data);
                        showMessage('Failed to load zones. Please refresh the page.', 'error');
                        return false;
                    }
                })
                .catch(error => {
                    console.error('Error loading zones:', error);
                    showMessage('Error loading zones. Please refresh the page.', 'error');
                    return false;
                });
        }
        
        // Show initial zone selection (all zones)
        function showInitialZoneSelection() {
            document.getElementById('no-order-section').style.display = 'none';
            document.getElementById('order-section').style.display = 'none';
            document.getElementById('initial-zone-selection').style.display = 'block';
            
            const initialZoneSelect = document.getElementById('initial-zone-select');
            if (!initialZoneSelect) return;
            
            initialZoneSelect.innerHTML = '<option value="">-- Select Zone --</option>';
            
            // Wait a bit for zones to load if not yet loaded
            if (!zones || zones.length === 0) {
                initialZoneSelect.innerHTML = '<option value="">Loading zones... Please wait.</option>';
                // Try to reload zones
                setTimeout(() => {
                    loadZones().then(() => {
                        if (zones && zones.length > 0) {
                            showInitialZoneSelection();
                        } else {
                            initialZoneSelect.innerHTML = '<option value="">No zones available. Please contact administrator.</option>';
                        }
                    });
                }, 1000);
                return;
            }
            
            zones.forEach(zone => {
                const option = document.createElement('option');
                option.value = zone.zone_code;
                option.textContent = `Zone ${zone.zone_code}${zone.zone_name ? ' - ' + zone.zone_name : ''}`;
                initialZoneSelect.appendChild(option);
            });
        }
        
        // Select initial zone and load orders for that zone
        function selectInitialZone(zoneCode) {
            if (!zoneCode) {
                showMessage('Please select a zone', 'error');
                return;
            }
            currentZone = zoneCode;
            document.getElementById('initial-zone-selection').style.display = 'none';
            document.getElementById('order-section').style.display = 'block';
            loadNextLoweringOrder(zoneCode);
        }
        
        // Start zone button handler
        document.getElementById('start-zone-btn').addEventListener('click', function() {
            const selectedZone = document.getElementById('initial-zone-select').value;
            selectInitialZone(selectedZone);
        });
        
        // Allow Enter key to start working on selected zone
        document.getElementById('initial-zone-select').addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && this.value) {
                selectInitialZone(this.value);
            }
        });

        // Load next lowering order
        function loadNextLoweringOrder(zone = null) {
            const url = zone ? `get_lowering_order.php?zone=${zone}` : 'get_lowering_order.php';
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.order) {
                        currentOrder = data.order;
                        allZones = data.all_zones || [];
                        
                        // If we have a current zone, directly display the order (no zone selection needed)
                        if (currentZone) {
                            // We're working on a specific zone, show the order directly
                            displayOrder(data.order);
                        } else if (data.order.available_zones && data.order.available_zones.length > 0) {
                            // No zone selected yet, show zone selection
                            showZoneSelection(data.order);
                        } else if (data.order.assigned_user && data.order.assigned_zone) {
                            // Zone already assigned, use it
                            currentZone = data.order.assigned_zone;
                            displayOrder(data.order);
                        } else {
                            // Show zone selection as fallback
                            showZoneSelection(data.order);
                        }
                        
                        document.getElementById('no-order-section').style.display = 'none';
                        document.getElementById('order-section').style.display = 'block';
                    } else {
                        // No more orders available for selected zone - Zone completed!
                        currentOrder = null;
                        
                        // Show zone completed message
                        const zoneCompletedMsg = currentZone ? 
                            `Zone ${currentZone} completed! All items have been lowered.` : 
                            'No more orders available.';
                        
                        showMessage(zoneCompletedMsg, 'success');
                        
                        // Clear current zone and go back to zone selection after 3 seconds
                        setTimeout(() => {
                            currentZone = null;
                            document.getElementById('no-order-section').style.display = 'none';
                            document.getElementById('order-section').style.display = 'none';
                            document.getElementById('zone-selection-section').style.display = 'none';
                            document.getElementById('main-order-section').style.display = 'none';
                            showInitialZoneSelection();
                            showMessage('Please select a zone to continue working', 'info');
                        }, 3000);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Failed to load lowering order', 'error');
                });
        }
        
        // Show zone selection interface
        function showZoneSelection(order) {
            document.getElementById('zone-selection-section').style.display = 'block';
            document.getElementById('main-order-section').style.display = 'none';
            
            const zoneSelect = document.getElementById('zone-select');
            const availableZonesList = document.getElementById('available-zones-list');
            
            zoneSelect.innerHTML = '<option value="">Select Zone</option>';
            availableZonesList.innerHTML = '';
            
            const availableZones = order.available_zones || [];
            const completedZones = order.completed_zones || [];
            
            if (availableZones.length === 0) {
                availableZonesList.innerHTML = '<p style="color: #dc3545;">No zones available. All zones are completed.</p>';
                return;
            }
            
            availableZones.forEach(zone => {
                const option = document.createElement('option');
                option.value = zone;
                option.textContent = `Zone ${zone}`;
                zoneSelect.appendChild(option);
                
                const badge = document.createElement('span');
                badge.textContent = zone;
                badge.style.cssText = 'display: inline-block; padding: 5px 10px; margin: 3px; background: #e3f2fd; border: 1px solid #2196f3; border-radius: 3px; font-weight: bold;';
                availableZonesList.appendChild(badge);
            });
            
            if (completedZones.length > 0) {
                const completedDiv = document.createElement('div');
                completedDiv.style.marginTop = '10px';
                completedDiv.innerHTML = '<strong>Completed Zones:</strong> ' + completedZones.join(', ');
                completedDiv.style.color = '#28a745';
                availableZonesList.appendChild(completedDiv);
            }
        }

        // Display order information
        function displayOrder(order) {
            document.getElementById('zone-selection-section').style.display = 'none';
            document.getElementById('main-order-section').style.display = 'block';
            
            // Zone info
            document.getElementById('current-zone-display').textContent = currentZone || order.assigned_zone || '-';
            const completedZones = order.completed_zones || [];
            document.getElementById('completed-zones-display').textContent = completedZones.length > 0 ? completedZones.join(', ') : 'None';
            
            // From location
            const fromLocation = order.from_full_location || `${order.from_zone}-${order.from_location_code}`;
            document.getElementById('from-location-display').textContent = fromLocation;

            // Item info
            document.getElementById('item-display').textContent = order.item_barcode || '-';
            document.getElementById('description-display').textContent = order.item_description || 'No description';
            document.getElementById('quantity-at-source-display').textContent = `${order.quantity_at_source || 0} units`;
            document.getElementById('priority-display').textContent = order.priority || '-';

            // Clear inputs
            document.getElementById('to-location-input').value = '';
            document.getElementById('to-zone-select').value = currentZone || order.assigned_zone || '';
            document.getElementById('item-barcode-input').value = '';
            document.getElementById('item-barcode-input').style.background = 'white';
            document.getElementById('item-barcode-input').style.borderColor = '#ddd';

            // Focus on to-location input
            setTimeout(() => {
                document.getElementById('to-location-input').focus();
            }, 100);
        }

        // Show message
        function showMessage(message, type) {
            const messageEl = document.getElementById('message');
            messageEl.textContent = message;
            messageEl.className = `message ${type}`;
            messageEl.style.display = 'block';

            setTimeout(() => {
                messageEl.style.display = 'none';
            }, 5000);
        }

        // Confirm button handler
        document.getElementById('confirm-btn').addEventListener('click', function() {
            processLowering();
        });

        // Cancel button handler
        document.getElementById('cancel-btn').addEventListener('click', function() {
            resetForm();
        });

        // Skip button handler
        document.getElementById('skip-btn').addEventListener('click', function() {
            if (confirm('Are you sure you want to skip this order? It will be moved to the end of the queue.')) {
                skipCurrentOrder();
            }
        });
        
        // Assign zone button handler
        document.getElementById('assign-zone-btn').addEventListener('click', function() {
            const selectedZone = document.getElementById('zone-select').value;
            if (!selectedZone) {
                showMessage('Please select a zone', 'error');
                return;
            }
            assignZone(selectedZone);
        });
        
        // Change zone button handler (in zone selection section)
        const changeZoneBtn = document.getElementById('change-zone-btn');
        if (changeZoneBtn) {
            changeZoneBtn.addEventListener('click', function() {
                if (confirm('Are you sure you want to change zone? Current work will be saved.')) {
                    currentZone = null;
                    currentOrder = null;
                    showInitialZoneSelection();
                }
            });
        }
        
        // Change zone button handler (in main order section)
        const changeZoneMainBtn = document.getElementById('change-zone-main-btn');
        if (changeZoneMainBtn) {
            changeZoneMainBtn.addEventListener('click', function() {
                if (confirm('Are you sure you want to change zone? Current work will be saved.')) {
                    currentZone = null;
                    currentOrder = null;
                    showInitialZoneSelection();
                }
            });
        }
        
        // Assign zone function
        function assignZone(zone) {
            if (!currentOrder) {
                showMessage('No order loaded', 'error');
                return;
            }
            
            const formData = new FormData();
            formData.append('lowering_id', currentOrder.id);
            formData.append('zone', zone);
            
            fetch('assign_zone.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    currentZone = zone;
                    showMessage(data.message, 'success');
                    // Reload order to get updated info
                    setTimeout(() => {
                        loadNextLoweringOrder(zone);
                    }, 1000);
                } else {
                    showMessage(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessage('Failed to assign zone', 'error');
            });
        }
        
        // Process lowering operation
        function processLowering() {
            if (!currentOrder) {
                showMessage('No lowering order loaded', 'error');
                return;
            }

            const itemBarcode = document.getElementById('item-barcode-input').value.trim();
            const toLocation = document.getElementById('to-location-input').value.trim();
            const toZone = document.getElementById('to-zone-select').value.trim();

            if (!toLocation || !toZone) {
                showMessage('Please enter/select destination location and zone', 'error');
                return;
            }

            // Validate location format
            if (!/^\d+-\d+$/.test(toLocation)) {
                showMessage('Invalid location format. Please use rack-shelf format (e.g., 1-0, 2-0)', 'error');
                return;
            }

            if (!itemBarcode) {
                showMessage('Please scan item barcode at destination', 'error');
                return;
            }

            if (itemBarcode !== currentOrder.item_barcode) {
                showMessage('Barcode does not match the required item', 'error');
                return;
            }

            const formData = new FormData();
            formData.append('lowering_id', currentOrder.id);
            formData.append('item_barcode', itemBarcode);
            formData.append('to_location_code', toLocation);
            formData.append('to_zone', toZone);
            formData.append('auto_quantity', '1'); // Flag to indicate auto quantity

            fetch('process_lowering.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage(data.message || 'Move completed successfully', 'success');
                    
                    // Keep working on the same zone - load next order for same zone
                    // Only go back to zone selection if no more orders available for this zone
                    setTimeout(() => {
                        if (currentZone) {
                            // Try to load next order for the same zone
                            loadNextLoweringOrder(currentZone);
                        } else {
                            // No zone selected, go back to zone selection
                            showInitialZoneSelection();
                        }
                    }, 1500);
                } else {
                    showMessage(data.message || 'Failed to process move', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessage('Failed to process move', 'error');
            });
        }

        // Skip current order
        function skipCurrentOrder() {
            if (!currentOrder) {
                showMessage('No order to skip', 'error');
                return;
            }

            fetch('skip_lowering_order.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `lowering_id=${currentOrder.id}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showMessage(data.message || 'Order skipped', 'success');
                    setTimeout(() => {
                        loadNextLoweringOrder();
                    }, 1000);
                } else {
                    showMessage(data.message || 'Failed to skip order', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessage('Failed to skip order', 'error');
            });
        }

        // Reset form
        function resetForm() {
            document.getElementById('to-location-input').value = '';
            document.getElementById('to-zone-select').value = '';
            document.getElementById('item-barcode-input').value = '';
            document.getElementById('item-barcode-input').style.background = 'white';
            document.getElementById('item-barcode-input').style.borderColor = '#ddd';
            
            if (currentOrder) {
                setTimeout(() => {
                    document.getElementById('to-location-input').focus();
                }, 100);
            }
        }

        // Auto-submit on Enter key for location input
        document.getElementById('to-location-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && this.value.trim()) {
                document.getElementById('to-zone-select').focus();
            }
        });

        // Auto-submit on Enter key for zone select
        document.getElementById('to-zone-select').addEventListener('change', function() {
            if (this.value) {
                document.getElementById('item-barcode-input').focus();
            }
        });

        // Auto-submit on Enter key for item barcode
        document.getElementById('item-barcode-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && this.value.trim()) {
                processLowering();
            }
        });

        // Visual feedback for inputs
        document.getElementById('item-barcode-input').addEventListener('input', function() {
            if (this.value.trim()) {
                if (this.value.trim() === (currentOrder?.item_barcode || '')) {
                    this.style.background = '#e8f5e8';
                    this.style.borderColor = '#28a745';
                } else {
                    this.style.background = '#fff3cd';
                    this.style.borderColor = '#ffc107';
                }
            } else {
                this.style.background = 'white';
                this.style.borderColor = '#ddd';
            }
        });
    </script>
</body>
</html>
