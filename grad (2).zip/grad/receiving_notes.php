<?php
session_start();
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] != 'manager' && $_SESSION['user_role'] != 'receiver')) {
    header("Location: login.php");
    exit();
}
include 'navbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receiving Notes</title>
    <style>
        .main-content {
            padding: 25px;
        }
        .page-header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-header h1 {
            color: var(--text-primary);
            font-size: 28px;
        }
        .btn-add {
            padding: 12px 24px;
            background: var(--light-blue);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: background 0.3s;
        }
        .btn-add:hover {
            background: var(--secondary);
        }
        .notes-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        thead {
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--secondary) 100%);
            color: white;
        }
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }
        tbody tr:hover {
            background: #f8f9fa;
        }
        .btn-action {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            margin: 2px;
            transition: all 0.3s;
        }
        .btn-view {
            background: #17a2b8;
            color: white;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-partial { background: #d1ecf1; color: #0c5460; }
        .status-completed { background: #d4edda; color: #155724; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="main-content">
            <div class="page-header">
                <div>
                    <h1>Receiving Notes</h1>
                    <p style="color: var(--text-muted);">Record items received from suppliers</p>
                </div>
                <button class="btn-add" onclick="openAddRNModal()">+ New Receiving Note</button>
            </div>

            <div id="notes-content">
                <div style="text-align: center; padding: 40px; color: #999;">Loading receiving notes...</div>
            </div>
        </div>
    </div>

    <!-- Add Receiving Note Modal -->
    <div id="rn-modal" class="modal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
        <div class="modal-content" style="background-color: white; margin: 2% auto; padding: 30px; border-radius: 8px; width: 90%; max-width: 900px; max-height: 90vh; overflow-y: auto;">
            <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid #eee;">
                <h2>New Receiving Note</h2>
                <span class="close" onclick="closeRNModal()" style="color: #aaa; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
            </div>
            <form id="rn-form">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                    <div class="form-group">
                        <label>PO Number *</label>
                        <select id="rn-po-id" required style="width: 100%; padding: 10px; border: 2px solid #ddd; border-radius: 5px;" onchange="loadPOItems()">
                            <option value="">Select Purchase Order</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>RN Number *</label>
                        <input type="text" id="rn-number" required>
                    </div>
                    <div class="form-group">
                        <label>Received Date *</label>
                        <input type="date" id="rn-date" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Notes</label>
                    <textarea id="rn-notes" rows="2"></textarea>
                </div>

                <h3 style="margin: 20px 0 10px 0;">Items Received</h3>
                <div id="rn-items-container">
                    <div style="text-align: center; padding: 20px; color: #999;">Select a Purchase Order to load items</div>
                </div>

                <div class="form-actions" style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn-cancel" onclick="closeRNModal()">Cancel</button>
                    <button type="submit" class="btn-save">Save Receiving Note</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function loadReceivingNotes() {
            fetch('get_receiving_notes.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayReceivingNotes(data.notes);
                    }
                });
        }

        function displayReceivingNotes(notes) {
            const contentDiv = document.getElementById('notes-content');
            if (notes.length === 0) {
                contentDiv.innerHTML = '<div style="text-align: center; padding: 40px; color: #999;">No receiving notes found</div>';
                return;
            }

            let html = '<div class="notes-table"><table><thead><tr>';
            html += '<th>RN Number</th><th>PO Number</th><th>Supplier</th><th>Received Date</th><th>Received By</th><th>Status</th><th>Actions</th>';
            html += '</tr></thead><tbody>';

            notes.forEach(note => {
                html += `<tr>
                    <td><strong>${note.rn_number}</strong></td>
                    <td>${note.po_number}</td>
                    <td>${note.supplier_name}</td>
                    <td>${note.received_date}</td>
                    <td>${note.received_by || 'N/A'}</td>
                    <td><span class="status-badge status-${note.status}">${note.status}</span></td>
                    <td><button class="btn-action btn-view" onclick="viewRN(${note.id})">View</button></td>
                </tr>`;
            });

            html += '</tbody></table></div>';
            contentDiv.innerHTML = html;
        }

        function openAddRNModal() {
            document.getElementById('rn-form').reset();
            document.getElementById('rn-date').value = new Date().toISOString().split('T')[0];
            loadPendingPOs();
            document.getElementById('rn-items-container').innerHTML = '<div style="text-align: center; padding: 20px; color: #999;">Select a Purchase Order to load items</div>';
            document.getElementById('rn-modal').style.display = 'block';
        }

        function closeRNModal() {
            document.getElementById('rn-modal').style.display = 'none';
        }

        function loadPendingPOs() {
            fetch('get_pending_purchase_orders.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const select = document.getElementById('rn-po-id');
                        select.innerHTML = '<option value="">Select Purchase Order</option>';
                        data.orders.forEach(order => {
                            const option = document.createElement('option');
                            option.value = order.id;
                            option.textContent = `${order.po_number} - ${order.supplier_name}`;
                            select.appendChild(option);
                        });
                    }
                });
        }

        function loadPOItems() {
            const poId = document.getElementById('rn-po-id').value;
            if (!poId) {
                document.getElementById('rn-items-container').innerHTML = '<div style="text-align: center; padding: 20px; color: #999;">Select a Purchase Order to load items</div>';
                return;
            }

            fetch(`get_po_items.php?po_id=${poId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayPOItems(data.items);
                    }
                });
        }

        function displayPOItems(items) {
            const container = document.getElementById('rn-items-container');
            let html = '<div style="display: grid; gap: 10px;">';
            items.forEach(item => {
                const remaining = item.quantity_ordered - item.quantity_received;
                html += `
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px;">
                        <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr 1fr; gap: 10px; align-items: end;">
                            <div>
                                <label><strong>${item.item_barcode}</strong></label>
                                <div style="font-size: 12px; color: #666;">${item.description || 'N/A'}</div>
                                <div style="font-size: 11px; color: #999;">Ordered: ${item.quantity_ordered} | Received: ${item.quantity_received} | Remaining: ${remaining}</div>
                            </div>
                            <div>
                                <label>Quantity Received *</label>
                                <input type="number" class="rn-item-qty" min="0" max="${remaining}" value="${remaining}" data-po-item-id="${item.id}" data-ordered="${item.quantity_ordered}" data-received="${item.quantity_received}">
                            </div>
                            <div>
                                <label>Damaged</label>
                                <input type="number" class="rn-item-damaged" min="0" value="0" data-po-item-id="${item.id}">
                            </div>
                            <div>
                                <label>Missing</label>
                                <input type="number" class="rn-item-missing" min="0" value="0" data-po-item-id="${item.id}">
                            </div>
                            <div>
                                <label>Notes</label>
                                <input type="text" class="rn-item-notes" data-po-item-id="${item.id}">
                            </div>
                        </div>
                    </div>
                `;
            });
            html += '</div>';
            container.innerHTML = html;
        }

        document.getElementById('rn-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const poId = document.getElementById('rn-po-id').value;
            const rnNumber = document.getElementById('rn-number').value;
            const receivedDate = document.getElementById('rn-date').value;
            const notes = document.getElementById('rn-notes').value;
            const receivedBy = '<?php echo $_SESSION['user_name'] ?? 'System'; ?>';

            const items = [];
            document.querySelectorAll('.rn-item-qty').forEach(input => {
                const poItemId = input.dataset.poItemId;
                const qtyReceived = parseInt(input.value) || 0;
                const qtyDamaged = parseInt(document.querySelector(`.rn-item-damaged[data-po-item-id="${poItemId}"]`).value) || 0;
                const qtyMissing = parseInt(document.querySelector(`.rn-item-missing[data-po-item-id="${poItemId}"]`).value) || 0;
                const itemNotes = document.querySelector(`.rn-item-notes[data-po-item-id="${poItemId}"]`).value || '';

                if (qtyReceived > 0 || qtyDamaged > 0 || qtyMissing > 0) {
                    items.push({
                        po_item_id: poItemId,
                        quantity_received: qtyReceived,
                        quantity_damaged: qtyDamaged,
                        quantity_missing: qtyMissing,
                        notes: itemNotes
                    });
                }
            });

            if (items.length === 0) {
                alert('Please enter at least one item received');
                return;
            }

            const formData = new FormData();
            formData.append('po_id', poId);
            formData.append('rn_number', rnNumber);
            formData.append('received_date', receivedDate);
            formData.append('received_by', receivedBy);
            formData.append('notes', notes);
            formData.append('items', JSON.stringify(items));

            fetch('save_receiving_note.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    closeRNModal();
                    loadReceivingNotes();
                    alert('Receiving note saved successfully');
                } else {
                    alert('Error: ' + data.message);
                }
            });
        });

        window.onclick = function(event) {
            const modal = document.getElementById('rn-modal');
            if (event.target == modal) {
                closeRNModal();
            }
        }

        function viewRN(id) {
            window.location.href = `view_rn.php?id=${id}`;
        }

        window.addEventListener('DOMContentLoaded', function() {
            loadReceivingNotes();
        });
    </script>
</body>
</html>
