<?php
include 'db_connect.php';

$message = '';
$message_type = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_area'])) {
        $area_code = trim($_POST['area_code']);
        $area_name = trim($_POST['area_name']);
        $branch = trim($_POST['branch']);
        
        if (empty($area_code) || empty($area_name) || empty($branch)) {
            $message = 'All fields are required';
            $message_type = 'error';
        } else {
            // Check if area_code already exists
            $check_stmt = $conn->prepare("SELECT id FROM areas WHERE area_code = ?");
            $check_stmt->bind_param("s", $area_code);
            $check_stmt->execute();
            $result = $check_stmt->get_result();
            
            if ($result->num_rows > 0) {
                $message = 'Area code already exists';
                $message_type = 'error';
            } else {
                $insert_stmt = $conn->prepare("INSERT INTO areas (area_code, area_name, branch) VALUES (?, ?, ?)");
                $insert_stmt->bind_param("sss", $area_code, $area_name, $branch);
                
                if ($insert_stmt->execute()) {
                    $message = 'Area added successfully';
                    $message_type = 'success';
                } else {
                    $message = 'Failed to add area';
                    $message_type = 'error';
                }
                $insert_stmt->close();
            }
            $check_stmt->close();
        }
    } elseif (isset($_POST['delete_area'])) {
        $area_id = intval($_POST['area_id']);
        $delete_stmt = $conn->prepare("DELETE FROM areas WHERE id = ?");
        $delete_stmt->bind_param("i", $area_id);
        
        if ($delete_stmt->execute()) {
            $message = 'Area deleted successfully';
            $message_type = 'success';
        } else {
            $message = 'Failed to delete area';
            $message_type = 'error';
        }
        $delete_stmt->close();
    } elseif (isset($_POST['toggle_status'])) {
        $area_id = intval($_POST['area_id']);
        $toggle_stmt = $conn->prepare("UPDATE areas SET is_active = NOT is_active WHERE id = ?");
        $toggle_stmt->bind_param("i", $area_id);
        
        if ($toggle_stmt->execute()) {
            $message = 'Area status updated successfully';
            $message_type = 'success';
        } else {
            $message = 'Failed to update area status';
            $message_type = 'error';
        }
        $toggle_stmt->close();
    }
}

// Get all areas
$areas_query = "SELECT * FROM areas ORDER BY branch, area_name";
$areas_result = $conn->query($areas_query);

// Get unique branches for dropdown
$branches_query = "SELECT DISTINCT branch FROM picking_orders WHERE branch IS NOT NULL ORDER BY branch";
$branches_result = $conn->query($branches_query);
$branches = [];
if ($branches_result->num_rows > 0) {
    while ($row = $branches_result->fetch_assoc()) {
        $branches[] = $row['branch'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Areas - Warehouse Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #f5f9ff 0%, #e8f4fd 100%);
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            margin-bottom: 20px;
        }
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .form-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 4px;
            margin-bottom: 30px;
        }
        .form-section h2 {
            color: #2c3e50;
            margin-bottom: 15px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
        }
        .btn-primary {
            background: #007bff;
            color: white;
        }
        .btn-primary:hover {
            background: #0056b3;
        }
        .btn-danger {
            background: #dc3545;
            color: white;
            padding: 5px 10px;
            font-size: 12px;
        }
        .btn-danger:hover {
            background: #c82333;
        }
        .btn-warning {
            background: #ffc107;
            color: #212529;
            padding: 5px 10px;
            font-size: 12px;
        }
        .btn-warning:hover {
            background: #e0a800;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #2c3e50;
            color: white;
        }
        tr:hover {
            background: #f5f5f5;
        }
        .status-active {
            color: #28a745;
            font-weight: bold;
        }
        .status-inactive {
            color: #dc3545;
            font-weight: bold;
        }
        .actions {
            display: flex;
            gap: 5px;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #007bff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <div class="main-content">
    <div class="container">
        <a href="warehouseM.php" class="back-link">← Back to Main Menu</a>
        <h1>Manage Areas</h1>
        
        <?php if ($message): ?>
            <div class="message <?php echo $message_type; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <div class="form-section">
            <h2>Add New Area</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="area_code">Area Code (Barcode):</label>
                    <input type="text" id="area_code" name="area_code" required placeholder="e.g., AREA1, AREA2">
                </div>
                <div class="form-group">
                    <label for="area_name">Area Name:</label>
                    <input type="text" id="area_name" name="area_name" required placeholder="e.g., Area 1, Area 2">
                </div>
                <div class="form-group">
                    <label for="branch">Branch:</label>
                    <select id="branch" name="branch" required>
                        <option value="">Select Branch</option>
                        <?php foreach ($branches as $branch): ?>
                            <option value="<?php echo htmlspecialchars($branch); ?>"><?php echo htmlspecialchars($branch); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <small style="color: #666; margin-top: 5px; display: block;">Or type a new branch name in the field above</small>
                    <input type="text" id="branch_custom" name="branch_custom" placeholder="Or enter custom branch name" style="margin-top: 5px;">
                </div>
                <button type="submit" name="add_area" class="btn btn-primary">Add Area</button>
            </form>
        </div>
        
        <div class="form-section">
            <h2>Existing Areas</h2>
            <?php if ($areas_result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Area Code</th>
                            <th>Area Name</th>
                            <th>Branch</th>
                            <th>Status</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($area = $areas_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $area['id']; ?></td>
                                <td><strong><?php echo htmlspecialchars($area['area_code']); ?></strong></td>
                                <td><?php echo htmlspecialchars($area['area_name']); ?></td>
                                <td><?php echo htmlspecialchars($area['branch']); ?></td>
                                <td>
                                    <span class="<?php echo $area['is_active'] ? 'status-active' : 'status-inactive'; ?>">
                                        <?php echo $area['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </td>
                                <td><?php echo $area['created_at']; ?></td>
                                <td>
                                    <div class="actions">
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="area_id" value="<?php echo $area['id']; ?>">
                                            <button type="submit" name="toggle_status" class="btn btn-warning">
                                                <?php echo $area['is_active'] ? 'Deactivate' : 'Activate'; ?>
                                            </button>
                                        </form>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this area?');">
                                            <input type="hidden" name="area_id" value="<?php echo $area['id']; ?>">
                                            <button type="submit" name="delete_area" class="btn btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No areas found. Please add an area above.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        // Allow custom branch input
        document.getElementById('branch').addEventListener('change', function() {
            if (this.value === '') {
                document.getElementById('branch_custom').style.display = 'block';
            } else {
                document.getElementById('branch_custom').style.display = 'none';
            }
        });
        
        // Handle form submission with custom branch
        document.querySelector('form').addEventListener('submit', function(e) {
            const branchSelect = document.getElementById('branch');
            const branchCustom = document.getElementById('branch_custom');
            
            if (branchSelect.value === '' && branchCustom.value.trim() !== '') {
                // Create a hidden input with the custom branch value
                const hiddenInput = document.createElement('input');
                hiddenInput.type = 'hidden';
                hiddenInput.name = 'branch';
                hiddenInput.value = branchCustom.value.trim();
                this.appendChild(hiddenInput);
                branchSelect.disabled = true;
            }
        });
    </script>
        </div>
    </div>
</body>
</html>
<?php
$conn->close();
?>




















