<?php

include 'navbar.php';
include 'db_connect.php';

// Check if suppliers table exists, if not create it
$check_table = $conn->query("SHOW TABLES LIKE 'suppliers'");
if ($check_table->num_rows == 0) {
    $create_table = "CREATE TABLE IF NOT EXISTS `suppliers` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `supplier_name` varchar(100) NOT NULL,
        `contact_person` varchar(100) DEFAULT NULL,
        `email` varchar(100) DEFAULT NULL,
        `phone` varchar(50) DEFAULT NULL,
        `address` text DEFAULT NULL,
        `status` enum('active','inactive') DEFAULT 'active',
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $conn->query($create_table);
}

// Handle delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $supplier_id = intval($_GET['delete']);
    $delete_stmt = $conn->prepare("DELETE FROM suppliers WHERE id = ?");
    $delete_stmt->bind_param("i", $supplier_id);
    if ($delete_stmt->execute()) {
        $message = "<div style='background: #d4edda; color: #155724; padding: 12px; border-radius: 5px; margin-bottom: 20px;'>Supplier deleted successfully!</div>";
    } else {
        $message = "<div style='background: #f8d7da; color: #721c24; padding: 12px; border-radius: 5px; margin-bottom: 20px;'>Error deleting supplier: " . $conn->error . "</div>";
    }
    $delete_stmt->close();
}

// Get all suppliers
$suppliers_query = "SELECT * FROM suppliers ORDER BY supplier_name";
$suppliers_result = $conn->query($suppliers_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Management</title>
    <style>
        .main-content {
            padding: 25px;
        }
        .page-header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-header h1 {
            color: var(--text-primary);
            font-size: 28px;
        }
        .btn-add {
            padding: 12px 24px;
            background: var(--light-blue);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: background 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-add:hover {
            background: var(--secondary);
        }
        .suppliers-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        thead {
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--secondary) 100%);
            color: white;
        }
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }
        tbody tr:hover {
            background: #f8f9fa;
        }
        .btn-action {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            margin: 2px;
            transition: all 0.3s;
        }
        .btn-edit {
            background: #ffc107;
            color: #333;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .status-active { background: #d4edda; color: #155724; }
        .status-inactive { background: #f8d7da; color: #721c24; }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
        }
        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .modal-header h2 {
            color: var(--text-primary);
        }
        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: #000;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: var(--text-primary);
            font-weight: 500;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        .btn-submit {
            padding: 12px 24px;
            background: var(--light-blue);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: background 0.3s;
        }
        .btn-submit:hover {
            background: var(--secondary);
        }
        .no-data {
            text-align: center;
            padding: 40px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php 
        $current_page = 'supplier_management.php';
        include 'navbar.php'; 
        ?>
        <div class="main-content">
            <div class="page-header">
                <div>
                    <h1>🏢 Supplier Management</h1>
                    <p style="color: var(--text-muted);">Manage supplier information and contacts</p>
                </div>
                <button class="btn-add" onclick="openAddModal()">➕ Add Supplier</button>
            </div>

            <?php if (isset($message)) echo $message; ?>

            <div class="suppliers-table">
                <?php if ($suppliers_result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Supplier Name</th>
                            <th>Contact Person</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $suppliers_result->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($row['supplier_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($row['contact_person'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($row['email'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($row['phone'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars(substr($row['address'] ?? '-', 0, 50)); ?><?php echo strlen($row['address'] ?? '') > 50 ? '...' : ''; ?></td>
                            <td><span class="status-badge status-<?php echo $row['status']; ?>"><?php echo ucfirst($row['status']); ?></span></td>
                            <td>
                                <button class="btn-action btn-edit" onclick="editSupplier(<?php echo $row['id']; ?>)">Edit</button>
                                <button class="btn-action btn-delete" onclick="deleteSupplier(<?php echo $row['id']; ?>)">Delete</button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="no-data">No suppliers found. Click "Add Supplier" to add a new supplier.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Add/Edit Modal -->
    <div id="supplier-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modal-title">Add Supplier</h2>
                <span class="close" onclick="closeModal()">&times;</span>
            </div>
            <form id="supplier-form" method="POST" action="save_supplier.php">
                <input type="hidden" id="supplier-id" name="id">
                <div class="form-group">
                    <label>Supplier Name *</label>
                    <input type="text" id="supplier-name" name="supplier_name" required>
                </div>
                <div class="form-group">
                    <label>Contact Person</label>
                    <input type="text" id="contact-person" name="contact_person">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" id="email" name="email">
                </div>
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" id="phone" name="phone">
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <textarea id="address" name="address"></textarea>
                </div>
                <div class="form-group">
                    <label>Status *</label>
                    <select id="status" name="status" required>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <div style="text-align: right;">
                    <button type="button" class="btn-submit" onclick="closeModal()" style="background: #6c757d; margin-right: 10px;">Cancel</button>
                    <button type="submit" class="btn-submit">Save</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openAddModal() {
            document.getElementById('modal-title').textContent = 'Add Supplier';
            document.getElementById('supplier-form').reset();
            document.getElementById('supplier-id').value = '';
            document.getElementById('status').value = 'active';
            document.getElementById('supplier-modal').style.display = 'block';
        }

        function editSupplier(id) {
            fetch('get_supplier.php?id=' + id)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const supplier = data.supplier;
                        document.getElementById('modal-title').textContent = 'Edit Supplier';
                        document.getElementById('supplier-id').value = supplier.id;
                        document.getElementById('supplier-name').value = supplier.supplier_name;
                        document.getElementById('contact-person').value = supplier.contact_person || '';
                        document.getElementById('email').value = supplier.email || '';
                        document.getElementById('phone').value = supplier.phone || '';
                        document.getElementById('address').value = supplier.address || '';
                        document.getElementById('status').value = supplier.status;
                        document.getElementById('supplier-modal').style.display = 'block';
                    }
                });
        }

        function deleteSupplier(id) {
            if (confirm('Are you sure you want to delete this supplier?')) {
                window.location.href = 'supplier_management.php?delete=' + id;
            }
        }

        function closeModal() {
            document.getElementById('supplier-modal').style.display = 'none';
        }

        window.onclick = function(event) {
            const modal = document.getElementById('supplier-modal');
            if (event.target == modal) {
                closeModal();
            }
        }

        document.getElementById('supplier-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            fetch('save_supplier.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'Error saving supplier');
                }
            });
        });
    </script>
</body>
</html>
<?php
$conn->close();
?>
