<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'loader') {
    header("Location: login.php?role=loader");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.9, maximum-scale=0.9">
    <title>Loader - Plate Loading System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background: #f5f5f5;
            padding: 10px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .header h1 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .header p {
            font-size: 14px;
            opacity: 0.9;
        }
        .content {
            padding: 20px;
        }
        .scanner-section {
            background: #f8f9fa;
            border: 2px dashed #2c3e50;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            text-align: center;
        }
        .scanner-icon {
            font-size: 48px;
            margin-bottom: 10px;
        }
        .field {
            margin-bottom: 15px;
        }
        .field label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
            font-size: 14px;
        }
        .field input {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            text-align: center;
            letter-spacing: 2px;
        }
        .field input:focus {
            outline: none;
            border-color: #2c3e50;
            background: #f8f9fa;
        }
        .info-box {
            background: white;
            border: 2px solid #2c3e50;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
        }
        .info-box h3 {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 18px;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 10px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .info-label {
            font-weight: bold;
            color: #666;
        }
        .info-value {
            color: #2c3e50;
            font-weight: 600;
        }
        .items-list {
            margin-top: 20px;
        }
        .item-card {
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 12px;
            margin-bottom: 10px;
        }
        .item-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }
        .item-barcode {
            font-weight: bold;
            color: #2c3e50;
            font-size: 16px;
        }
        .item-description {
            color: #666;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .item-quantity {
            color: #28a745;
            font-weight: bold;
            font-size: 18px;
        }
        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #28a745;
            color: white;
        }
        .btn-primary:hover {
            background: #218838;
        }
        .btn-primary:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
            margin-top: 10px;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        .status-ready {
            background: #28a745;
            color: white;
        }
        .message {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
            font-weight: bold;
        }
        .message-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .message-info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        .hidden {
            display: none;
        }
        .loading {
            text-align: center;
            padding: 20px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📦 Loader - Plate Loading</h1>
            <p>Scan Plate ID to load verified plates to branch</p>
            <?php if (isset($_SESSION['user_name'])): ?>
            <p style="font-size: 12px; margin-top: 5px;">Welcome, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></p>
            <a href="logout.php" style="color: #fff; text-decoration: none; font-size: 12px; margin-top: 5px; display: inline-block; padding: 5px 10px; background: rgba(255,255,255,0.2); border-radius: 3px;">Logout</a>
            <?php endif; ?>
        </div>
        <div class="content">
            <div id="message-container"></div>
            
            <div class="scanner-section">
                <div class="scanner-icon">📷</div>
                <div class="field">
                    <label>Scan Plate ID</label>
                    <input type="text" id="plate-id-input" placeholder="Enter or scan Plate ID (e.g., L-000123)" autofocus>
                </div>
            </div>

            <div id="plate-info" class="hidden">
                <div class="info-box">
                    <h3>Plate Information</h3>
                    <div class="info-row">
                        <span class="info-label">Plate ID:</span>
                        <span class="info-value" id="plate-id-display">-</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Work ID:</span>
                        <span class="info-value" id="work-id-display">-</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Branch:</span>
                        <span class="info-value" id="branch-display">-</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Status:</span>
                        <span class="info-value">
                            <span class="status-badge status-ready" id="status-display">Ready for Load</span>
                        </span>
                    </div>
                </div>

                <div class="info-box">
                    <h3>Personnel Information</h3>
                    <div class="info-row">
                        <span class="info-label">Picker:</span>
                        <span class="info-value" id="picker-display">-</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">QC Verified By:</span>
                        <span class="info-value" id="qc-display">-</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Verified At:</span>
                        <span class="info-value" id="verified-at-display">-</span>
                    </div>
                </div>

                <div class="info-box items-list">
                    <h3>Items to Load</h3>
                    <div id="items-container"></div>
                    <div class="info-row" style="margin-top: 15px; padding-top: 15px; border-top: 2px solid #2c3e50;">
                        <span class="info-label" style="font-size: 16px;">Total Items:</span>
                        <span class="info-value" style="font-size: 18px;" id="total-items-display">0</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label" style="font-size: 16px;">Total Quantity:</span>
                        <span class="info-value" style="font-size: 18px; color: #28a745;" id="total-quantity-display">0</span>
                    </div>
                </div>

                <button class="btn btn-primary" id="confirm-loading-btn">✅ Confirm Loading</button>
                <button class="btn btn-secondary" id="scan-new-btn">Scan New Plate</button>
            </div>
        </div>
    </div>

    <script>
        let currentPlateData = null;

        // Auto-focus on plate ID input
        document.getElementById('plate-id-input').focus();

        // Handle plate ID input
        document.getElementById('plate-id-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const plateId = this.value.trim();
                if (plateId) {
                    loadPlateData(plateId);
                }
            }
        });

        // Scan new plate button
        document.getElementById('scan-new-btn').addEventListener('click', function() {
            resetForm();
        });

        // Confirm loading button
        document.getElementById('confirm-loading-btn').addEventListener('click', function() {
            if (currentPlateData) {
                confirmLoading(currentPlateData.plate_id);
            }
        });

        function loadPlateData(plateId) {
            showMessage('Loading plate data...', 'info');
            document.getElementById('plate-info').classList.add('hidden');
            document.getElementById('confirm-loading-btn').disabled = true;

            fetch(`get_plate_for_loading.php?plate_id=${encodeURIComponent(plateId)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        currentPlateData = data;
                        displayPlateInfo(data);
                        showMessage('Plate loaded successfully. Review and confirm loading.', 'success');
                    } else {
                        showMessage(data.message || 'Plate not found or not ready for loading', 'error');
                        resetForm();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Failed to load plate data', 'error');
                    resetForm();
                });
        }

        function displayPlateInfo(data) {
            // Plate information
            document.getElementById('plate-id-display').textContent = data.plate_id;
            document.getElementById('work-id-display').textContent = data.work_id || '-';
            document.getElementById('branch-display').textContent = data.branch || '-';
            document.getElementById('status-display').textContent = 'Ready for Load';

            // Personnel information
            document.getElementById('picker-display').textContent = data.picker_name || 'Unknown';
            document.getElementById('qc-display').textContent = data.qc_name || 'Unknown';
            document.getElementById('verified-at-display').textContent = data.verified_at ? 
                new Date(data.verified_at).toLocaleString() : '-';

            // Items
            const itemsContainer = document.getElementById('items-container');
            itemsContainer.innerHTML = '';

            let totalItems = 0;
            let totalQuantity = 0;

            if (data.items && data.items.length > 0) {
                data.items.forEach(item => {
                    const itemCard = document.createElement('div');
                    itemCard.className = 'item-card';
                    itemCard.innerHTML = `
                        <div class="item-header">
                            <span class="item-barcode">${item.item_barcode}</span>
                            <span class="item-quantity">${item.qc_quantity || item.quantity_picked} PC</span>
                        </div>
                        <div class="item-description">${item.description || item.item_barcode}</div>
                    `;
                    itemsContainer.appendChild(itemCard);
                    totalItems++;
                    totalQuantity += parseInt(item.qc_quantity || item.quantity_picked || 0);
                });
            } else {
                itemsContainer.innerHTML = '<div class="loading">No items found</div>';
            }

            document.getElementById('total-items-display').textContent = totalItems;
            document.getElementById('total-quantity-display').textContent = totalQuantity + ' PC';

            // Show plate info
            document.getElementById('plate-info').classList.remove('hidden');
            document.getElementById('confirm-loading-btn').disabled = false;
        }

        function confirmLoading(plateId) {
            if (!confirm('Are you sure you want to confirm loading this plate to the branch?')) {
                return;
            }

            document.getElementById('confirm-loading-btn').disabled = true;
            showMessage('Confirming loading...', 'info');

            fetch('confirm_loading.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `plate_id=${encodeURIComponent(plateId)}`
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage('✅ Plate loaded successfully! Plate status updated to "Loaded".', 'success');
                        setTimeout(() => {
                            resetForm();
                        }, 2000);
                    } else {
                        showMessage(data.message || 'Failed to confirm loading', 'error');
                        document.getElementById('confirm-loading-btn').disabled = false;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Failed to confirm loading', 'error');
                    document.getElementById('confirm-loading-btn').disabled = false;
                });
        }

        function resetForm() {
            document.getElementById('plate-id-input').value = '';
            document.getElementById('plate-id-input').focus();
            document.getElementById('plate-info').classList.add('hidden');
            document.getElementById('message-container').innerHTML = '';
            currentPlateData = null;
        }

        function showMessage(message, type) {
            const messageContainer = document.getElementById('message-container');
            messageContainer.innerHTML = `<div class="message message-${type}">${message}</div>`;
            setTimeout(() => {
                messageContainer.innerHTML = '';
            }, 5000);
        }
    </script>
</body>
</html>


