<?php
session_start();
header('Content-Type: application/json');
include 'db_connect.php';

// Check if suppliers table exists, if not create it
$check_table = $conn->query("SHOW TABLES LIKE 'suppliers'");
if ($check_table->num_rows == 0) {
    $create_table = "CREATE TABLE IF NOT EXISTS `suppliers` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `supplier_name` varchar(100) NOT NULL,
        `contact_person` varchar(100) DEFAULT NULL,
        `email` varchar(100) DEFAULT NULL,
        `phone` varchar(50) DEFAULT NULL,
        `address` text DEFAULT NULL,
        `status` enum('active','inactive') DEFAULT 'active',
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $conn->query($create_table);
}

$query = "SELECT id, supplier_name, status FROM suppliers WHERE status = 'active' ORDER BY supplier_name";
$result = $conn->query($query);

$suppliers = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $suppliers[] = $row;
    }
}

echo json_encode(['success' => true, 'suppliers' => $suppliers]);
$conn->close();
?>
