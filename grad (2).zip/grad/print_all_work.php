<?php
include 'db_connect.php';

// Get all pending work orders
$orders_query = "
    SELECT 
        po.id,
        po.work_id,
        po.branch,
        po.status,
        po.created_at,
        po.updated_at,
        COUNT(DISTINCT poi.id) as item_count,
        COALESCE(SUM(poi.quantity_required), 0) as total_quantity,
        COALESCE(SUM(CASE WHEN poi.status = 'picked' THEN 1 ELSE 0 END), 0) as picked_items
    FROM picking_orders po
    LEFT JOIN picking_order_items poi ON po.work_id = poi.work_id
    WHERE po.status = 'pending'
    GROUP BY po.id
    ORDER BY po.created_at DESC
";
$orders_result = $conn->query($orders_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print All Pending Work Orders</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background: white;
            color: #333;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #2c3e50;
        }
        .header h1 {
            color: #2c3e50;
            font-size: 28px;
            margin-bottom: 10px;
        }
        .print-date {
            color: #666;
            font-size: 14px;
        }
        .work-order {
            margin-bottom: 40px;
            page-break-after: always;
            border: 2px solid #ddd;
            padding: 20px;
            border-radius: 8px;
        }
        .work-order:last-child {
            page-break-after: auto;
        }
        .work-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #2c3e50;
        }
        .work-info {
            flex: 1;
        }
        .work-info h2 {
            color: #2c3e50;
            font-size: 22px;
            margin-bottom: 10px;
        }
        .info-row {
            display: flex;
            gap: 30px;
            margin-bottom: 5px;
        }
        .info-label {
            font-weight: bold;
            min-width: 120px;
        }
        .info-value {
            color: #555;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #2c3e50;
            color: white;
            font-weight: 600;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .status {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            background: #fff3cd;
            color: #856404;
        }
        .no-print {
            text-align: center;
            margin-bottom: 20px;
        }
        .print-btn {
            background: #28a745;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin: 10px;
        }
        .print-btn:hover {
            background: #218838;
        }
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                padding: 0;
            }
            .work-order {
                border: 1px solid #ddd;
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="no-print">
        <button class="print-btn" onclick="window.print()">🖨️ Print All</button>
        <a href="transfer_orders.php" style="color: #007bff; text-decoration: none; padding: 12px 30px; background: #f8f9fa; border-radius: 5px; display: inline-block;">← Back to Orders</a>
    </div>

    <div class="header">
        <h1>All Pending Work Orders</h1>
        <div class="print-date">Printed on: <?php echo date('Y-m-d H:i:s'); ?></div>
    </div>

    <?php
    if ($orders_result && $orders_result->num_rows > 0) {
        while ($order = $orders_result->fetch_assoc()) {
            // Get items for this work order
            $work_id = $order['work_id'];
            $items_query = "
                SELECT 
                    poi.*,
                    COALESCE(ad.name, ad.description, poi.item_barcode) as item_name
                FROM picking_order_items poi
                LEFT JOIN adddesc ad ON poi.item_barcode = ad.barcode
                WHERE poi.work_id = '$work_id'
                ORDER BY 
                    CAST(SUBSTRING_INDEX(COALESCE(poi.location_code, ''), '-', 1) AS UNSIGNED) ASC,
                    poi.sequence,
                    poi.id
            ";
            $items_result = $conn->query($items_query);
            ?>
            <div class="work-order">
                <div class="work-header">
                    <div class="work-info">
                        <h2>Work ID: <?php echo htmlspecialchars($order['work_id']); ?></h2>
                        <div class="info-row">
                            <div>
                                <span class="info-label">Branch:</span>
                                <span class="info-value"><?php echo htmlspecialchars($order['branch'] ?? '-'); ?></span>
                            </div>
                            <div>
                                <span class="info-label">Status:</span>
                                <span class="status"><?php echo ucwords(str_replace('_', ' ', $order['status'])); ?></span>
                            </div>
                            <div>
                                <span class="info-label">Created:</span>
                                <span class="info-value"><?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></span>
                            </div>
                        </div>
                        <div class="info-row">
                            <div>
                                <span class="info-label">Total Items:</span>
                                <span class="info-value"><?php echo $order['item_count']; ?></span>
                            </div>
                            <div>
                                <span class="info-label">Total Quantity:</span>
                                <span class="info-value"><?php echo $order['total_quantity']; ?></span>
                            </div>
                            <div>
                                <span class="info-label">Picked Items:</span>
                                <span class="info-value"><?php echo $order['picked_items']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Item Barcode</th>
                            <th>Item Name</th>
                            <th>Location</th>
                            <th>Required Qty</th>
                            <th>Picked Qty</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($items_result && $items_result->num_rows > 0) {
                            $item_num = 1;
                            while ($item = $items_result->fetch_assoc()) {
                                $status_class = $item['status'] === 'picked' ? 'completed' : ($item['status'] === 'skipped' ? 'cancelled' : 'pending');
                                $status_display = ucwords($item['status']);
                                ?>
                                <tr>
                                    <td><?php echo $item_num++; ?></td>
                                    <td><?php echo htmlspecialchars($item['item_barcode']); ?></td>
                                    <td><?php echo htmlspecialchars($item['item_name'] ?? '-'); ?></td>
                                    <td><?php echo htmlspecialchars($item['location_code'] ?? '-'); ?></td>
                                    <td><?php echo $item['quantity_required']; ?></td>
                                    <td><?php echo $item['quantity_picked'] ?? 0; ?></td>
                                    <td>
                                        <span class="status status-<?php echo $status_class; ?>">
                                            <?php echo $status_display; ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="7" style="text-align: center; color: #999;">No items found</td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <?php
        }
    } else {
        ?>
        <div style="text-align: center; padding: 40px; color: #999;">
            <h2>No Pending Work Orders</h2>
            <p>All work orders have been processed.</p>
        </div>
        <?php
    }
    ?>

    <script>
        // Auto-print when page loads (optional - can be removed if not needed)
        // window.onload = function() {
        //     window.print();
        // }
    </script>
</body>
</html>

