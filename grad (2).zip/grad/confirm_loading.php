<?php
session_start();
header('Content-Type: application/json');
include 'db_connect.php';

// Add loaded_by column to plate_verifications if it doesn't exist
$check_column = $conn->query("SHOW COLUMNS FROM plate_verifications LIKE 'loaded_by'");
if ($check_column->num_rows == 0) {
    $conn->query("ALTER TABLE plate_verifications ADD COLUMN loaded_by varchar(100) DEFAULT NULL AFTER ready_for_load_at");
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

if (!isset($_POST['plate_id']) || empty(trim($_POST['plate_id']))) {
    echo json_encode([
        'success' => false,
        'message' => 'Plate ID is required'
    ]);
    exit;
}

$plate_id = trim($_POST['plate_id']);

// Start transaction
$conn->begin_transaction();

try {
    // Verify plate exists and is ready_to_load
    $check_stmt = $conn->prepare("
        SELECT plate_id, plate_status, work_id, branch
        FROM plate_verifications
        WHERE plate_id = ?
        AND plate_status = 'ready_to_load'
        LIMIT 1
    ");
    $check_stmt->bind_param("s", $plate_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows === 0) {
        throw new Exception('Plate not found or not ready for loading. Only plates with status "ready_to_load" can be loaded.');
    }
    
    $plate_data = $check_result->fetch_assoc();
    $check_stmt->close();
    
    // Update plate status to 'loaded' with loader name
    $loaded_by = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'System';
    $update_stmt = $conn->prepare("
        UPDATE plate_verifications
        SET plate_status = 'loaded',
            ready_for_load_at = NOW(),
            loaded_by = ?
        WHERE plate_id = ?
    ");
    $update_stmt->bind_param("ss", $loaded_by, $plate_id);
    $update_stmt->execute();
    
    if ($update_stmt->affected_rows === 0) {
        throw new Exception('Failed to update plate status');
    }
    $update_stmt->close();
    
    // Commit transaction
    $conn->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Plate loaded successfully. Status updated to "loaded".',
        'plate_id' => $plate_id,
        'branch' => $plate_data['branch']
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

$conn->close();
?>


