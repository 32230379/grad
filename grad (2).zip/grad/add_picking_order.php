<?php
// Helper file to add picking orders
// This can be used by branches to create picking orders with work-ids
include 'db_connect.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $work_id = trim($_POST['work_id'] ?? '');
    $branch = trim($_POST['branch'] ?? '');
    $items = $_POST['items'] ?? []; // Array of items: [['barcode' => '', 'location' => '', 'quantity' => ''], ...]
    
    if (empty($work_id)) {
        $message = "Error: Work ID is required";
    } else {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Step 1: Find best location for each item and group by zone
            $items_by_zone = []; // Structure: ['A' => [items...], 'B' => [items...], ...]
            
            if (!empty($items) && is_array($items)) {
                foreach ($items as $item) {
                    if (!empty($item['barcode']) && !empty($item['quantity'])) {
                        $barcode = trim($item['barcode']);
                        $quantity = intval($item['quantity']);
                        
                        // Find best location for this item (prioritize lower shelves, one zone only)
                        $location_stmt = $conn->prepare("
                            SELECT 
                                i.location_code,
                                i.zone,
                                i.quantity,
                                loc.shelf_number
                            FROM inventory i
                            LEFT JOIN locations loc ON i.location_code = loc.location_code
                            WHERE i.item_barcode = ? 
                                AND i.quantity > 0
                            ORDER BY 
                                COALESCE(loc.shelf_number, 999) ASC,
                                i.quantity DESC
                            LIMIT 1
                        ");
                        $location_stmt->bind_param("s", $barcode);
                        $location_stmt->execute();
                        $location_result = $location_stmt->get_result();
                        
                        if ($location_result->num_rows > 0) {
                            $location_data = $location_result->fetch_assoc();
                            $zone = $location_data['zone'] ?? 'UNKNOWN';
                            $location_code = $location_data['location_code'];
                            
                            // Group items by zone
                            if (!isset($items_by_zone[$zone])) {
                                $items_by_zone[$zone] = [];
                            }
                            
                            $items_by_zone[$zone][] = [
                                'barcode' => $barcode,
                                'quantity' => $quantity,
                                'location_code' => $location_code,
                                'zone' => $zone
                            ];
                        } else {
                            // Item not found in inventory - add to UNKNOWN zone
                            if (!isset($items_by_zone['UNKNOWN'])) {
                                $items_by_zone['UNKNOWN'] = [];
                            }
                            $items_by_zone['UNKNOWN'][] = [
                                'barcode' => $barcode,
                                'quantity' => $quantity,
                                'location_code' => null,
                                'zone' => 'UNKNOWN'
                            ];
                        }
                        
                        $location_stmt->close();
                    }
                }
            }
            
            // Step 2: Create separate work_id for each zone
            $created_work_ids = [];
            $zone_counter = 1;
            
            foreach ($items_by_zone as $zone => $zone_items) {
                // Create work_id for this zone: original_work_id-ZONE (e.g., workid-123-A, workid-123-B)
                $zone_work_id = $work_id . '-' . $zone;
                
                // Insert picking order for this zone
                $stmt = $conn->prepare("INSERT INTO picking_orders (work_id, branch, status) VALUES (?, ?, 'pending') ON DUPLICATE KEY UPDATE branch = VALUES(branch), status = 'pending'");
                $stmt->bind_param("ss", $zone_work_id, $branch);
                $stmt->execute();
                $stmt->close();
                
                // Sort items by rack number ONLY (extract number before dash, ignore shelf number)
                usort($zone_items, function($a, $b) {
                    $rack_a = 0;
                    $rack_b = 0;
                    if (!empty($a['location_code']) && strpos($a['location_code'], '-') !== false) {
                        $rack_a = intval(explode('-', $a['location_code'])[0]);
                    }
                    if (!empty($b['location_code']) && strpos($b['location_code'], '-') !== false) {
                        $rack_b = intval(explode('-', $b['location_code'])[0]);
                    }
                    return $rack_a <=> $rack_b; // Sort by rack number only (ascending)
                });
                
                // Insert items for this zone
                $stmt = $conn->prepare("INSERT INTO picking_order_items (work_id, item_barcode, location_code, quantity_required, status, sequence) VALUES (?, ?, ?, ?, 'pending', ?) ON DUPLICATE KEY UPDATE quantity_required = VALUES(quantity_required), location_code = VALUES(location_code)");
                
                $sequence = 1;
                foreach ($zone_items as $zone_item) {
                    $stmt->bind_param("sssii", 
                        $zone_work_id, 
                        $zone_item['barcode'], 
                        $zone_item['location_code'],
                        $zone_item['quantity'],
                        $sequence
                    );
                    $stmt->execute();
                    $sequence++;
                }
                $stmt->close();
                
                $created_work_ids[] = $zone_work_id;
                $zone_counter++;
            }
            
            $conn->commit();
            
            // Create success message with all created work_ids
            if (count($created_work_ids) > 0) {
                $work_ids_list = implode(', ', $created_work_ids);
                $message = "Success: Order '{$work_id}' has been divided into " . count($created_work_ids) . " work order(s) by zones: {$work_ids_list}";
            } else {
                $message = "Warning: Order created but no items were found in inventory.";
            }
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Picking Order</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2 { color: #333; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="number"] { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .message { padding: 10px; margin: 10px 0; border-radius: 4px; }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
        .item-row { display: flex; gap: 10px; margin-bottom: 10px; }
        .item-row input { flex: 1; }
        #add-item { background: #28a745; margin-bottom: 15px; }
        #add-item:hover { background: #218838; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add Picking Order</h2>
        
        <?php if ($message): ?>
            <div class="message <?= strpos($message, 'Success') !== false ? 'success' : 'error' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" id="order-form">
            <div class="form-group">
                <label>Work ID *</label>
                <input type="text" name="work_id" required placeholder="e.g., workid-123">
            </div>
            
            <div class="form-group">
                <label>Branch Name *</label>
                <input type="text" name="branch" required placeholder="e.g., Dweir Branch">
            </div>
            
            <h3>Order Items</h3>
            <p style="color: #666; margin-bottom: 15px; font-size: 14px;">
                <strong>Note:</strong> System will automatically divide this order by zones. Each zone will get a separate work_id (e.g., workid-123-A, workid-123-B).<br>
                For each item, system will select the best location (one zone and one location only, prioritizing lower shelves).
            </p>
            <div id="items-container">
                <div class="item-row">
                    <input type="text" name="items[0][barcode]" placeholder="Item Barcode" required style="flex: 2;">
                    <input type="number" name="items[0][quantity]" placeholder="Quantity" min="1" required style="flex: 1;">
                </div>
            </div>
            
            <button type="button" id="add-item">+ Add Item</button>
            <button type="submit">Create Picking Order</button>
        </form>
    </div>
    
    <script>
        let itemCount = 1;
        document.getElementById('add-item').addEventListener('click', function() {
            const container = document.getElementById('items-container');
            const newRow = document.createElement('div');
            newRow.className = 'item-row';
            newRow.innerHTML = `
                <input type="text" name="items[${itemCount}][barcode]" placeholder="Item Barcode" required style="flex: 2;">
                <input type="number" name="items[${itemCount}][quantity]" placeholder="Quantity" min="1" required style="flex: 1;">
            `;
            container.appendChild(newRow);
            itemCount++;
        });
    </script>
</body>
</html>
