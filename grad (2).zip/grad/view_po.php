<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'manager') {
    header("Location: login.php?role=manager");
    exit();
}
include 'db_connect.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: purchase_orders.php");
    exit;
}

$po_id = intval($_GET['id']);
$print_mode = isset($_GET['print']) && $_GET['print'] == '1';

// Get PO details with supplier info
// Use only columns that definitely exist (supplier_name is required)
$po_query = "
    SELECT po.*, s.supplier_name
    FROM purchase_orders po
    LEFT JOIN suppliers s ON po.supplier_id = s.id
    WHERE po.id = ?
";
$stmt = $conn->prepare($po_query);
$stmt->bind_param("i", $po_id);
$stmt->execute();
$po_result = $stmt->get_result();

if ($po_result->num_rows === 0) {
    header("Location: purchase_orders.php");
    exit;
}

$po = $po_result->fetch_assoc();
$stmt->close();

// Get PO items
$items_query = "
    SELECT poi.*, ad.name as item_name, ad.description
    FROM purchase_order_items poi
    LEFT JOIN adddesc ad ON poi.item_barcode = ad.barcode
    WHERE poi.po_id = ?
    ORDER BY poi.id
";
$stmt = $conn->prepare($items_query);
$stmt->bind_param("i", $po_id);
$stmt->execute();
$items_result = $stmt->get_result();
$items = [];
while ($row = $items_result->fetch_assoc()) {
    $items[] = $row;
}
$stmt->close();

include 'navbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Purchase Order - <?php echo htmlspecialchars($po['po_number']); ?></title>
    <style>
        .main-content {
            padding: 25px;
        }
        .page-header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-header h1 {
            color: var(--text-primary);
            font-size: 28px;
        }
        .btn-back {
            padding: 10px 20px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-back:hover {
            background: #5a6268;
        }
        .btn-print {
            padding: 10px 20px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-left: 10px;
        }
        .btn-print:hover {
            background: #218838;
        }
        @media print {
            .btn-back, .btn-print, .no-print {
                display: none !important;
            }
            body {
                background: white;
            }
            .main-content {
                padding: 0;
            }
            .po-details, .items-table {
                box-shadow: none;
                border: 1px solid #ddd;
                page-break-inside: avoid;
            }
            table {
                page-break-inside: auto;
            }
            tr {
                page-break-inside: avoid;
                page-break-after: auto;
            }
        }
        .po-details {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 25px;
            margin-bottom: 25px;
        }
        .detail-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 15px;
        }
        .detail-item {
            margin-bottom: 15px;
        }
        .detail-item label {
            display: block;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 5px;
        }
        .detail-item span {
            color: var(--text-muted);
        }
        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-partial { background: #d1ecf1; color: #0c5460; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        .items-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        thead {
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--secondary) 100%);
            color: white;
        }
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }
        tbody tr:hover {
            background: #f8f9fa;
        }
        .summary-box {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .summary-total {
            font-size: 18px;
            font-weight: bold;
            padding-top: 10px;
            border-top: 2px solid #ddd;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php 
        $current_page = 'purchase_orders.php';
        include 'navbar.php'; 
        ?>
        <div class="main-content">
            <div class="page-header">
                <div>
                    <h1>Purchase Order: <?php echo htmlspecialchars($po['po_number']); ?></h1>
                </div>
                <div>
                    <?php if (!$print_mode): ?>
                    <a href="purchase_orders.php" class="btn-back">← Back to Purchase Orders</a>
                    <button class="btn-print" onclick="window.print()">🖨️ Print</button>
                    <?php endif; ?>
                </div>
            </div>

            <div class="po-details">
                <h2 style="margin-bottom: 20px; color: var(--text-primary);">Order Information</h2>
                <div class="detail-row">
                    <div class="detail-item">
                        <label>PO Number</label>
                        <span><?php echo htmlspecialchars($po['po_number']); ?></span>
                    </div>
                    <div class="detail-item">
                        <label>Status</label>
                        <span><span class="status-badge status-<?php echo $po['status']; ?>"><?php echo ucfirst($po['status']); ?></span></span>
                    </div>
                    <div class="detail-item">
                        <label>Supplier</label>
                        <span><?php echo htmlspecialchars($po['supplier_name'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-item">
                        <label>Order Date</label>
                        <span><?php echo htmlspecialchars($po['order_date']); ?></span>
                    </div>
                    <div class="detail-item">
                        <label>Expected Delivery Date</label>
                        <span><?php echo htmlspecialchars($po['expected_delivery_date'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-item">
                        <label>Created By</label>
                        <span><?php echo htmlspecialchars($po['created_by'] ?? 'System'); ?></span>
                    </div>
                </div>
                <?php if (!empty($po['notes'])): ?>
                <div class="detail-item">
                    <label>Notes</label>
                    <span><?php echo nl2br(htmlspecialchars($po['notes'])); ?></span>
                </div>
                <?php endif; ?>
            </div>

            <div class="items-table">
                <h2 style="padding: 20px 20px 10px 20px; color: var(--text-primary);">Order Items</h2>
                <?php if (count($items) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Item Barcode</th>
                            <th>Item Name</th>
                            <th>Quantity Ordered</th>
                            <th>Quantity Received</th>
                            <th>Unit Price</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $subtotal = 0;
                        foreach ($items as $item): 
                            $subtotal += floatval($item['total_price']);
                        ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($item['item_barcode']); ?></strong></td>
                            <td><?php echo htmlspecialchars($item['item_name'] ?? 'N/A'); ?></td>
                            <td><?php echo $item['quantity_ordered']; ?></td>
                            <td><?php echo $item['quantity_received'] ?? 0; ?></td>
                            <td><?php echo number_format($item['unit_price'], 2); ?></td>
                            <td><strong><?php echo number_format($item['total_price'], 2); ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="summary-box">
                    <div class="summary-row">
                        <strong>Subtotal:</strong>
                        <span><?php echo number_format($po['subtotal'], 2); ?></span>
                    </div>
                    <div class="summary-row">
                        <strong>Tax (<?php echo $po['tax_rate']; ?>%):</strong>
                        <span><?php echo number_format($po['tax_amount'], 2); ?></span>
                    </div>
                    <div class="summary-row summary-total">
                        <strong>Total Amount:</strong>
                        <span><?php echo number_format($po['total_amount'], 2); ?></span>
                    </div>
                </div>
                <?php else: ?>
                <div style="text-align: center; padding: 40px; color: #999;">No items found for this purchase order.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
<?php
$conn->close();
?>
