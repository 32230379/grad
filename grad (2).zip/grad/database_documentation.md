# Warehouse Management System - Database Documentation

## Database: `warehouse`

### Table Overview

| Table Name | Purpose | Key Fields |
|------------|---------|------------|
| `adddesc` | Item descriptions | barcode, name, description |
| `inventory` | Current inventory | item_barcode, location_code, quantity |
| `locations` | Location master data | location_code, area |
| `picking_log` | Picking history | work_id, item_barcode, quantity_picked |
| `picking_orders` | Picking orders | work_id, branch, status |
| `picking_order_items` | Items in picking orders | work_id, item_barcode, quantity_required |
| `putaway` | Putaway operations | plate_id, item_barcode, to_location |
| `receiving` | Received items | plate_id, item_barcode, quantity, expiry_date |
| `stocktaking` | Stock count results | item_barcode, location_code, counted_qty |
| `users` | System users | name, password, role |
| `work_orders` | Legacy work orders | work_id, item_barcode, quantity |

---

## Table Details

### 1. `adddesc` - Item Descriptions
Stores item names and descriptions linked by barcode.

**Fields:**
- `id` (int, PK, Auto Increment)
- `barcode` (varchar(50), UNIQUE) - Links to item_barcode in other tables
- `name` (varchar(100)) - Item name
- `description` (text) - Item description

**Relationships:**
- `barcode` → `inventory.item_barcode`
- `barcode` → `receiving.item_barcode`
- `barcode` → `picking_order_items.item_barcode`

---

### 2. `inventory` - Current Inventory
Main inventory table storing items with their locations and quantities.

**Fields:**
- `id` (int, PK, Auto Increment)
- `item_barcode` (varchar(50), NOT NULL)
- `location_code` (varchar(50), NOT NULL)
- `zone` (varchar(50), NULL)
- `quantity` (int, DEFAULT 0)
- `last_update` (timestamp, Auto Update)
- `user_quantity` (int, DEFAULT 0)

**Key Points:**
- Same item can exist in multiple locations
- Quantity is updated when items are picked/put away
- Zone can be NULL (extracted from location_code if needed)

---

### 3. `locations` - Location Master
Stores location information.

**Fields:**
- `id` (int, PK, Auto Increment)
- `location_code` (varchar(50), UNIQUE, NOT NULL)
- `area` (varchar(100), NULL)

---

### 4. `picking_orders` - Picking Orders
Stores picking orders (work orders) sent from branches.

**Fields:**
- `id` (int, PK, Auto Increment)
- `work_id` (varchar(100), UNIQUE, NOT NULL) - e.g., "workid-123"
- `branch` (varchar(100), NULL) - Branch name
- `status` (enum: 'pending', 'in_progress', 'completed', 'cancelled')
- `created_at` (datetime, Auto)
- `updated_at` (datetime, Auto Update)

**Status Flow:**
- `pending` → `in_progress` → `completed`

---

### 5. `picking_order_items` - Picking Order Items
Stores individual items in each picking order.

**Fields:**
- `id` (int, PK, Auto Increment)
- `work_id` (varchar(100), NOT NULL) - Links to picking_orders
- `item_barcode` (varchar(100), NOT NULL)
- `location_code` (varchar(100), NULL) - Can be NULL (looked up from inventory)
- `quantity_required` (int, NOT NULL, DEFAULT 0)
- `quantity_picked` (int, DEFAULT 0)
- `status` (enum: 'pending', 'picked', 'skipped')
- `target_lp` (varchar(100), NULL) - Target license plate
- `picked_at` (datetime, NULL)
- `created_at` (datetime, Auto)

**Relationships:**
- `work_id` → `picking_orders.work_id`
- `item_barcode` → `inventory.item_barcode`
- `item_barcode` → `adddesc.barcode`

---

### 6. `picking_log` - Picking History
Logs all picking activities for audit trail.

**Fields:**
- `id` (int, PK, Auto Increment)
- `work_id` (varchar(100), NOT NULL)
- `item_barcode` (varchar(100), NOT NULL)
- `quantity_picked` (int, NOT NULL)
- `location_code` (varchar(100), NULL)
- `target_lp` (varchar(100), NULL)
- `picked_at` (datetime, Auto)

---

### 7. `receiving` - Received Items
Stores items received from suppliers.

**Fields:**
- `id` (int, PK, Auto Increment)
- `plate_id` (varchar(50), NULL) - Receiving plate ID
- `item_barcode` (varchar(50), NULL)
- `item_name` (varchar(100), NULL)
- `description` (text, NULL)
- `quantity` (int, NULL)
- `expiry_date` (date, NULL)
- `receive_date` (date, Auto)
- `received_by` (varchar(100), NULL)
- `location` (varchar(50), NULL)
- `status` (enum: 'received', 'stored')

**Workflow:**
- Items received → `status = 'received'`
- After putaway → `status = 'stored'`

---

### 8. `putaway` - Putaway Operations
Logs putaway operations (moving items from receiving to storage locations).

**Fields:**
- `id` (int, PK, Auto Increment)
- `plate_id` (varchar(50), NOT NULL)
- `item_barcode` (varchar(50), NOT NULL)
- `item_name` (varchar(100), NULL)
- `quantity` (int, NULL)
- `from_location` (varchar(50), NULL) - Usually "Receiving Area"
- `to_location` (varchar(50), NOT NULL)
- `zone` (varchar(50), NULL)
- `moved_by` (varchar(100), NULL)
- `moved_at` (timestamp, Auto)

**Workflow:**
- Items from `receiving` → moved to `inventory` via putaway

---

### 9. `stocktaking` - Stock Count Results
Stores stocktaking/cycle count results.

**Fields:**
- `id` (int, PK, Auto Increment)
- `item_barcode` (varchar(50), NOT NULL)
- `location_code` (varchar(100), NOT NULL)
- `system_qty` (int, NOT NULL) - System quantity
- `counted_qty` (int, NOT NULL) - Physical count
- `difference` (int, NOT NULL) - counted_qty - system_qty
- `counted_at` (datetime, NOT NULL)

---

### 10. `users` - System Users
Stores system users with roles.

**Fields:**
- `id` (int, PK, Auto Increment)
- `name` (varchar(100), NOT NULL)
- `password` (varchar(255), NOT NULL) - Hashed password
- `role` (enum: 'manager', 'receiver', 'loader', 'picker', 'quantity controller', 'putaway')

**Roles:**
- `manager` - Warehouse manager
- `receiver` - Receiving staff
- `loader` - Loading staff
- `picker` - Picking staff
- `quantity controller` - QC staff
- `putaway` - Putaway staff

---

### 11. `work_orders` - Legacy Work Orders
Alternative/legacy work orders table (may not be actively used).

**Fields:**
- `id` (int, PK, Auto Increment)
- `work_id` (varchar(50), NOT NULL)
- `item_barcode` (varchar(50), NOT NULL)
- `quantity` (int, NOT NULL)
- `status` (enum: 'pending', 'picked')
- `created_at` (datetime, Auto)

---

## Key Relationships

```
adddesc (barcode)
    ↓
inventory (item_barcode) ←→ picking_order_items (item_barcode)
    ↓                           ↓
putaway (item_barcode)    picking_log (item_barcode)
    ↑
receiving (item_barcode)

picking_orders (work_id) ←→ picking_order_items (work_id)
    ↓
picking_log (work_id)
```

---

## Common Queries

### Get item with description and inventory
```sql
SELECT 
    i.*,
    ad.name,
    ad.description
FROM inventory i
LEFT JOIN adddesc ad ON i.item_barcode = ad.barcode
WHERE i.item_barcode = '12';
```

### Get picking order with items
```sql
SELECT 
    po.*,
    poi.*,
    ad.name,
    ad.description,
    i.quantity as available_quantity
FROM picking_orders po
JOIN picking_order_items poi ON po.work_id = poi.work_id
LEFT JOIN adddesc ad ON poi.item_barcode = ad.barcode
LEFT JOIN inventory i ON poi.item_barcode = i.item_barcode 
    AND poi.location_code = i.location_code
WHERE po.work_id = 'workid-123';
```

### Get picking progress
```sql
SELECT 
    work_id,
    COUNT(*) as total_items,
    SUM(CASE WHEN status = 'picked' THEN 1 ELSE 0 END) as picked_items,
    SUM(CASE WHEN status = 'skipped' THEN 1 ELSE 0 END) as skipped_items
FROM picking_order_items
WHERE work_id = 'workid-123'
GROUP BY work_id;
```

---

## Notes

1. **Barcode Consistency**: Use same barcode format across all tables
2. **Location Codes**: Format like "p0101" (zone + location)
3. **Quantity Updates**: Always update `inventory.quantity` when picking/putaway
4. **Status Management**: Update order status automatically when all items processed
5. **Password Security**: Always use `password_hash()` for user passwords



