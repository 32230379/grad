<?php
header('Content-Type: application/json');
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

$lowering_id = isset($_POST['lowering_id']) ? intval($_POST['lowering_id']) : 0;

if ($lowering_id <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid lowering order ID'
    ]);
    exit;
}

// Get current priority
$stmt = $conn->prepare("SELECT priority FROM lowering_orders WHERE id = ?");
$stmt->bind_param("i", $lowering_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Lowering order not found'
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

$order = $result->fetch_assoc();
$current_priority = $order['priority'];
$stmt->close();

// Get maximum priority for pending/in_progress orders
$max_stmt = $conn->prepare("SELECT COALESCE(MAX(priority), 0) as max_priority FROM lowering_orders WHERE status IN ('pending', 'in_progress')");
$max_stmt->execute();
$max_result = $max_stmt->get_result();
$max_row = $max_result->fetch_assoc();
$new_priority = ($max_row['max_priority'] ?? 0) + 1;
$max_stmt->close();

// Update priority to move to end of queue
$update_stmt = $conn->prepare("UPDATE lowering_orders SET priority = ?, updated_at = NOW() WHERE id = ?");
$update_stmt->bind_param("ii", $new_priority, $lowering_id);
$update_stmt->execute();

if ($update_stmt->affected_rows > 0) {
    echo json_encode([
        'success' => true,
        'message' => 'Order moved to end of queue'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to update order priority'
    ]);
}

$update_stmt->close();
$conn->close();
?>

