<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $delete = "DELETE FROM receiving WHERE id = $id";
    if (mysqli_query($conn, $delete)) {
        header("Location: ViewReceivedItems.php");
        exit();
    } else {
        echo "Error deleting item: " . mysqli_error($conn);
    }
} else {
    header("Location: ViewReceivedItems.php");
    exit();
}
?>
