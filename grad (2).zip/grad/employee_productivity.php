<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'manager') {
    header("Location: login.php?role=manager");
    exit();
}
include 'navbar.php';
include 'db_connect.php';

// Get date range filter
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-d', strtotime('-30 days'));
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');
$filter_role = isset($_GET['role']) && !empty($_GET['role']) ? $_GET['role'] : '';

// Get all available roles from users table
$roles_query = "SELECT DISTINCT role FROM users WHERE role != 'manager' ORDER BY role";
$roles_result = $conn->query($roles_query);
$available_roles = [];
if ($roles_result && $roles_result->num_rows > 0) {
    while ($role_row = $roles_result->fetch_assoc()) {
        $available_roles[] = $role_row['role'];
    }
}

// Get all employees with their productivity stats
// Use prepared statement with proper escaping for date values
$productivity_query = "
    SELECT 
        u.id,
        u.name,
        u.role,
        COALESCE(picking_stats.items_picked, 0) as items_picked,
        COALESCE(picking_stats.total_quantity, 0) as picking_quantity,
        COALESCE(qc_stats.plates_verified, 0) as plates_verified,
        COALESCE(receiving_stats.items_received, 0) as items_received,
        COALESCE(receiving_stats.total_received_qty, 0) as receiving_quantity,
        COALESCE(putaway_stats.items_putaway, 0) as items_putaway,
        COALESCE(putaway_stats.total_putaway_qty, 0) as putaway_quantity,
        COALESCE(lowering_stats.items_lowered, 0) as items_lowered,
        COALESCE(lowering_stats.total_lowered_qty, 0) as lowering_quantity
    FROM users u
    LEFT JOIN (
        SELECT 
            picked_by,
            COUNT(DISTINCT item_barcode) as items_picked,
            SUM(quantity_picked) as total_quantity
        FROM picking_log
        WHERE DATE(picked_at) BETWEEN ? AND ?
        GROUP BY picked_by
    ) picking_stats ON u.name = picking_stats.picked_by
    LEFT JOIN (
        SELECT 
            verified_by,
            COUNT(DISTINCT plate_id) as plates_verified
        FROM plate_verifications
        WHERE DATE(verified_at) BETWEEN ? AND ?
        GROUP BY verified_by
    ) qc_stats ON u.name = qc_stats.verified_by
    LEFT JOIN (
        SELECT 
            received_by,
            COUNT(DISTINCT item_barcode) as items_received,
            SUM(quantity) as total_received_qty
        FROM receiving
        WHERE DATE(receive_date) BETWEEN ? AND ?
        GROUP BY received_by
    ) receiving_stats ON u.name = receiving_stats.received_by
    LEFT JOIN (
        SELECT 
            moved_by,
            COUNT(DISTINCT item_barcode) as items_putaway,
            SUM(quantity) as total_putaway_qty
        FROM putaway
        WHERE DATE(moved_at) BETWEEN ? AND ?
        GROUP BY moved_by
    ) putaway_stats ON u.name = putaway_stats.moved_by
    LEFT JOIN (
        SELECT 
            lowered_by,
            COUNT(DISTINCT id) as items_lowered,
            SUM(quantity_moved) as total_lowered_qty
        FROM lowering_orders
        WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed'
        GROUP BY lowered_by
    ) lowering_stats ON u.name = lowering_stats.lowered_by
    WHERE u.role != 'manager'
    " . (!empty($filter_role) ? "AND u.role = ?" : "") . "
    ORDER BY 
        (COALESCE(picking_stats.items_picked, 0) + 
         COALESCE(qc_stats.plates_verified, 0) + 
         COALESCE(receiving_stats.items_received, 0) + 
         COALESCE(putaway_stats.items_putaway, 0) + 
         COALESCE(lowering_stats.items_lowered, 0)) DESC
";

// Try to execute query, if it fails due to missing tables/columns, use simpler query
$stmt = $conn->prepare($productivity_query);
if ($stmt) {
    if (!empty($filter_role)) {
        $stmt->bind_param("sssssssssss", $date_from, $date_to, $date_from, $date_to, $date_from, $date_to, $date_from, $date_to, $date_from, $date_to, $filter_role);
    } else {
        $stmt->bind_param("ssssssssss", $date_from, $date_to, $date_from, $date_to, $date_from, $date_to, $date_from, $date_to, $date_from, $date_to);
    }
    $stmt->execute();
    $productivity_result = $stmt->get_result();
} else {
    // Fallback: simpler query without optional tables
    $simple_query = "
        SELECT 
            u.id,
            u.name,
            u.role,
            0 as items_picked,
            0 as picking_quantity,
            0 as plates_verified,
            COALESCE(receiving_stats.items_received, 0) as items_received,
            COALESCE(receiving_stats.total_received_qty, 0) as receiving_quantity,
            COALESCE(putaway_stats.items_putaway, 0) as items_putaway,
            COALESCE(putaway_stats.total_putaway_qty, 0) as putaway_quantity,
            0 as items_lowered,
            0 as lowering_quantity
        FROM users u
        LEFT JOIN (
            SELECT 
                received_by,
                COUNT(DISTINCT item_barcode) as items_received,
                SUM(quantity) as total_received_qty
            FROM receiving
            WHERE DATE(receive_date) BETWEEN ? AND ?
            GROUP BY received_by
        ) receiving_stats ON u.name = receiving_stats.received_by
        LEFT JOIN (
            SELECT 
                moved_by,
                COUNT(DISTINCT item_barcode) as items_putaway,
                SUM(quantity) as total_putaway_qty
            FROM putaway
            WHERE DATE(moved_at) BETWEEN ? AND ?
            GROUP BY moved_by
        ) putaway_stats ON u.name = putaway_stats.moved_by
        WHERE u.role != 'manager'
        " . (!empty($filter_role) ? "AND u.role = ?" : "") . "
        ORDER BY u.name
    ";
    $stmt = $conn->prepare($simple_query);
    if (!empty($filter_role)) {
        $stmt->bind_param("sssss", $date_from, $date_to, $date_from, $date_to, $filter_role);
    } else {
        $stmt->bind_param("ssss", $date_from, $date_to, $date_from, $date_to);
    }
    $stmt->execute();
    $productivity_result = $stmt->get_result();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Productivity</title>
    <style>
        .main-content {
            padding: 25px;
        }
        .page-header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-header h1 {
            color: var(--text-primary);
            font-size: 28px;
        }
        .filter-section {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }
        .filter-row {
            display: flex;
            gap: 15px;
            align-items: end;
        }
        .filter-group {
            flex: 1;
        }
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            color: var(--text-primary);
            font-weight: 500;
        }
        .filter-group input,
        .filter-group select {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        .btn-filter {
            padding: 10px 24px;
            background: var(--light-blue);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: background 0.3s;
        }
        .btn-filter:hover {
            background: var(--secondary);
        }
        .productivity-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        thead {
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--secondary) 100%);
            color: white;
        }
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }
        tbody tr:hover {
            background: #f8f9fa;
        }
        .role-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            text-transform: capitalize;
        }
        .role-picker { background: #d1ecf1; color: #0c5460; }
        .role-qc { background: #fff3cd; color: #856404; }
        .role-receiver { background: #d4edda; color: #155724; }
        .role-putaway { background: #e2e3e5; color: #383d41; }
        .role-loader { background: #cce5ff; color: #004085; }
        .role-house-keeper { background: #f8d7da; color: #721c24; }
        .stat-number {
            font-weight: 600;
            color: var(--text-primary);
        }
        .no-data {
            text-align: center;
            padding: 40px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php 
        $current_page = 'employee_productivity.php';
        include 'navbar.php'; 
        ?>
        <div class="main-content">
            <div class="page-header">
                <div>
                    <h1>📊 Employee Productivity</h1>
                    <p style="color: var(--text-muted);">Track employee performance and activity</p>
                </div>
            </div>

            <div class="filter-section">
                <form method="GET" action="">
                    <div class="filter-row">
                        <div class="filter-group">
                            <label>Date From</label>
                            <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" required>
                        </div>
                        <div class="filter-group">
                            <label>Date To</label>
                            <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" required>
                        </div>
                        <div class="filter-group">
                            <label>Role</label>
                            <select name="role">
                                <option value="">All Roles</option>
                                <?php foreach ($available_roles as $role): ?>
                                    <option value="<?php echo htmlspecialchars($role); ?>" <?php echo $filter_role === $role ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars(ucwords($role)); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="filter-group">
                            <button type="submit" class="btn-filter">Filter</button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="productivity-table">
                <?php if ($productivity_result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>Role</th>
                            <th>Items Picked</th>
                            <th>Picking Qty</th>
                            <th>Plates Verified</th>
                            <th>Items Received</th>
                            <th>Receiving Qty</th>
                            <th>Items Putaway</th>
                            <th>Putaway Qty</th>
                            <th>Items Lowered</th>
                            <th>Lowering Qty</th>
                            <th>Total Activity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $productivity_result->fetch_assoc()): 
                            $total_activity = $row['items_picked'] + $row['plates_verified'] + $row['items_received'] + $row['items_putaway'] + $row['items_lowered'];
                            $role_class = 'role-' . str_replace(' ', '-', strtolower($row['role']));
                        ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($row['name']); ?></strong></td>
                            <td><span class="role-badge <?php echo $role_class; ?>"><?php echo htmlspecialchars($row['role']); ?></span></td>
                            <td><span class="stat-number"><?php echo $row['items_picked']; ?></span></td>
                            <td><span class="stat-number"><?php echo $row['picking_quantity']; ?></span></td>
                            <td><span class="stat-number"><?php echo $row['plates_verified']; ?></span></td>
                            <td><span class="stat-number"><?php echo $row['items_received']; ?></span></td>
                            <td><span class="stat-number"><?php echo $row['receiving_quantity']; ?></span></td>
                            <td><span class="stat-number"><?php echo $row['items_putaway']; ?></span></td>
                            <td><span class="stat-number"><?php echo $row['putaway_quantity']; ?></span></td>
                            <td><span class="stat-number"><?php echo $row['items_lowered']; ?></span></td>
                            <td><span class="stat-number"><?php echo $row['lowering_quantity']; ?></span></td>
                            <td><strong style="color: var(--light-blue);"><?php echo $total_activity; ?></strong></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="no-data">No productivity data found for the selected date range.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>
