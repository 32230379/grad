<?php
// Get current page name to highlight active menu item
$current_page = basename($_SERVER['PHP_SELF']);
?>
<style>
    :root {
        --primary: #2c3e50;
        --secondary: #3498db;
        --light-blue: #4A90E2;
        --light-blue-text: #5BA3F5;
        --light-blue-bg: #E8F4FD;
    }
    
    .dashboard-container {
        display: flex;
        min-height: 100vh;
    }
    
    /* Sidebar Styles */
    .sidebar {
        width: 250px;
        background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
        color: white;
        transition: all 0.3s;
        box-shadow: 4px 0 15px rgba(0,0,0,0.1);
        position: fixed;
        height: 100vh;
        overflow-y: auto;
    }
    
    .sidebar-header {
        padding: 25px 20px;
        background: linear-gradient(135deg, var(--light-blue) 0%, var(--secondary) 100%);
        text-align: center;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
    
    .sidebar-header h2 {
        color: white;
        font-weight: 600;
        text-shadow: 0 2px 4px rgba(0,0,0,0.2);
        font-size: 20px;
    }
    
    .sidebar-header p {
        color: rgba(255,255,255,0.9);
        font-size: 13px;
        margin-top: 5px;
    }
    
    .sidebar-menu {
        padding: 15px 0;
    }
    
    .menu-item {
        padding: 12px 20px;
        display: flex;
        align-items: center;
        cursor: pointer;
        transition: all 0.3s ease;
        text-decoration: none;
        color: white;
    }
    
    .menu-item:hover, .menu-item.active {
        background: linear-gradient(90deg, var(--light-blue) 0%, var(--secondary) 100%);
        border-left: 4px solid white;
        padding-left: 16px;
    }
    
    .menu-item i {
        margin-right: 10px;
        width: 20px;
        text-align: center;
        font-size: 18px;
    }
    
    /* Main Content Styles */
    .main-content {
        flex: 1;
        padding: 25px;
        overflow-y: auto;
        margin-left: 250px;
    }
    
    /* Mobile Menu Toggle */
    .menu-toggle {
        display: none;
        background: var(--light-blue);
        color: white;
        border: none;
        padding: 10px 15px;
        font-size: 20px;
        cursor: pointer;
        position: fixed;
        top: 10px;
        left: 10px;
        z-index: 1001;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    
    @media (max-width: 768px) {
        .menu-toggle {
            display: block;
        }
        
        .sidebar {
            width: 250px;
            position: fixed;
            left: -250px;
            top: 0;
            z-index: 1000;
            transition: left 0.3s ease;
            height: 100vh;
        }
        
        .sidebar.open {
            left: 0;
        }
        
        .main-content {
            margin-left: 0;
            padding: 15px;
        }
        
        /* Overlay when menu is open */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }
        
        .sidebar-overlay.show {
            display: block;
        }
    }
    
    @media (max-width: 480px) {
        .main-content {
            padding: 10px;
        }
        
        .sidebar {
            width: 100%;
            left: -100%;
        }
    }
</style>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>
<div class="sidebar-overlay" id="sidebar-overlay" onclick="toggleSidebar()"></div>
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h2>Warehouse System</h2>
        <p>Manager Dashboard</p>
    </div>
    <div class="sidebar-menu">
        <a href="warehouseM.php" class="menu-item <?php echo ($current_page == 'warehouseM.php') ? 'active' : ''; ?>">
            <i>📊</i> Dashboard
        </a>
        <a href="user_management.php" class="menu-item <?php echo ($current_page == 'user_management.php') ? 'active' : ''; ?>">
            <i>👥</i> User Management
        </a>
        <a href="inv.php" class="menu-item <?php echo ($current_page == 'inv.php') ? 'active' : ''; ?>">
            <i>📦</i> Inventory Overview
        </a>
        <a href="transfer_orders.php" class="menu-item <?php echo ($current_page == 'transfer_orders.php') ? 'active' : ''; ?>">
            <i>🔄</i> Transfer Orders
        </a>
        <a href="reports.html" class="menu-item <?php echo ($current_page == 'reports.html') ? 'active' : ''; ?>">
            <i>📈</i> Reports & Analytics
        </a>
        <a href="saveItem.php" class="menu-item <?php echo ($current_page == 'saveItem.php') ? 'active' : ''; ?>">
            <i>⚙️</i> Add Description
        </a>
        <a href="add_user.php" class="menu-item <?php echo ($current_page == 'add_user.php') ? 'active' : ''; ?>">
            <i>➕</i> Add User
        </a>
        <a href="ViewReceivedItems.php" class="menu-item <?php echo ($current_page == 'ViewReceivedItems.php') ? 'active' : ''; ?>">
            <i>📦</i> View Received Items
        </a>
        <a href="lowering_orders.php" class="menu-item <?php echo ($current_page == 'lowering_orders.php') ? 'active' : ''; ?>">
            <i>⬇️</i> Lowering Orders (Admin)
        </a>
        <a href="manage_areas.php" class="menu-item <?php echo ($current_page == 'manage_areas.php') ? 'active' : ''; ?>">
            <i>📍</i> Manage Areas
        </a>
        <a href="employee_productivity.php" class="menu-item <?php echo ($current_page == 'employee_productivity.php') ? 'active' : ''; ?>">
            <i>📊</i> Employee Productivity
        </a>
        <a href="supplier_management.php" class="menu-item <?php echo ($current_page == 'supplier_management.php') ? 'active' : ''; ?>">
            <i>🏢</i> Supplier Management
        </a>
        <a href="purchase_orders.php" class="menu-item <?php echo ($current_page == 'purchase_orders.php') ? 'active' : ''; ?>">
            <i>📋</i> Purchase Orders
        </a>
        <a href="reorder_requests.php" class="menu-item <?php echo ($current_page == 'reorder_requests.php') ? 'active' : ''; ?>">
            <i>🔄</i> Reorder Requests
        </a>
        <a href="receiving_notes.php" class="menu-item <?php echo ($current_page == 'receiving_notes.php') ? 'active' : ''; ?>">
            <i>📥</i> Receiving Notes
        </a>
        <a href="loaded_plates.php" class="menu-item <?php echo ($current_page == 'loaded_plates.php') ? 'active' : ''; ?>">
            <i>📦</i> Loaded Plates
        </a>
    </div>
</div>

<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    
    if (sidebar.classList.contains('open')) {
        sidebar.classList.remove('open');
        overlay.classList.remove('show');
    } else {
        sidebar.classList.add('open');
        overlay.classList.add('show');
    }
}

// Close sidebar when clicking outside on mobile
document.addEventListener('click', function(event) {
    const sidebar = document.getElementById('sidebar');
    const menuToggle = document.querySelector('.menu-toggle');
    const overlay = document.getElementById('sidebar-overlay');
    
    if (window.innerWidth <= 768) {
        if (!sidebar.contains(event.target) && !menuToggle.contains(event.target) && sidebar.classList.contains('open')) {
            sidebar.classList.remove('open');
            overlay.classList.remove('show');
        }
    }
});

// Close sidebar when window is resized to desktop
window.addEventListener('resize', function() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    
    if (window.innerWidth > 768) {
        sidebar.classList.remove('open');
        overlay.classList.remove('show');
    }
});
</script>

