<?php
include 'db_connect.php';

// 🔹 جلب الفلاتر من المستخدم
$barcodeFilter = isset($_GET['item_barcode']) ? trim($_GET['item_barcode']) : '';
$locationFilter = isset($_GET['location_code']) ? trim($_GET['location_code']) : '';

// 🔹 بناء الاستعلام مع الفلاتر - يشمل Inventory والـ Receiving (status = 'received')
$query = "
    SELECT 
        'inventory' as source,
        i.id,
        i.item_barcode,
        i.location_code,
        i.zone,
        i.quantity,
        i.last_update,
        NULL as plate_id,
        NULL as receive_date
    FROM inventory i
    WHERE 1
";
if ($barcodeFilter !== '') {
    $query .= " AND i.item_barcode LIKE '%" . $conn->real_escape_string($barcodeFilter) . "%'";
}
if ($locationFilter !== '') {
    $query .= " AND i.location_code LIKE '%" . $conn->real_escape_string($locationFilter) . "%'";
}

$query .= "
    UNION ALL
    
    SELECT 
        'receiving' as source,
        r.id,
        r.item_barcode,
        'rec' as location_code,
        NULL as zone,
        r.quantity,
        r.receive_date as last_update,
        r.plate_id,
        r.receive_date
    FROM receiving r
    WHERE r.status = 'received'
";
if ($barcodeFilter !== '') {
    $query .= " AND r.item_barcode LIKE '%" . $conn->real_escape_string($barcodeFilter) . "%'";
}
if ($locationFilter !== '') {
    $query .= " AND 'rec' LIKE '%" . $conn->real_escape_string($locationFilter) . "%'";
}

$query .= " ORDER BY last_update DESC";
$result = $conn->query($query);

// 🔹 حفظ التعديلات
if (isset($_POST['save'])) {
    $id = $_POST['id'];
    $barcode = $_POST['item_barcode'];
    $location = $_POST['location_code'];
    $quantity = $_POST['quantity'];

    $stmt = $conn->prepare("UPDATE inventory SET item_barcode=?, location_code=?, quantity=?, last_update=NOW() WHERE id=?");
    $stmt->bind_param("ssii", $barcode, $location, $quantity, $id);
    $stmt->execute();

    echo "<script> window.location.href='inv.php';</script>";
    exit;
}

// 🔹 حذف سجل
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM inventory WHERE id = $id");
    header("Location: inv.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Inventory Management</title>
<style>
body { font-family: Arial; background: linear-gradient(135deg, #f5f9ff 0%, #e8f4fd 100%); text-align: center; }
h2 { color: #333; }
table { border-collapse: collapse; width: 90%; margin: 20px auto; background: white; }
th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
th { background: #007bff; color: white; }
tr:nth-child(even) { background: #f2f2f2; }
a.btn, button { padding: 5px 10px; text-decoration: none; border-radius: 5px; cursor: pointer; }
.edit { background: #28a745; color: white; border: none; }
.delete { background: #dc3545; color: white; border: none; }
.save { background: #007bff; color: white; border: none; }
.cancel { background: #6c757d; color: white; border: none; }
input[type="text"], input[type="number"] { width: 100px; text-align: center; }
.filter-box {
  background: white; padding: 15px; margin: 20px auto; width: 90%; border-radius: 8px;
  box-shadow: 0 0 10px #ccc; display: flex; justify-content: center; gap: 10px;
}
.filter-box input { padding: 8px; width: 180px; border: 1px solid #ccc; border-radius: 5px; }
.filter-box button { padding: 8px 15px; border: none; background: #007bff; color: white; border-radius: 5px; cursor: pointer; }
.filter-box button:hover { background: #0056b3; }
</style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <div class="main-content">
<h2>📦 Inventory Management (Filter + Inline Edit)</h2>

<!-- 🔍 Filter Form -->
<form method="GET" class="filter-box">
    <input type="text" name="item_barcode" placeholder="Search by Barcode" value="<?= htmlspecialchars($barcodeFilter) ?>">
    <input type="text" name="location_code" placeholder="Search by Location (rack-shelf)" value="<?= htmlspecialchars($locationFilter) ?>">
    <button type="submit">Filter</button>
    <a href="inv.php" style="text-decoration:none;"><button type="button">Clear</button></a>
</form>

<table>
    <tr>
        <th>ID</th>
        <th>Item Barcode</th>
        <th>Location Code</th>
        <th>Zone</th>
        <th>Quantity</th>
        <th>Status</th>
        <th>Last Update</th>
        <th>Actions</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()): ?>
    <tr style="<?= $row['source'] == 'receiving' ? 'background-color: #fff3cd;' : '' ?>">
        <?php if ($row['source'] == 'inventory'): ?>
        <form method="POST">
            <td><?= $row['id'] ?><input type="hidden" name="id" value="<?= $row['id'] ?>"></td>
            <td><input type="text" name="item_barcode" value="<?= htmlspecialchars($row['item_barcode']) ?>" disabled></td>
            <td><input type="text" name="location_code" value="<?= htmlspecialchars($row['location_code']) ?>" placeholder="rack-shelf (e.g., 1-0)" pattern="[0-9]+-[0-9]+" disabled></td>
            <td><?= htmlspecialchars($row['zone'] ?? '-') ?></td>
            <td><input type="number" name="quantity" value="<?= $row['quantity'] ?>" disabled></td>
            <td><span style="color: #28a745; font-weight: bold;">In Stock</span></td>
            <td><?= $row['last_update'] ?></td>
            <td>
                <button type="button" class="edit" onclick="enableEdit(this)">Edit</button>
                <button type="submit" name="save" class="save" style="display:none;">Save</button>
                <button type="button" class="cancel" style="display:none;" onclick="cancelEdit(this)">Cancel</button>
                <a class="delete" href="?delete=<?= $row['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </form>
        <?php else: ?>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['item_barcode']) ?></td>
        <td><strong style="color: #ffc107;"><?= htmlspecialchars($row['location_code']) ?></strong></td>
        <td>-</td>
        <td><?= $row['quantity'] ?></td>
        <td><span style="color: #ffc107; font-weight: bold;">Received (Not Put Away)</span></td>
        <td><?= $row['receive_date'] ?></td>
        <td>
            <span style="color: #6c757d; font-size: 12px;">Plate: <?= htmlspecialchars($row['plate_id']) ?></span>
        </td>
        <?php endif; ?>
    </tr>
    <?php endwhile; ?>
</table>

<script>
function enableEdit(button) {
    const row = button.closest('tr');
    row.querySelectorAll('input').forEach(i => i.disabled = false);
    row.querySelector('.save').style.display = 'inline-block';
    row.querySelector('.cancel').style.display = 'inline-block';
    button.style.display = 'none';
}
function cancelEdit(button) {
    const row = button.closest('tr');
    row.querySelectorAll('input').forEach(i => i.disabled = true);
    row.querySelector('.save').style.display = 'none';
    row.querySelector('.edit').style.display = 'inline-block';
    button.style.display = 'none';
}
</script>
        </div>
    </div>
</body>
</html>
