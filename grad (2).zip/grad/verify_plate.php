<?php
header('Content-Type: application/json');
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

$plate_id = isset($_POST['plate_id']) ? trim($_POST['plate_id']) : '';
$has_variance = isset($_POST['has_variance']) ? intval($_POST['has_variance']) : 0;
$qc_quantities = isset($_POST['qc_quantities']) ? json_decode($_POST['qc_quantities'], true) : [];

// Debug: Log what we received
error_log("Plate ID: $plate_id");
error_log("Has Variance: $has_variance");
error_log("QC Quantities (raw): " . (isset($_POST['qc_quantities']) ? $_POST['qc_quantities'] : 'NOT SET'));
error_log("QC Quantities (decoded): " . print_r($qc_quantities, true));

if (empty($plate_id)) {
    echo json_encode([
        'success' => false,
        'message' => 'Plate ID is required'
    ]);
    exit;
}

// Check if plate exists
$check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM picking_log WHERE plate_id = ?");
$check_stmt->bind_param("s", $plate_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();
$check_row = $check_result->fetch_assoc();

if ($check_row['count'] == 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Plate not found'
    ]);
    $check_stmt->close();
    $conn->close();
    exit;
}
$check_stmt->close();

// Check if plate verification table exists, if not create it
$create_table = "CREATE TABLE IF NOT EXISTS `plate_verifications` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `plate_id` varchar(50) NOT NULL,
    `work_id` varchar(100) DEFAULT NULL,
    `branch` varchar(100) DEFAULT NULL,
    `verified_by` varchar(100) DEFAULT NULL,
    `verification_status` enum('complete','variance') DEFAULT 'complete',
    `plate_status` enum('verified','ready_to_load','loaded') DEFAULT 'verified',
    `verified_at` datetime DEFAULT current_timestamp(),
    `ready_for_load_at` datetime DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_plate_id` (`plate_id`),
    KEY `idx_plate_id` (`plate_id`),
    KEY `idx_work_id` (`work_id`),
    KEY `idx_plate_status` (`plate_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

$conn->query($create_table);

// Add plate_status column if it doesn't exist
$check_column = $conn->query("SHOW COLUMNS FROM `plate_verifications` LIKE 'plate_status'");
if ($check_column->num_rows == 0) {
    $conn->query("ALTER TABLE `plate_verifications` ADD COLUMN `plate_status` enum('verified','ready_to_load','loaded') DEFAULT 'verified' AFTER `verification_status`");
    $conn->query("ALTER TABLE `plate_verifications` ADD COLUMN `ready_for_load_at` datetime DEFAULT NULL AFTER `verified_at`");
    $conn->query("ALTER TABLE `plate_verifications` ADD KEY `idx_plate_status` (`plate_status`)");
}

// Check if plate_verification_items table exists, if not create it
$create_items_table = "CREATE TABLE IF NOT EXISTS `plate_verification_items` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `plate_id` varchar(50) NOT NULL,
    `item_barcode` varchar(100) NOT NULL,
    `qc_quantity` int(11) NOT NULL,
    `verified_at` datetime DEFAULT current_timestamp(),
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_plate_item` (`plate_id`, `item_barcode`),
    KEY `idx_plate_id` (`plate_id`),
    KEY `idx_item_barcode` (`item_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

$conn->query($create_items_table);

// Use has_variance from POST (determined by QC employee)
// QC employee enters quantities and system compares them

// Get work_id and branch for this plate
$info_stmt = $conn->prepare("
    SELECT DISTINCT po.work_id, po.branch
    FROM picking_log pl
    INNER JOIN picking_orders po ON pl.work_id = po.work_id
    WHERE pl.plate_id = ?
    LIMIT 1
");
$info_stmt->bind_param("s", $plate_id);
$info_stmt->execute();
$info_result = $info_stmt->get_result();
$info_row = $info_result->fetch_assoc();
$info_stmt->close();

// Insert verification record
$status = ($has_variance == 1) ? 'variance' : 'complete';
session_start();
$verified_by = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'System'; // Use session user name
$work_id_value = $info_row['work_id'] ?? null;
$branch_value = $info_row['branch'] ?? null;

$insert_stmt = $conn->prepare("
    INSERT INTO plate_verifications (plate_id, work_id, branch, verified_by, verification_status)
    VALUES (?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
        verified_by = VALUES(verified_by),
        verification_status = VALUES(verification_status),
        verified_at = NOW()
");

// Check if plate_id is unique, if not, we need to handle duplicates
$insert_stmt->bind_param("sssss", 
    $plate_id, 
    $work_id_value, 
    $branch_value, 
    $verified_by, 
    $status
);

if ($insert_stmt->execute()) {
    // Save QC quantities for each item
    // Debug: Log received quantities
    error_log("Received qc_quantities: " . print_r($qc_quantities, true));
    
    if (!empty($qc_quantities) && is_array($qc_quantities)) {
        $items_stmt = $conn->prepare("
            INSERT INTO plate_verification_items (plate_id, item_barcode, qc_quantity)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE
                qc_quantity = VALUES(qc_quantity),
                verified_at = NOW()
        ");
        
        $saved_count = 0;
        foreach ($qc_quantities as $barcode => $quantity) {
            // Accept 0 as valid quantity, only reject null/undefined/negative
            if (is_numeric($quantity) && $quantity >= 0) {
                $items_stmt->bind_param("ssi", $plate_id, $barcode, $quantity);
                if ($items_stmt->execute()) {
                    $saved_count++;
                } else {
                    error_log("Failed to save QC quantity for item $barcode: " . $items_stmt->error);
                }
            } else {
                error_log("Invalid quantity for item $barcode: $quantity");
            }
        }
        $items_stmt->close();
        error_log("Saved $saved_count QC quantities for plate $plate_id");
    } else {
        error_log("No QC quantities received or empty array for plate $plate_id");
    }
    
    $message = $has_variance 
        ? "Plate verified with variance. Please check items manually."
        : "Plate verified - Complete. No variance detected.";
    
    echo json_encode([
        'success' => true,
        'message' => $message,
        'has_variance' => $has_variance,
        'status' => $status
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to save verification'
    ]);
}

$insert_stmt->close();
$conn->close();
?>

