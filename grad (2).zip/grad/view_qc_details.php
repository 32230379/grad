<?php
include 'db_connect.php';

if (!isset($_GET['work_id'])) {
    header("Location: transfer_orders.php");
    exit;
}

$work_id = mysqli_real_escape_string($conn, $_GET['work_id']);

// Get order details
$order_query = "SELECT * FROM picking_orders WHERE work_id = '$work_id'";
$order_result = $conn->query($order_query);

if ($order_result->num_rows === 0) {
    header("Location: transfer_orders.php");
    exit;
}

$order = $order_result->fetch_assoc();

// Get all plates for this work_id with QC status
$plates_query = "
    SELECT 
        DISTINCT poi.plate_id,
        pv.verification_status,
        pv.plate_status,
        pv.verified_by,
        pv.verified_at,
        pv.ready_for_load_at,
        COUNT(DISTINCT poi.id) as item_count,
        COUNT(DISTINCT CASE WHEN pvi.qc_quantity IS NOT NULL THEN poi.item_barcode END) as verified_items
    FROM picking_order_items poi
    LEFT JOIN plate_verifications pv ON poi.plate_id = pv.plate_id
    LEFT JOIN plate_verification_items pvi ON poi.plate_id = pvi.plate_id 
        AND poi.item_barcode = pvi.item_barcode
    WHERE poi.work_id = '$work_id' 
        AND poi.plate_id IS NOT NULL 
        AND poi.plate_id != ''
    GROUP BY poi.plate_id, pv.verification_status, pv.plate_status, pv.verified_by, pv.verified_at, pv.ready_for_load_at
    ORDER BY poi.plate_id
";
$plates_result = $conn->query($plates_query);

// Get QC summary
$qc_summary_query = "
    SELECT 
        COUNT(DISTINCT poi.plate_id) as total_plates,
        COUNT(DISTINCT CASE WHEN pv.plate_status IN ('verified', 'ready_to_load', 'loaded') THEN poi.plate_id END) as verified_plates,
        COUNT(DISTINCT CASE WHEN pv.verification_status = 'variance' THEN poi.plate_id END) as variance_plates,
        COUNT(DISTINCT CASE WHEN pv.plate_status = 'ready_to_load' THEN poi.plate_id END) as ready_plates,
        COUNT(DISTINCT CASE WHEN pv.plate_status = 'loaded' THEN poi.plate_id END) as loaded_plates
    FROM picking_order_items poi
    LEFT JOIN plate_verifications pv ON poi.plate_id = pv.plate_id
    WHERE poi.work_id = '$work_id' 
        AND poi.plate_id IS NOT NULL 
        AND poi.plate_id != ''
";
$qc_summary_result = $conn->query($qc_summary_query);
$qc_summary = $qc_summary_result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QC Details - <?php echo htmlspecialchars($work_id); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background: linear-gradient(135deg, #f5f9ff 0%, #e8f4fd 100%);
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: white;
            text-decoration: none;
            opacity: 0.9;
        }
        .back-link:hover {
            opacity: 1;
            text-decoration: underline;
        }
        .content {
            padding: 20px;
        }
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .summary-card {
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
        }
        .summary-card h3 {
            font-size: 32px;
            color: #667eea;
            margin-bottom: 5px;
        }
        .summary-card p {
            color: #6c757d;
            font-size: 14px;
        }
        .content-section {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e9ecef;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .status {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .status-verified {
            background: #d4edda;
            color: #155724;
        }
        .status-ready_to_load {
            background: #d1ecf1;
            color: #0c5460;
        }
        .status-loaded {
            background: #cce5ff;
            color: #004085;
        }
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        .status-complete {
            background: #d4edda;
            color: #155724;
        }
        .status-variance {
            background: #f8d7da;
            color: #721c24;
        }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover {
            background: #5568d3;
        }
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e0e0e0;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 5px;
        }
        .progress-fill {
            height: 100%;
            background: #27ae60;
            transition: width 0.3s;
        }
        .plate-details {
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .plate-details h4 {
            margin-bottom: 10px;
            color: #2c3e50;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
            margin-top: 10px;
        }
        .info-item {
            font-size: 13px;
        }
        .info-item strong {
            color: #495057;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <a href="transfer_orders.php" class="back-link">← Back to Transfer Orders</a>
            <h1>🔍 QC Details: <?php echo htmlspecialchars($work_id); ?></h1>
            <p>Branch: <?php echo htmlspecialchars($order['branch'] ?? '-'); ?></p>
        </div>

        <div class="content">
            <!-- QC Summary -->
            <div class="summary-cards">
                <div class="summary-card">
                    <h3><?php echo intval($qc_summary['total_plates'] ?? 0); ?></h3>
                    <p>Total Plates</p>
                </div>
                <div class="summary-card">
                    <h3><?php echo intval($qc_summary['verified_plates'] ?? 0); ?></h3>
                    <p>Verified Plates</p>
                </div>
                <div class="summary-card">
                    <h3><?php echo intval($qc_summary['variance_plates'] ?? 0); ?></h3>
                    <p>Variance Plates</p>
                </div>
                <div class="summary-card">
                    <h3><?php echo intval($qc_summary['ready_plates'] ?? 0); ?></h3>
                    <p>Ready for Load</p>
                </div>
                <div class="summary-card">
                    <h3><?php echo intval($qc_summary['loaded_plates'] ?? 0); ?></h3>
                    <p>Loaded Plates</p>
                </div>
            </div>

            <!-- Plates List -->
            <div class="content-section">
                <h2 class="section-title">Plates QC Status</h2>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Plate ID</th>
                                <th>Items</th>
                                <th>Verified Items</th>
                                <th>Verification Status</th>
                                <th>Plate Status</th>
                                <th>Verified By</th>
                                <th>Verified At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($plates_result && $plates_result->num_rows > 0) {
                                while ($plate = $plates_result->fetch_assoc()) {
                                    $item_count = intval($plate['item_count'] ?? 0);
                                    $verified_items = intval($plate['verified_items'] ?? 0);
                                    $progress = $item_count > 0 ? round(($verified_items / $item_count) * 100) : 0;
                                    
                                    $verification_status = $plate['verification_status'] ?? null;
                                    $plate_status = $plate['plate_status'] ?? null;
                                    
                                    $verification_status_class = $verification_status ? 'status-' . $verification_status : 'status-pending';
                                    $verification_status_display = $verification_status ? ucwords($verification_status) : 'Not Verified';
                                    
                                    $plate_status_class = $plate_status ? 'status-' . $plate_status : 'status-pending';
                                    $plate_status_display = $plate_status ? ucwords(str_replace('_', ' ', $plate_status)) : 'Pending';
                                    
                                    echo "<tr>";
                                    echo "<td><strong>" . htmlspecialchars($plate['plate_id']) . "</strong></td>";
                                    echo "<td>{$item_count}</td>";
                                    echo "<td>";
                                    echo "<div class='progress-bar'><div class='progress-fill' style='width: {$progress}%'></div></div>";
                                    echo "<small>{$verified_items}/{$item_count} verified ({$progress}%)</small>";
                                    echo "</td>";
                                    echo "<td><span class='status {$verification_status_class}'>{$verification_status_display}</span></td>";
                                    echo "<td><span class='status {$plate_status_class}'>{$plate_status_display}</span></td>";
                                    echo "<td>" . htmlspecialchars($plate['verified_by'] ?? '-') . "</td>";
                                    echo "<td>" . ($plate['verified_at'] ? date('Y-m-d H:i', strtotime($plate['verified_at'])) : '-') . "</td>";
                                    echo "<td>";
                                    echo "<a href='qc_check.php?plate_id=" . urlencode($plate['plate_id']) . "' class='btn btn-primary' target='_blank'>View Details</a>";
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='8' style='text-align: center; padding: 20px;'>No plates found for this work order</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php
$conn->close();
?>




