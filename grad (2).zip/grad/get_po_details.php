<?php
session_start();
header('Content-Type: application/json');
include 'db_connect.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid PO ID']);
    exit;
}

$po_id = intval($_GET['id']);

// Get PO details
$po_query = "SELECT * FROM purchase_orders WHERE id = ?";
$stmt = $conn->prepare($po_query);
$stmt->bind_param("i", $po_id);
$stmt->execute();
$po_result = $stmt->get_result();

if ($po_result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Purchase order not found']);
    exit;
}

$po = $po_result->fetch_assoc();
$stmt->close();

// Get PO items
$items_query = "SELECT * FROM purchase_order_items WHERE po_id = ? ORDER BY id";
$stmt = $conn->prepare($items_query);
$stmt->bind_param("i", $po_id);
$stmt->execute();
$items_result = $stmt->get_result();

$items = [];
while ($row = $items_result->fetch_assoc()) {
    $items[] = [
        'id' => $row['id'],
        'item_barcode' => $row['item_barcode'],
        'quantity_ordered' => $row['quantity_ordered'],
        'quantity_received' => $row['quantity_received'] ?? 0,
        'unit_price' => $row['unit_price'],
        'total_price' => $row['total_price']
    ];
}
$stmt->close();

echo json_encode([
    'success' => true,
    'po' => $po,
    'items' => $items
]);

$conn->close();
?>
