<?php
header('Content-Type: application/json');
include 'db_connect.php';

if (!isset($_GET['work_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Work ID is required'
    ]);
    exit;
}

$work_id = trim($_GET['work_id']);

// Get picking order details
$stmt = $conn->prepare("SELECT * FROM picking_orders WHERE work_id = ?");
$stmt->bind_param("s", $work_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Picking order not found for this Work ID'
    ]);
    exit;
}

$order = $result->fetch_assoc();

// Check if order has an area assigned and verify it's valid for this branch
if (!empty($order['area'])) {
    $area_check_stmt = $conn->prepare("SELECT * FROM areas WHERE area_code = ? AND is_active = 1");
    $area_check_stmt->bind_param("s", $order['area']);
    $area_check_stmt->execute();
    $area_check_result = $area_check_stmt->get_result();
    
    if ($area_check_result->num_rows > 0) {
        $area_info = $area_check_result->fetch_assoc();
        // Verify branch match
        if (strcasecmp(trim($order['branch']), trim($area_info['branch'])) !== 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Cannot start picking! This work order has an invalid area assigned. Work order belongs to "' . $order['branch'] . '" but area "' . $area_info['area_name'] . ' (' . $order['area'] . ')' . '" belongs to "' . $area_info['branch'] . '". Please contact administrator to fix the area assignment.'
            ]);
            $area_check_stmt->close();
            $conn->close();
            exit;
        }
    } else {
        // Area code exists in order but not found in areas table (might be inactive or deleted)
        echo json_encode([
            'success' => false,
            'message' => 'Cannot start picking! The area assigned to this work order (' . $order['area'] . ') is not found or inactive. Please contact administrator.'
        ]);
        $area_check_stmt->close();
        $conn->close();
        exit;
    }
    $area_check_stmt->close();
}

// Get plate_id if it already exists (from previous picked items that are still pending)
// Plate_id will be created automatically when first item is picked
// Only get plate_id from pending items (not from items that were on a full plate)
$plate_check_stmt = $conn->prepare("SELECT plate_id FROM picking_order_items WHERE work_id = ? AND plate_id IS NOT NULL AND plate_id != '' AND status = 'pending' LIMIT 1");
$plate_check_stmt->bind_param("s", $work_id);
$plate_check_stmt->execute();
$plate_result = $plate_check_stmt->get_result();
$plate_id = null;

if ($plate_result->num_rows > 0) {
    // Plate already exists for this work order (from previous items that are still pending)
    $plate_row = $plate_result->fetch_assoc();
    $plate_id = $plate_row['plate_id'];
}
$plate_check_stmt->close();

// Get total items count
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM picking_order_items WHERE work_id = ?");
$stmt->bind_param("s", $work_id);
$stmt->execute();
$totalResult = $stmt->get_result();
$totalRow = $totalResult->fetch_assoc();
$total_items = intval($totalRow['total'] ?? 0);

// Get picked items count
$stmt = $conn->prepare("SELECT COUNT(*) as picked FROM picking_order_items WHERE work_id = ? AND status = 'picked'");
$stmt->bind_param("s", $work_id);
$stmt->execute();
$pickedResult = $stmt->get_result();
$pickedRow = $pickedResult->fetch_assoc();
$picked_items = intval($pickedRow['picked'] ?? 0);

// Get the next unpicked item
// Items are ordered by rack number ONLY (ascending - closest rack first)
// Example: rack 1 comes before rack 2, rack 2 before rack 4, rack 4 before rack 5
// Format: location_code is "rack-shelf" (e.g., "1-2", "2-3", "4-2", "5-2")
// Only the rack number (before the dash) is used for sorting

// First, try to find items from low shelves (0, 1, 2) with inventory
$stmt = $conn->prepare("
    SELECT poi.*, 
           i.location_code,
           loc.full_location_code,
           loc.shelf_number,
           COALESCE(z.zone_code, i.zone) as zone,
           COALESCE(ad.description, ad.name, poi.item_barcode) as description,
           COALESCE(i.quantity, 0) as available_quantity
    FROM picking_order_items poi
    LEFT JOIN inventory i ON poi.item_barcode = i.item_barcode 
        AND i.quantity > 0
    LEFT JOIN locations loc ON i.location_code = loc.location_code
    LEFT JOIN zones z ON loc.zone_id = z.id OR (i.zone IS NOT NULL AND z.zone_code = i.zone)
    LEFT JOIN adddesc ad ON poi.item_barcode = ad.barcode
    WHERE poi.work_id = ? 
        AND poi.status = 'pending'
        AND i.item_barcode IS NOT NULL  -- Must exist in inventory
        AND (loc.shelf_number IS NULL OR loc.shelf_number <= 2)  -- Only low shelves (0 = bottom, 1, 2)
        -- If location_code is specified in order, try to match it; otherwise accept any location
        AND (poi.location_code IS NULL OR poi.location_code = '' OR poi.location_code = i.location_code)
        -- Ensure this is the best location for this item (lowest shelf with quantity)
        AND NOT EXISTS (
            SELECT 1 
            FROM inventory i2
            LEFT JOIN locations loc2 ON i2.location_code = loc2.location_code
            WHERE i2.item_barcode = poi.item_barcode
                AND i2.quantity > 0
                AND (loc2.shelf_number IS NULL OR loc2.shelf_number <= 2)
                AND (
                    (loc2.shelf_number IS NOT NULL AND loc2.shelf_number < COALESCE(loc.shelf_number, 999))
                    OR (loc2.shelf_number IS NULL AND loc.shelf_number IS NOT NULL)
                    OR (loc2.shelf_number = COALESCE(loc.shelf_number, 999) AND i2.quantity > i.quantity)
                )
        )
    ORDER BY 
        CAST(SUBSTRING_INDEX(COALESCE(loc.location_code, i.location_code, poi.location_code), '-', 1) AS UNSIGNED) ASC  -- Order by rack number only (ascending)
    LIMIT 1
");
$stmt->bind_param("s", $work_id);
$stmt->execute();
$itemResult = $stmt->get_result();

$current_item = null;
if ($itemResult->num_rows > 0) {
    $current_item = $itemResult->fetch_assoc();
} else {
    // If no items found in low shelves, try to find from all shelves (including high shelves)
    $stmt = $conn->prepare("
        SELECT poi.*, 
               i.location_code,
               loc.full_location_code,
               loc.shelf_number,
               COALESCE(z.zone_code, i.zone) as zone,
               COALESCE(ad.description, ad.name, poi.item_barcode) as description,
               COALESCE(i.quantity, 0) as available_quantity
        FROM picking_order_items poi
        LEFT JOIN inventory i ON poi.item_barcode = i.item_barcode 
            AND i.quantity > 0
        LEFT JOIN locations loc ON i.location_code = loc.location_code
        LEFT JOIN zones z ON loc.zone_id = z.id OR (i.zone IS NOT NULL AND z.zone_code = i.zone)
        LEFT JOIN adddesc ad ON poi.item_barcode = ad.barcode
        WHERE poi.work_id = ? 
            AND poi.status = 'pending'
            AND i.item_barcode IS NOT NULL  -- Must exist in inventory
            -- If location_code is specified in order, try to match it; otherwise accept any location
            AND (poi.location_code IS NULL OR poi.location_code = '' OR poi.location_code = i.location_code)
            -- Ensure this is the best location for this item (lowest shelf with quantity)
            AND NOT EXISTS (
                SELECT 1 
                FROM inventory i2
                LEFT JOIN locations loc2 ON i2.location_code = loc2.location_code
                WHERE i2.item_barcode = poi.item_barcode
                    AND i2.quantity > 0
                    AND (
                        (loc2.shelf_number IS NOT NULL AND loc.shelf_number IS NOT NULL AND loc2.shelf_number < loc.shelf_number)
                        OR (loc2.shelf_number IS NOT NULL AND loc.shelf_number IS NULL)
                        OR (loc2.shelf_number IS NULL AND loc.shelf_number IS NOT NULL)
                        OR (COALESCE(loc2.shelf_number, 999) = COALESCE(loc.shelf_number, 999) AND i2.quantity > i.quantity)
                    )
            )
        ORDER BY 
            CAST(SUBSTRING_INDEX(COALESCE(loc.location_code, i.location_code, poi.location_code), '-', 1) AS UNSIGNED) ASC  -- Order by rack number only (ascending)
        LIMIT 1
    ");
    $stmt->bind_param("s", $work_id);
    $stmt->execute();
    $itemResult = $stmt->get_result();
    
    if ($itemResult->num_rows > 0) {
        $current_item = $itemResult->fetch_assoc();
    } else {
        // If still no items found in inventory, get any pending item (even if not in inventory)
        // This allows picker to see what needs to be picked, even if item is out of stock
        $stmt = $conn->prepare("
            SELECT poi.*, 
                   poi.location_code,
                   NULL as full_location_code,
                   NULL as shelf_number,
                   NULL as zone,
                   COALESCE(ad.description, ad.name, poi.item_barcode) as description,
                   0 as available_quantity
            FROM picking_order_items poi
            LEFT JOIN adddesc ad ON poi.item_barcode = ad.barcode
            WHERE poi.work_id = ? 
                AND poi.status = 'pending'
            ORDER BY 
                CAST(SUBSTRING_INDEX(COALESCE(poi.location_code, ''), '-', 1) AS UNSIGNED) ASC  -- Order by rack number ascending
            LIMIT 1
        ");
        $stmt->bind_param("s", $work_id);
        $stmt->execute();
        $itemResult = $stmt->get_result();
        
        if ($itemResult->num_rows > 0) {
            $current_item = $itemResult->fetch_assoc();
        }
    }
}

if ($current_item) {
    // Get expiry date if available from receiving table
    $expiry_stmt = $conn->prepare("SELECT expiry_date FROM receiving WHERE item_barcode = ? ORDER BY receive_date DESC LIMIT 1");
    $expiry_stmt->bind_param("s", $current_item['item_barcode']);
    $expiry_stmt->execute();
    $expiry_result = $expiry_stmt->get_result();
    if ($expiry_result->num_rows > 0) {
        $expiry_row = $expiry_result->fetch_assoc();
        $current_item['expiry_date'] = $expiry_row['expiry_date'] ?? 'N/A';
    } else {
        $current_item['expiry_date'] = 'N/A';
    }
    $expiry_stmt->close();
    
    // Set status based on available quantity
    $available_qty = intval($current_item['available_quantity'] ?? 0);
    $required_qty = intval($current_item['quantity_required'] ?? 0);
    $shelf_number = $current_item['shelf_number'] ?? null;
    
    if ($available_qty >= $required_qty) {
        if ($shelf_number !== null && $shelf_number > 2) {
            $current_item['status'] = 'Available (High Shelf - Check Lowering Orders)';
        } else {
            $current_item['status'] = 'Available';
        }
    } else if ($available_qty > 0) {
        if ($shelf_number !== null && $shelf_number > 2) {
            $current_item['status'] = 'Partial (' . $available_qty . ' available - High Shelf)';
        } else {
            $current_item['status'] = 'Partial (' . $available_qty . ' available)';
        }
    } else {
        $current_item['status'] = 'Out of Stock';
    }
    
    // Ensure zone is set (use first character of location_code if zone is NULL)
    if (empty($current_item['zone']) && !empty($current_item['location_code'])) {
        $current_item['zone'] = strtoupper(substr($current_item['location_code'], 0, 1));
    }
}

echo json_encode([
    'success' => true,
    'order' => [
        'work_id' => $order['work_id'],
        'branch' => $order['branch'],
        'total_items' => $total_items,
        'picked_items' => $picked_items,
        'plate_id' => $plate_id  // One plate per work order
    ],
    'current_item' => $current_item
]);

$stmt->close();
$conn->close();
?>
