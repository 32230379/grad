<?php
header('Content-Type: application/json');
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

$plate_id = isset($_POST['plate_id']) ? trim($_POST['plate_id']) : '';

if (empty($plate_id)) {
    echo json_encode([
        'success' => false,
        'message' => 'Plate ID is required'
    ]);
    exit;
}

// Check if plate exists and is verified
$check_stmt = $conn->prepare("
    SELECT verification_status, plate_status
    FROM plate_verifications
    WHERE plate_id = ?
    LIMIT 1
");
$check_stmt->bind_param("s", $plate_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Plate not found or not verified yet'
    ]);
    $check_stmt->close();
    $conn->close();
    exit;
}

$plate_data = $check_result->fetch_assoc();
$check_stmt->close();

// Check if already ready for load or loaded
if ($plate_data['plate_status'] === 'ready_to_load') {
    echo json_encode([
        'success' => false,
        'message' => 'Plate is already marked as ready for load'
    ]);
    $conn->close();
    exit;
}

if ($plate_data['plate_status'] === 'loaded') {
    echo json_encode([
        'success' => false,
        'message' => 'Plate has already been loaded'
    ]);
    $conn->close();
    exit;
}

// Start transaction
$conn->begin_transaction();

try {
    // Update plate status to ready_to_load
    $update_stmt = $conn->prepare("
        UPDATE plate_verifications
        SET plate_status = 'ready_to_load',
            ready_for_load_at = NOW()
        WHERE plate_id = ?
    ");
    $update_stmt->bind_param("s", $plate_id);
    $update_stmt->execute();
    $update_stmt->close();
    
    // Get all items for this plate with QC quantities and their locations
    $items_stmt = $conn->prepare("
        SELECT 
            pl.item_barcode,
            pl.location_code,
            pl.quantity_picked as picker_quantity,
            pvi.qc_quantity,
            i.quantity as current_inventory_qty
        FROM picking_log pl
        INNER JOIN plate_verification_items pvi ON pl.plate_id = pvi.plate_id 
            AND pl.item_barcode = pvi.item_barcode
        LEFT JOIN inventory i ON pl.item_barcode = i.item_barcode 
            AND pl.location_code = i.location_code
        WHERE pl.plate_id = ?
    ");
    $items_stmt->bind_param("s", $plate_id);
    $items_stmt->execute();
    $items_result = $items_stmt->get_result();
    
    $updated_items = [];
    $errors = [];
    
    while ($item = $items_result->fetch_assoc()) {
        $item_barcode = $item['item_barcode'];
        $location_code = $item['location_code'];
        $picker_qty = intval($item['picker_quantity'] ?? 0);
        $qc_qty = intval($item['qc_quantity'] ?? 0);
        $current_inv_qty = intval($item['current_inventory_qty'] ?? 0);
        
        // Use QC quantity as final quantity (QC is the last stage to confirm correct quantity)
        $final_quantity = $qc_qty;
        
        if ($final_quantity <= 0) {
            $errors[] = "Item {$item_barcode}: QC quantity is 0 or invalid";
            continue;
        }
        
        // Calculate the difference: picker picked X, but QC confirmed Y
        // When picking happened, inventory was reduced by picker_qty
        // Now we need to adjust: inventory should reflect qc_qty was picked (final quantity)
        // Adjustment = picker_qty - qc_qty
        // If positive: picker picked more than QC confirmed, add back to inventory
        // If negative: picker picked less than QC confirmed, subtract more from inventory
        
        $adjustment = $picker_qty - $qc_qty;
        
        if ($adjustment != 0) {
            // Adjust inventory: add back the difference (if positive) or subtract more (if negative)
            $new_inv_qty = $current_inv_qty + $adjustment;
            
            // Ensure inventory doesn't go negative
            if ($new_inv_qty < 0) {
                $errors[] = "Item {$item_barcode}: Cannot adjust inventory (would go negative. Current: {$current_inv_qty}, Adjustment: {$adjustment})";
                continue;
            }
            
            // Update inventory with adjusted quantity
            $update_inv_stmt = $conn->prepare("
                UPDATE inventory 
                SET quantity = ?, last_update = NOW() 
                WHERE item_barcode = ? AND location_code = ?
            ");
            $update_inv_stmt->bind_param("iss", $new_inv_qty, $item_barcode, $location_code);
            
            if ($update_inv_stmt->execute()) {
                $updated_items[] = [
                    'item' => $item_barcode,
                    'location' => $location_code,
                    'picker_qty' => $picker_qty,
                    'qc_qty' => $qc_qty,
                    'adjustment' => $adjustment,
                    'final_inv' => $new_inv_qty
                ];
            } else {
                $errors[] = "Item {$item_barcode}: Failed to update inventory";
            }
            $update_inv_stmt->close();
        } else {
            // No adjustment needed - picker and QC quantities match
            $updated_items[] = [
                'item' => $item_barcode,
                'location' => $location_code,
                'picker_qty' => $picker_qty,
                'qc_qty' => $qc_qty,
                'adjustment' => 0,
                'final_inv' => $current_inv_qty
            ];
        }
        
        // Update picking_log with final QC quantity (for record keeping)
        $update_log_stmt = $conn->prepare("
            UPDATE picking_log 
            SET quantity_picked = ? 
            WHERE plate_id = ? AND item_barcode = ?
        ");
        $update_log_stmt->bind_param("iss", $qc_qty, $plate_id, $item_barcode);
        $update_log_stmt->execute();
        $update_log_stmt->close();
    }
    $items_stmt->close();
    
    if (!empty($errors)) {
        throw new Exception("Some items failed to update: " . implode(", ", $errors));
    }
    
    // Commit transaction
    $conn->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Plate marked as Ready for Load successfully. Inventory updated with QC confirmed quantities.',
        'updated_items' => count($updated_items)
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode([
        'success' => false,
        'message' => 'Failed to update plate status: ' . $e->getMessage()
    ]);
}

$conn->close();
?>

