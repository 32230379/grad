<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'manager') {
    header("Location: login.php?role=manager");
    exit();
}
include 'db_connect.php';

// Add minimum_quantity column to adddesc if it doesn't exist
$check_column = $conn->query("SHOW COLUMNS FROM adddesc LIKE 'minimum_quantity'");
if ($check_column->num_rows == 0) {
    $conn->query("ALTER TABLE adddesc ADD COLUMN minimum_quantity int(11) DEFAULT 20 AFTER description");
}

// Handle create PO Draft from selected items
if (isset($_POST['create_po_draft']) && isset($_POST['selected_items'])) {
    $selected_items = json_decode($_POST['selected_items'], true);
    $supplier_id = intval($_POST['supplier_id'] ?? 0);
    
    if (empty($selected_items) || $supplier_id <= 0) {
        $message = "<div class='alert alert-error'>Please select items and supplier</div>";
    } else {
        // Create Purchase Order from Reorder
        // Generate PO number: PO-YYYYMMDD-XXXRE (where XXX is auto-increment based on today's reorder POs)
        $today = date('Y-m-d');
        $po_prefix = 'PO-' . date('Ymd');
        
        // Count today's reorder POs (ending with RE) to generate unique number
        $count_query = "SELECT COUNT(*) as count FROM purchase_orders WHERE po_number LIKE '$po_prefix%RE'";
        $count_result = $conn->query($count_query);
        $count_row = $count_result->fetch_assoc();
        $po_suffix = str_pad(($count_row['count'] + 1), 3, '0', STR_PAD_LEFT);
        $po_number = $po_prefix . '-' . $po_suffix . 'RE';
        
        $order_date = date('Y-m-d');
        $expected_delivery_date = date('Y-m-d', strtotime('+7 days'));
        
        $stmt = $conn->prepare("INSERT INTO purchase_orders (po_number, supplier_id, order_date, expected_delivery_date, status, created_by) VALUES (?, ?, ?, ?, 'pending', ?)");
        $created_by = $_SESSION['user_name'] ?? 'Manager';
        $stmt->bind_param("sisss", $po_number, $supplier_id, $order_date, $expected_delivery_date, $created_by);
        
        if ($stmt->execute()) {
            $po_id = $conn->insert_id;
            
            // Insert items with prices
            $item_stmt = $conn->prepare("INSERT INTO purchase_order_items (po_id, item_barcode, quantity_ordered, unit_price, total_price) VALUES (?, ?, ?, ?, ?)");
            foreach ($selected_items as $item) {
                $unit_price = floatval($item['price'] ?? 0);
                $quantity = intval($item['quantity']);
                $total_price = $unit_price * $quantity;
                $item_stmt->bind_param("isidd", $po_id, $item['barcode'], $quantity, $unit_price, $total_price);
                $item_stmt->execute();
            }
            $item_stmt->close();
            
            // Update PO totals
            $totals_query = "
                SELECT 
                    SUM(total_price) as subtotal
                FROM purchase_order_items
                WHERE po_id = ?
            ";
            $totals_stmt = $conn->prepare($totals_query);
            $totals_stmt->bind_param("i", $po_id);
            $totals_stmt->execute();
            $totals_result = $totals_stmt->get_result();
            $totals_row = $totals_result->fetch_assoc();
            $subtotal = floatval($totals_row['subtotal'] ?? 0);
            $tax_rate = 0; // Default tax rate
            $tax_amount = $subtotal * ($tax_rate / 100);
            $total_amount = $subtotal + $tax_amount;
            
            $update_po_stmt = $conn->prepare("UPDATE purchase_orders SET subtotal = ?, tax_rate = ?, tax_amount = ?, total_amount = ? WHERE id = ?");
            $update_po_stmt->bind_param("ddddi", $subtotal, $tax_rate, $tax_amount, $total_amount, $po_id);
            $update_po_stmt->execute();
            $update_po_stmt->close();
            $totals_stmt->close();
            
            $message = "<div class='alert alert-success'>Purchase Order created successfully! PO Number: $po_number</div>";
        } else {
            $message = "<div class='alert alert-error'>Error creating PO Draft: " . $conn->error . "</div>";
        }
        $stmt->close();
    }
}

// Get items below minimum quantity OR quantity < 10 (Low Stock)
$reorder_query = "
    SELECT 
        ad.barcode,
        ad.name,
        ad.description,
        COALESCE(ad.minimum_quantity, 20) as minimum_quantity,
        COALESCE(SUM(i.quantity), 0) as current_quantity,
        ad.minimum_quantity as reorder_level,
        CASE 
            WHEN COALESCE(SUM(i.quantity), 0) < 10 THEN 'low_stock'
            WHEN COALESCE(SUM(i.quantity), 0) < COALESCE(ad.minimum_quantity, 20) THEN 'below_minimum'
            ELSE 'normal'
        END as reorder_reason
    FROM adddesc ad
    LEFT JOIN inventory i ON ad.barcode = i.item_barcode AND i.location_code != 'rec'
    GROUP BY ad.barcode, ad.name, ad.description, ad.minimum_quantity
    HAVING COALESCE(SUM(i.quantity), 0) < 10 
        OR COALESCE(SUM(i.quantity), 0) < COALESCE(ad.minimum_quantity, 20)
    ORDER BY 
        CASE 
            WHEN COALESCE(SUM(i.quantity), 0) < 10 THEN 0
            ELSE 1
        END,
        (COALESCE(SUM(i.quantity), 0) - COALESCE(ad.minimum_quantity, 20)) ASC
";
$reorder_result = $conn->query($reorder_query);

// Get all suppliers
$suppliers_query = "SELECT id, supplier_name FROM suppliers WHERE status = 'active' ORDER BY supplier_name";
$suppliers_result = $conn->query($suppliers_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reorder Requests - Warehouse System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 5px;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #6c757d;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .manual-add-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
        }
        .manual-add-section h2 {
            color: #333;
            margin-bottom: 15px;
            font-size: 20px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr auto;
            gap: 10px;
            margin-bottom: 10px;
            align-items: end;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-group label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        .form-group input, .form-group select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        .btn-primary {
            background: #6c757d;
            color: white;
        }
        .btn-primary:hover {
            background: #5a6268;
        }
        .btn-success {
            background: #28a745;
            color: white;
        }
        .btn-success:hover {
            background: #218838;
        }
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #343a40;
            color: white;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background: #f8f9fa;
        }
        tr:hover {
            background: #e9ecef;
        }
        .checkbox-col {
            width: 50px;
            text-align: center;
        }
        .quantity-input {
            width: 80px;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 3px;
        }
        .current-qty {
            color: #dc3545;
            font-weight: bold;
        }
        .minimum-qty {
            color: #ffc107;
            font-weight: bold;
        }
        .po-form {
            background: #fff3cd;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
            display: none;
        }
        .po-form.show {
            display: block;
        }
        .selected-count {
            background: #6c757d;
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <div class="main-content">
            <div class="container">
                <h1>📦 Reorder Requests</h1>
                
                <?php if (isset($message)) echo $message; ?>
                
                <!-- Manual Add Section -->
                <div class="manual-add-section">
                    <h2>➕ Add Manual Reorder Request</h2>
                    <form id="manual-add-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Item Barcode</label>
                                <input type="text" id="manual-barcode" placeholder="Scan or enter barcode" required>
                            </div>
                            <div class="form-group">
                                <label>Minimum Quantity</label>
                                <input type="number" id="manual-min-qty" value="20" min="1" required>
                            </div>
                            <div class="form-group">
                                <label>Requested Quantity</label>
                                <input type="number" id="manual-req-qty" value="50" min="1" required>
                            </div>
                            <div>
                                <button type="button" class="btn btn-primary" onclick="addManualRequest()">Add</button>
                            </div>
                        </div>
                    </form>
                </div>
                
                <!-- Reorder Requests Table -->
                <form method="POST" id="reorder-form">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <h2 style="margin: 0;">Items Below Minimum Quantity</h2>
                        <div>
                            <span id="selected-count" class="selected-count" style="display: none;">0 selected</span>
                            <button type="button" class="btn btn-success" onclick="showPOForm()" id="create-po-btn" style="display: none;">Create Purchase Order</button>
                        </div>
                    </div>
                    
                    <table>
                        <thead>
                            <tr>
                                <th class="checkbox-col">
                                    <input type="checkbox" id="select-all" onchange="toggleAll(this)">
                                </th>
                                <th>Item Barcode</th>
                                <th>Item Name</th>
                                <th>Current Quantity</th>
                                <th>Minimum Quantity</th>
                                <th>Requested Quantity</th>
                                <th>Unit Price</th>
                            </tr>
                        </thead>
                        <tbody id="reorder-tbody">
                            <?php
                            $manual_requests = [];
                            if ($reorder_result && $reorder_result->num_rows > 0) {
                                while ($row = $reorder_result->fetch_assoc()) {
                                    $current_qty = $row['current_quantity'];
                                    $min_qty = $row['minimum_quantity'];
                                    
                                    // Calculate requested quantity based on reason
                                    if ($current_qty < 10) {
                                        // Low stock: request to reach at least 50 or minimum_quantity, whichever is higher
                                        $requested_qty = max(50, $min_qty);
                                    } else {
                                        // Below minimum: request to cover deficit + buffer
                                        $deficit = $min_qty - $current_qty;
                                        $requested_qty = max($deficit + 20, 20);
                                    }
                                    
                                    $row_class = $row['reorder_reason'] == 'low_stock' ? 'style="background-color: #fff3cd;"' : '';
                                    ?>
                                    <tr data-barcode="<?php echo htmlspecialchars($row['barcode']); ?>" <?php echo $row_class; ?>>
                                        <td class="checkbox-col">
                                            <input type="checkbox" class="item-checkbox" 
                                                   data-barcode="<?php echo htmlspecialchars($row['barcode']); ?>"
                                                   data-name="<?php echo htmlspecialchars($row['name'] ?? $row['barcode']); ?>"
                                                   onchange="updateSelectedCount()">
                                        </td>
                                        <td><?php echo htmlspecialchars($row['barcode']); ?></td>
                                        <td>
                                            <?php echo htmlspecialchars($row['name'] ?? $row['description'] ?? $row['barcode']); ?>
                                            <?php if ($row['reorder_reason'] == 'low_stock'): ?>
                                                <span style="background: #ffc107; color: #333; padding: 2px 6px; border-radius: 3px; font-size: 10px; margin-left: 5px;">Low Stock</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="current-qty"><?php echo $current_qty; ?></td>
                                        <td class="minimum-qty"><?php echo $min_qty; ?></td>
                                        <td>
                                            <input type="number" 
                                                   class="quantity-input req-qty" 
                                                   value="<?php echo $requested_qty; ?>" 
                                                   min="1"
                                                   data-barcode="<?php echo htmlspecialchars($row['barcode']); ?>">
                                        </td>
                                        <td>
                                            <input type="number" 
                                                   class="quantity-input req-price" 
                                                   value="0" 
                                                   step="0.01"
                                                   min="0"
                                                   placeholder="0.00"
                                                   data-barcode="<?php echo htmlspecialchars($row['barcode']); ?>">
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                ?>
                                <tr>
                                    <td colspan="6" style="text-align: center; padding: 40px; color: #999;">
                                        No items below minimum quantity
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                    
                    <!-- PO Creation Form -->
                    <div class="po-form" id="po-form">
                        <h3>Create Purchase Order</h3>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Select Supplier *</label>
                                <select name="supplier_id" id="po-supplier" required>
                                    <option value="">Select Supplier</option>
                                    <?php
                                    if ($suppliers_result && $suppliers_result->num_rows > 0) {
                                        while ($supplier = $suppliers_result->fetch_assoc()) {
                                            echo "<option value='{$supplier['id']}'>{$supplier['supplier_name']}</option>";
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div>
                                <button type="submit" name="create_po_draft" class="btn btn-success">Create Purchase Order</button>
                                <button type="button" class="btn btn-danger" onclick="hidePOForm()">Cancel</button>
                            </div>
                        </div>
                        <input type="hidden" name="selected_items" id="selected-items-input">
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        let manualRequests = [];
        
        function addManualRequest() {
            const barcode = document.getElementById('manual-barcode').value.trim();
            const minQty = parseInt(document.getElementById('manual-min-qty').value) || 20;
            const reqQty = parseInt(document.getElementById('manual-req-qty').value) || 50;
            
            if (!barcode) {
                alert('Please enter item barcode');
                return;
            }
            
            // Check if item already exists in table
            const existingRow = document.querySelector(`tr[data-barcode="${barcode}"]`);
            if (existingRow) {
                alert('Item already exists in the list');
                return;
            }
            
            // Add to manual requests array
            manualRequests.push({
                barcode: barcode,
                minQty: minQty,
                reqQty: reqQty
            });
            
            // Add row to table
            const tbody = document.getElementById('reorder-tbody');
            const tr = document.createElement('tr');
            tr.setAttribute('data-barcode', barcode);
            tr.innerHTML = `
                <td class="checkbox-col">
                    <input type="checkbox" class="item-checkbox" 
                           data-barcode="${barcode}"
                           data-name="${barcode}"
                           onchange="updateSelectedCount()">
                </td>
                <td>${barcode}</td>
                <td>${barcode} (Manual)</td>
                <td class="current-qty">0</td>
                <td class="minimum-qty">${minQty}</td>
                <td>
                    <input type="number" 
                           class="quantity-input req-qty" 
                           value="${reqQty}" 
                           min="1"
                           data-barcode="${barcode}">
                </td>
                <td>
                    <input type="number" 
                           class="quantity-input req-price" 
                           value="0" 
                           step="0.01"
                           min="0"
                           placeholder="0.00"
                           data-barcode="${barcode}">
                </td>
            `;
            tbody.appendChild(tr);
            
            // Clear form
            document.getElementById('manual-barcode').value = '';
            document.getElementById('manual-req-qty').value = '50';
        }
        
        function toggleAll(checkbox) {
            const checkboxes = document.querySelectorAll('.item-checkbox');
            checkboxes.forEach(cb => cb.checked = checkbox.checked);
            updateSelectedCount();
        }
        
        function updateSelectedCount() {
            const checked = document.querySelectorAll('.item-checkbox:checked');
            const count = checked.length;
            const countSpan = document.getElementById('selected-count');
            const createBtn = document.getElementById('create-po-btn');
            
            if (count > 0) {
                countSpan.textContent = count + ' selected';
                countSpan.style.display = 'inline-block';
                createBtn.style.display = 'inline-block';
            } else {
                countSpan.style.display = 'none';
                createBtn.style.display = 'none';
                hidePOForm();
            }
        }
        
        function showPOForm() {
            const checked = document.querySelectorAll('.item-checkbox:checked');
            if (checked.length === 0) {
                alert('Please select at least one item');
                return;
            }
            
            const selectedItems = [];
            checked.forEach(cb => {
                const barcode = cb.getAttribute('data-barcode');
                const qtyInput = document.querySelector(`.req-qty[data-barcode="${barcode}"]`);
                const priceInput = document.querySelector(`.req-price[data-barcode="${barcode}"]`);
                const qty = parseInt(qtyInput.value) || 1;
                const price = parseFloat(priceInput.value) || 0;
                selectedItems.push({
                    barcode: barcode,
                    quantity: qty,
                    price: price
                });
            });
            
            document.getElementById('selected-items-input').value = JSON.stringify(selectedItems);
            document.getElementById('po-form').classList.add('show');
        }
        
        function hidePOForm() {
            document.getElementById('po-form').classList.remove('show');
        }
    </script>
</body>
</html>

