<?php


include 'db_connect.php';

// Get filter parameters
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';
$work_id_filter = isset($_GET['work_id']) ? trim($_GET['work_id']) : '';
$branch_filter = isset($_GET['branch']) ? trim($_GET['branch']) : '';

// Build query for loaded plates
$query = "
    SELECT 
        pv.plate_id,
        pv.work_id,
        pv.branch,
        pv.verified_by as qc_name,
        pv.verified_at,
        pv.ready_for_load_at,
        pv.loaded_by,
        pv.plate_status,
        COUNT(DISTINCT pl.item_barcode) as item_count,
        SUM(COALESCE(pvi.qc_quantity, pl.quantity_picked)) as total_quantity
    FROM plate_verifications pv
    LEFT JOIN picking_log pl ON pv.plate_id = pl.plate_id
    LEFT JOIN plate_verification_items pvi ON pv.plate_id = pvi.plate_id AND pl.item_barcode = pvi.item_barcode
    WHERE pv.plate_status = 'loaded'
";

$params = [];
$types = '';

if (!empty($date_from)) {
    $query .= " AND DATE(pv.ready_for_load_at) >= ?";
    $params[] = $date_from;
    $types .= 's';
}

if (!empty($date_to)) {
    $query .= " AND DATE(pv.ready_for_load_at) <= ?";
    $params[] = $date_to;
    $types .= 's';
}

if (!empty($work_id_filter)) {
    $query .= " AND pv.work_id LIKE ?";
    $params[] = '%' . $work_id_filter . '%';
    $types .= 's';
}

if (!empty($branch_filter)) {
    $query .= " AND pv.branch LIKE ?";
    $params[] = '%' . $branch_filter . '%';
    $types .= 's';
}

$query .= " GROUP BY pv.plate_id ORDER BY pv.ready_for_load_at DESC";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// Get branches for filter
$branches_query = "SELECT DISTINCT branch FROM plate_verifications WHERE branch IS NOT NULL AND plate_status = 'loaded' ORDER BY branch";
$branches_result = $conn->query($branches_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loaded Plates - Warehouse System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 5px;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #6c757d;
        }
        .filters {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        .filter-group {
            display: flex;
            flex-direction: column;
        }
        .filter-group label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
            font-size: 14px;
        }
        .filter-group input, .filter-group select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: #6c757d;
            color: white;
        }
        .btn-primary:hover {
            background: #5a6268;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #343a40;
            color: white;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background: #f8f9fa;
        }
        tr:hover {
            background: #e9ecef;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: bold;
        }
        .status-loaded {
            background: #28a745;
            color: white;
        }
        .btn-view {
            background: #007bff;
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            text-decoration: none;
            font-size: 12px;
        }
        .btn-view:hover {
            background: #0056b3;
        }
        .no-data {
            text-align: center;
            padding: 40px;
            color: #999;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
        }
        .stat-card h3 {
            color: #333;
            font-size: 24px;
            margin-bottom: 5px;
        }
        .stat-card p {
            color: #666;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <div class="main-content">
            <div class="container">
                <h1>📦 Loaded Plates</h1>
                
                <?php
                // Calculate statistics
                $stats_query = "
                    SELECT 
                        COUNT(DISTINCT pv.plate_id) as total_plates,
                        SUM(COALESCE(pvi.qc_quantity, pl.quantity_picked)) as total_quantity,
                        COUNT(DISTINCT pv.work_id) as total_work_orders
                    FROM plate_verifications pv
                    LEFT JOIN picking_log pl ON pv.plate_id = pl.plate_id
                    LEFT JOIN plate_verification_items pvi ON pv.plate_id = pvi.plate_id AND pl.item_barcode = pvi.item_barcode
                    WHERE pv.plate_status = 'loaded'
                ";
                $stats_result = $conn->query($stats_query);
                $stats = $stats_result->fetch_assoc();
                ?>
                
                <div class="stats">
                    <div class="stat-card">
                        <h3><?php echo $stats['total_plates'] ?? 0; ?></h3>
                        <p>Total Loaded Plates</p>
                    </div>
                    <div class="stat-card">
                        <h3><?php echo $stats['total_quantity'] ?? 0; ?></h3>
                        <p>Total Items Loaded</p>
                    </div>
                    <div class="stat-card">
                        <h3><?php echo $stats['total_work_orders'] ?? 0; ?></h3>
                        <p>Work Orders</p>
                    </div>
                </div>
                
                <!-- Filters -->
                <form method="GET" class="filters">
                    <div class="filter-group">
                        <label>Date From</label>
                        <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
                    </div>
                    <div class="filter-group">
                        <label>Date To</label>
                        <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
                    </div>
                    <div class="filter-group">
                        <label>Work ID</label>
                        <input type="text" name="work_id" placeholder="Search Work ID" value="<?php echo htmlspecialchars($work_id_filter); ?>">
                    </div>
                    <div class="filter-group">
                        <label>Branch</label>
                        <select name="branch">
                            <option value="">All Branches</option>
                            <?php
                            while ($branch = $branches_result->fetch_assoc()) {
                                $selected = ($branch_filter == $branch['branch']) ? 'selected' : '';
                                echo "<option value='{$branch['branch']}' $selected>{$branch['branch']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="filter-group" style="justify-content: flex-end;">
                        <label>&nbsp;</label>
                        <div>
                            <button type="submit" class="btn btn-primary">Filter</button>
                            <a href="loaded_plates.php" class="btn btn-secondary" style="margin-left: 5px;">Clear</a>
                        </div>
                    </div>
                </form>
                
                <!-- Plates Table -->
                <table>
                    <thead>
                        <tr>
                            <th>Plate ID</th>
                            <th>Work ID</th>
                            <th>Branch</th>
                            <th>Items Count</th>
                            <th>Total Quantity</th>
                            <th>QC Verified By</th>
                            <th>Loaded By</th>
                            <th>Loaded At</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($row['plate_id']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($row['work_id'] ?? '-'); ?></td>
                                    <td><?php echo htmlspecialchars($row['branch'] ?? '-'); ?></td>
                                    <td><?php echo $row['item_count']; ?></td>
                                    <td><strong><?php echo $row['total_quantity']; ?></strong></td>
                                    <td><?php echo htmlspecialchars($row['qc_name'] ?? '-'); ?></td>
                                    <td><?php echo htmlspecialchars($row['loaded_by'] ?? '-'); ?></td>
                                    <td><?php echo $row['ready_for_load_at'] ? date('Y-m-d H:i', strtotime($row['ready_for_load_at'])) : '-'; ?></td>
                                    <td>
                                        <span class="status-badge status-loaded">Loaded</span>
                                    </td>
                                    <td>
                                        <a href="view_plate_details.php?plate_id=<?php echo urlencode($row['plate_id']); ?>" class="btn-view">View Details</a>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="10" class="no-data">No loaded plates found</td>
                            </tr>
                            <?php
                        }
                        $stmt->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>

