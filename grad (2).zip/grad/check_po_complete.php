<?php
session_start();
header('Content-Type: application/json');
include 'db_connect.php';

if (!isset($_GET['po_id']) || !is_numeric($_GET['po_id'])) {
    echo json_encode(['success' => false, 'is_complete' => false]);
    exit;
}

$po_id = intval($_GET['po_id']);

// Check if all items in PO are fully received
$query = "
    SELECT 
        COUNT(*) as total_items,
        SUM(CASE WHEN COALESCE(quantity_received, 0) >= quantity_ordered THEN 1 ELSE 0 END) as completed_items
    FROM purchase_order_items
    WHERE po_id = ?
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $po_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
    $is_complete = ($data['total_items'] > 0 && $data['completed_items'] == $data['total_items']);
    
    echo json_encode([
        'success' => true,
        'is_complete' => $is_complete,
        'total_items' => $data['total_items'],
        'completed_items' => $data['completed_items']
    ]);
} else {
    echo json_encode(['success' => false, 'is_complete' => false]);
}

$stmt->close();
$conn->close();
?>

