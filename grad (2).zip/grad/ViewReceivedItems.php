<?php
session_start();
include "db_connect.php";

// 🔒 تأكد من تسجيل الدخول
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

// 🗑️ حذف عنصر
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM receiving WHERE id=$id");
    header("Location: ViewReceivedItems.php");
    exit();
}

// 🗑️ حذف بلت كامل
if (isset($_GET['delete_plate'])) {
    $plate_id = mysqli_real_escape_string($conn, $_GET['delete_plate']);
    mysqli_query($conn, "DELETE FROM receiving WHERE plate_id='$plate_id'");
    header("Location: ViewReceivedItems.php");
    exit();
}

// ✏️ تعديل عنصر
if (isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $plate = mysqli_real_escape_string($conn, $_POST['plate_id']);
    $barcode = mysqli_real_escape_string($conn, $_POST['item_barcode']);
    $name = mysqli_real_escape_string($conn, $_POST['item_name']);
    $desc = mysqli_real_escape_string($conn, $_POST['description']);
    $qty = intval($_POST['quantity']);
    $exp = mysqli_real_escape_string($conn, $_POST['expiry_date']);

    $update = "UPDATE receiving 
               SET plate_id='$plate', 
                   item_barcode='$barcode', 
                   item_name='$name', 
                   description='$desc', 
                   quantity=$qty, 
                   expiry_date='$exp' 
               WHERE id=$id";
    mysqli_query($conn, $update);
    header("Location: ViewReceivedItems.php");
    exit();
}

// 🔍 فلترة البحث
$filter = "";
if (isset($_GET['search'])) {
    $keyword = mysqli_real_escape_string($conn, $_GET['search']);
    $filter = "WHERE item_barcode LIKE '%$keyword%' OR description LIKE '%$keyword%' OR plate_id LIKE '%$keyword%'";
}

// جلب البيانات مجمعة حسب plate_id
$sql = "SELECT 
            plate_id,
            COUNT(*) as item_count,
            SUM(quantity) as total_quantity,
            MIN(receive_date) as receive_date,
            MAX(receive_date) as last_update,
            GROUP_CONCAT(DISTINCT received_by) as received_by,
            GROUP_CONCAT(DISTINCT status) as statuses
        FROM receiving 
        $filter 
        GROUP BY plate_id 
        ORDER BY MIN(receive_date) DESC, plate_id DESC";
$plates_result = mysqli_query($conn, $sql);

// جلب جميع العناصر للتفاصيل
$items_sql = "SELECT * FROM receiving $filter ORDER BY plate_id, id DESC";
$all_items_result = mysqli_query($conn, $items_sql);
$all_items = [];
while ($item = mysqli_fetch_assoc($all_items_result)) {
    $all_items[$item['plate_id']][] = $item;
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Received Items</title>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body {
    font-family: Arial, sans-serif;
    background: #f5f5f5;
    padding: 20px;
}
.container {
    max-width: 1400px;
    margin: 0 auto;
    background: white;
    padding: 20px;
    border-radius: 5px;
}
h2 {
  text-align: center;
    color: #333;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid #6c757d;
}
.search-form {
  text-align: center;
    margin-bottom: 20px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 5px;
}
.search-form input[type="text"] {
    padding: 10px;
    width: 300px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}
.search-form button {
    padding: 10px 20px;
  border: none;
    border-radius: 4px;
    background: #6c757d;
  color: white;
  cursor: pointer;
    font-size: 14px;
    margin: 0 5px;
}
.search-form button:hover {
    background: #5a6268;
}
.search-form a {
    color: #6c757d;
    text-decoration: none;
    margin-left: 10px;
}
.plate-row {
    background: white;
    border: 1px solid #ddd;
    border-radius: 5px;
    margin-bottom: 15px;
    overflow: hidden;
}
.plate-header {
    padding: 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #6c757d;
    color: white;
    cursor: pointer;
}
.plate-header.expanded {
    background: #5a6268;
}
.plate-info {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}
.plate-info span {
    display: flex;
    align-items: center;
    gap: 5px;
}
.plate-actions {
    display: flex;
    gap: 10px;
}
.plate-actions a {
    padding: 5px 10px;
    background: rgba(255,255,255,0.2);
    color: white;
    text-decoration: none;
    border-radius: 3px;
    font-size: 12px;
}
.plate-actions a.delete {
    background: rgba(220, 53, 69, 0.8);
}
.plate-details {
    display: none;
    padding: 0;
}
.plate-details.show {
    display: block;
}
.items-table {
  width: 100%;
  border-collapse: collapse;
}
.items-table th {
    background: #343a40;
    color: white;
    padding: 10px;
    text-align: center;
    font-weight: bold;
}
.items-table td {
    padding: 10px;
  text-align: center;
  border-bottom: 1px solid #ddd;
}
.items-table tr:nth-child(even) {
    background: #f8f9fa;
}
.badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 3px;
    font-size: 11px;
    font-weight: bold;
}
.badge-primary {
    background: #6c757d;
    color: white;
}
.badge-success {
    background: #28a745;
  color: white;
}
.badge-warning {
    background: #ffc107;
    color: #333;
}
.edit-btn, .delete-btn {
    padding: 5px 10px;
    border-radius: 3px;
  text-decoration: none;
    font-size: 12px;
    margin: 0 2px;
    display: inline-block;
}
.edit-btn {
    background: #6c757d;
    color: white;
}
.edit-btn:hover {
    background: #5a6268;
}
.delete-btn {
    background: #dc3545;
    color: white;
}
.delete-btn:hover {
    background: #c82333;
}
.expand-icon {
    font-size: 14px;
}
.no-items {
    text-align: center;
    padding: 40px;
    color: #999;
}
.edit-form {
    background: #fff3cd;
    padding: 10px;
}
.edit-form input {
    padding: 5px;
    border: 1px solid #ddd;
    border-radius: 3px;
    width: 100%;
    max-width: 150px;
}
.edit-form button {
    padding: 5px 10px;
    background: #28a745;
    color: white;
    border: none;
    border-radius: 3px;
    cursor: pointer;
}
</style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'navbar.php'; ?>
        <div class="main-content">
<div class="container">
<h2>📦 View Received Items</h2>

    <form method="GET" class="search-form">
        <input type="text" name="search" placeholder="Search by barcode, description, or plate ID..."
         value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        <button type="submit">🔍 Search</button>
        <a href="ViewReceivedItems.php">🔄 Clear</a>
</form>

    <?php if (mysqli_num_rows($plates_result) > 0): ?>
        <?php while ($plate = mysqli_fetch_assoc($plates_result)): 
            $plate_id = $plate['plate_id'];
            $items = isset($all_items[$plate_id]) ? $all_items[$plate_id] : [];
        ?>
            <div class="plate-row">
                <div class="plate-header" id="header-<?php echo htmlspecialchars($plate_id); ?>" onclick="togglePlate('<?php echo htmlspecialchars($plate_id); ?>')">
                    <div class="plate-info">
                        <span>
                            <span class="expand-icon">▼</span>
                            <strong>Plate ID:</strong> <?php echo htmlspecialchars($plate_id); ?>
                        </span>
                        <span>
                            <strong>Items Count:</strong> 
                            <span class="badge badge-primary"><?php echo $plate['item_count']; ?></span>
                        </span>
                        <span>
                            <strong>Total Quantity:</strong> 
                            <span class="badge badge-success"><?php echo $plate['total_quantity']; ?></span>
                        </span>
                        <span>
                            <strong>Receive Date:</strong> <?php echo $plate['receive_date']; ?>
                        </span>
                        <span>
                            <strong>Received By:</strong> <?php echo htmlspecialchars($plate['received_by']); ?>
                        </span>
                    </div>
                    <div class="plate-actions" onclick="event.stopPropagation();">
                        <a href="?delete_plate=<?php echo urlencode($plate_id); ?>" 
                           class="delete"
                           onclick="return confirm('Are you sure you want to delete all items in plate <?php echo htmlspecialchars($plate_id); ?>?')">
                            🗑️ Delete Plate
                        </a>
                    </div>
                </div>
                
                <div class="plate-details" id="details-<?php echo htmlspecialchars($plate_id); ?>">
                    <table class="items-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Barcode</th>
                                <th>Item Name</th>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Expiry Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): 
                                $is_editing = isset($_GET['edit']) && $_GET['edit'] == $item['id'];
                            ?>
                                <?php if ($is_editing): ?>
                                    <tr class="edit-form" onclick="event.stopPropagation();">
                                        <form method="POST" onclick="event.stopPropagation();">
                                            <td><?php echo $item['id']; ?>
                                                <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                                            </td>
                                            <td><input type="text" name="item_barcode" value="<?php echo htmlspecialchars($item['item_barcode']); ?>" required onclick="event.stopPropagation();" onfocus="event.stopPropagation();"></td>
                                            <td><input type="text" name="item_name" value="<?php echo htmlspecialchars($item['item_name']); ?>" onclick="event.stopPropagation();" onfocus="event.stopPropagation();"></td>
                                            <td><input type="text" name="description" value="<?php echo htmlspecialchars($item['description']); ?>" onclick="event.stopPropagation();" onfocus="event.stopPropagation();"></td>
                                            <td><input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" required onclick="event.stopPropagation();" onfocus="event.stopPropagation();"></td>
                                            <td><input type="date" name="expiry_date" value="<?php echo $item['expiry_date']; ?>" onclick="event.stopPropagation();" onfocus="event.stopPropagation();"></td>
                                            <td><?php echo htmlspecialchars($item['status'] ?? 'received'); ?></td>
                                            <td>
                                                <button type="submit" name="update" onclick="event.stopPropagation();">💾 Save</button>
                                                <a href="ViewReceivedItems.php<?php echo isset($_GET['search']) ? '?search=' . urlencode($_GET['search']) : ''; ?>" style="color: #e74c3c; text-decoration: none; margin-left: 10px;" onclick="event.stopPropagation();">❌ Cancel</a>
                                            </td>
                                        </form>
</tr>
                                <?php else: ?>
            <tr>
                                        <td><?php echo $item['id']; ?></td>
                                        <td><?php echo htmlspecialchars($item['item_barcode']); ?></td>
                                        <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                                        <td><?php echo htmlspecialchars($item['description']); ?></td>
                                        <td><span class="badge badge-warning"><?php echo $item['quantity']; ?></span></td>
                                        <td><?php echo $item['expiry_date']; ?></td>
                                        <td>
                                            <span class="badge <?php echo ($item['status'] ?? 'received') == 'stored' ? 'badge-success' : 'badge-primary'; ?>">
                                                <?php echo htmlspecialchars($item['status'] ?? 'received'); ?>
                                            </span>
              </td>
                                        <td>
                                            <a href="?edit=<?php echo $item['id']; ?><?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>" 
                                               class="edit-btn" 
                                               onclick="event.stopPropagation(); return true;">✏️ Edit</a>
                                            <a href="?delete=<?php echo $item['id']; ?><?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>" 
                                               class="delete-btn" 
                                               onclick="event.stopPropagation(); return confirm('Are you sure you want to delete this item?');">
                                                🗑️ Delete
                                            </a>
              </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="no-items">
            <p>❌ No received items found</p>
        </div>
    <?php endif; ?>
</div>

<script>
function togglePlate(plateId) {
    const details = document.getElementById('details-' + plateId);
    const header = document.getElementById('header-' + plateId);
    
    if (details.classList.contains('show')) {
        details.classList.remove('show');
        header.classList.remove('expanded');
    } else {
        // إغلاق جميع البلتات الأخرى
        document.querySelectorAll('.plate-details.show').forEach(el => {
            el.classList.remove('show');
        });
        document.querySelectorAll('.plate-header.expanded').forEach(el => {
            el.classList.remove('expanded');
        });
        
        // فتح البلت المحدد
        details.classList.add('show');
        header.classList.add('expanded');
    }
}

// Open the selected plate if in edit mode
<?php if (isset($_GET['edit'])): 
    $edit_id = intval($_GET['edit']);
    $edit_sql = "SELECT plate_id FROM receiving WHERE id = $edit_id";
    $edit_result = mysqli_query($conn, $edit_sql);
    if ($edit_result && $edit_row = mysqli_fetch_assoc($edit_result)):
?>
    document.addEventListener('DOMContentLoaded', function() {
        togglePlate('<?php echo htmlspecialchars($edit_row['plate_id']); ?>');
    });
<?php endif; endif; ?>
</script>
        </div>
    </div>
</body>
</html>
