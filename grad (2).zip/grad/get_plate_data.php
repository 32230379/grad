<?php
header('Content-Type: application/json');
include 'db_connect.php';

if (!isset($_GET['plate_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Plate ID is required'
    ]);
    exit;
}

$plate_id = trim($_GET['plate_id']);

// Get plate data from picking_log and picking_orders
// First check if plate exists in picking_log (even if not verified yet)
$stmt = $conn->prepare("
    SELECT DISTINCT
        pl.plate_id,
        pl.work_id,
        po.branch,
        po.area
    FROM picking_log pl
    LEFT JOIN picking_orders po ON pl.work_id = po.work_id
    WHERE pl.plate_id = ?
    LIMIT 1
");
$stmt->bind_param("s", $plate_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Plate not found in picking log. Please make sure the picker has prepared items on this plate.'
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

$plate_info = $result->fetch_assoc();
$work_id = $plate_info['work_id'] ?? null;
$stmt->close();

// If work_id is null, try to get it from picking_log directly
if (empty($work_id)) {
    $work_stmt = $conn->prepare("SELECT DISTINCT work_id FROM picking_log WHERE plate_id = ? LIMIT 1");
    $work_stmt->bind_param("s", $plate_id);
    $work_stmt->execute();
    $work_result = $work_stmt->get_result();
    if ($work_result->num_rows > 0) {
        $work_row = $work_result->fetch_assoc();
        $work_id = $work_row['work_id'];
        $plate_info['work_id'] = $work_id;
    }
    $work_stmt->close();
}

// Check if plate_verification_items table exists, if not create it
$create_table = "CREATE TABLE IF NOT EXISTS `plate_verification_items` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `plate_id` varchar(50) NOT NULL,
    `item_barcode` varchar(100) NOT NULL,
    `qc_quantity` int(11) NOT NULL,
    `verified_at` datetime DEFAULT current_timestamp(),
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_plate_item` (`plate_id`, `item_barcode`),
    KEY `idx_plate_id` (`plate_id`),
    KEY `idx_item_barcode` (`item_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

$conn->query($create_table);

// Get verification status (if exists)
$verification_stmt = $conn->prepare("
    SELECT verification_status, plate_status, verified_at, ready_for_load_at
    FROM plate_verifications
    WHERE plate_id = ?
    LIMIT 1
");
$verification_stmt->bind_param("s", $plate_id);
$verification_stmt->execute();
$verification_result = $verification_stmt->get_result();
$verification_data = $verification_result->fetch_assoc();
$verification_stmt->close();

// Check if plate is ready_to_load or loaded - QC cannot access these
$plate_status = $verification_data['plate_status'] ?? null;
if ($plate_status === 'ready_to_load' || $plate_status === 'loaded') {
    echo json_encode([
        'success' => false,
        'message' => 'This plate is already marked as ready for load or loaded. QC cannot access it anymore.',
        'plate_status' => $plate_status
    ]);
    $conn->close();
    exit;
}

// If plate is verified, ensure we get all QC quantities even if they're 0
// Check if verification exists first
$is_verified = ($verification_data && isset($verification_data['verification_status']));

// Get all items for this plate with QC quantities
// Use LEFT JOIN for picking_order_items to get items even if not in picking_order_items
$items_stmt = $conn->prepare("
    SELECT 
        pl.item_barcode,
        pl.quantity_picked,
        pl.location_code,
        COALESCE(poi.quantity_required, pl.quantity_picked) as quantity_required,
        COALESCE(ad.description, ad.name, pl.item_barcode) as description,
        pvi.qc_quantity
    FROM picking_log pl
    LEFT JOIN picking_order_items poi ON pl.work_id = poi.work_id 
        AND pl.item_barcode = poi.item_barcode
    LEFT JOIN adddesc ad ON pl.item_barcode = ad.barcode
    LEFT JOIN plate_verification_items pvi ON pl.plate_id = pvi.plate_id 
        AND pl.item_barcode = pvi.item_barcode
    WHERE pl.plate_id = ?
    ORDER BY pl.item_barcode
");
$items_stmt->bind_param("s", $plate_id);
$items_stmt->execute();
$items_result = $items_stmt->get_result();

$items = [];
while ($row = $items_result->fetch_assoc()) {
    // Ensure qc_quantity is properly set
    // If qc_quantity is NULL in database, set it to null in JSON
    // If it's 0 or any number, convert to int
    if ($row['qc_quantity'] === null) {
        $row['qc_quantity'] = null;
    } else {
        $row['qc_quantity'] = intval($row['qc_quantity']);
    }
    $items[] = $row;
}
$items_stmt->close();

echo json_encode([
    'success' => true,
    'plate_id' => $plate_info['plate_id'],
    'work_id' => $plate_info['work_id'],
    'branch' => $plate_info['branch'],
    'area' => $plate_info['area'],
    'verification_status' => $verification_data['verification_status'] ?? null,
    'plate_status' => $verification_data['plate_status'] ?? null, // null means not verified yet, QC can access
    'verified_at' => $verification_data['verified_at'] ?? null,
    'ready_for_load_at' => $verification_data['ready_for_load_at'] ?? null,
    'items' => $items
]);

$conn->close();
?>




















