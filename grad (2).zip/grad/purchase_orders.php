
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Orders</title>
    <style>
        .main-content {
            padding: 25px;
        }
        .page-header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-header h1 {
            color: var(--text-primary);
            font-size: 28px;
        }
        .btn-add {
            padding: 12px 24px;
            background: var(--light-blue);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: background 0.3s;
        }
        .btn-add:hover {
            background: var(--secondary);
        }
        .orders-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        thead {
            background: linear-gradient(135deg, var(--light-blue) 0%, var(--secondary) 100%);
            color: white;
        }
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }
        tbody tr:hover {
            background: #f8f9fa;
        }
        .btn-action {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            margin: 2px;
            transition: all 0.3s;
        }
        .btn-view {
            background: #17a2b8;
            color: white;
        }
        .btn-edit {
            background: #ffc107;
            color: #333;
        }
        .btn-print {
            background: #28a745;
            color: white;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-partial { background: #d1ecf1; color: #0c5460; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php 
        $current_page = 'purchase_orders.php';
        include 'navbar.php'; 
        ?>
        <div class="main-content">
            <div class="page-header">
                <div>
                    <h1>Purchase Orders</h1>
                    <p style="color: var(--text-muted);">Manage purchase orders from suppliers</p>
                </div>
                <button class="btn-add" onclick="openAddPOModal()">+ New Purchase Order</button>
            </div>

            <div id="orders-content">
                <div style="text-align: center; padding: 40px; color: #999;">Loading purchase orders...</div>
            </div>
        </div>
    </div>

    <!-- Add/Edit PO Modal -->
    <div id="po-modal" class="modal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
        <div class="modal-content" style="background-color: white; margin: 2% auto; padding: 30px; border-radius: 8px; width: 90%; max-width: 900px; max-height: 90vh; overflow-y: auto;">
            <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid #eee;">
                <h2 id="po-modal-title">New Purchase Order</h2>
                <span class="close" onclick="closePOModal()" style="color: #aaa; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
            </div>
            <form id="po-form">
                <input type="hidden" id="po-id">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                    <div class="form-group">
                        <label>PO Number *</label>
                        <input type="text" id="po-number" required>
                    </div>
                    <div class="form-group">
                        <label>Supplier *</label>
                        <select id="po-supplier" required style="width: 100%; padding: 10px; border: 2px solid #ddd; border-radius: 5px;">
                            <option value="">Select Supplier</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Order Date *</label>
                        <input type="date" id="po-order-date" required>
                    </div>
                    <div class="form-group">
                        <label>Expected Delivery Date</label>
                        <input type="date" id="po-delivery-date">
                    </div>
                    <div class="form-group">
                        <label>Tax Rate (%)</label>
                        <input type="number" id="po-tax-rate" step="0.01" min="0" max="100" value="0">
                    </div>
                </div>
                <div class="form-group">
                    <label>Notes</label>
                    <textarea id="po-notes" rows="2"></textarea>
                </div>
                
                <h3 style="margin: 20px 0 10px 0;">Items</h3>
                <div id="po-items-container">
                    <div class="po-item-row" style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr auto; gap: 10px; margin-bottom: 10px; align-items: end;">
                        <div>
                            <label>Item Barcode</label>
                            <input type="text" class="item-barcode" placeholder="Scan or enter barcode">
                        </div>
                        <div>
                            <label>Quantity</label>
                            <input type="number" class="item-quantity" min="1" value="1">
                        </div>
                        <div>
                            <label>Unit Price</label>
                            <input type="number" class="item-price" step="0.01" min="0" value="0">
                        </div>
                        <div>
                            <label>Total</label>
                            <input type="text" class="item-total" readonly style="background: #f5f5f5;">
                        </div>
                        <div>
                            <button type="button" class="btn-action btn-delete" onclick="removeItemRow(this)">Remove</button>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn-add" onclick="addItemRow()" style="margin-bottom: 20px;">+ Add Item</button>
                
                <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                        <strong>Subtotal:</strong>
                        <span id="po-subtotal">0.00</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                        <strong>Tax:</strong>
                        <span id="po-tax">0.00</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; font-size: 18px; font-weight: bold; padding-top: 10px; border-top: 2px solid #ddd;">
                        <strong>Total:</strong>
                        <span id="po-total">0.00</span>
                    </div>
                </div>

                <div class="form-actions" style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn-cancel" onclick="closePOModal()">Cancel</button>
                    <button type="submit" class="btn-save">Save Purchase Order</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function loadPurchaseOrders() {
            fetch('get_purchase_orders.php')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        displayPurchaseOrders(data.orders);
                    } else {
                        document.getElementById('orders-content').innerHTML = 
                            '<div style="text-align: center; padding: 40px; color: #999;">Error loading purchase orders</div>';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('orders-content').innerHTML = 
                        '<div style="text-align: center; padding: 40px; color: #dc3545;">Error loading purchase orders: ' + error.message + '</div>';
                });
        }

        function displayPurchaseOrders(orders) {
            const contentDiv = document.getElementById('orders-content');
            if (orders.length === 0) {
                contentDiv.innerHTML = '<div style="text-align: center; padding: 40px; color: #999;">No purchase orders found</div>';
                return;
            }

            let html = '<div class="orders-table"><table><thead><tr>';
            html += '<th>PO Number</th><th>Supplier</th><th>Order Date</th><th>Status</th><th>Total Amount</th><th>Actions</th>';
            html += '</tr></thead><tbody>';

            orders.forEach(order => {
                html += `<tr>
                    <td><strong>${order.po_number}</strong></td>
                    <td>${order.supplier_name}</td>
                    <td>${order.order_date}</td>
                    <td><span class="status-badge status-${order.status}">${order.status}</span></td>
                    <td>${parseFloat(order.total_amount).toFixed(2)}</td>
                    <td>
                        <button class="btn-action btn-view" onclick="viewPO(${order.id})">View</button>
                        <button class="btn-action btn-edit" onclick="editPO(${order.id})">Edit</button>
                        <button class="btn-action btn-print" onclick="printPO(${order.id})">🖨️ Print</button>
                    </td>
                </tr>`;
            });

            html += '</tbody></table></div>';
            contentDiv.innerHTML = html;
        }

        function openAddPOModal() {
            document.getElementById('po-modal-title').textContent = 'New Purchase Order';
            document.getElementById('po-form').reset();
            document.getElementById('po-id').value = '';
            document.getElementById('po-order-date').value = new Date().toISOString().split('T')[0];
            loadSuppliers();
            document.getElementById('po-modal').style.display = 'block';
        }

        function closePOModal() {
            document.getElementById('po-modal').style.display = 'none';
        }

        function loadSuppliers() {
            return fetch('get_suppliers.php')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        const select = document.getElementById('po-supplier');
                        select.innerHTML = '<option value="">Select Supplier</option>';
                        if (data.suppliers && data.suppliers.length > 0) {
                            data.suppliers.forEach(supplier => {
                                const option = document.createElement('option');
                                option.value = supplier.id;
                                option.textContent = supplier.supplier_name;
                                select.appendChild(option);
                            });
                        }
                    }
                    return data;
                })
                .catch(error => {
                    console.error('Error loading suppliers:', error);
                    return { success: false };
                });
        }

        function addItemRow() {
            const container = document.getElementById('po-items-container');
            const newRow = container.firstElementChild.cloneNode(true);
            newRow.querySelectorAll('input').forEach(input => input.value = '');
            newRow.querySelector('.item-quantity').value = '1';
            newRow.querySelector('.item-price').value = '0';
            newRow.querySelector('.item-total').value = '0.00';
            container.appendChild(newRow);
            attachItemListeners(newRow);
        }

        function removeItemRow(btn) {
            const container = document.getElementById('po-items-container');
            if (container.children.length > 1) {
                btn.closest('.po-item-row').remove();
                calculateTotals();
            }
        }

        function attachItemListeners(row) {
            const qtyInput = row.querySelector('.item-quantity');
            const priceInput = row.querySelector('.item-price');
            const totalInput = row.querySelector('.item-total');

            qtyInput.addEventListener('input', calculateItemTotal);
            priceInput.addEventListener('input', calculateItemTotal);

            function calculateItemTotal() {
                const qty = parseFloat(qtyInput.value) || 0;
                const price = parseFloat(priceInput.value) || 0;
                totalInput.value = (qty * price).toFixed(2);
                calculateTotals();
            }
        }

        function calculateTotals() {
            let subtotal = 0;
            document.querySelectorAll('.item-total').forEach(input => {
                subtotal += parseFloat(input.value) || 0;
            });

            const taxRate = parseFloat(document.getElementById('po-tax-rate').value) || 0;
            const tax = subtotal * (taxRate / 100);
            const total = subtotal + tax;

            document.getElementById('po-subtotal').textContent = subtotal.toFixed(2);
            document.getElementById('po-tax').textContent = tax.toFixed(2);
            document.getElementById('po-total').textContent = total.toFixed(2);
        }

        document.getElementById('po-tax-rate').addEventListener('input', calculateTotals);

        // Attach listeners to initial item row
        document.querySelectorAll('.po-item-row').forEach(row => attachItemListeners(row));

        document.getElementById('po-form').addEventListener('submit', function(e) {
            e.preventDefault();
            // Collect form data and items
            const formData = new FormData();
            formData.append('id', document.getElementById('po-id').value);
            formData.append('po_number', document.getElementById('po-number').value);
            formData.append('supplier_id', document.getElementById('po-supplier').value);
            formData.append('order_date', document.getElementById('po-order-date').value);
            formData.append('expected_delivery_date', document.getElementById('po-delivery-date').value);
            formData.append('tax_rate', document.getElementById('po-tax-rate').value);
            formData.append('notes', document.getElementById('po-notes').value);
            formData.append('subtotal', document.getElementById('po-subtotal').textContent);
            formData.append('tax_amount', document.getElementById('po-tax').textContent);
            formData.append('total_amount', document.getElementById('po-total').textContent);

            // Collect items
            const items = [];
            document.querySelectorAll('.po-item-row').forEach(row => {
                const barcode = row.querySelector('.item-barcode').value.trim();
                const qty = row.querySelector('.item-quantity').value;
                const price = row.querySelector('.item-price').value;
                if (barcode && qty && price) {
                    items.push({
                        item_barcode: barcode,
                        quantity_ordered: qty,
                        unit_price: price,
                        total_price: row.querySelector('.item-total').value
                    });
                }
            });

            formData.append('items', JSON.stringify(items));

            fetch('save_purchase_order.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    closePOModal();
                    loadPurchaseOrders();
                    alert('Purchase order saved successfully!');
                } else {
                    alert('Error: ' + (data.message || 'Failed to save purchase order'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error saving purchase order: ' + error.message);
            });
        });

        window.onclick = function(event) {
            const modal = document.getElementById('po-modal');
            if (event.target == modal) {
                closePOModal();
            }
        }

        function viewPO(id) {
            window.location.href = `view_po.php?id=${id}`;
        }
        function printPO(id) {
            window.open(`view_po.php?id=${id}&print=1`, '_blank');
        }

        function editPO(id) {
            // Load PO data and populate form
            fetch(`get_po_details.php?id=${id}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        const po = data.po;
                        document.getElementById('po-modal-title').textContent = 'Edit Purchase Order';
                        document.getElementById('po-id').value = po.id;
                        document.getElementById('po-number').value = po.po_number;
                        document.getElementById('po-supplier').value = po.supplier_id;
                        document.getElementById('po-order-date').value = po.order_date;
                        document.getElementById('po-delivery-date').value = po.expected_delivery_date || '';
                        document.getElementById('po-tax-rate').value = po.tax_rate || 0;
                        document.getElementById('po-notes').value = po.notes || '';
                        
                        // Load suppliers first, then populate items
                        loadSuppliers().then(() => {
                            // Set supplier after suppliers are loaded
                            setTimeout(() => {
                                document.getElementById('po-supplier').value = po.supplier_id;
                                
                                // Load items
                                const container = document.getElementById('po-items-container');
                                container.innerHTML = '';
                                if (data.items && data.items.length > 0) {
                                    data.items.forEach(item => {
                                        addItemRow();
                                        const rows = container.querySelectorAll('.po-item-row');
                                        const lastRow = rows[rows.length - 1];
                                        lastRow.querySelector('.item-barcode').value = item.item_barcode || '';
                                        lastRow.querySelector('.item-quantity').value = item.quantity_ordered || 1;
                                        lastRow.querySelector('.item-price').value = item.unit_price || 0;
                                        lastRow.querySelector('.item-total').value = parseFloat(item.total_price || 0).toFixed(2);
                                        attachItemListeners(lastRow);
                                    });
                                } else {
                                    // Add one empty row if no items
                                    addItemRow();
                                }
                                
                                calculateTotals();
                                document.getElementById('po-modal').style.display = 'block';
                            }, 100);
                        });
                    } else {
                        alert('Error loading purchase order: ' + (data.message || 'Unknown error'));
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error loading purchase order: ' + error.message);
                });
        }

        window.addEventListener('DOMContentLoaded', function() {
            loadPurchaseOrders();
        });
    </script>
</body>
</html>



