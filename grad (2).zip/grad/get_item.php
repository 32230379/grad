<?php
header('Content-Type: application/json');
include 'db_connect.php'; // تأكد أنو فيه الاتصال بقاعدة البيانات

if (!isset($_GET['barcode'])) {
    echo json_encode(["error" => "No barcode provided"]);
    exit();
}

$barcode = $_GET['barcode'];

$stmt = $conn->prepare("SELECT name, description FROM adddesc WHERE barcode = ?");
$stmt->bind_param("s", $barcode);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $item = $result->fetch_assoc();
    echo json_encode($item);
} else {
    echo json_encode(["name" => "Unknown Item", "description" => "No description found."]);
}

$stmt->close();
$conn->close();
?>
