<?php
session_start();
header('Content-Type: application/json');
include 'db_connect.php';

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'manager') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid supplier ID']);
    exit;
}

$supplier_id = intval($_GET['id']);

// Check if suppliers table exists
$check_table = $conn->query("SHOW TABLES LIKE 'suppliers'");
if ($check_table->num_rows == 0) {
    echo json_encode(['success' => false, 'message' => 'Suppliers table does not exist']);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM suppliers WHERE id = ?");
$stmt->bind_param("i", $supplier_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $supplier = $result->fetch_assoc();
    echo json_encode(['success' => true, 'supplier' => $supplier]);
} else {
    echo json_encode(['success' => false, 'message' => 'Supplier not found']);
}

$stmt->close();
$conn->close();
?>
