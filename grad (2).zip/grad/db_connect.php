<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "warehouse";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    // Don't output HTML - let the calling script handle the error
    $conn = null;
    if (function_exists('http_response_code')) {
        http_response_code(500);
    }
    // If output buffering is active, clean it
    if (ob_get_level() > 0) {
        ob_clean();
    }
    // Only output if headers haven't been sent and we're not in JSON mode
    if (!headers_sent() && (!isset($_SERVER['HTTP_ACCEPT']) || strpos($_SERVER['HTTP_ACCEPT'], 'application/json') === false)) {
        die("Connection failed: " . mysqli_connect_error());
    }
}
?>