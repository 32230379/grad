-- =====================================================
-- Complete Warehouse Management System Database
-- File: final.sql
-- Generated: 2025-11-09
-- Description: Complete database schema with all tables, functions, views, and sample data
-- Format: All locations use rack-shelf format (e.g., 1-0, 2-3)
-- =====================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- =====================================================
-- Database: `warehouse`
-- =====================================================

-- =====================================================
-- Drop All Tables, Views, and Functions (in correct order to avoid foreign key constraints)
-- =====================================================

-- Disable foreign key checks temporarily
SET FOREIGN_KEY_CHECKS = 0;

-- Drop tables that depend on other tables first
DROP TABLE IF EXISTS `picking_log`;
DROP TABLE IF EXISTS `picking_order_items`;
DROP TABLE IF EXISTS `picking_orders`;
DROP TABLE IF EXISTS `plate_verification_items`;
DROP TABLE IF EXISTS `plate_verifications`;
DROP TABLE IF EXISTS `lowering_orders`;
DROP TABLE IF EXISTS `stocktaking`;
DROP TABLE IF EXISTS `inventory`;
DROP TABLE IF EXISTS `putaway`;
DROP TABLE IF EXISTS `purchase_order_items`;
DROP TABLE IF EXISTS `purchase_orders`;
DROP TABLE IF EXISTS `supplier_items`;
DROP TABLE IF EXISTS `suppliers`;
DROP TABLE IF EXISTS `receiving`;
DROP TABLE IF EXISTS `locations`;  -- Depends on zones
DROP TABLE IF EXISTS `work_orders`;
DROP TABLE IF EXISTS `areas`;
DROP TABLE IF EXISTS `adddesc`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `zones`;  -- Drop zones after locations

-- Drop views
DROP VIEW IF EXISTS `plate_tracking`;

-- Drop functions
DROP FUNCTION IF EXISTS `get_full_location_code`;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================
-- Functions
-- =====================================================

DELIMITER $$

CREATE FUNCTION `get_full_location_code` (
    `zone_code` VARCHAR(10), 
    `location_code` VARCHAR(50)
) RETURNS VARCHAR(60) CHARSET utf8mb4 COLLATE utf8mb4_general_ci 
DETERMINISTIC READS SQL DATA 
BEGIN
    RETURN CONCAT(zone_code, '-', location_code);
END$$

DELIMITER ;

-- =====================================================
-- Table: `adddesc` - Item Descriptions
-- =====================================================

CREATE TABLE `adddesc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(50) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `barcode` (`barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `zones` - Warehouse Zones
-- =====================================================

CREATE TABLE `zones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_code` varchar(10) NOT NULL,
  `zone_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_zone_code` (`zone_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `locations` - Storage Locations
-- =====================================================

CREATE TABLE `locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_id` int(11) NOT NULL,
  `rack_number` int(11) NOT NULL COMMENT 'رقم الرف/العمود',
  `shelf_number` int(11) NOT NULL COMMENT 'المستوى من الأسفل (0, 1, 2...)',
  `location_code` varchar(50) NOT NULL COMMENT 'Format: rack-shelf (e.g., 1-0, 1-1)',
  `full_location_code` varchar(60) NOT NULL COMMENT 'Format: Zone-rack-shelf (e.g., A-1-0)',
  `area` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_location_code` (`full_location_code`),
  KEY `zone_id` (`zone_id`),
  KEY `location_code` (`location_code`),
  CONSTRAINT `fk_locations_zone` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `users` - System Users
-- =====================================================

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('manager','receiver','loader','picker','quantity controller','putaway','house keeper') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `receiving` - Received Items
-- =====================================================

CREATE TABLE `receiving` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plate_id` varchar(50) DEFAULT NULL,
  `po_id` int(11) DEFAULT NULL COMMENT 'Link to Purchase Order',
  `item_barcode` varchar(50) DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `receive_date` date DEFAULT curdate(),
  `received_by` varchar(100) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `status` enum('received','stored') DEFAULT 'received',
  PRIMARY KEY (`id`),
  KEY `idx_plate_id` (`plate_id`),
  KEY `idx_po_id` (`po_id`),
  KEY `idx_item_barcode` (`item_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `putaway` - Putaway Operations
-- =====================================================

CREATE TABLE `putaway` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plate_id` varchar(50) NOT NULL,
  `item_barcode` varchar(50) NOT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `from_location` varchar(50) DEFAULT NULL,
  `to_location` varchar(50) NOT NULL COMMENT 'Format: rack-shelf (e.g., 1-0, 2-3)',
  `zone` varchar(50) DEFAULT NULL,
  `moved_by` varchar(100) DEFAULT NULL,
  `moved_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_plate_id` (`plate_id`),
  KEY `idx_item_barcode` (`item_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `inventory` - Current Inventory
-- =====================================================

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plate_id` varchar(50) DEFAULT NULL,
  `item_barcode` varchar(50) NOT NULL,
  `location_code` varchar(50) NOT NULL COMMENT 'Format: rack-shelf (e.g., 1-0, 2-3)',
  `zone` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_quantity` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_plate_id` (`plate_id`),
  KEY `idx_item_barcode` (`item_barcode`),
  KEY `idx_location_code` (`location_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `picking_orders` - Picking Orders
-- =====================================================

CREATE TABLE `picking_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_id` varchar(100) NOT NULL,
  `branch` varchar(100) DEFAULT NULL,
  `area` varchar(100) DEFAULT NULL COMMENT 'Area where prepared plate is placed',
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `work_id` (`work_id`),
  KEY `idx_work_id` (`work_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `picking_order_items` - Picking Order Items
-- =====================================================

CREATE TABLE `picking_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_id` varchar(100) NOT NULL,
  `plate_id` varchar(50) DEFAULT NULL,
  `sequence` int(11) DEFAULT 0 COMMENT 'Order sequence - lower numbers picked first, skipped items get higher numbers',
  `item_barcode` varchar(100) NOT NULL,
  `location_code` varchar(100) DEFAULT NULL COMMENT 'Format: rack-shelf (e.g., 1-0, 2-3)',
  `quantity_required` int(11) NOT NULL DEFAULT 0,
  `quantity_picked` int(11) DEFAULT 0,
  `status` enum('pending','picked','skipped') DEFAULT 'pending',
  `target_lp` varchar(100) DEFAULT NULL,
  `picked_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_work_id` (`work_id`),
  KEY `idx_plate_id` (`plate_id`),
  KEY `idx_item_barcode` (`item_barcode`),
  KEY `idx_status` (`status`),
  KEY `idx_sequence` (`sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `picking_log` - Picking History
-- =====================================================

CREATE TABLE `picking_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_id` varchar(100) NOT NULL,
  `plate_id` varchar(50) DEFAULT NULL,
  `item_barcode` varchar(100) NOT NULL,
  `quantity_picked` int(11) NOT NULL,
  `location_code` varchar(100) DEFAULT NULL COMMENT 'Format: rack-shelf (e.g., 1-0, 2-3)',
  `target_lp` varchar(100) DEFAULT NULL,
  `picked_at` datetime DEFAULT current_timestamp(),
  `picked_by` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_work_id` (`work_id`),
  KEY `idx_plate_id` (`plate_id`),
  KEY `idx_item_barcode` (`item_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `stocktaking` - Stock Count Results
-- =====================================================

CREATE TABLE `stocktaking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plate_id` varchar(50) DEFAULT NULL,
  `item_barcode` varchar(50) NOT NULL,
  `location_code` varchar(100) NOT NULL COMMENT 'Format: rack-shelf (e.g., 1-0, 2-3)',
  `system_qty` int(11) NOT NULL,
  `counted_qty` int(11) NOT NULL,
  `difference` int(11) NOT NULL,
  `counted_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_plate_id` (`plate_id`),
  KEY `idx_item_barcode` (`item_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `work_orders` - Legacy Work Orders
-- =====================================================

CREATE TABLE `work_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_id` varchar(50) NOT NULL,
  `item_barcode` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` enum('pending','picked') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `areas` - Storage Areas for Prepared Plates
-- =====================================================

CREATE TABLE `areas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `area_code` varchar(100) NOT NULL COMMENT 'Area barcode (e.g., AREA1, AREA2)',
  `area_name` varchar(100) NOT NULL COMMENT 'Area name (e.g., Area 1, Area 2)',
  `branch` varchar(100) NOT NULL COMMENT 'Branch name (e.g., Hasbaya Branch)',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_code` (`area_code`),
  KEY `idx_branch` (`branch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `plate_verifications` - Plate Verification by QC
-- =====================================================

CREATE TABLE `plate_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plate_id` varchar(50) NOT NULL,
  `work_id` varchar(100) DEFAULT NULL,
  `branch` varchar(100) DEFAULT NULL,
  `verified_by` varchar(100) DEFAULT NULL,
  `verification_status` enum('complete','variance') DEFAULT 'complete',
  `plate_status` enum('verified','ready_to_load','loaded') DEFAULT 'verified',
  `verified_at` datetime DEFAULT current_timestamp(),
  `ready_for_load_at` datetime DEFAULT NULL,
  `loaded_by` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_plate_id` (`plate_id`),
  KEY `idx_plate_id` (`plate_id`),
  KEY `idx_work_id` (`work_id`),
  KEY `idx_plate_status` (`plate_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `plate_verification_items` - QC Quantities for Each Item
-- =====================================================

CREATE TABLE `plate_verification_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plate_id` varchar(50) NOT NULL,
  `item_barcode` varchar(100) NOT NULL,
  `qc_quantity` int(11) NOT NULL,
  `verified_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_plate_item` (`plate_id`, `item_barcode`),
  KEY `idx_plate_id` (`plate_id`),
  KEY `idx_item_barcode` (`item_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `lowering_orders` - Lowering Orders (High Shelf to Low Shelf)
-- =====================================================

CREATE TABLE `lowering_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_barcode` varchar(100) NOT NULL,
  `from_location_code` varchar(100) NOT NULL COMMENT 'Format: rack-shelf (e.g., 1-3, 2-4)',
  `from_zone` varchar(10) DEFAULT NULL,
  `from_full_location` varchar(60) DEFAULT NULL COMMENT 'Format: Zone-rack-shelf (e.g., A-1-3)',
  `to_location_code` varchar(100) DEFAULT NULL COMMENT 'Target location (rack-shelf format) - User will choose',
  `to_zone` varchar(10) DEFAULT NULL,
  `quantity_at_source` int(11) NOT NULL COMMENT 'Quantity available at source location (all will be moved)',
  `quantity_moved` int(11) DEFAULT 0,
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  `priority` int(11) DEFAULT 5 COMMENT '1=Highest, 10=Lowest',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `completed_zones` text DEFAULT NULL COMMENT 'Comma-separated list of completed zones (e.g., A,B,C)',
  `assigned_user` varchar(100) DEFAULT NULL COMMENT 'Username assigned to this zone',
  `assigned_zone` varchar(10) DEFAULT NULL COMMENT 'Zone assigned to user',
  `lowered_by` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_item_barcode` (`item_barcode`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`),
  KEY `idx_assigned_user` (`assigned_user`),
  KEY `idx_assigned_zone` (`assigned_zone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `suppliers` - Suppliers Management
-- =====================================================

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `purchase_orders` - Purchase Orders from Suppliers
-- =====================================================

CREATE TABLE `purchase_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_number` varchar(100) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `tax_rate` decimal(5,2) DEFAULT 0.00,
  `tax_amount` decimal(10,2) DEFAULT 0.00,
  `subtotal` decimal(10,2) DEFAULT 0.00,
  `total_amount` decimal(10,2) DEFAULT 0.00,
  `status` enum('pending','partial','completed','cancelled') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_number` (`po_number`),
  KEY `supplier_id` (`supplier_id`),
  KEY `status` (`status`),
  CONSTRAINT `fk_po_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `purchase_order_items` - Items in Purchase Orders
-- =====================================================

CREATE TABLE `purchase_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_id` int(11) NOT NULL,
  `item_barcode` varchar(100) NOT NULL,
  `quantity_ordered` int(11) NOT NULL DEFAULT 0,
  `quantity_received` int(11) DEFAULT 0,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `po_id` (`po_id`),
  KEY `item_barcode` (`item_barcode`),
  CONSTRAINT `fk_poi_po` FOREIGN KEY (`po_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Table: `supplier_items` - Supplier-Item Relationships
-- =====================================================

CREATE TABLE `supplier_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `item_barcode` varchar(100) NOT NULL,
  `last_purchase_price` decimal(10,2) DEFAULT NULL,
  `last_purchase_date` date DEFAULT NULL,
  `is_primary` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_item` (`supplier_id`, `item_barcode`),
  KEY `supplier_id` (`supplier_id`),
  KEY `item_barcode` (`item_barcode`),
  CONSTRAINT `fk_si_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- Clear All Existing Data (Delete Old Data)
-- =====================================================

-- Delete data in reverse order of dependencies
DELETE FROM `picking_log`;
DELETE FROM `picking_order_items`;
DELETE FROM `picking_orders`;
DELETE FROM `plate_verification_items`;
DELETE FROM `plate_verifications`;
DELETE FROM `lowering_orders`;
DELETE FROM `stocktaking`;
DELETE FROM `inventory`;
DELETE FROM `putaway`;
DELETE FROM `purchase_order_items`;
DELETE FROM `purchase_orders`;
DELETE FROM `supplier_items`;
DELETE FROM `suppliers`;
DELETE FROM `receiving`;
DELETE FROM `locations`;
DELETE FROM `work_orders`;
DELETE FROM `areas`;
DELETE FROM `adddesc`;
DELETE FROM `users`;
DELETE FROM `zones`;

-- Reset AUTO_INCREMENT counters
ALTER TABLE `picking_log` AUTO_INCREMENT = 1;
ALTER TABLE `picking_order_items` AUTO_INCREMENT = 1;
ALTER TABLE `picking_orders` AUTO_INCREMENT = 1;
ALTER TABLE `plate_verification_items` AUTO_INCREMENT = 1;
ALTER TABLE `plate_verifications` AUTO_INCREMENT = 1;
ALTER TABLE `lowering_orders` AUTO_INCREMENT = 1;
ALTER TABLE `stocktaking` AUTO_INCREMENT = 1;
ALTER TABLE `inventory` AUTO_INCREMENT = 1;
ALTER TABLE `putaway` AUTO_INCREMENT = 1;
ALTER TABLE `purchase_order_items` AUTO_INCREMENT = 1;
ALTER TABLE `purchase_orders` AUTO_INCREMENT = 1;
ALTER TABLE `supplier_items` AUTO_INCREMENT = 1;
ALTER TABLE `suppliers` AUTO_INCREMENT = 1;
ALTER TABLE `receiving` AUTO_INCREMENT = 1;
ALTER TABLE `locations` AUTO_INCREMENT = 1;
ALTER TABLE `work_orders` AUTO_INCREMENT = 1;
ALTER TABLE `areas` AUTO_INCREMENT = 1;
ALTER TABLE `adddesc` AUTO_INCREMENT = 1;
ALTER TABLE `users` AUTO_INCREMENT = 1;
ALTER TABLE `zones` AUTO_INCREMENT = 1;

-- =====================================================
-- Insert Sample Data: Zones
-- =====================================================

INSERT INTO `zones` (`zone_code`, `zone_name`, `description`) VALUES
('A', 'Zone A', 'Main Storage Area - Fast Moving Items'),
('B', 'Zone B', 'Secondary Storage - Medium Priority'),
('C', 'Zone C', 'Bulk Storage - Large Items'),
('D', 'Zone D', 'Cold Storage - Perishable Items');

-- =====================================================
-- Insert Sample Data: Locations (rack-shelf format)
-- =====================================================

-- Zone A: Racks 1-5, Shelves 0-3 (20 locations)
INSERT INTO `locations` (`zone_id`, `rack_number`, `shelf_number`, `location_code`, `full_location_code`, `area`, `is_active`) 
SELECT 
    (SELECT id FROM zones WHERE zone_code = 'A'),
    rack,
    shelf,
    CONCAT(rack, '-', shelf) as location_code,
    CONCAT('A-', rack, '-', shelf) as full_location_code,
    'Zone A Storage',
    1
FROM (
    SELECT 1 as rack, 0 as shelf UNION ALL SELECT 1, 1 UNION ALL SELECT 1, 2 UNION ALL SELECT 1, 3 UNION ALL
    SELECT 2, 0 UNION ALL SELECT 2, 1 UNION ALL SELECT 2, 2 UNION ALL SELECT 2, 3 UNION ALL
    SELECT 3, 0 UNION ALL SELECT 3, 1 UNION ALL SELECT 3, 2 UNION ALL SELECT 3, 3 UNION ALL
    SELECT 4, 0 UNION ALL SELECT 4, 1 UNION ALL SELECT 4, 2 UNION ALL SELECT 4, 3 UNION ALL
    SELECT 5, 0 UNION ALL SELECT 5, 1 UNION ALL SELECT 5, 2 UNION ALL SELECT 5, 3
) as locations_data;

-- Zone B: Racks 1-3, Shelves 0-2 (9 locations)
INSERT INTO `locations` (`zone_id`, `rack_number`, `shelf_number`, `location_code`, `full_location_code`, `area`, `is_active`) 
SELECT 
    (SELECT id FROM zones WHERE zone_code = 'B'),
    rack,
    shelf,
    CONCAT(rack, '-', shelf) as location_code,
    CONCAT('B-', rack, '-', shelf) as full_location_code,
    'Zone B Storage',
    1
FROM (
    SELECT 1 as rack, 0 as shelf UNION ALL SELECT 1, 1 UNION ALL SELECT 1, 2 UNION ALL
    SELECT 2, 0 UNION ALL SELECT 2, 1 UNION ALL SELECT 2, 2 UNION ALL
    SELECT 3, 0 UNION ALL SELECT 3, 1 UNION ALL SELECT 3, 2
) as locations_data;

-- Zone C: Racks 1-2, Shelves 0-1 (4 locations)
INSERT INTO `locations` (`zone_id`, `rack_number`, `shelf_number`, `location_code`, `full_location_code`, `area`, `is_active`) 
SELECT 
    (SELECT id FROM zones WHERE zone_code = 'C'),
    rack,
    shelf,
    CONCAT(rack, '-', shelf) as location_code,
    CONCAT('C-', rack, '-', shelf) as full_location_code,
    'Zone C Bulk Storage',
    1
FROM (
    SELECT 1 as rack, 0 as shelf UNION ALL SELECT 1, 1 UNION ALL
    SELECT 2, 0 UNION ALL SELECT 2, 1
) as locations_data;

-- Zone D: Racks 1-2, Shelves 0-2 (6 locations)
INSERT INTO `locations` (`zone_id`, `rack_number`, `shelf_number`, `location_code`, `full_location_code`, `area`, `is_active`) 
SELECT 
    (SELECT id FROM zones WHERE zone_code = 'D'),
    rack,
    shelf,
    CONCAT(rack, '-', shelf) as location_code,
    CONCAT('D-', rack, '-', shelf) as full_location_code,
    'Zone D Cold Storage',
    1
FROM (
    SELECT 1 as rack, 0 as shelf UNION ALL SELECT 1, 1 UNION ALL SELECT 1, 2 UNION ALL
    SELECT 2, 0 UNION ALL SELECT 2, 1 UNION ALL SELECT 2, 2
) as locations_data;

-- =====================================================
-- Insert Sample Data: Users (All Roles)
-- =====================================================

INSERT INTO `users` (`name`, `password`, `role`) VALUES
-- Manager (password: admin123)
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'manager'),
('manager1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'manager'),

-- Receiver (password: receiver123)
('receiver1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'receiver'),
('receiver2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'receiver'),

-- Picker (password: picker123)
('picker1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'picker'),
('picker2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'picker'),

-- Putaway (password: putaway123)
('putaway1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'putaway'),
('putaway2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'putaway'),

-- Loader (password: loader123)
('loader1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'loader'),
('loader2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'loader'),

-- Quantity Controller (password: qc123)
('qc1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'quantity controller'),
('qc2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'quantity controller'),

-- House Keeper (password: housekeeper123)
('housekeeper1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'house keeper'),
('housekeeper2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'house keeper');

-- =====================================================
-- Insert Sample Data: Item Descriptions (adddesc)
-- =====================================================
-- Food Items (Food Warehouse)
INSERT INTO `adddesc` (`barcode`, `name`, `description`) VALUES
-- Rice & Grains
('RICE001', 'Basmati Rice 5kg', 'Premium Basmati Rice - 5kg Bag'),
('RICE002', 'White Rice 10kg', 'Long Grain White Rice - 10kg Bag'),
('RICE003', 'Brown Rice 2kg', 'Organic Brown Rice - 2kg Bag'),
('SUGAR001', 'White Sugar 1kg', 'Granulated White Sugar - 1kg Pack'),
('SUGAR002', 'Brown Sugar 500g', 'Brown Sugar - 500g Pack'),
('CHICKPEA001', 'Chickpeas 1kg', 'Dried Chickpeas - 1kg Pack'),
('CHICKPEA002', 'Canned Chickpeas 400g', 'Canned Chickpeas in Water - 400g Can'),
('LENTIL001', 'Red Lentils 1kg', 'Red Split Lentils - 1kg Pack'),
('LENTIL002', 'Green Lentils 500g', 'Whole Green Lentils - 500g Pack'),

-- Spices & Condiments
('SPICE001', 'Black Pepper 100g', 'Ground Black Pepper - 100g'),
('SPICE002', 'Turmeric Powder 200g', 'Turmeric Powder - 200g'),
('SPICE003', 'Cumin Seeds 250g', 'Whole Cumin Seeds - 250g'),
('OIL001', 'Olive Oil 1L', 'Extra Virgin Olive Oil - 1 Liter'),
('OIL002', 'Sunflower Oil 2L', 'Sunflower Cooking Oil - 2 Liters'),

-- Canned Goods
('CAN001', 'Tomato Paste 200g', 'Tomato Paste - 200g Can'),
('CAN002', 'Tuna in Oil 185g', 'Tuna in Olive Oil - 185g Can'),
('CAN003', 'Corn Kernels 340g', 'Sweet Corn Kernels - 340g Can'),

-- Beverages
('BEV001', 'Mineral Water 500ml', 'Natural Mineral Water - 500ml Bottle'),
('BEV002', 'Orange Juice 1L', 'Fresh Orange Juice - 1 Liter'),
('BEV003', 'Green Tea 100g', 'Premium Green Tea Leaves - 100g'),

-- Non-Food Items (Non-Food Warehouse)
-- Medicines & Health
('MED001', 'Paracetamol 500mg', 'Paracetamol Tablets 500mg - Pack of 20'),
('MED002', 'Ibuprofen 400mg', 'Ibuprofen Tablets 400mg - Pack of 12'),
('MED003', 'Vitamin C 1000mg', 'Vitamin C Tablets 1000mg - Pack of 30'),
('MED004', 'Bandages 5cm', 'Medical Bandages 5cm x 5m - Pack of 5'),
('MED005', 'Antiseptic Solution 100ml', 'Antiseptic Wound Solution - 100ml'),

-- Cleaning Products
('CLEAN001', 'Laundry Detergent 2kg', 'Liquid Laundry Detergent - 2kg Bottle'),
('CLEAN002', 'Dish Soap 750ml', 'Lemon Dishwashing Liquid - 750ml'),
('CLEAN003', 'Fabric Softener 1L', 'Fabric Softener - 1 Liter'),
('CLEAN004', 'Bleach 1L', 'Chlorine Bleach - 1 Liter'),
('CLEAN005', 'All-Purpose Cleaner 500ml', 'Multi-Surface Cleaner - 500ml'),

-- Personal Care
('CARE001', 'Shampoo 400ml', 'Moisturizing Shampoo - 400ml'),
('CARE002', 'Body Soap Bar', 'Antibacterial Body Soap - Pack of 4'),
('CARE003', 'Toothpaste 100g', 'Fluoride Toothpaste - 100g Tube'),
('CARE004', 'Toilet Paper 4 Pack', '2-Ply Toilet Paper - 4 Rolls Pack'),

-- Office Supplies
('OFF001', 'A4 Paper 500 Sheets', 'White A4 Copy Paper - 500 Sheets'),
('OFF002', 'Blue Pens Pack 12', 'Blue Ballpoint Pens - Pack of 12'),
('OFF003', 'Stapler with Staples', 'Heavy Duty Stapler with 1000 Staples'),
('OFF004', 'File Folders A4', 'A4 File Folders - Pack of 50'),
('OFF005', 'Sticky Notes Yellow', 'Yellow Sticky Notes 3x3 - Pack of 10');

-- =====================================================
-- Insert Sample Data: Suppliers
-- =====================================================

INSERT INTO `suppliers` (`supplier_name`, `contact_person`, `email`, `phone`, `address`, `status`) VALUES
('ABC Food Supplies', 'John Smith', 'john@abcfood.com', '+961-1-1234567', 'Beirut, Lebanon', 'active'),
('MediCare Pharmaceuticals', 'Sarah Johnson', 'sarah@medicare.com', '+961-1-2345678', 'Beirut, Lebanon', 'active'),
('CleanPro Distributors', 'Mike Wilson', 'mike@cleanpro.com', '+961-1-3456789', 'Tripoli, Lebanon', 'active'),
('OfficeMax Lebanon', 'Lisa Brown', 'lisa@officemax.com', '+961-1-4567890', 'Beirut, Lebanon', 'active'),
('Global Beverages Co', 'David Lee', 'david@globalbev.com', '+961-1-5678901', 'Sidon, Lebanon', 'active');

-- =====================================================
-- Insert Sample Data: Purchase Orders
-- =====================================================

SET @po_date_1 = DATE_SUB(CURDATE(), INTERVAL 5 DAY);
SET @po_date_2 = DATE_SUB(CURDATE(), INTERVAL 3 DAY);
SET @po_date_3 = DATE_SUB(CURDATE(), INTERVAL 2 DAY);
SET @po_date_4 = CURDATE();

INSERT INTO `purchase_orders` (`po_number`, `supplier_id`, `order_date`, `expected_delivery_date`, `tax_rate`, `tax_amount`, `subtotal`, `total_amount`, `status`, `created_by`) VALUES
('PO-2024-001', 1, @po_date_1, DATE_ADD(@po_date_1, INTERVAL 7 DAY), 11.00, 110.00, 1000.00, 1110.00, 'completed', 'admin'),
('PO-2024-002', 2, @po_date_2, DATE_ADD(@po_date_2, INTERVAL 5 DAY), 11.00, 55.00, 500.00, 555.00, 'partial', 'admin'),
('PO-2024-003', 3, @po_date_3, DATE_ADD(@po_date_3, INTERVAL 7 DAY), 11.00, 88.00, 800.00, 888.00, 'pending', 'admin'),
('PO-2024-004', 1, @po_date_4, DATE_ADD(@po_date_4, INTERVAL 10 DAY), 11.00, 165.00, 1500.00, 1665.00, 'pending', 'admin');

-- =====================================================
-- Insert Sample Data: Purchase Order Items
-- =====================================================

INSERT INTO `purchase_order_items` (`po_id`, `item_barcode`, `quantity_ordered`, `quantity_received`, `unit_price`, `total_price`) VALUES
-- PO-2024-001 (Completed)
(1, 'RICE001', 50, 50, 10.00, 500.00),
(1, 'SUGAR001', 100, 100, 5.00, 500.00),

-- PO-2024-002 (Partial - some items received)
(2, 'MED001', 200, 200, 2.00, 400.00),
(2, 'MED002', 150, 100, 1.00, 100.00), -- Only 100 received out of 150

-- PO-2024-003 (Pending)
(3, 'CLEAN001', 100, 0, 8.00, 800.00),

-- PO-2024-004 (Pending)
(4, 'RICE002', 30, 0, 12.00, 360.00),
(4, 'CHICKPEA001', 60, 0, 6.00, 360.00),
(4, 'OIL001', 50, 0, 15.00, 750.00);

-- =====================================================
-- Insert Sample Data: Supplier Items
-- =====================================================

INSERT INTO `supplier_items` (`supplier_id`, `item_barcode`, `last_purchase_price`, `last_purchase_date`, `is_primary`) VALUES
(1, 'RICE001', 10.00, @po_date_1, 1),
(1, 'SUGAR001', 5.00, @po_date_1, 1),
(1, 'RICE002', 12.00, @po_date_4, 1),
(1, 'CHICKPEA001', 6.00, @po_date_4, 1),
(1, 'OIL001', 15.00, @po_date_4, 1),
(2, 'MED001', 2.00, @po_date_2, 1),
(2, 'MED002', 1.00, @po_date_2, 1),
(3, 'CLEAN001', 8.00, @po_date_3, 1);

-- =====================================================
-- Insert Sample Data: Inventory (rack-shelf format)
-- =====================================================
-- Zone A - Fast Moving Food Items (Bottom Shelves: 0, 1)
INSERT INTO `inventory` (`item_barcode`, `location_code`, `zone`, `quantity`, `plate_id`) VALUES
-- Rice & Grains (Bottom Shelf - shelf_number = 0)
('RICE001', '1-0', 'A', 50, 'PLATE-A001'),
('RICE002', '1-0', 'A', 30, 'PLATE-A002'),
('SUGAR001', '2-0', 'A', 100, 'PLATE-A003'),
('SUGAR002', '2-0', 'A', 80, 'PLATE-A004'),
('CHICKPEA001', '3-0', 'A', 60, 'PLATE-A005'),
('LENTIL001', '3-0', 'A', 45, 'PLATE-A006'),

-- Food Items (Second Shelf - shelf_number = 1)
('RICE003', '1-1', 'A', 25, 'PLATE-A007'),
('CHICKPEA002', '2-1', 'A', 40, 'PLATE-A008'),
('LENTIL002', '3-1', 'A', 35, 'PLATE-A009'),
('OIL001', '4-1', 'A', 50, 'PLATE-A010'),
('OIL002', '4-1', 'A', 40, 'PLATE-A011'),

-- Food Items (Third Shelf - shelf_number = 2)
('SPICE001', '1-2', 'A', 75, 'PLATE-A012'),
('SPICE002', '2-2', 'A', 60, 'PLATE-A013'),
('SPICE003', '3-2', 'A', 55, 'PLATE-A014'),
('CAN001', '4-2', 'A', 80, 'PLATE-A015'),
('CAN002', '5-2', 'A', 70, 'PLATE-A016'),

-- Food Items (High Shelf - shelf_number = 3) - Will need lowering
('CAN003', '1-3', 'A', 50, 'PLATE-A017'),
('BEV001', '2-3', 'A', 120, 'PLATE-A018'),
('BEV002', '3-3', 'A', 60, 'PLATE-A019'),
('BEV003', '4-3', 'A', 40, 'PLATE-A020'),

-- Zone B - Non-Food Items (Medicines & Health)
('MED001', '1-0', 'B', 200, 'PLATE-B001'),
('MED002', '1-0', 'B', 150, 'PLATE-B002'),
('MED003', '2-0', 'B', 100, 'PLATE-B003'),
('MED004', '2-1', 'B', 80, 'PLATE-B004'),
('MED005', '3-0', 'B', 90, 'PLATE-B005'),

-- Zone B - High Shelves (Medicines - will need lowering)
('MED001', '1-3', 'B', 50, 'PLATE-B006'),
('MED002', '2-3', 'B', 40, 'PLATE-B007'),

-- Zone C - Cleaning Products (Bulk Storage)
('CLEAN001', '1-0', 'C', 100, 'PLATE-C001'),
('CLEAN002', '1-0', 'C', 120, 'PLATE-C002'),
('CLEAN003', '1-1', 'C', 80, 'PLATE-C003'),
('CLEAN004', '2-0', 'C', 90, 'PLATE-C004'),
('CLEAN005', '2-1', 'C', 70, 'PLATE-C005'),

-- Zone C - High Shelves (Cleaning - will need lowering)
('CLEAN001', '1-2', 'C', 30, 'PLATE-C006'),
('CLEAN002', '2-2', 'C', 25, 'PLATE-C007'),

-- Zone D - Personal Care & Office (Cold Storage Area)
('CARE001', '1-0', 'D', 150, 'PLATE-D001'),
('CARE002', '1-1', 'D', 100, 'PLATE-D002'),
('CARE003', '2-0', 'D', 200, 'PLATE-D003'),
('CARE004', '2-1', 'D', 80, 'PLATE-D004'),
('OFF001', '1-2', 'D', 50, 'PLATE-D005'),
('OFF002', '2-2', 'D', 60, 'PLATE-D006'),
('OFF003', '1-3', 'D', 40, 'PLATE-D007'),
('OFF004', '2-3', 'D', 30, 'PLATE-D008'),
('OFF005', '1-3', 'D', 45, 'PLATE-D009');

-- =====================================================
-- Insert Sample Data: Receiving Records
-- =====================================================
-- Set date variables
SET @today = CURDATE();
SET @yesterday_rec = DATE_SUB(CURDATE(), INTERVAL 1 DAY);
SET @two_days_ago_rec = DATE_SUB(CURDATE(), INTERVAL 2 DAY);
SET @three_days_ago_rec = DATE_SUB(CURDATE(), INTERVAL 3 DAY);

INSERT INTO `receiving` (`plate_id`, `po_id`, `item_barcode`, `item_name`, `description`, `quantity`, `expiry_date`, `receive_date`, `received_by`, `status`) VALUES
-- Food Items Receiving (Today) - Linked to PO-2024-001 (Completed)
('PLATE-R001', 1, 'RICE001', 'Basmati Rice 5kg', 'Premium Basmati Rice - 5kg Bag', 50, '2026-12-31', @po_date_1, 'receiver1', 'stored'),
('PLATE-R001', 1, 'SUGAR001', 'White Sugar 1kg', 'Granulated White Sugar - 1kg Pack', 100, '2027-06-30', @po_date_1, 'receiver1', 'stored'),

-- Food Items Receiving (Yesterday) - Not linked to PO
('PLATE-R002', NULL, 'RICE002', 'White Rice 10kg', 'Long Grain White Rice - 10kg Bag', 30, '2026-12-31', @yesterday_rec, 'receiver2', 'received'),
('PLATE-R002', NULL, 'CHICKPEA001', 'Chickpeas 1kg', 'Dried Chickpeas - 1kg Pack', 60, '2026-12-31', @yesterday_rec, 'receiver2', 'received'),

-- Food Items Receiving (Yesterday) - Not linked to PO
('PLATE-R003', NULL, 'OIL001', 'Olive Oil 1L', 'Extra Virgin Olive Oil - 1 Liter', 50, '2027-12-31', @yesterday_rec, 'receiver1', 'received'),
('PLATE-R003', NULL, 'SPICE001', 'Black Pepper 100g', 'Ground Black Pepper - 100g', 75, '2027-12-31', @yesterday_rec, 'receiver1', 'received'),
('PLATE-R004', NULL, 'CAN001', 'Tomato Paste 200g', 'Tomato Paste - 200g Can', 80, '2027-06-30', @yesterday_rec, 'receiver2', 'received'),
('PLATE-R004', NULL, 'BEV001', 'Mineral Water 500ml', 'Natural Mineral Water - 500ml Bottle', 120, '2026-12-31', @yesterday_rec, 'receiver2', 'received'),

-- Non-Food Items Receiving (Medicines) - Linked to PO-2024-002 (Partial)
('PLATE-R005', 2, 'MED001', 'Paracetamol 500mg', 'Paracetamol Tablets 500mg - Pack of 20', 200, '2027-12-31', @po_date_2, 'receiver1', 'stored'),
('PLATE-R005', 2, 'MED002', 'Ibuprofen 400mg', 'Ibuprofen Tablets 400mg - Pack of 12', 100, '2027-12-31', @po_date_2, 'receiver1', 'stored'), -- Partial: 100 out of 150
('PLATE-R006', NULL, 'MED003', 'Vitamin C 1000mg', 'Vitamin C Tablets 1000mg - Pack of 30', 100, '2027-12-31', @yesterday_rec, 'receiver2', 'received'),

-- Non-Food Items Receiving (Cleaning Products) - Linked to PO-2024-003 (Pending)
('PLATE-R007', 3, 'CLEAN001', 'Laundry Detergent 2kg', 'Liquid Laundry Detergent - 2kg Bottle', 100, '2028-12-31', @po_date_3, 'receiver1', 'received'),
('PLATE-R007', NULL, 'CLEAN002', 'Dish Soap 750ml', 'Lemon Dishwashing Liquid - 750ml', 120, '2028-12-31', @yesterday_rec, 'receiver1', 'received'),
('PLATE-R008', NULL, 'CLEAN003', 'Fabric Softener 1L', 'Fabric Softener - 1 Liter', 80, '2028-12-31', @yesterday_rec, 'receiver2', 'received'),

-- Personal Care & Office Supplies - Not linked to PO
('PLATE-R009', NULL, 'CARE001', 'Shampoo 400ml', 'Moisturizing Shampoo - 400ml', 150, '2027-12-31', @today, 'receiver1', 'received'),
('PLATE-R009', NULL, 'CARE003', 'Toothpaste 100g', 'Fluoride Toothpaste - 100g Tube', 200, '2027-12-31', @today, 'receiver1', 'received'),
('PLATE-R010', NULL, 'OFF001', 'A4 Paper 500 Sheets', 'White A4 Copy Paper - 500 Sheets', 50, NULL, @yesterday_rec, 'receiver2', 'received'),
('PLATE-R010', NULL, 'OFF002', 'Blue Pens Pack 12', 'Blue Ballpoint Pens - Pack of 12', 60, NULL, @yesterday_rec, 'receiver2', 'received');

-- =====================================================
-- Insert Sample Data: Putaway Records
-- =====================================================

-- Set date variables for use in INSERT statements
SET @yesterday = DATE_SUB(NOW(), INTERVAL 1 DAY);
SET @two_days_ago = DATE_SUB(NOW(), INTERVAL 2 DAY);
SET @three_days_ago = DATE_SUB(NOW(), INTERVAL 3 DAY);

INSERT INTO `putaway` (`plate_id`, `item_barcode`, `item_name`, `quantity`, `from_location`, `to_location`, `zone`, `moved_by`, `moved_at`) VALUES
-- Food Items Putaway
('PLATE-R001', 'RICE001', 'Basmati Rice 5kg', 50, 'Receiving Area', '1-0', 'A', 'putaway1', @two_days_ago),
('PLATE-R001', 'RICE002', 'White Rice 10kg', 30, 'Receiving Area', '1-0', 'A', 'putaway1', @two_days_ago),
('PLATE-R002', 'SUGAR001', 'White Sugar 1kg', 100, 'Receiving Area', '2-0', 'A', 'putaway2', @yesterday),
('PLATE-R002', 'CHICKPEA001', 'Chickpeas 1kg', 60, 'Receiving Area', '3-0', 'A', 'putaway2', @yesterday),
('PLATE-R003', 'OIL001', 'Olive Oil 1L', 50, 'Receiving Area', '4-1', 'A', 'putaway1', @three_days_ago),
('PLATE-R003', 'SPICE001', 'Black Pepper 100g', 75, 'Receiving Area', '1-2', 'A', 'putaway1', @three_days_ago),
('PLATE-R004', 'CAN001', 'Tomato Paste 200g', 80, 'Receiving Area', '4-2', 'A', 'putaway2', @two_days_ago),
('PLATE-R004', 'BEV001', 'Mineral Water 500ml', 120, 'Receiving Area', '2-3', 'A', 'putaway2', @two_days_ago),

-- Non-Food Items Putaway (Medicines)
('PLATE-R005', 'MED001', 'Paracetamol 500mg', 200, 'Receiving Area', '1-0', 'B', 'putaway1', @yesterday),
('PLATE-R005', 'MED002', 'Ibuprofen 400mg', 150, 'Receiving Area', '1-0', 'B', 'putaway1', @yesterday),
('PLATE-R006', 'MED003', 'Vitamin C 1000mg', 100, 'Receiving Area', '2-0', 'B', 'putaway2', @two_days_ago),

-- Non-Food Items Putaway (Cleaning)
('PLATE-R007', 'CLEAN001', 'Laundry Detergent 2kg', 100, 'Receiving Area', '1-0', 'C', 'putaway1', @yesterday),
('PLATE-R007', 'CLEAN002', 'Dish Soap 750ml', 120, 'Receiving Area', '1-0', 'C', 'putaway1', @yesterday),
('PLATE-R008', 'CLEAN003', 'Fabric Softener 1L', 80, 'Receiving Area', '1-1', 'C', 'putaway2', @two_days_ago),

-- Personal Care & Office Putaway
('PLATE-R009', 'CARE001', 'Shampoo 400ml', 150, 'Receiving Area', '1-0', 'D', 'putaway1', @yesterday),
('PLATE-R009', 'CARE003', 'Toothpaste 100g', 200, 'Receiving Area', '2-0', 'D', 'putaway1', @yesterday),
('PLATE-R010', 'OFF001', 'A4 Paper 500 Sheets', 50, 'Receiving Area', '1-2', 'D', 'putaway2', @two_days_ago),
('PLATE-R010', 'OFF002', 'Blue Pens Pack 12', 60, 'Receiving Area', '2-2', 'D', 'putaway2', @two_days_ago);

-- =====================================================
-- Insert Sample Data: Picking Orders (for testing)
-- =====================================================

SET @one_hour_ago = DATE_SUB(NOW(), INTERVAL 1 HOUR);

INSERT INTO `picking_orders` (`work_id`, `branch`, `status`, `created_at`) VALUES
('WORK-001', 'Downtown Branch', 'pending', NOW()),
('WORK-002', 'Uptown Branch', 'pending', NOW()),
('WORK-003', 'Westside Branch', 'pending', NOW()),
('WORK-004', 'Eastside Branch', 'in_progress', @one_hour_ago),
('WORK-005', 'Central Branch', 'pending', NOW());

-- =====================================================
-- Insert Sample Data: Picking Order Items
-- =====================================================

INSERT INTO `picking_order_items` (`work_id`, `plate_id`, `sequence`, `item_barcode`, `location_code`, `quantity_required`, `status`) VALUES
-- Work Order 001 - Food Items (Rice, Sugar, Chickpeas)
-- plate_id will be scanned by picker at first item (virtual plate)
('WORK-001', NULL, 1, 'RICE001', '1-0', 10, 'pending'),
('WORK-001', NULL, 2, 'SUGAR001', '2-0', 20, 'pending'),
('WORK-001', NULL, 3, 'CHICKPEA001', '3-0', 15, 'pending'),
('WORK-001', NULL, 4, 'OIL001', '4-1', 10, 'pending'),

-- Work Order 002 - Food Items (Spices, Canned Goods)
('WORK-002', NULL, 1, 'SPICE001', '1-2', 25, 'pending'),
('WORK-002', NULL, 2, 'CAN001', '4-2', 20, 'pending'),
('WORK-002', NULL, 3, 'CAN002', '5-2', 15, 'pending'),
('WORK-002', NULL, 4, 'BEV001', '2-3', 30, 'pending'),

-- Work Order 003 - Non-Food Items (Medicines)
('WORK-003', NULL, 1, 'MED001', '1-0', 50, 'pending'),
('WORK-003', NULL, 2, 'MED002', '1-0', 30, 'pending'),
('WORK-003', NULL, 3, 'MED003', '2-0', 20, 'pending'),
('WORK-003', NULL, 4, 'MED004', '2-1', 15, 'pending'),

-- Work Order 004 - Non-Food Items (Cleaning Products) - In Progress
('WORK-004', NULL, 1, 'CLEAN001', '1-0', 25, 'pending'),
('WORK-004', NULL, 2, 'CLEAN002', '1-0', 30, 'pending'),
('WORK-004', NULL, 3, 'CLEAN003', '1-1', 20, 'pending'),

-- Work Order 005 - Mixed Items (Personal Care & Office)
('WORK-005', NULL, 1, 'CARE001', '1-0', 40, 'pending'),
('WORK-005', NULL, 2, 'CARE003', '2-0', 50, 'pending'),
('WORK-005', NULL, 3, 'OFF001', '1-2', 10, 'pending'),
('WORK-005', NULL, 4, 'OFF002', '2-2', 15, 'pending');

-- =====================================================
-- Insert Sample Data: Stocktaking Records
-- =====================================================

INSERT INTO `stocktaking` (`item_barcode`, `location_code`, `system_qty`, `counted_qty`, `difference`, `counted_at`, `plate_id`) VALUES
-- Food Items Stocktaking
('RICE001', '1-0', 50, 50, 0, @yesterday, 'PLATE-A001'),
('SUGAR001', '2-0', 100, 98, -2, @yesterday, 'PLATE-A003'),
('CHICKPEA001', '3-0', 60, 60, 0, @two_days_ago, 'PLATE-A005'),

-- Non-Food Items Stocktaking
('MED001', '1-0', 200, 200, 0, @yesterday, 'PLATE-B001'),
('CLEAN001', '1-0', 100, 98, -2, @yesterday, 'PLATE-C001'),
('CARE001', '1-0', 150, 150, 0, @two_days_ago, 'PLATE-D001');

-- =====================================================
-- Insert Sample Data: Lowering Orders
-- =====================================================
-- These orders are created automatically when picking from low shelves runs out
-- and items are available on high shelves (shelf_number > 2)

INSERT INTO `lowering_orders` (`item_barcode`, `from_location_code`, `from_zone`, `from_full_location`, `quantity_at_source`, `priority`, `created_by`) VALUES
-- Food Items Lowering Orders (High Shelf - user will choose destination)
('BEV001', '2-3', 'A', 'A-2-3', 120, 1, 'System'),
('CAN003', '1-3', 'A', 'A-1-3', 50, 1, 'System'),

-- Non-Food Items Lowering Orders (Medicines)
('MED001', '1-3', 'B', 'B-1-3', 50, 1, 'System'),
('MED002', '2-3', 'B', 'B-2-3', 40, 1, 'System'),

-- Non-Food Items Lowering Orders (Cleaning Products)
('CLEAN001', '1-2', 'C', 'C-1-2', 30, 2, 'System'),
('CLEAN002', '2-2', 'C', 'C-2-2', 25, 2, 'System');

-- =====================================================
-- Insert Sample Data: Areas (for prepared plates)
-- =====================================================

INSERT INTO `areas` (`area_code`, `area_name`, `branch`, `is_active`) VALUES
('AREA001', 'Area 1', 'Downtown Branch', 1),
('AREA002', 'Area 2', 'Uptown Branch', 1),
('AREA003', 'Area 3', 'Westside Branch', 1),
('AREA004', 'Area 4', 'Eastside Branch', 1),
('AREA005', 'Area 5', 'Central Branch', 1),
('AREA006', 'Area 6', 'Hasbaya Branch', 1),
('AREA007', 'Area 7', 'Ain Dleb Branch', 1),
('AREA008', 'Area 8', 'Dweir Branch', 1),
('AREA009', 'Area 9', 'South Branch', 1),
('AREA010', 'Area 10', 'North Branch', 1);

-- =====================================================
-- Insert Sample Data: Picking Log (for loaded plates)
-- =====================================================

SET @two_hours_ago = DATE_SUB(NOW(), INTERVAL 2 HOUR);
SET @three_hours_ago = DATE_SUB(NOW(), INTERVAL 3 HOUR);
SET @yesterday_pick = DATE_SUB(NOW(), INTERVAL 1 DAY);

INSERT INTO `picking_log` (`work_id`, `plate_id`, `item_barcode`, `quantity_picked`, `location_code`, `target_lp`, `picked_at`, `picked_by`) VALUES
-- Plate L-001 (Loaded) - Work Order 001
('WORK-001', 'L-001', 'RICE001', 10, '1-0', 'Downtown Branch', @three_hours_ago, 'picker1'),
('WORK-001', 'L-001', 'SUGAR001', 20, '2-0', 'Downtown Branch', @three_hours_ago, 'picker1'),
('WORK-001', 'L-001', 'CHICKPEA001', 15, '3-0', 'Downtown Branch', @three_hours_ago, 'picker1'),
('WORK-001', 'L-001', 'OIL001', 10, '4-1', 'Downtown Branch', @three_hours_ago, 'picker1'),

-- Plate L-002 (Loaded) - Work Order 002
('WORK-002', 'L-002', 'SPICE001', 25, '1-2', 'Uptown Branch', @two_hours_ago, 'picker2'),
('WORK-002', 'L-002', 'CAN001', 20, '4-2', 'Uptown Branch', @two_hours_ago, 'picker2'),
('WORK-002', 'L-002', 'CAN002', 15, '5-2', 'Uptown Branch', @two_hours_ago, 'picker2'),
('WORK-002', 'L-002', 'BEV001', 30, '2-3', 'Uptown Branch', @two_hours_ago, 'picker2'),

-- Plate L-003 (Loaded) - Work Order 003
('WORK-003', 'L-003', 'MED001', 50, '1-0', 'Westside Branch', @yesterday_pick, 'picker1'),
('WORK-003', 'L-003', 'MED002', 30, '1-0', 'Westside Branch', @yesterday_pick, 'picker1'),
('WORK-003', 'L-003', 'MED003', 20, '2-0', 'Westside Branch', @yesterday_pick, 'picker1'),

-- Plate L-004 (Loaded) - Work Order 004
('WORK-004', 'L-004', 'CLEAN001', 25, '1-0', 'Eastside Branch', @yesterday_pick, 'picker2'),
('WORK-004', 'L-004', 'CLEAN002', 30, '1-0', 'Eastside Branch', @yesterday_pick, 'picker2'),
('WORK-004', 'L-004', 'CLEAN003', 20, '1-1', 'Eastside Branch', @yesterday_pick, 'picker2');

-- =====================================================
-- Insert Sample Data: Plate Verifications (Loaded Plates)
-- =====================================================

SET @loaded_time_1 = DATE_SUB(NOW(), INTERVAL 1 HOUR);
SET @loaded_time_2 = DATE_SUB(NOW(), INTERVAL 2 HOUR);
SET @loaded_time_3 = DATE_SUB(NOW(), INTERVAL 1 DAY);
SET @loaded_time_4 = DATE_SUB(NOW(), INTERVAL 1 DAY);

INSERT INTO `plate_verifications` (`plate_id`, `work_id`, `branch`, `verified_by`, `verification_status`, `plate_status`, `verified_at`, `ready_for_load_at`, `loaded_by`) VALUES
-- Plate L-001 - Loaded
('L-001', 'WORK-001', 'Downtown Branch', 'qc1', 'complete', 'loaded', @three_hours_ago, @loaded_time_1, 'loader1'),

-- Plate L-002 - Loaded
('L-002', 'WORK-002', 'Uptown Branch', 'qc2', 'complete', 'loaded', @two_hours_ago, @loaded_time_2, 'loader2'),

-- Plate L-003 - Loaded
('L-003', 'WORK-003', 'Westside Branch', 'qc1', 'complete', 'loaded', @yesterday_pick, @loaded_time_3, 'loader1'),

-- Plate L-004 - Loaded
('L-004', 'WORK-004', 'Eastside Branch', 'qc2', 'complete', 'loaded', @yesterday_pick, @loaded_time_4, 'loader2');

-- =====================================================
-- Insert Sample Data: Plate Verification Items (QC Quantities)
-- =====================================================

INSERT INTO `plate_verification_items` (`plate_id`, `item_barcode`, `qc_quantity`, `verified_at`) VALUES
-- Plate L-001 Items
('L-001', 'RICE001', 10, @three_hours_ago),
('L-001', 'SUGAR001', 20, @three_hours_ago),
('L-001', 'CHICKPEA001', 15, @three_hours_ago),
('L-001', 'OIL001', 10, @three_hours_ago),

-- Plate L-002 Items
('L-002', 'SPICE001', 25, @two_hours_ago),
('L-002', 'CAN001', 20, @two_hours_ago),
('L-002', 'CAN002', 15, @two_hours_ago),
('L-002', 'BEV001', 30, @two_hours_ago),

-- Plate L-003 Items
('L-003', 'MED001', 50, @yesterday_pick),
('L-003', 'MED002', 30, @yesterday_pick),
('L-003', 'MED003', 20, @yesterday_pick),

-- Plate L-004 Items
('L-004', 'CLEAN001', 25, @yesterday_pick),
('L-004', 'CLEAN002', 30, @yesterday_pick),
('L-004', 'CLEAN003', 20, @yesterday_pick);

-- =====================================================
-- Insert Additional Sample Data: More Picking Orders (In Progress & Completed)
-- =====================================================

INSERT INTO `picking_orders` (`work_id`, `branch`, `status`, `created_at`) VALUES
('WORK-006', 'Central Branch', 'in_progress', DATE_SUB(NOW(), INTERVAL 3 HOUR)),
('WORK-007', 'Hasbaya Branch', 'completed', DATE_SUB(NOW(), INTERVAL 2 DAY)),
('WORK-008', 'Ain Dleb Branch', 'pending', DATE_SUB(NOW(), INTERVAL 1 HOUR)),
('WORK-009', 'Dweir Branch', 'in_progress', DATE_SUB(NOW(), INTERVAL 4 HOUR)),
('WORK-010', 'South Branch', 'pending', NOW());

-- =====================================================
-- Insert Additional Sample Data: More Picking Order Items
-- =====================================================

INSERT INTO `picking_order_items` (`work_id`, `plate_id`, `sequence`, `item_barcode`, `location_code`, `quantity_required`, `quantity_picked`, `status`) VALUES
-- Work Order 006 - In Progress
('WORK-006', 'L-005', 1, 'CARE001', '1-0', 40, 40, 'picked'),
('WORK-006', 'L-005', 2, 'CARE003', '2-0', 50, 50, 'picked'),
('WORK-006', NULL, 3, 'OFF001', '1-2', 10, 0, 'pending'),

-- Work Order 007 - Completed
('WORK-007', 'L-006', 1, 'RICE002', '1-0', 30, 30, 'picked'),
('WORK-007', 'L-006', 2, 'OIL001', '4-1', 25, 25, 'picked'),
('WORK-007', 'L-006', 3, 'SPICE001', '1-2', 20, 20, 'picked'),

-- Work Order 008 - Pending
('WORK-008', NULL, 1, 'MED004', '2-1', 15, 0, 'pending'),
('WORK-008', NULL, 2, 'CLEAN002', '1-0', 30, 0, 'pending'),

-- Work Order 009 - In Progress
('WORK-009', 'L-007', 1, 'BEV001', '2-3', 40, 40, 'picked'),
('WORK-009', NULL, 2, 'CAN001', '4-2', 25, 0, 'pending'),

-- Work Order 010 - Pending
('WORK-010', NULL, 1, 'OFF003', '1-3', 20, 0, 'pending'),
('WORK-010', NULL, 2, 'OFF004', '2-3', 15, 0, 'pending'),
('WORK-010', NULL, 3, 'OFF005', '1-3', 10, 0, 'pending');

-- =====================================================
-- Insert Additional Sample Data: More Picking Log
-- =====================================================

INSERT INTO `picking_log` (`work_id`, `plate_id`, `item_barcode`, `quantity_picked`, `location_code`, `target_lp`, `picked_at`, `picked_by`) VALUES
-- Work Order 006
('WORK-006', 'L-005', 'CARE001', 40, '1-0', 'Central Branch', DATE_SUB(NOW(), INTERVAL 2 HOUR), 'picker1'),
('WORK-006', 'L-005', 'CARE003', 50, '2-0', 'Central Branch', DATE_SUB(NOW(), INTERVAL 2 HOUR), 'picker1'),

-- Work Order 007
('WORK-007', 'L-006', 'RICE002', 30, '1-0', 'Hasbaya Branch', DATE_SUB(NOW(), INTERVAL 2 DAY), 'picker2'),
('WORK-007', 'L-006', 'OIL001', 25, '4-1', 'Hasbaya Branch', DATE_SUB(NOW(), INTERVAL 2 DAY), 'picker2'),
('WORK-007', 'L-006', 'SPICE001', 20, '1-2', 'Hasbaya Branch', DATE_SUB(NOW(), INTERVAL 2 DAY), 'picker2'),

-- Work Order 009
('WORK-009', 'L-007', 'BEV001', 40, '2-3', 'Dweir Branch', DATE_SUB(NOW(), INTERVAL 3 HOUR), 'picker1');

-- =====================================================
-- Insert Additional Sample Data: More Plate Verifications (Ready to Load & Verified)
-- =====================================================

INSERT INTO `plate_verifications` (`plate_id`, `work_id`, `branch`, `verified_by`, `verification_status`, `plate_status`, `verified_at`, `ready_for_load_at`, `loaded_by`) VALUES
-- Plate L-005 - Ready to Load
('L-005', 'WORK-006', 'Central Branch', 'qc1', 'complete', 'ready_to_load', DATE_SUB(NOW(), INTERVAL 1 HOUR), DATE_SUB(NOW(), INTERVAL 30 MINUTE), NULL),

-- Plate L-006 - Loaded (Completed)
('L-006', 'WORK-007', 'Hasbaya Branch', 'qc2', 'complete', 'loaded', DATE_SUB(NOW(), INTERVAL 2 DAY), DATE_SUB(NOW(), INTERVAL 2 DAY), 'loader1'),

-- Plate L-007 - Verified (Not ready for load yet)
('L-007', 'WORK-009', 'Dweir Branch', 'qc1', 'complete', 'verified', DATE_SUB(NOW(), INTERVAL 2 HOUR), NULL, NULL);

-- =====================================================
-- Insert Additional Sample Data: More Plate Verification Items
-- =====================================================

INSERT INTO `plate_verification_items` (`plate_id`, `item_barcode`, `qc_quantity`, `verified_at`) VALUES
-- Plate L-005 Items
('L-005', 'CARE001', 40, DATE_SUB(NOW(), INTERVAL 1 HOUR)),
('L-005', 'CARE003', 50, DATE_SUB(NOW(), INTERVAL 1 HOUR)),

-- Plate L-006 Items
('L-006', 'RICE002', 30, DATE_SUB(NOW(), INTERVAL 2 DAY)),
('L-006', 'OIL001', 25, DATE_SUB(NOW(), INTERVAL 2 DAY)),
('L-006', 'SPICE001', 20, DATE_SUB(NOW(), INTERVAL 2 DAY)),

-- Plate L-007 Items
('L-007', 'BEV001', 40, DATE_SUB(NOW(), INTERVAL 2 HOUR));

-- =====================================================
-- Insert Additional Sample Data: More Receiving Records
-- =====================================================

INSERT INTO `receiving` (`plate_id`, `po_id`, `item_barcode`, `item_name`, `description`, `quantity`, `expiry_date`, `receive_date`, `received_by`, `status`) VALUES
-- More Receiving Records
('PLATE-R011', NULL, 'RICE001', 'Basmati Rice 5kg', 'Premium Basmati Rice - 5kg Bag', 100, '2026-12-31', @today, 'receiver1', 'received'),
('PLATE-R011', NULL, 'SUGAR001', 'White Sugar 1kg', 'Granulated White Sugar - 1kg Pack', 150, '2027-06-30', @today, 'receiver1', 'received'),
('PLATE-R012', 4, 'RICE002', 'White Rice 10kg', 'Long Grain White Rice - 10kg Bag', 60, '2026-12-31', @today, 'receiver2', 'received'),
('PLATE-R012', 4, 'CHICKPEA001', 'Chickpeas 1kg', 'Dried Chickpeas - 1kg Pack', 80, '2026-12-31', @today, 'receiver2', 'received'),
('PLATE-R013', NULL, 'MED004', 'Aspirin 100mg', 'Aspirin Tablets 100mg - Pack of 30', 120, '2027-12-31', @yesterday_rec, 'receiver1', 'received'),
('PLATE-R014', NULL, 'CLEAN004', 'Bleach 1L', 'Household Bleach - 1 Liter', 90, '2028-12-31', @yesterday_rec, 'receiver2', 'received');

-- =====================================================
-- Insert Additional Sample Data: More Putaway Records
-- =====================================================

INSERT INTO `putaway` (`plate_id`, `item_barcode`, `item_name`, `quantity`, `from_location`, `to_location`, `zone`, `moved_by`, `moved_at`) VALUES
-- More Putaway Records
('PLATE-R011', 'RICE001', 'Basmati Rice 5kg', 100, 'Receiving Area', '1-0', 'A', 'putaway1', @yesterday),
('PLATE-R011', 'SUGAR001', 'White Sugar 1kg', 150, 'Receiving Area', '2-0', 'A', 'putaway1', @yesterday),
('PLATE-R012', 'RICE002', 'White Rice 10kg', 60, 'Receiving Area', '1-0', 'A', 'putaway2', @yesterday),
('PLATE-R012', 'CHICKPEA001', 'Chickpeas 1kg', 80, 'Receiving Area', '3-0', 'A', 'putaway2', @yesterday),
('PLATE-R013', 'MED004', 'Aspirin 100mg', 120, 'Receiving Area', '2-1', 'B', 'putaway1', @two_days_ago),
('PLATE-R014', 'CLEAN004', 'Bleach 1L', 90, 'Receiving Area', '1-1', 'C', 'putaway2', @two_days_ago);

-- =====================================================
-- Create View: Plate Tracking
-- =====================================================

CREATE VIEW `plate_tracking` AS
SELECT 
    r.plate_id,
    r.item_barcode,
    r.item_name,
    r.description,
    r.quantity as received_quantity,
    r.receive_date,
    r.received_by,
    r.status as receiving_status,
    p.to_location as putaway_location,
    p.zone as putaway_zone,
    p.moved_at as putaway_date,
    i.quantity as inventory_quantity,
    i.location_code as current_location,
    i.zone as current_zone,
    i.last_update as inventory_update
FROM `receiving` r
LEFT JOIN `putaway` p ON r.plate_id = p.plate_id AND r.item_barcode = p.item_barcode
LEFT JOIN `inventory` i ON r.item_barcode = i.item_barcode AND p.to_location = i.location_code
ORDER BY r.plate_id, r.item_barcode;

-- =====================================================
-- Commit Transaction
-- =====================================================

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- =====================================================
-- Summary
-- =====================================================

-- Total Records Inserted:
-- Zones: 4 (A, B, C, D)
-- Locations: 39 (A: 20, B: 9, C: 4, D: 6)
-- Users: 14 (2 managers, 2 receivers, 2 pickers, 2 putaway, 2 loaders, 2 QC, 2 house keepers)
-- Items (adddesc): 25
-- Inventory: 25 records across all zones
-- Receiving: 8 records
-- Putaway: 6 records
-- Picking Orders: 5
-- Picking Order Items: 17
-- Stocktaking: 3 records
-- Lowering Orders: 6 records
-- Areas: 10 records
-- Picking Orders: 10 total (5 original + 5 additional)
-- Picking Order Items: 30 total (17 original + 13 additional)
-- Picking Log: 22 records (15 original + 7 additional)
-- Plate Verifications: 7 records (5 loaded + 1 ready_to_load + 1 verified)
-- Plate Verification Items: 22 records (15 original + 7 additional)
-- Receiving: 24 records (18 original + 6 additional)
-- Putaway: 18 records (12 original + 6 additional)

-- =====================================================
-- Additional Columns Added (Latest Updates):
-- =====================================================
-- lowering_orders: completed_zones, assigned_user, assigned_zone, lowered_by
-- plate_verifications: loaded_by
-- picking_log: picked_by
-- users: role 'house keeper' added

-- =====================================================
-- End of Complete Database Schema
-- =====================================================