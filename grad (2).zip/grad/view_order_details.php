<?php
include 'db_connect.php';

// Add picked_by column to picking_log if it doesn't exist
$check_column = $conn->query("SHOW COLUMNS FROM picking_log LIKE 'picked_by'");
if ($check_column->num_rows == 0) {
    $conn->query("ALTER TABLE picking_log ADD COLUMN picked_by varchar(100) DEFAULT NULL AFTER picked_at");
}

if (!isset($_GET['work_id'])) {
    header("Location: transfer_orders.php");
    exit;
}

$work_id = mysqli_real_escape_string($conn, $_GET['work_id']);
$print_mode = isset($_GET['print']) && $_GET['print'] == '1';

// Get order details
$order_query = "SELECT * FROM picking_orders WHERE work_id = '$work_id'";
$order_result = $conn->query($order_query);

if ($order_result->num_rows === 0) {
    header("Location: transfer_orders.php");
    exit;
}

$order = $order_result->fetch_assoc();

// Get order items with picker information
$items_query = "
    SELECT 
        poi.*,
        COALESCE(ad.name, ad.description, poi.item_barcode) as item_name,
        i.quantity as available_quantity,
        i.location_code as inventory_location,
        (SELECT GROUP_CONCAT(DISTINCT pl2.picked_by SEPARATOR ', ')
         FROM picking_log pl2
         WHERE pl2.work_id = poi.work_id 
           AND pl2.item_barcode = poi.item_barcode
           AND (poi.plate_id IS NULL OR pl2.plate_id = poi.plate_id)
           AND pl2.picked_by IS NOT NULL
        ) as picked_by_users
    FROM picking_order_items poi
    LEFT JOIN adddesc ad ON poi.item_barcode = ad.barcode
    LEFT JOIN inventory i ON poi.item_barcode = i.item_barcode 
        AND (poi.location_code = i.location_code OR poi.location_code IS NULL)
    WHERE poi.work_id = '$work_id'
    ORDER BY 
        CAST(SUBSTRING_INDEX(COALESCE(poi.location_code, ''), '-', 1) AS UNSIGNED) ASC,
        poi.sequence,
        poi.id
";
$items_result = $conn->query($items_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details - <?php echo htmlspecialchars($work_id); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background-color: #f5f7fa;
            color: #333;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #2c3e50;
        }
        .header h1 {
            color: #2c3e50;
            font-size: 24px;
            margin-bottom: 10px;
        }
        .order-info {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
        }
        .info-item {
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .info-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
        }
        .info-value {
            font-size: 16px;
            font-weight: 600;
            color: #2c3e50;
        }
        .status {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-in_progress { background: #d1ecf1; color: #0c5460; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        .print-btn {
            background: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 20px;
        }
        .print-btn:hover {
            background: #218838;
        }
        @media print {
            .print-btn, .header a, .no-print {
                display: none !important;
            }
            body {
                background: white;
            }
            .container {
                max-width: 100%;
                padding: 0;
            }
            .order-info, .content-section {
                box-shadow: none;
                border: 1px solid #ddd;
                page-break-inside: avoid;
            }
            table {
                page-break-inside: auto;
            }
            tr {
                page-break-inside: avoid;
                page-break-after: auto;
            }
        }
        .content-section {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .item-status {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: 500;
        }
        .status-picked { background: #d4edda; color: #155724; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-skipped { background: #f8d7da; color: #721c24; }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }
        .btn-secondary {
            background: #95a5a6;
            color: white;
        }
        .btn-secondary:hover {
            background: #7f8c8d;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #3498db;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!$print_mode): ?>
        <a href="transfer_orders.php" class="back-link">← Back to Transfer Orders</a>
        <button class="print-btn" onclick="window.print()">🖨️ Print</button>
        <?php endif; ?>
        
        <div class="header">
            <h1>📋 Order Details: <?php echo htmlspecialchars($work_id); ?></h1>
        </div>

        <!-- Order Information -->
        <div class="order-info">
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Work ID</div>
                    <div class="info-value"><?php echo htmlspecialchars($order['work_id']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Branch</div>
                    <div class="info-value"><?php echo htmlspecialchars($order['branch'] ?? '-'); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Status</div>
                    <div class="info-value">
                        <span class="status status-<?php echo $order['status']; ?>">
                            <?php echo ucwords(str_replace('_', ' ', $order['status'])); ?>
                        </span>
                    </div>
                </div>
                <div class="info-item">
                    <div class="info-label">Created At</div>
                    <div class="info-value"><?php echo date('Y-m-d H:i:s', strtotime($order['created_at'])); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Updated At</div>
                    <div class="info-value"><?php echo date('Y-m-d H:i:s', strtotime($order['updated_at'])); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Area</div>
                    <div class="info-value"><?php echo htmlspecialchars($order['area'] ?? '-'); ?></div>
                </div>
            </div>
        </div>

        <!-- Order Items -->
        <div class="content-section">
            <h2 class="section-title">Order Items</h2>
            <table>
                <thead>
                    <tr>
                        <th>Item Barcode</th>
                        <th>Item Name</th>
                        <th>Location</th>
                        <th>Required Qty</th>
                        <th>Picked Qty</th>
                        <th>Available Qty</th>
                        <th>Status</th>
                        <th>Plate ID</th>
                        <th>Picked By</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($items_result && $items_result->num_rows > 0) {
                        while ($item = $items_result->fetch_assoc()) {
                            $status_class = 'status-' . $item['status'];
                            $status_display = ucwords($item['status']);
                            
                            // Get unique picker names
                            $picked_by = '-';
                            if (!empty($item['picked_by_users'])) {
                                $pickers = array_unique(explode(', ', $item['picked_by_users']));
                                $picked_by = implode(', ', $pickers);
                            }
                            
                            echo "<tr>";
                            echo "<td><strong>" . htmlspecialchars($item['item_barcode']) . "</strong></td>";
                            echo "<td>" . htmlspecialchars($item['item_name'] ?? $item['item_barcode']) . "</td>";
                            echo "<td>" . htmlspecialchars($item['location_code'] ?? '-') . "</td>";
                            echo "<td>{$item['quantity_required']}</td>";
                            echo "<td>{$item['quantity_picked']}</td>";
                            echo "<td>" . ($item['available_quantity'] ?? '-') . "</td>";
                            echo "<td><span class='item-status {$status_class}'>{$status_display}</span></td>";
                            echo "<td>" . htmlspecialchars($item['plate_id'] ?? '-') . "</td>";
                            echo "<td>" . htmlspecialchars($picked_by) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='9' style='text-align: center; padding: 20px;'>No items found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <div style="margin-top: 20px;">
            <a href="transfer_orders.php" class="btn btn-secondary">← Back to Transfer Orders</a>
        </div>
    </div>
</body>
</html>
<?php
$conn->close();
?>


