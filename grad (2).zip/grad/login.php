<?php
session_start();
include "db_connect.php";

// Check and update users table to include 'house keeper' role if not exists
$check_enum = $conn->query("SHOW COLUMNS FROM users WHERE Field = 'role'");
if ($check_enum && $row = $check_enum->fetch_assoc()) {
    $enum_values = $row['Type'];
    if (strpos($enum_values, 'house keeper') === false) {
        // Add 'house keeper' to enum
        $conn->query("ALTER TABLE `users` MODIFY COLUMN `role` enum('manager','receiver','loader','picker','quantity controller','putaway','house keeper') NOT NULL");
    }
}

$message = "";
$required_role = isset($_GET['role']) ? $_GET['role'] : '';
$role_display = ucwords($required_role);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $password = $_POST['password'];
    $required_role = isset($_POST['required_role']) ? $_POST['required_role'] : '';

    // Check if role is required
    if (!empty($required_role)) {
        $query = mysqli_query($conn, "SELECT * FROM users WHERE name='$name' AND role='$required_role'");
    } else {
    $query = mysqli_query($conn, "SELECT * FROM users WHERE name='$name'");
    }
    
    if (mysqli_num_rows($query) > 0) {
        $user = mysqli_fetch_assoc($query);
        if (password_verify($password, $user['password'])) {
            // Check if role matches required role
            if (!empty($required_role) && $user['role'] != $required_role) {
                $message = "<p style='color:red;'>You don't have access to this role!</p>";
            } else {
            // حفظ بيانات المستخدم في السيشن
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_role'] = $user['role'];

            // توجيه حسب الدور
            switch ($user['role']) {
                case 'manager':
                    header("Location: warehouseM.php");
                    break;
                case 'receiver':
                    header("Location: receiving.php");
                    break;
                case 'loader':
                    header("Location: loader.php");
                    break;
                case 'picker':
                        header("Location: pick.php");
                    break;
                case 'quantity controller':
                        header("Location: qc_check.php");
                    break;
                     case 'putaway':
                    header("Location: putaway.php");
                    break;
                    case 'house keeper':
                        header("Location: lowering.php");
                        break;
                default:
                    header("Location: login.php");
            }
            exit();
            }
        } else {
            $message = "<p style='color:red;'>Invalid password!</p>";
        }
    } else {
        if (!empty($required_role)) {
            $message = "<p style='color:red;'>User not found or you don't have access to this role!</p>";
    } else {
        $message = "<p style='color:red;'>User not found!</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Login</title>
  <style>
    body {
      font-family: Poppins, sans-serif;
      background: #eef2f7;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .login-box {
      background: #fff;
      padding: 25px 30px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      width: 320px;
    }
    h2 { text-align: center; color: #333; margin-bottom: 20px; }
    label { font-weight: 600; margin-top: 10px; display: block; }
    input {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 6px;
    }
    button {
      width: 100%;
      padding: 10px;
      background: #28a745;
      color: #fff;
      border: none;
      border-radius: 6px;
      margin-top: 15px;
      cursor: pointer;
      font-weight: bold;
    }
    button:hover { background: #218838; }
    p { text-align: center; font-size: 14px; }
  </style>
</head>
<body>

<div class="login-box">
  <h2><?php echo !empty($role_display) ? $role_display . ' Login' : 'Login'; ?></h2>
  <?php echo $message; ?>
  <form method="POST">
    <?php if (!empty($required_role)): ?>
      <input type="hidden" name="required_role" value="<?php echo htmlspecialchars($required_role); ?>">
    <?php endif; ?>
    <label>Name</label>
    <input type="text" name="name" required autofocus>

    <label>Password</label>
    <input type="password" name="password" required>

    <button type="submit">Login</button>
  </form>
  <p><a href="index.php" style="color: #007bff; text-decoration: none;">← Back to Main Menu</a></p>
</div>

</body>
</html>
