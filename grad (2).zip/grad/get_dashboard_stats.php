<?php
header('Content-Type: application/json');
include 'db_connect.php';

// Get all statistics
$stats = [];

// 1. Total Users
$result = $conn->query("SELECT COUNT(*) as total FROM users");
$stats['total_users'] = $result->fetch_assoc()['total'];

// 2. Total Inventory Items (distinct items)
$result = $conn->query("SELECT COUNT(DISTINCT item_barcode) as total FROM inventory WHERE quantity > 0");
$stats['total_items'] = $result->fetch_assoc()['total'];

// 3. Total Inventory Quantity
$result = $conn->query("SELECT COALESCE(SUM(quantity), 0) as total FROM inventory");
$stats['total_quantity'] = $result->fetch_assoc()['total'];

// 4. Pending Picking Orders
$result = $conn->query("SELECT COUNT(*) as total FROM picking_orders WHERE status IN ('pending', 'in_progress')");
$stats['pending_orders'] = $result->fetch_assoc()['total'];

// 5. Completed Picking Orders (Today)
$result = $conn->query("SELECT COUNT(*) as total FROM picking_orders WHERE status = 'completed' AND DATE(updated_at) = CURDATE()");
$stats['completed_today'] = $result->fetch_assoc()['total'];

// 6. Plates Ready for Load
$result = $conn->query("SELECT COUNT(*) as total FROM plate_verifications WHERE plate_status = 'ready_to_load'");
$stats['ready_to_load'] = $result->fetch_assoc()['total'];

// 7. Plates Loaded (Today)
$result = $conn->query("SELECT COUNT(*) as total FROM plate_verifications WHERE plate_status = 'loaded' AND DATE(ready_for_load_at) = CURDATE()");
$stats['loaded_today'] = $result->fetch_assoc()['total'];

// 8. Pending Lowering Orders
$result = $conn->query("SELECT COUNT(*) as total FROM lowering_orders WHERE status IN ('pending', 'in_progress')");
$stats['pending_lowering'] = $result->fetch_assoc()['total'];

// 9. Low Stock Items (quantity < 10)
$result = $conn->query("SELECT COUNT(DISTINCT item_barcode) as total FROM inventory WHERE quantity > 0 AND quantity < 10");
$stats['low_stock'] = $result->fetch_assoc()['total'];

// 10. Items Received Today
$result = $conn->query("SELECT COUNT(DISTINCT plate_id) as total FROM receiving WHERE receive_date = CURDATE()");
$stats['received_today'] = $result->fetch_assoc()['total'];

// 11. Active Areas
$result = $conn->query("SELECT COUNT(*) as total FROM areas WHERE is_active = 1");
$stats['active_areas'] = $result->fetch_assoc()['total'];

// 12. Total Zones
$result = $conn->query("SELECT COUNT(*) as total FROM zones");
$stats['total_zones'] = $result->fetch_assoc()['total'];

// Get recent picking orders with user information
$recent_orders = [];
$result = $conn->query("
    SELECT po.work_id, po.branch, po.status, po.created_at, 
           COUNT(DISTINCT poi.id) as item_count,
           COALESCE(SUM(poi.quantity_required), 0) as total_quantity,
           COALESCE(SUM(CASE WHEN poi.status = 'picked' THEN 1 ELSE 0 END), 0) as picked_items,
           COALESCE(SUM(CASE WHEN poi.status = 'pending' THEN 1 ELSE 0 END), 0) as pending_items,
           GROUP_CONCAT(DISTINCT pl.picked_by SEPARATOR ', ') as pickers,
           GROUP_CONCAT(DISTINCT pv.verified_by SEPARATOR ', ') as qc_users,
           GROUP_CONCAT(DISTINCT r.received_by SEPARATOR ', ') as receiver_users,
           GROUP_CONCAT(DISTINCT p.moved_by SEPARATOR ', ') as putaway_users,
           GROUP_CONCAT(DISTINCT pv.loaded_by SEPARATOR ', ') as loader_users
    FROM picking_orders po
    LEFT JOIN picking_order_items poi ON po.work_id = poi.work_id
    LEFT JOIN picking_log pl ON po.work_id = pl.work_id AND pl.picked_by IS NOT NULL
    LEFT JOIN plate_verifications pv ON poi.plate_id = pv.plate_id
    LEFT JOIN receiving r ON poi.plate_id = r.plate_id AND r.received_by IS NOT NULL
    LEFT JOIN putaway p ON r.plate_id = p.plate_id AND p.moved_by IS NOT NULL
    WHERE po.status IN ('pending', 'in_progress')
    GROUP BY po.id
    ORDER BY po.created_at DESC
    LIMIT 10
");
while ($row = $result->fetch_assoc()) {
    // Ensure numeric values
    $row['item_count'] = intval($row['item_count']);
    $row['picked_items'] = intval($row['picked_items']);
    $row['pending_items'] = intval($row['pending_items']);
    $recent_orders[] = $row;
}

// Get plates ready for load
$ready_plates = [];
$result = $conn->query("
    SELECT pv.plate_id, pv.work_id, pv.branch, pv.verified_by, pv.verified_at,
           COUNT(DISTINCT pl.item_barcode) as item_count,
           SUM(COALESCE(pvi.qc_quantity, pl.quantity_picked)) as total_quantity
    FROM plate_verifications pv
    LEFT JOIN picking_log pl ON pv.plate_id = pl.plate_id
    LEFT JOIN plate_verification_items pvi ON pv.plate_id = pvi.plate_id AND pl.item_barcode = pvi.item_barcode
    WHERE pv.plate_status = 'ready_to_load'
    GROUP BY pv.plate_id
    ORDER BY pv.verified_at DESC
    LIMIT 10
");
while ($row = $result->fetch_assoc()) {
    $ready_plates[] = $row;
}

// Get low stock items
$low_stock_items = [];
$result = $conn->query("
    SELECT i.item_barcode, i.location_code, i.quantity, i.zone,
           COALESCE(ad.name, ad.description, i.item_barcode) as item_name
    FROM inventory i
    LEFT JOIN adddesc ad ON i.item_barcode = ad.barcode
    WHERE i.quantity > 0 AND i.quantity < 10
    ORDER BY i.quantity ASC
    LIMIT 10
");
while ($row = $result->fetch_assoc()) {
    $low_stock_items[] = $row;
}

// Get recent activities (from picking_log, receiving, putaway)
$recent_activities = [];
$result = $conn->query("
    SELECT 'Picking' as activity_type, 
           CONCAT('Picked ', quantity_picked, ' of ', item_barcode) as description,
           work_id as reference,
           picked_at as activity_date
    FROM picking_log
    WHERE DATE(picked_at) = CURDATE()
    UNION ALL
    SELECT 'Receiving' as activity_type,
           CONCAT('Received ', quantity, ' of ', item_barcode) as description,
           plate_id as reference,
           receive_date as activity_date
    FROM receiving
    WHERE receive_date = CURDATE()
    UNION ALL
    SELECT 'Putaway' as activity_type,
           CONCAT('Moved ', quantity, ' of ', item_barcode, ' to ', to_location) as description,
           plate_id as reference,
           moved_at as activity_date
    FROM putaway
    WHERE DATE(moved_at) = CURDATE()
    ORDER BY activity_date DESC
    LIMIT 20
");
while ($row = $result->fetch_assoc()) {
    $recent_activities[] = $row;
}

// Get pending lowering orders
$pending_lowering = [];
$result = $conn->query("
    SELECT lo.id, lo.item_barcode, lo.from_location_code, lo.from_zone, 
           lo.quantity_at_source, lo.priority, lo.created_at,
           COALESCE(ad.name, ad.description, lo.item_barcode) as item_name
    FROM lowering_orders lo
    LEFT JOIN adddesc ad ON lo.item_barcode = ad.barcode
    WHERE lo.status IN ('pending', 'in_progress')
    ORDER BY lo.priority ASC, lo.created_at ASC
    LIMIT 10
");
while ($row = $result->fetch_assoc()) {
    $pending_lowering[] = $row;
}

echo json_encode([
    'success' => true,
    'stats' => $stats,
    'recent_orders' => $recent_orders,
    'ready_plates' => $ready_plates,
    'low_stock_items' => $low_stock_items,
    'recent_activities' => $recent_activities,
    'pending_lowering' => $pending_lowering
]);

$conn->close();
?>

