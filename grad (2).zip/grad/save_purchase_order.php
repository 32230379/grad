<?php
// Suppress any output before JSON
ob_start();
session_start();
header('Content-Type: application/json');

// Include database connection
include 'db_connect.php';

// Clear any output buffer
ob_clean();

// Check if tables exist, if not create them
$table_check = $conn->query("SHOW TABLES LIKE 'purchase_orders'");
if ($table_check->num_rows == 0) {
    $sql_file = @file_get_contents('create_supplier_tables.sql');
    if ($sql_file !== false && !empty($sql_file)) {
        // Execute SQL file
        $queries = array_filter(array_map('trim', explode(';', $sql_file)));
        foreach ($queries as $query) {
            if (!empty($query) && strpos($query, '--') !== 0) {
                $conn->query($query);
            }
        }
    } else {
        // Create tables manually if SQL file doesn't exist
        $conn->query("CREATE TABLE IF NOT EXISTS `suppliers` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `supplier_name` varchar(100) NOT NULL,
            `contact_person` varchar(100) DEFAULT NULL,
            `email` varchar(100) DEFAULT NULL,
            `phone` varchar(50) DEFAULT NULL,
            `address` text DEFAULT NULL,
            `status` enum('active','inactive') DEFAULT 'active',
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        
        $conn->query("CREATE TABLE IF NOT EXISTS `purchase_orders` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `po_number` varchar(100) NOT NULL,
            `supplier_id` int(11) NOT NULL,
            `order_date` date NOT NULL,
            `expected_delivery_date` date DEFAULT NULL,
            `tax_rate` decimal(5,2) DEFAULT 0.00,
            `tax_amount` decimal(10,2) DEFAULT 0.00,
            `subtotal` decimal(10,2) DEFAULT 0.00,
            `total_amount` decimal(10,2) DEFAULT 0.00,
            `status` enum('pending','partial','completed','cancelled') DEFAULT 'pending',
            `notes` text DEFAULT NULL,
            `created_by` varchar(100) DEFAULT NULL,
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `po_number` (`po_number`),
            KEY `supplier_id` (`supplier_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        
        $conn->query("CREATE TABLE IF NOT EXISTS `purchase_order_items` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `po_id` int(11) NOT NULL,
            `item_barcode` varchar(100) NOT NULL,
            `quantity_ordered` int(11) NOT NULL DEFAULT 0,
            `quantity_received` int(11) DEFAULT 0,
            `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
            `total_price` decimal(10,2) NOT NULL DEFAULT 0.00,
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `po_id` (`po_id`),
            KEY `item_barcode` (`item_barcode`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        
        $conn->query("CREATE TABLE IF NOT EXISTS `supplier_items` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `supplier_id` int(11) NOT NULL,
            `item_barcode` varchar(100) NOT NULL,
            `last_purchase_price` decimal(10,2) DEFAULT NULL,
            `last_purchase_date` date DEFAULT NULL,
            `is_primary` tinyint(1) DEFAULT 0,
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `supplier_item` (`supplier_id`, `item_barcode`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
}

$id = isset($_POST['id']) && !empty($_POST['id']) ? intval($_POST['id']) : null;
$po_number = trim($_POST['po_number']);
$supplier_id = intval($_POST['supplier_id']);
$order_date = $_POST['order_date'];
$expected_delivery_date = !empty($_POST['expected_delivery_date']) ? $_POST['expected_delivery_date'] : null;
$tax_rate = floatval($_POST['tax_rate'] ?? 0);
$notes = trim($_POST['notes'] ?? '');
$subtotal = floatval($_POST['subtotal'] ?? 0);
$tax_amount = floatval($_POST['tax_amount'] ?? 0);
$total_amount = floatval($_POST['total_amount'] ?? 0);
$items_json = $_POST['items'] ?? '[]';
$items = json_decode($items_json, true);
$created_by = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'System';

// Validate JSON decode
if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['success' => false, 'message' => 'Invalid items JSON: ' . json_last_error_msg()]);
    exit;
}

if (empty($po_number) || empty($supplier_id) || empty($order_date)) {
    echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
    exit;
}

if (empty($items) || !is_array($items)) {
    echo json_encode(['success' => false, 'message' => 'At least one item is required']);
    exit;
}

$conn->begin_transaction();

try {
    if ($id) {
        // Update existing PO
        $stmt = $conn->prepare("UPDATE purchase_orders SET po_number = ?, supplier_id = ?, order_date = ?, expected_delivery_date = ?, tax_rate = ?, tax_amount = ?, subtotal = ?, total_amount = ?, notes = ? WHERE id = ?");
        if (!$stmt) {
            throw new Exception("Failed to prepare update statement: " . $conn->error);
        }
        // Types: s=string, i=integer, d=double/decimal
        // 10 parameters in order:
        // 1. po_number (s), 2. supplier_id (i), 3. order_date (s), 4. expected_delivery_date (s), 
        // 5. tax_rate (d), 6. tax_amount (d), 7. subtotal (d), 8. total_amount (d), 
        // 9. notes (s), 10. id (i)
        // String should be: "sisdddddssi" = 11 chars but we have 10 params - ERROR!
        // Let me recount: s-i-s-s-d-d-d-d-s-i = "sisdddddssi" = 10 chars - CORRECT!
        $stmt->bind_param("sisdddddssi", $po_number, $supplier_id, $order_date, $expected_delivery_date, $tax_rate, $tax_amount, $subtotal, $total_amount, $notes, $id);
        $stmt->execute();
        $po_id = $id;
        
        // Delete old items
        $delete_stmt = $conn->prepare("DELETE FROM purchase_order_items WHERE po_id = ?");
        $delete_stmt->bind_param("i", $po_id);
        $delete_stmt->execute();
        $delete_stmt->close();
    } else {
        // Insert new PO
        $stmt = $conn->prepare("INSERT INTO purchase_orders (po_number, supplier_id, order_date, expected_delivery_date, tax_rate, tax_amount, subtotal, total_amount, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            throw new Exception("Failed to prepare statement: " . $conn->error);
        }
        // Types: s=string, i=integer, d=double/decimal
        // 10 parameters: po_number(s), supplier_id(i), order_date(s), expected_delivery_date(s), tax_rate(d), tax_amount(d), subtotal(d), total_amount(d), notes(s), created_by(s)
        $stmt->bind_param("sisssdddss", $po_number, $supplier_id, $order_date, $expected_delivery_date, $tax_rate, $tax_amount, $subtotal, $total_amount, $notes, $created_by);
        if (!$stmt->execute()) {
            throw new Exception("Failed to execute statement: " . $stmt->error);
        }
        $po_id = $conn->insert_id;
        if ($po_id == 0) {
            throw new Exception("Failed to get insert ID");
        }
    }
    $stmt->close();

    // Insert items
    $item_stmt = $conn->prepare("INSERT INTO purchase_order_items (po_id, item_barcode, quantity_ordered, unit_price, total_price) VALUES (?, ?, ?, ?, ?)");
    if (!$item_stmt) {
        throw new Exception("Failed to prepare item statement: " . $conn->error);
    }
    foreach ($items as $item) {
        $item_barcode = $item['item_barcode'] ?? '';
        $quantity_ordered = intval($item['quantity_ordered'] ?? 0);
        $unit_price = floatval($item['unit_price'] ?? 0);
        $total_price = floatval($item['total_price'] ?? 0);
        
        if (empty($item_barcode) || $quantity_ordered <= 0) {
            continue; // Skip invalid items
        }
        
        $item_stmt->bind_param("isidd", $po_id, $item_barcode, $quantity_ordered, $unit_price, $total_price);
        if (!$item_stmt->execute()) {
            throw new Exception("Failed to insert item: " . $item_stmt->error);
        }
        
        // Update supplier_items table with last purchase price (optional, ignore errors)
        $update_supplier_item = $conn->prepare("
            INSERT INTO supplier_items (supplier_id, item_barcode, last_purchase_price, last_purchase_date, is_primary)
            VALUES (?, ?, ?, ?, 0)
            ON DUPLICATE KEY UPDATE 
                last_purchase_price = VALUES(last_purchase_price),
                last_purchase_date = VALUES(last_purchase_date)
        ");
        if ($update_supplier_item) {
            $update_supplier_item->bind_param("isds", $supplier_id, $item_barcode, $unit_price, $order_date);
            $update_supplier_item->execute(); // Ignore errors for this optional operation
            $update_supplier_item->close();
        }
    }
    $item_stmt->close();

    $conn->commit();
    $response = ['success' => true, 'message' => 'Purchase order saved successfully', 'po_id' => $po_id];
} catch (Exception $e) {
    $conn->rollback();
    $response = ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
} catch (Error $e) {
    if (isset($conn)) {
        $conn->rollback();
    }
    $response = ['success' => false, 'message' => 'Fatal error: ' . $e->getMessage()];
}

// Ensure no output before JSON
ob_clean();
echo json_encode($response);

if (isset($conn)) {
    $conn->close();
}
exit;
?>



