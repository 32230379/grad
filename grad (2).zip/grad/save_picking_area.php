<?php
header('Content-Type: application/json');
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

$work_id = isset($_POST['work_id']) ? trim($_POST['work_id']) : '';
thi$area_code = isset($_POST['area']) ? trim($_POST['area']) : '';

if (empty($work_id)) {
    echo json_encode([
        'success' => false,
        'message' => 'Work ID is required'
    ]);
    exit;
}

// Check if picking order exists and is completed
$stmt = $conn->prepare("SELECT * FROM picking_orders WHERE work_id = ?");
$stmt->bind_param("s", $work_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Picking order not found'
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

$order = $result->fetch_assoc();
$stmt->close();

// Check if order has area column, if not, we'll add it
// First, check if column exists
$check_column = $conn->query("SHOW COLUMNS FROM picking_orders LIKE 'area'");
if ($check_column->num_rows === 0) {
    // Add area column
    $conn->query("ALTER TABLE picking_orders ADD COLUMN area VARCHAR(100) DEFAULT NULL AFTER branch");
}

// If area_code is provided, use it. Otherwise, get the default area for this branch
if (empty($area_code)) {
    // Get the default area for this branch (first active area for this branch)
    $area_stmt = $conn->prepare("SELECT * FROM areas WHERE branch = ? AND is_active = 1 ORDER BY id ASC LIMIT 1");
    $area_stmt->bind_param("s", $order['branch']);
    $area_stmt->execute();
    $area_result = $area_stmt->get_result();
    
    if ($area_result->num_rows === 0) {
        echo json_encode([
            'success' => false,
            'message' => 'No area found for branch "' . $order['branch'] . '". Please add an area for this branch in Manage Areas.'
        ]);
        $area_stmt->close();
        $conn->close();
        exit;
    }
    
    $area = $area_result->fetch_assoc();
    $area_code = $area['area_code'];
    $area_stmt->close();
} else {
    // Check if area exists and verify branch match
    $area_stmt = $conn->prepare("SELECT * FROM areas WHERE area_code = ? AND is_active = 1");
    $area_stmt->bind_param("s", $area_code);
    $area_stmt->execute();
    $area_result = $area_stmt->get_result();

    if ($area_result->num_rows === 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Area not found or inactive! Please check the area barcode and try again.'
        ]);
        $area_stmt->close();
        $conn->close();
        exit;
    }

    $area = $area_result->fetch_assoc();
    $area_stmt->close();

    // Verify branch match
    if (strcasecmp(trim($order['branch']), trim($area['branch'])) !== 0) {
        echo json_encode([
            'success' => false,
            'message' => 'This area is not for your work order! Your work order is for "' . $order['branch'] . '" but this area "' . $area['area_name'] . ' (' . $area_code . ')' . '" is for "' . $area['branch'] . '". Please scan the correct area for your branch.'
        ]);
        $conn->close();
        exit;
    }
}

// Check if there are remaining pending items
$check_remaining = $conn->prepare("SELECT COUNT(*) as remaining FROM picking_order_items WHERE work_id = ? AND status = 'pending'");
$check_remaining->bind_param("s", $work_id);
$check_remaining->execute();
$remaining_result = $check_remaining->get_result();
$remaining_row = $remaining_result->fetch_assoc();
$remaining_count = $remaining_row['remaining'] ?? 0;
$check_remaining->close();

// Update picking order with area (store area_code)
// If there are remaining items, keep status as 'in_progress', otherwise mark as 'completed'
if ($remaining_count > 0) {
    $update_stmt = $conn->prepare("UPDATE picking_orders SET area = ?, status = 'in_progress' WHERE work_id = ?");
} else {
    $update_stmt = $conn->prepare("UPDATE picking_orders SET area = ?, status = 'completed' WHERE work_id = ?");
}
$update_stmt->bind_param("ss", $area_code, $work_id);
$update_stmt->execute();

if ($update_stmt->affected_rows > 0) {
    $message = "Area '{$area['area_name']}' ({$area_code}) saved successfully for work order '{$work_id}'";
    if ($remaining_count > 0) {
        $message .= ". {$remaining_count} item(s) remaining. You can scan the same work ID again to continue with remaining items on a new plate.";
    } else {
        $message .= ". All items have been picked. Work order completed.";
    }
    
    echo json_encode([
        'success' => true,
        'message' => $message,
        'remaining_items' => $remaining_count
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to save area'
    ]);
}

$update_stmt->close();
$conn->close();
?>
