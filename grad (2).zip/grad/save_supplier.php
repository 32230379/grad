<?php
session_start();
header('Content-Type: application/json');
include 'db_connect.php';

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'manager') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Check if suppliers table exists, if not create it
$check_table = $conn->query("SHOW TABLES LIKE 'suppliers'");
if ($check_table->num_rows == 0) {
    $create_table = "CREATE TABLE IF NOT EXISTS `suppliers` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `supplier_name` varchar(100) NOT NULL,
        `contact_person` varchar(100) DEFAULT NULL,
        `email` varchar(100) DEFAULT NULL,
        `phone` varchar(50) DEFAULT NULL,
        `address` text DEFAULT NULL,
        `status` enum('active','inactive') DEFAULT 'active',
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $conn->query($create_table);
}

$id = isset($_POST['id']) && !empty($_POST['id']) ? intval($_POST['id']) : null;
$supplier_name = trim($_POST['supplier_name'] ?? '');
$contact_person = trim($_POST['contact_person'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$address = trim($_POST['address'] ?? '');
$status = $_POST['status'] ?? 'active';

if (empty($supplier_name)) {
    echo json_encode(['success' => false, 'message' => 'Supplier name is required']);
    exit;
}

if ($id) {
    // Update existing supplier
    $stmt = $conn->prepare("UPDATE suppliers SET supplier_name = ?, contact_person = ?, email = ?, phone = ?, address = ?, status = ? WHERE id = ?");
    $stmt->bind_param("ssssssi", $supplier_name, $contact_person, $email, $phone, $address, $status, $id);
} else {
    // Insert new supplier
    $stmt = $conn->prepare("INSERT INTO suppliers (supplier_name, contact_person, email, phone, address, status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $supplier_name, $contact_person, $email, $phone, $address, $status);
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => $id ? 'Supplier updated successfully' : 'Supplier added successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
}

$stmt->close();
$conn->close();
?>
