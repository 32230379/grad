<?php
session_start();
header('Content-Type: application/json');
include 'db_connect.php';

// Get Purchase Orders that are pending or partial (not completed or cancelled)
$query = "
    SELECT po.id, po.po_number, s.supplier_name, po.status
    FROM purchase_orders po
    LEFT JOIN suppliers s ON po.supplier_id = s.id
    WHERE po.status IN ('pending', 'partial')
    ORDER BY po.order_date DESC, po.id DESC
";

$result = $conn->query($query);
$orders = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = [
            'id' => $row['id'],
            'po_number' => $row['po_number'],
            'supplier_name' => $row['supplier_name'] ?? 'Unknown Supplier',
            'status' => $row['status']
        ];
    }
}

echo json_encode(['success' => true, 'orders' => $orders]);
$conn->close();
?>

