<?php
header('Content-Type: application/json');
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_name'])) {
    echo json_encode(["status" => "error", "msg" => "Unauthorized access"]);
    exit();
}

$plate = $_POST['plate_id'] ?? '';
$barcode = $_POST['barcode'] ?? '';
$name = $_POST['name'] ?? '';
$desc = $_POST['description'] ?? '';
$qty = intval($_POST['quantity'] ?? 0);
$exp = $_POST['expiry'] ?? '';
$po_id = !empty($_POST['po_id']) ? intval($_POST['po_id']) : null;
$received_by = $_SESSION['user_name'];

if (empty($plate) || empty($barcode) || $qty <= 0 || empty($exp)) {
    echo json_encode(["status" => "error", "msg" => "Missing required fields"]);
    exit();
}

// Check if po_id column exists in receiving table, if not add it
$check_column = $conn->query("SHOW COLUMNS FROM receiving LIKE 'po_id'");
if ($check_column->num_rows == 0) {
    $conn->query("ALTER TABLE receiving ADD COLUMN po_id int(11) DEFAULT NULL AFTER plate_id");
    $conn->query("ALTER TABLE receiving ADD KEY idx_po_id (po_id)");
}

$conn->begin_transaction();

try {
    // Insert into receiving table
    if ($po_id) {
        $stmt = $conn->prepare("INSERT INTO receiving (plate_id, po_id, item_barcode, item_name, description, quantity, expiry_date, receive_date, received_by) VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE(), ?)");
        $stmt->bind_param("sisssiss", $plate, $po_id, $barcode, $name, $desc, $qty, $exp, $received_by);
    } else {
$stmt = $conn->prepare("INSERT INTO receiving (plate_id, item_barcode, item_name, description, quantity, expiry_date, receive_date, received_by) VALUES (?, ?, ?, ?, ?, ?, CURDATE(), ?)");
$stmt->bind_param("ssssiss", $plate, $barcode, $name, $desc, $qty, $exp, $received_by);
    }

    if (!$stmt->execute()) {
        throw new Exception("Failed to insert receiving record: " . $stmt->error);
    }
    $stmt->close();
    
    // Add item to inventory at "rec" location (receiving area)
    $checkRecInv = $conn->prepare("SELECT * FROM inventory WHERE item_barcode = ? AND location_code = 'rec'");
    $checkRecInv->bind_param("s", $barcode);
    $checkRecInv->execute();
    $recInvResult = $checkRecInv->get_result();
    
    if ($recInvResult->num_rows > 0) {
        // Update existing "rec" inventory
        $updateRecInv = $conn->prepare("UPDATE inventory SET quantity = quantity + ?, last_update = NOW() WHERE item_barcode = ? AND location_code = 'rec'");
        $updateRecInv->bind_param("is", $qty, $barcode);
        $updateRecInv->execute();
        $updateRecInv->close();
} else {
        // Insert new "rec" inventory
        $insertRecInv = $conn->prepare("INSERT INTO inventory (item_barcode, location_code, zone, quantity, last_update) VALUES (?, 'rec', NULL, ?, NOW())");
        $insertRecInv->bind_param("si", $barcode, $qty);
        $insertRecInv->execute();
        $insertRecInv->close();
    }
    $checkRecInv->close();
    
    // If PO ID is provided, validate and update purchase_order_items
    if ($po_id) {
        // Find the PO item for this barcode
        $po_item_stmt = $conn->prepare("SELECT id, quantity_ordered, quantity_received FROM purchase_order_items WHERE po_id = ? AND item_barcode = ?");
        $po_item_stmt->bind_param("is", $po_id, $barcode);
        $po_item_stmt->execute();
        $po_item_result = $po_item_stmt->get_result();
        
        if ($po_item_result->num_rows == 0) {
            // Item not found in PO - reject
            throw new Exception("Wrong barcode! This item is not in the selected PO.");
        }
        
        if ($po_item_result->num_rows > 0) {
            $po_item = $po_item_result->fetch_assoc();
            $quantity_ordered = intval($po_item['quantity_ordered']);
            $quantity_received = intval($po_item['quantity_received'] ?? 0);
            $new_quantity_received = $quantity_received + $qty;
            
            // Validate that new quantity doesn't exceed ordered quantity
            if ($new_quantity_received > $quantity_ordered) {
                throw new Exception("Quantity exceeds! Ordered: {$quantity_ordered}, Already received: {$quantity_received}, Trying to add: {$qty}. Maximum allowed: " . ($quantity_ordered - $quantity_received));
            }
            
            // Update quantity_received
            $update_stmt = $conn->prepare("UPDATE purchase_order_items SET quantity_received = ? WHERE id = ?");
            $update_stmt->bind_param("ii", $new_quantity_received, $po_item['id']);
            $update_stmt->execute();
            $update_stmt->close();
            
            // Check if all items are received and update PO status
            $check_complete_stmt = $conn->prepare("
                SELECT 
                    COUNT(*) as total_items,
                    SUM(CASE WHEN quantity_received >= quantity_ordered THEN 1 ELSE 0 END) as completed_items
                FROM purchase_order_items
                WHERE po_id = ?
            ");
            $check_complete_stmt->bind_param("i", $po_id);
            $check_complete_stmt->execute();
            $complete_result = $check_complete_stmt->get_result();
            $complete_data = $complete_result->fetch_assoc();
            $check_complete_stmt->close();
            
            // Update PO status
            $new_status = 'partial';
            if ($complete_data['total_items'] > 0 && $complete_data['completed_items'] == $complete_data['total_items']) {
                $new_status = 'completed';
            } else if ($complete_data['completed_items'] > 0) {
                $new_status = 'partial';
}

            $update_po_stmt = $conn->prepare("UPDATE purchase_orders SET status = ? WHERE id = ?");
            $update_po_stmt->bind_param("si", $new_status, $po_id);
            $update_po_stmt->execute();
            $update_po_stmt->close();
        }
        $po_item_stmt->close();
    }
    
    $conn->commit();
    echo json_encode(["status" => "success", "msg" => "Item received successfully" . ($po_id ? " and linked to PO" : "")]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(["status" => "error", "msg" => $e->getMessage()]);
}

$conn->close();
?>
