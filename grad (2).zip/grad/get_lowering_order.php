<?php
header('Content-Type: application/json');
include 'db_connect.php';

session_start();

// Check if zone tracking columns exist, if not add them
$check_completed_zones = $conn->query("SHOW COLUMNS FROM lowering_orders LIKE 'completed_zones'");
if ($check_completed_zones->num_rows == 0) {
    $conn->query("ALTER TABLE `lowering_orders` ADD COLUMN `completed_zones` TEXT DEFAULT NULL COMMENT 'Comma-separated list of completed zones (e.g., A,B,C)' AFTER `created_by`");
}
$check_assigned_user = $conn->query("SHOW COLUMNS FROM lowering_orders LIKE 'assigned_user'");
if ($check_assigned_user->num_rows == 0) {
    $conn->query("ALTER TABLE `lowering_orders` ADD COLUMN `assigned_user` VARCHAR(100) DEFAULT NULL COMMENT 'Username assigned to this zone' AFTER `completed_zones`");
}
$check_assigned_zone = $conn->query("SHOW COLUMNS FROM lowering_orders LIKE 'assigned_zone'");
if ($check_assigned_zone->num_rows == 0) {
    $conn->query("ALTER TABLE `lowering_orders` ADD COLUMN `assigned_zone` VARCHAR(10) DEFAULT NULL COMMENT 'Zone assigned to user' AFTER `assigned_user`");
}

$current_user = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : null;
$requested_zone = isset($_GET['zone']) ? trim($_GET['zone']) : null;

// Get all available zones from zones table
$zones_query = "SELECT zone_code, zone_name FROM zones ORDER BY zone_code";
$zones_result = $conn->query($zones_query);
$all_zones = [];
while ($row = $zones_result->fetch_assoc()) {
    $all_zones[] = $row['zone_code'];
}

// If zone is requested, get orders for that zone only
// Otherwise, get orders for zones that are not completed
// Show orders that are either not assigned, or assigned to current user, or assigned to different zone
if ($requested_zone) {
    // Get orders for specific zone that are not completed for this zone
    // Priority: orders assigned to current user for this zone > unassigned orders for this zone
    $stmt = $conn->prepare("
        SELECT lo.*, 
               COALESCE(ad.description, ad.name, lo.item_barcode) as item_description,
               CASE 
                   WHEN lo.completed_zones IS NULL OR lo.completed_zones = '' THEN ''
                   ELSE lo.completed_zones
               END as completed_zones_list
        FROM lowering_orders lo
        LEFT JOIN adddesc ad ON lo.item_barcode = ad.barcode
        WHERE lo.status IN ('pending', 'in_progress')
          AND lo.from_zone = ?
          AND (lo.completed_zones IS NULL 
               OR lo.completed_zones = '' 
               OR FIND_IN_SET(?, lo.completed_zones) = 0)
          AND (lo.assigned_user IS NULL 
               OR lo.assigned_user = '' 
               OR lo.assigned_user = ?
               OR (lo.assigned_user != ? AND lo.assigned_zone != ?))
        ORDER BY 
            CASE WHEN lo.assigned_user = ? AND lo.assigned_zone = ? THEN 0 ELSE 1 END,
            lo.priority ASC, 
            lo.created_at ASC
        LIMIT 1
    ");
    $stmt->bind_param("sssssss", $requested_zone, $requested_zone, $current_user, $current_user, $requested_zone, $current_user, $requested_zone);
} else {
    // Get orders for any zone that is not completed
    // Show all available orders - prioritize orders assigned to current user, then unassigned orders
    // Allow users to see orders even if assigned to others (they can reassign by selecting zone)
    $stmt = $conn->prepare("
        SELECT lo.*, 
               COALESCE(ad.description, ad.name, lo.item_barcode) as item_description,
               CASE 
                   WHEN lo.completed_zones IS NULL OR lo.completed_zones = '' THEN ''
                   ELSE lo.completed_zones
               END as completed_zones_list
        FROM lowering_orders lo
        LEFT JOIN adddesc ad ON lo.item_barcode = ad.barcode
        WHERE lo.status IN ('pending', 'in_progress')
          AND (
               lo.from_zone IS NULL 
               OR lo.from_zone = '' 
               OR lo.completed_zones IS NULL 
               OR lo.completed_zones = '' 
               OR FIND_IN_SET(lo.from_zone, lo.completed_zones) = 0
          )
        ORDER BY 
            CASE WHEN lo.assigned_user = ? THEN 0 
                 WHEN lo.assigned_user IS NULL OR lo.assigned_user = '' THEN 1 
                 ELSE 2 END,
            lo.priority ASC, 
            lo.created_at ASC
        LIMIT 1
    ");
    $stmt->bind_param("s", $current_user);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $order = $result->fetch_assoc();
    
    // Parse completed zones
    $completed_zones = [];
    if (!empty($order['completed_zones_list'])) {
        $completed_zones = array_map('trim', explode(',', $order['completed_zones_list']));
    }
    
    // Get available zones (zones that are not completed for this order)
    $available_zones = [];
    if (!empty($order['from_zone'])) {
        // If this order has a specific zone, check if it's completed
        if (!in_array($order['from_zone'], $completed_zones)) {
            $available_zones[] = $order['from_zone'];
        }
    } else {
        // If no specific zone, show all zones that are not completed
        foreach ($all_zones as $zone) {
            if (!in_array($zone, $completed_zones)) {
                $available_zones[] = $zone;
            }
        }
    }
    
    $order['available_zones'] = $available_zones;
    $order['completed_zones'] = $completed_zones;
    
    echo json_encode([
        'success' => true,
        'order' => $order,
        'all_zones' => $all_zones
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'No lowering orders available for your zone',
        'all_zones' => $all_zones
    ]);
}

$stmt->close();
$conn->close();
?>
