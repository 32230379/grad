<?php
header('Content-Type: application/json');
include 'db_connect.php';

if (!isset($_GET['item_barcode'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Item barcode is required'
    ]);
    exit;
}

$item_barcode = trim($_GET['item_barcode']);

// Get all locations where this item is available in inventory (quantity > 0)
// Show only actual locations from inventory table - no duplicates
$stmt = $conn->prepare("
    SELECT 
        i.location_code,
        i.zone,
        i.quantity,
        loc.full_location_code,
        loc.shelf_number,
        COALESCE(z.zone_code, i.zone) as zone_code
    FROM inventory i
    LEFT JOIN locations loc ON i.location_code = loc.location_code
    LEFT JOIN zones z ON loc.zone_id = z.id
    WHERE i.item_barcode = ? 
        AND i.quantity > 0
    ORDER BY 
        CASE WHEN loc.shelf_number = 0 THEN 0 ELSE 1 END,  -- Priority: shelf_number = 0 (bottom) first
        COALESCE(loc.shelf_number, 999) ASC,               -- Then 1, then 2, etc.
        i.quantity DESC                                     -- Then by quantity
");

$stmt->bind_param("s", $item_barcode);
$stmt->execute();
$result = $stmt->get_result();

$locations = [];
$seen_locations = []; // Track seen location_codes to avoid duplicates (same location_code should appear only once)

if ($result->num_rows === 0) {
    // No locations found in inventory
    echo json_encode([
        'success' => false,
        'message' => 'Item not found in inventory or out of stock',
        'locations' => []
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

while ($row = $result->fetch_assoc()) {
    // Use location_code as unique key to avoid duplicates
    // Same location_code (e.g., "1-1") should appear only once, regardless of zone
    $location_key = $row['location_code'];
    
    // Skip if we've already seen this exact location_code
    if (isset($seen_locations[$location_key])) {
        continue;
    }
    
    $seen_locations[$location_key] = true;
    
    // Build full_location_code: use from locations table if available, otherwise construct from zone + location_code
    $zone_code = $row['zone_code'] ?? $row['zone'] ?? 'A';
    $full_location = $row['full_location_code'] ?? ($zone_code . '-' . $row['location_code']);
    
    $locations[] = [
        'location_code' => $row['location_code'],
        'zone' => $zone_code,
        'full_location_code' => $full_location,
        'quantity' => intval($row['quantity']), // Ensure quantity is integer
        'shelf_number' => $row['shelf_number'] ?? null
    ];
}

$stmt->close();
$conn->close();

echo json_encode([
    'success' => true,
    'locations' => $locations
]);
?>
