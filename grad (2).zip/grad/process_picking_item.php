<?php
// Turn off error display and enable output buffering to catch any errors
error_reporting(E_ALL);
ini_set('display_errors', 0);
ob_start();

session_start();

// Include database connection
include 'db_connect.php';

// Check for database connection error
if (!$conn) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed'
    ]);
    exit;
}

// Check for any output before JSON (errors, warnings, etc.)
$output = ob_get_clean();
if (!empty($output) && trim($output) !== '') {
    // If there's output, it's likely an error - log it and return JSON error
    error_log("process_picking_item.php output before JSON: " . $output);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Server error occurred. Please check server logs.',
        'debug' => substr($output, 0, 200) // Limit debug output
    ]);
    exit;
}

// Set JSON header after checking for errors
header('Content-Type: application/json');

// Add picked_by column to picking_log if it doesn't exist
$check_column = $conn->query("SHOW COLUMNS FROM picking_log LIKE 'picked_by'");
if ($check_column->num_rows == 0) {
    $conn->query("ALTER TABLE picking_log ADD COLUMN picked_by varchar(100) DEFAULT NULL AFTER picked_at");
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

$work_id = isset($_POST['work_id']) ? trim($_POST['work_id']) : '';
$item_barcode = isset($_POST['item_barcode']) ? trim($_POST['item_barcode']) : '';
$action = isset($_POST['action']) ? trim($_POST['action']) : 'pick';
$plate_id = isset($_POST['plate_id']) ? trim($_POST['plate_id']) : '';

// Ensure item_barcode is not empty and is exact (no partial matching)
if (empty($item_barcode)) {
    echo json_encode([
        'success' => false,
        'message' => 'Item barcode is required and cannot be empty'
    ]);
    exit;
}

// For seal_plate action, only work_id is required (not item_barcode)
if (empty($work_id)) {
    echo json_encode([
        'success' => false,
        'message' => 'Work ID is required'
    ]);
    exit;
}

// For pick and skip actions, item_barcode is required
if (($action === 'pick' || $action === 'skip') && empty($item_barcode)) {
    echo json_encode([
        'success' => false,
        'message' => 'Item Barcode is required'
    ]);
    exit;
}

// Check if the picking order exists
$stmt = $conn->prepare("SELECT * FROM picking_orders WHERE work_id = ?");
$stmt->bind_param("s", $work_id);
$stmt->execute();
$orderResult = $stmt->get_result();

if ($orderResult->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Picking order not found'
    ]);
    exit;
}

// Handle skip action - move item to end of queue instead of marking as skipped
if ($action === 'skip') {
    $conn->begin_transaction();
    try {
        // Get the maximum sequence number for this work_id (items that are still pending)
        $max_seq_stmt = $conn->prepare("SELECT COALESCE(MAX(sequence), 0) as max_sequence FROM picking_order_items WHERE work_id = ? AND status = 'pending'");
        $max_seq_stmt->bind_param("s", $work_id);
        $max_seq_stmt->execute();
        $max_seq_result = $max_seq_stmt->get_result();
        $max_seq_row = $max_seq_result->fetch_assoc();
        $new_sequence = ($max_seq_row['max_sequence'] ?? 0) + 1;
        $max_seq_stmt->close();
        
        // Update the item: set sequence to highest (move to end of queue) but keep status as 'pending'
        // This way it will be picked at the end of the order
        $stmt = $conn->prepare("UPDATE picking_order_items SET sequence = ? WHERE work_id = ? AND item_barcode = ? AND status = 'pending'");
        $stmt->bind_param("iss", $new_sequence, $work_id, $item_barcode);
        $stmt->execute();
        
        if ($stmt->affected_rows === 0) {
            throw new Exception("Item not found or already processed");
        }
        
        // Update picking_orders status to 'in_progress' if it's still 'pending'
        $update_order_stmt = $conn->prepare("UPDATE picking_orders SET status = 'in_progress' WHERE work_id = ? AND status = 'pending'");
        $update_order_stmt->bind_param("s", $work_id);
        $update_order_stmt->execute();
        $update_order_stmt->close();
        
        $conn->commit();
        echo json_encode([
            'success' => true,
            'message' => 'Item moved to end of queue. It will be picked after all other items.'
        ]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode([
            'success' => false,
            'message' => 'Failed to skip item: ' . $e->getMessage()
        ]);
    }
    $stmt->close();
    $conn->close();
    exit;
}

// Handle full action - mark current plate as full, remove plate_id from remaining pending items
if ($action === 'full') {
    if (empty($plate_id)) {
        echo json_encode([
            'success' => false,
            'message' => 'Plate ID is required to mark plate as full'
        ]);
        exit;
    }
    
    $conn->begin_transaction();
    try {
        // Count how many items are already picked with this plate_id
        $count_picked_stmt = $conn->prepare("SELECT COUNT(*) as picked_count FROM picking_order_items WHERE work_id = ? AND plate_id = ? AND status = 'picked'");
        $count_picked_stmt->bind_param("ss", $work_id, $plate_id);
        $count_picked_stmt->execute();
        $count_result = $count_picked_stmt->get_result();
        $count_row = $count_result->fetch_assoc();
        $picked_count = $count_row['picked_count'] ?? 0;
        $count_picked_stmt->close();
        
        // Remove plate_id from all remaining pending items (they will be available for a new plate)
        $remove_plate_stmt = $conn->prepare("UPDATE picking_order_items SET plate_id = NULL WHERE work_id = ? AND plate_id = ? AND status = 'pending'");
        $remove_plate_stmt->bind_param("ss", $work_id, $plate_id);
        $remove_plate_stmt->execute();
        $remaining_items = $remove_plate_stmt->affected_rows;
        $remove_plate_stmt->close();
        
        // Update picking_orders status to 'in_progress' if it's still 'pending'
        $update_order_stmt = $conn->prepare("UPDATE picking_orders SET status = 'in_progress' WHERE work_id = ? AND status = 'pending'");
        $update_order_stmt->bind_param("s", $work_id);
        $update_order_stmt->execute();
        $update_order_stmt->close();
        
        $conn->commit();
        
        $message = "Plate '{$plate_id}' marked as FULL. {$picked_count} item(s) picked on this plate. ";
        if ($remaining_items > 0) {
            $message .= "{$remaining_items} remaining item(s) are now available for a new plate. Please scan area to complete this work order, then scan the same work ID again to continue with remaining items.";
        } else {
            $message .= "All items have been picked. Please scan area to complete this work order.";
        }
        
        echo json_encode([
            'success' => true,
            'message' => $message,
            'picked_count' => $picked_count,
            'remaining_items' => $remaining_items,
            'show_area' => true  // Flag to indicate area input should be shown
        ]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode([
            'success' => false,
            'message' => 'Failed to mark plate as full: ' . $e->getMessage()
        ]);
    }
    $conn->close();
    exit;
}

// Handle seal plate action - close current plate, save area, remove plate_id from remaining items
if ($action === 'seal_plate') {
    if (empty($plate_id)) {
        echo json_encode([
            'success' => false,
            'message' => 'Plate ID is required to seal plate'
        ]);
        exit;
    }
    
    $area_code = isset($_POST['area']) ? trim($_POST['area']) : '';
    
    $conn->begin_transaction();
    try {
        // Get picking order to check branch
        $order_stmt = $conn->prepare("SELECT * FROM picking_orders WHERE work_id = ?");
        $order_stmt->bind_param("s", $work_id);
        $order_stmt->execute();
        $order_result = $order_stmt->get_result();
        if ($order_result->num_rows === 0) {
            throw new Exception("Picking order not found");
        }
        $order = $order_result->fetch_assoc();
        $order_stmt->close();
        
        // If area_code is provided, use it. Otherwise, get the default area for this branch
        if (empty($area_code)) {
            // Get the default area for this branch (first active area for this branch)
            $area_stmt = $conn->prepare("SELECT * FROM areas WHERE branch = ? AND is_active = 1 ORDER BY id ASC LIMIT 1");
            $area_stmt->bind_param("s", $order['branch']);
            $area_stmt->execute();
            $area_result = $area_stmt->get_result();
            
            if ($area_result->num_rows === 0) {
                throw new Exception("No area found for branch \"" . $order['branch'] . "\". Please add an area for this branch in Manage Areas.");
            }
            
            $area = $area_result->fetch_assoc();
            $area_code = $area['area_code'];
            $area_stmt->close();
        } else {
            // Check if area exists and verify branch match
            $area_stmt = $conn->prepare("SELECT * FROM areas WHERE area_code = ? AND is_active = 1");
            $area_stmt->bind_param("s", $area_code);
            $area_stmt->execute();
            $area_result = $area_stmt->get_result();
            
            if ($area_result->num_rows === 0) {
                throw new Exception("Area not found or inactive! Please check the area barcode and try again.");
            }
            
            $area = $area_result->fetch_assoc();
            $area_stmt->close();
            
            // Verify branch match
            if (strcasecmp(trim($order['branch']), trim($area['branch'])) !== 0) {
                throw new Exception("This area is not for your work order! Your work order is for \"" . $order['branch'] . "\" but this area \"" . $area['area_name'] . " (" . $area_code . ")" . "\" is for \"" . $area['branch'] . "\". Please scan the correct area for your branch.");
            }
        }
        
        // Count how many items are already picked with this plate_id
        $count_picked_stmt = $conn->prepare("SELECT COUNT(*) as picked_count FROM picking_order_items WHERE work_id = ? AND plate_id = ? AND status = 'picked'");
        $count_picked_stmt->bind_param("ss", $work_id, $plate_id);
        $count_picked_stmt->execute();
        $count_result = $count_picked_stmt->get_result();
        $count_row = $count_result->fetch_assoc();
        $picked_count = $count_row['picked_count'] ?? 0;
        $count_picked_stmt->close();
        
        // Remove plate_id from all remaining pending items (they will be available for a new plate)
        $remove_plate_stmt = $conn->prepare("UPDATE picking_order_items SET plate_id = NULL WHERE work_id = ? AND plate_id = ? AND status = 'pending'");
        $remove_plate_stmt->bind_param("ss", $work_id, $plate_id);
        $remove_plate_stmt->execute();
        $remaining_items = $remove_plate_stmt->affected_rows;
        $remove_plate_stmt->close();
        
        // Save area for this plate/work order
        // Check if order has area column, if not, we'll add it
        $check_column = $conn->query("SHOW COLUMNS FROM picking_orders LIKE 'area'");
        if ($check_column->num_rows === 0) {
            $conn->query("ALTER TABLE picking_orders ADD COLUMN area VARCHAR(100) DEFAULT NULL AFTER branch");
        }
        
        // Update picking order with area (store area_code)
        // If there are remaining items, keep status as 'in_progress', otherwise mark as 'completed'
        if ($remaining_items > 0) {
            $update_area_stmt = $conn->prepare("UPDATE picking_orders SET area = ?, status = 'in_progress' WHERE work_id = ?");
        } else {
            $update_area_stmt = $conn->prepare("UPDATE picking_orders SET area = ?, status = 'completed' WHERE work_id = ?");
        }
        $update_area_stmt->bind_param("ss", $area_code, $work_id);
        $update_area_stmt->execute();
        $update_area_stmt->close();
        
        // Update picking_orders status to 'in_progress' if it's still 'pending'
        $update_order_stmt = $conn->prepare("UPDATE picking_orders SET status = 'in_progress' WHERE work_id = ? AND status = 'pending'");
        $update_order_stmt->bind_param("s", $work_id);
        $update_order_stmt->execute();
        $update_order_stmt->close();
        
        $conn->commit();
        
        $message = "Plate '{$plate_id}' sealed and placed in area '{$area['area_name']}' ({$area_code}). {$picked_count} item(s) picked on this plate. ";
        if ($remaining_items > 0) {
            $message .= "{$remaining_items} remaining item(s) are now available for a new plate. Please scan the work ID again to continue.";
        } else {
            $message .= "All items have been picked. Work order completed.";
        }
        
        echo json_encode([
            'success' => true,
            'message' => $message,
            'picked_count' => $picked_count,
            'remaining_items' => $remaining_items
        ]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode([
            'success' => false,
            'message' => 'Failed to seal plate: ' . $e->getMessage()
        ]);
    }
    $conn->close();
    exit;
}

// Handle pick action
$quantity_picked = isset($_POST['quantity_picked']) ? intval($_POST['quantity_picked']) : 0;
$target_lp = isset($_POST['target_lp']) ? trim($_POST['target_lp']) : '';

if ($quantity_picked <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid quantity'
    ]);
    exit;
}

// Get the order item details
$stmt = $conn->prepare("SELECT * FROM picking_order_items WHERE work_id = ? AND item_barcode = ? AND status = 'pending'");
$stmt->bind_param("ss", $work_id, $item_barcode);
$stmt->execute();
$itemResult = $stmt->get_result();

if ($itemResult->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Item not found in order or already processed'
    ]);
    exit;
}

$orderItem = $itemResult->fetch_assoc();
$required_quantity = $orderItem['quantity_required'];

// Get inventory information
// System finds best location automatically based on shelf priority (rack-shelf format)
// Priority: lower shelves first (shelf_number ASC)
// If override_location_code is provided, use it (picker selected a different location)
$override_location = isset($_POST['override_location_code']) && !empty($_POST['override_location_code']) 
    ? trim($_POST['override_location_code']) 
    : null;
$location_code = $override_location ?? ($orderItem['location_code'] ?? '');

// Get inventory with location priority (rack-shelf format: 1-0, 2-3, etc.)
// Priority: shelf_number = 0 (bottom shelf) first, then 1, then 2
// Join with locations table to get shelf_number for priority
if ($override_location) {
    // If override location is provided, MUST find item at that exact location
    // Do NOT fall back to other locations - this is an explicit override
    // Use exact match for item_barcode (not LIKE) to ensure unique barcode matching
    $stmt = $conn->prepare("
        SELECT i.*, loc.shelf_number 
        FROM inventory i
        LEFT JOIN locations loc ON i.location_code = loc.location_code
        WHERE i.item_barcode = ? 
            AND i.location_code = ? 
            AND i.quantity > 0
        LIMIT 1
    ");
    if (!$stmt) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $conn->error
        ]);
        exit;
    }
    $stmt->bind_param("ss", $item_barcode, $override_location);
    if (!$stmt->execute()) {
        echo json_encode([
            'success' => false,
            'message' => 'Database query error: ' . $stmt->error
        ]);
        exit;
    }
    $invResult = $stmt->get_result();
    
    // If not found at override location, return error - do NOT search other locations
    if ($invResult->num_rows === 0) {
        // Check if item exists at all in inventory
        $check_stmt = $conn->prepare("SELECT location_code, quantity FROM inventory WHERE item_barcode = ? AND quantity > 0 LIMIT 5");
        $check_stmt->bind_param("s", $item_barcode);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $available_locations = [];
        while ($row = $check_result->fetch_assoc()) {
            $available_locations[] = $row['location_code'] . " (Qty: " . $row['quantity'] . ")";
        }
        $check_stmt->close();
        
        $locations_msg = !empty($available_locations) 
            ? " Available locations: " . implode(", ", $available_locations)
            : " Item not found in inventory.";
        
        echo json_encode([
            'success' => false,
            'message' => "Item '{$item_barcode}' not found at location '{$override_location}'.{$locations_msg}"
        ]);
        exit;
    }
    $stmt->close();
} else if ($location_code) {
    // Original location specified, try exact location first
    $stmt = $conn->prepare("
        SELECT i.*, loc.shelf_number 
        FROM inventory i
        LEFT JOIN locations loc ON i.location_code = loc.location_code
        WHERE i.item_barcode = ? 
            AND i.location_code = ? 
            AND i.quantity > 0
        ORDER BY 
            CASE WHEN loc.shelf_number = 0 THEN 0 ELSE 1 END,  -- Priority: shelf_number = 0 (bottom) first
            COALESCE(loc.shelf_number, 999) ASC
        LIMIT 1
    ");
    $stmt->bind_param("ss", $item_barcode, $location_code);
    $stmt->execute();
    $invResult = $stmt->get_result();
    
    // If not found at exact location, try any location with priority (shelf_number = 0 first)
    if ($invResult->num_rows === 0) {
        $stmt = $conn->prepare("
            SELECT i.*, loc.shelf_number 
            FROM inventory i
            LEFT JOIN locations loc ON i.location_code = loc.location_code
            WHERE i.item_barcode = ? 
                AND i.quantity > 0
            ORDER BY 
                CASE WHEN loc.shelf_number = 0 THEN 0 ELSE 1 END,  -- Priority: shelf_number = 0 (bottom) first
                COALESCE(loc.shelf_number, 999) ASC,               -- Then 1, then 2, etc.
                i.quantity DESC                                     -- Then by quantity
            LIMIT 1
        ");
        $stmt->bind_param("s", $item_barcode);
        $stmt->execute();
        $invResult = $stmt->get_result();
    }
} else {
    // No location specified, get from any location with shelf priority (shelf_number = 0 first)
    $stmt = $conn->prepare("
        SELECT i.*, loc.shelf_number 
        FROM inventory i
        LEFT JOIN locations loc ON i.location_code = loc.location_code
        WHERE i.item_barcode = ? 
            AND i.quantity > 0
        ORDER BY 
            CASE WHEN loc.shelf_number = 0 THEN 0 ELSE 1 END,  -- Priority: shelf_number = 0 (bottom) first
            COALESCE(loc.shelf_number, 999) ASC,               -- Then 1, then 2, etc.
            i.quantity DESC                                     -- Then by quantity
        LIMIT 1
    ");
    $stmt->bind_param("s", $item_barcode);
    $stmt->execute();
    $invResult = $stmt->get_result();
}

if ($invResult->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Item not found in inventory or out of stock'
    ]);
    exit;
}

$inventory = $invResult->fetch_assoc();
$available_quantity = $inventory['quantity'];
// If override location was used, use it; otherwise use actual location from inventory
$actual_location_code = $override_location ? $override_location : $inventory['location_code'];

    // Update location_code in order item if it was missing
    if (empty($location_code)) {
        $location_code = $actual_location_code;
        $update_loc_stmt = $conn->prepare("UPDATE picking_order_items SET location_code = ? WHERE work_id = ? AND item_barcode = ?");
        if ($update_loc_stmt) {
            $update_loc_stmt->bind_param("sss", $location_code, $work_id, $item_barcode);
            $update_loc_stmt->execute();
            $update_loc_stmt->close();
        }
    }

// Check if enough quantity is available
if ($quantity_picked > $available_quantity) {
    echo json_encode([
        'success' => false,
        'message' => "Insufficient quantity. Available: {$available_quantity}, Requested: {$quantity_picked}"
    ]);
    exit;
}

// Validate that quantity_picked doesn't exceed required_quantity
if ($quantity_picked > $required_quantity) {
    echo json_encode([
        'success' => false,
        'message' => "Quantity picked ({$quantity_picked}) exceeds required quantity ({$required_quantity})"
    ]);
    exit;
}

// Start transaction
$conn->begin_transaction();

try {
    // Update picking order item status and plate_id together
    // First, ensure plate_id is set
    if (empty($plate_id)) {
        throw new Exception("Plate ID is required. Please scan the virtual plate barcode first.");
    }
    
    // Update picking order item: set status to 'picked', quantity_picked, plate_id, and picked_at
    $stmt = $conn->prepare("UPDATE picking_order_items SET quantity_picked = ?, status = 'picked', picked_at = NOW(), target_lp = ?, plate_id = ? WHERE work_id = ? AND item_barcode = ? AND status = 'pending'");
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    // Parameters: quantity_picked (i), target_lp (s), plate_id (s), work_id (s), item_barcode (s) = 5 parameters
    $stmt->bind_param("issss", $quantity_picked, $target_lp, $plate_id, $work_id, $item_barcode);
    if (!$stmt->execute()) {
        throw new Exception("Failed to update picking_order_items: " . $stmt->error);
    }
    
    // Check if the update was successful
    if ($stmt->affected_rows === 0) {
        // Item might already be picked, check current status
        $check_stmt = $conn->prepare("SELECT status, plate_id FROM picking_order_items WHERE work_id = ? AND item_barcode = ?");
        $check_stmt->bind_param("ss", $work_id, $item_barcode);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        if ($check_result->num_rows > 0) {
            $check_row = $check_result->fetch_assoc();
            $check_stmt->close();
            if ($check_row['status'] === 'picked') {
                throw new Exception("This item has already been picked!");
            } else {
                throw new Exception("Item not found or cannot be updated. Current status: " . ($check_row['status'] ?? 'unknown'));
            }
        } else {
            $check_stmt->close();
            throw new Exception("Item not found in picking order");
        }
    }
    $stmt->close();
    
    // Update inventory quantity
    $new_quantity = $available_quantity - $quantity_picked;
    $stmt = $conn->prepare("UPDATE inventory SET quantity = ?, last_update = NOW() WHERE item_barcode = ? AND location_code = ?");
    if (!$stmt) {
        throw new Exception("Failed to prepare inventory update statement: " . $conn->error);
    }
    $stmt->bind_param("iss", $new_quantity, $item_barcode, $actual_location_code);
    if (!$stmt->execute()) {
        throw new Exception("Failed to update inventory: " . $stmt->error);
    }
    if ($stmt->affected_rows === 0) {
        throw new Exception("Inventory update failed: No rows affected. Item: {$item_barcode}, Location: {$actual_location_code}");
    }
    $stmt->close();
    
    // Plate_id is already set in the UPDATE statement above
    // Also update all other pending items in this order to use the same plate_id
    $update_all_plate_stmt = $conn->prepare("UPDATE picking_order_items SET plate_id = ? WHERE work_id = ? AND status = 'pending' AND (plate_id IS NULL OR plate_id = '')");
    $update_all_plate_stmt->bind_param("ss", $plate_id, $work_id);
    $update_all_plate_stmt->execute();
    $update_all_plate_stmt->close();
    
    // Insert into picking log with plate_id and picked_by
    $picked_by = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'System';
    $stmt = $conn->prepare("INSERT INTO picking_log (work_id, plate_id, item_barcode, quantity_picked, location_code, target_lp, picked_at, picked_by) VALUES (?, ?, ?, ?, ?, ?, NOW(), ?)");
    if (!$stmt) {
        throw new Exception("Failed to prepare picking_log insert statement: " . $conn->error);
    }
    // 7 parameters: work_id(s), plate_id(s), item_barcode(s), quantity_picked(i), location_code(s), target_lp(s), picked_by(s)
    $stmt->bind_param("sssisss", $work_id, $plate_id, $item_barcode, $quantity_picked, $actual_location_code, $target_lp, $picked_by);
    if (!$stmt->execute()) {
        throw new Exception("Failed to insert into picking_log: " . $stmt->error);
    }
    $stmt->close();
    
    // Update picking_orders status to 'in_progress' if it's still 'pending'
    $update_order_stmt = $conn->prepare("UPDATE picking_orders SET status = 'in_progress' WHERE work_id = ? AND status = 'pending'");
    $update_order_stmt->bind_param("s", $work_id);
    $update_order_stmt->execute();
    $update_order_stmt->close();
    
    // Check if all items are picked and update order status to 'completed'
    $check_complete_stmt = $conn->prepare("SELECT COUNT(*) as remaining FROM picking_order_items WHERE work_id = ? AND status = 'pending'");
    $check_complete_stmt->bind_param("s", $work_id);
    $check_complete_stmt->execute();
    $complete_result = $check_complete_stmt->get_result();
    $complete_row = $complete_result->fetch_assoc();
    if ($complete_row['remaining'] == 0) {
        $update_complete_stmt = $conn->prepare("UPDATE picking_orders SET status = 'completed' WHERE work_id = ?");
        $update_complete_stmt->bind_param("s", $work_id);
        $update_complete_stmt->execute();
        $update_complete_stmt->close();
    }
    $check_complete_stmt->close();
    
    // Check if quantity on bottom shelf (shelf_number = 0) is exhausted or reserved for branches
    // Create lowering order automatically if needed
    $remaining_required = $required_quantity - $quantity_picked;
    $stock_message = '';
    $lowering_order_created = false;
    
    if ($remaining_required > 0) {
        // Check total available quantity on bottom shelf (shelf_number = 0)
        $check_bottom_shelf_stmt = $conn->prepare("
            SELECT COALESCE(SUM(i.quantity), 0) as total_bottom_shelf
            FROM inventory i
            LEFT JOIN locations loc ON i.location_code = loc.location_code
            WHERE i.item_barcode = ? 
                AND i.quantity > 0
                AND loc.shelf_number = 0
        ");
        $check_bottom_shelf_stmt->bind_param("s", $item_barcode);
        $check_bottom_shelf_stmt->execute();
        $bottom_shelf_result = $check_bottom_shelf_stmt->get_result();
        $bottom_shelf_row = $bottom_shelf_result->fetch_assoc();
        $total_bottom_shelf = $bottom_shelf_row['total_bottom_shelf'] ?? 0;
        $check_bottom_shelf_stmt->close();
        
        // Check total reserved quantity for all branches (pending picking orders)
        $check_reserved_stmt = $conn->prepare("
            SELECT COALESCE(SUM(poi.quantity_required - COALESCE(poi.quantity_picked, 0)), 0) as total_reserved
            FROM picking_order_items poi
            INNER JOIN picking_orders po ON poi.work_id = po.work_id
            WHERE poi.item_barcode = ? 
                AND poi.status = 'pending'
                AND po.status IN ('pending', 'in_progress')
        ");
        $check_reserved_stmt->bind_param("s", $item_barcode);
        $check_reserved_stmt->execute();
        $reserved_result = $check_reserved_stmt->get_result();
        $reserved_row = $reserved_result->fetch_assoc();
        $total_reserved = $reserved_row['total_reserved'] ?? 0;
        $check_reserved_stmt->close();
        
        // If bottom shelf quantity is exhausted or all reserved for branches, check high shelves
        if ($total_bottom_shelf < $remaining_required || $total_bottom_shelf <= $total_reserved) {
            $check_high_shelf_stmt = $conn->prepare("
                SELECT i.*, loc.shelf_number, loc.full_location_code, 
                       COALESCE(z.zone_code, i.zone) as zone_code
                FROM inventory i
                LEFT JOIN locations loc ON i.location_code = loc.location_code
                LEFT JOIN zones z ON loc.zone_id = z.id OR (i.zone IS NOT NULL AND z.zone_code = i.zone)
                WHERE i.item_barcode = ? 
                    AND i.quantity > 0
                    AND loc.shelf_number > 2
                ORDER BY loc.shelf_number ASC, i.quantity DESC
                LIMIT 1
            ");
            $check_high_shelf_stmt->bind_param("s", $item_barcode);
            $check_high_shelf_stmt->execute();
            $high_shelf_result = $check_high_shelf_stmt->get_result();
            
            if ($high_shelf_result->num_rows > 0) {
                $high_shelf_item = $high_shelf_result->fetch_assoc();
                $high_shelf_qty = $high_shelf_item['quantity'];
                $high_shelf_location = $high_shelf_item['location_code'];
                $high_shelf_zone = $high_shelf_item['zone_code'] ?? 'A';
                $high_shelf_full = $high_shelf_item['full_location_code'] ?? ($high_shelf_zone . '-' . $high_shelf_location);
                
                // Check if lowering order already exists for this item and location
                $check_existing_stmt = $conn->prepare("
                    SELECT id FROM lowering_orders 
                    WHERE item_barcode = ? 
                        AND from_location_code = ? 
                        AND status IN ('pending', 'in_progress')
                    LIMIT 1
                ");
                $check_existing_stmt->bind_param("ss", $item_barcode, $high_shelf_location);
                $check_existing_stmt->execute();
                $existing_result = $check_existing_stmt->get_result();
                
                if ($existing_result->num_rows === 0) {
                    // Create lowering order automatically (quantity_at_source = all quantity at high shelf)
                    // to_location_code will be NULL - user will choose destination manually
                    $create_lowering_stmt = $conn->prepare("
                        INSERT INTO lowering_orders 
                        (item_barcode, from_location_code, from_zone, from_full_location, 
                         quantity_at_source, priority, created_by)
                        VALUES (?, ?, ?, ?, ?, 1, 'System')
                    ");
                    // Parameters: item_barcode (s), from_location_code (s), from_zone (s), from_full_location (s), quantity_at_source (i) = 5 parameters
                    $create_lowering_stmt->bind_param("ssssi", 
                        $item_barcode, $high_shelf_location, $high_shelf_zone, 
                        $high_shelf_full, $high_shelf_qty
                    );
                    $create_lowering_stmt->execute();
                    $create_lowering_stmt->close();
                    $lowering_order_created = true;
                }
                $check_existing_stmt->close();
                
                // Message: Item needs to be lowered from high shelf
                $stock_message = "⚠️ WARNING: Bottom shelf (shelf 0) quantity exhausted or reserved for branches. Lowering order created. This item needs to be moved from high shelf location: {$high_shelf_full} (Available: {$high_shelf_qty} units) to a bottom shelf location.";
            } else {
                // No quantity on high shelves - stock exhausted
                $stock_message = "⚠️ WARNING: Stock exhausted for this item in the warehouse. No quantity available on bottom shelf or high shelves. Total remaining required: {$remaining_required} units.";
            }
            $check_high_shelf_stmt->close();
        }
    }
    
    // Commit transaction
    $conn->commit();
    
    $response_message = 'Item picked successfully';
    if (!empty($stock_message)) {
        $response_message = $stock_message;
    }
    
    // Clean any output before JSON
    if (ob_get_level() > 0) {
        ob_clean();
    }
    
    echo json_encode([
        'success' => true,
        'message' => $response_message,
        'stock_warning' => !empty($stock_message),
        'lowering_order_created' => $lowering_order_created
    ]);
    
    // Flush output
    if (ob_get_level() > 0) {
        ob_end_flush();
    }
    exit;
    
} catch (Exception $e) {
    // Rollback transaction on error
    if (isset($conn)) {
        try {
            $conn->rollback();
        } catch (Exception $rollback_error) {
            // Ignore rollback errors
        }
    }
    
    // Clean any output before JSON
    if (ob_get_level() > 0) {
        ob_clean();
    }
    
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Error processing item: ' . $e->getMessage()
    ]);
    exit;
} catch (Error $e) {
    // Catch PHP 7+ fatal errors
    if (isset($conn)) {
        try {
            $conn->rollback();
        } catch (Exception $rollback_error) {
            // Ignore rollback errors
        }
    }
    
    // Clean any output before JSON
    if (ob_get_level() > 0) {
        ob_clean();
    }
    
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Fatal error: ' . $e->getMessage()
    ]);
    exit;
}

// This should never be reached if everything works correctly
// But just in case, ensure we have valid JSON output
if (ob_get_level() > 0) {
    $remaining = ob_get_clean();
    if (!empty($remaining)) {
        // If there's remaining output, something went wrong
        error_log("process_picking_item.php: Unexpected output at end: " . $remaining);
    }
}

// Close connections if they exist
if (isset($stmt) && $stmt) {
    @$stmt->close();
}
if (isset($conn) && $conn) {
    @$conn->close();
}
?>
